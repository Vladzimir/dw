<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-atlanta-ath-1200r.php","кухонный комбайн м видео");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-atlanta-ath-1200r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кухонный комбайн м видео Утюг Atlanta ATH-496  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кухонный комбайн м видео, микроволновые печи уфа, где отремонтировать утюг, электрочайник braun, аппараты для педикюра с пылесосом, рецепты для пароварки тефаль, мешки для пылесоса цена, мясорубки белорусские, блюда в хлебопечке, кофеварка via veneto, как разобрать утюг, купить пылесос зелмер, пароварка tefal 7001, индукционная плита с духовкой,  фильтр для пылесоса самсунг">
		<meta name="description" content="кухонный комбайн м видео Утюг Atlanta ATH-496 с пароувлажнителем мощностью 2000 Вт – мощный стильный приб...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/17eda0a4b5c1d490489508803719dcb3.jpeg" title="кухонный комбайн м видео Утюг Atlanta ATH-496"><img src="photos/17eda0a4b5c1d490489508803719dcb3.jpeg" alt="кухонный комбайн м видео Утюг Atlanta ATH-496" title="кухонный комбайн м видео Утюг Atlanta ATH-496 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/filtry-bumazhnye-brigitta-razmer-sht-korichnevye-90r-2.php"><img src="photos/faec7368a9c18bee1d97e75c55772203.jpeg" alt="микроволновые печи уфа Фильтры бумажные Brigitta, размер 4, 80 шт., коричневые" title="микроволновые печи уфа Фильтры бумажные Brigitta, размер 4, 80 шт., коричневые"></a><h2>Фильтры бумажные Brigitta, размер 4, 80 шт., коричневые</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-processor-redmond-rfp-2990r.php"><img src="photos/470cf0a1bfd5b3c4e3890030dcd4cf8d.jpeg" alt="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901" title="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901"></a><h2>Кухонный процессор Redmond  RFP-3901</h2></li>
							<li><a href="http://kitchentech.elitno.net/chopper-vitek-vt-1790r.php"><img src="photos/ab6d4d55ecf241ffc9d0ef81c9ea44bc.jpeg" alt="электрочайник braun Чоппер Vitek VT-1641" title="электрочайник braun Чоппер Vitek VT-1641"></a><h2>Чоппер Vitek VT-1641</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кухонный комбайн м видео Утюг Atlanta ATH-496</h1>
						<div class="tb"><p>Цена: от <span class="price">1200</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19763.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Утюг Atlanta ATH-496 с пароувлажнителем мощностью 2000 Вт – мощный стильный прибор фиолетового цвета для глажки, с подошвой с керамическим напылением. Абсолютно безопасен, т. к. имеет функцию автоматического отключения. Также есть функция самоочистки. Кроме того, он имеет функцию парового удара. Иногда для проглаживания сильно пересушенных или толстых тканей не хватает даже максимальной модности постоянного пара. Специально для таких случаев в этом утюге есть паровой удар. При нажатии на кнопку происходит мощная подача пара, находящегося под высоким давлением. Сильный удар горячего пара размягчает волокна и быстро разглаживает даже глубокие складки. А подача вертикального пара позволяет гладить пиджаки, пальто и другие вещи прямо на вешалке или манекене.</p><p>Характеристики:</p><ul type=disc><li>Высокая мощность <li>Подошва с керамическим напылением <li>Автоматическое отключение <li>Защита от перегрева <li>Самоочистка  <li>Вертикальная подача пара <li>Функция увлажнения <li>Противокапельный механизм <li>Ручка с противоскользящим покрытием <li>Изделие сертифицировано Госстандартом РФ <li>Соответствует европейским нормам безопасности <li>Потребляемая мощность 2000 Вт  <li>230 В, 50 Гц <li>31.8 x 12.4 x 17.8 см </li></ul><p> </p><p><strong>Производитель: США</strong></p> кухонный комбайн м видео</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/4e6a1db3aa397f67ece5fe8079d3244b.jpeg" alt="аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный" title="аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный"><div class="box" page="vspenivatel-melitta-cremio-chernyy-4155r"><span class="title">аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный</span><p>от <span class="price">4155</span> руб.</p></div></li>
						<li><img src="photos/a685203e8ea8fb080bb213d2c8d8a964.jpeg" alt="рецепты для пароварки тефаль Электрическая кофемолка красная Bodum BISTRO 10903-294EURO" title="рецепты для пароварки тефаль Электрическая кофемолка красная Bodum BISTRO 10903-294EURO"><div class="box" page="elektricheskaya-kofemolka-krasnaya-bodum-bistro-euro-5730r"><span class="title">рецепты для пароварки тефаль Электрическая кофемолка красная Bodum BISTRO 10903-294EURO</span><p>от <span class="price">5730</span> руб.</p></div></li>
						<li><img src="photos/ebf4f38956f30ceea82d2b188167ae53.jpeg" alt="мешки для пылесоса цена Электрическая кофемолка Bodum BISTRO 10903-565EURO лимонная" title="мешки для пылесоса цена Электрическая кофемолка Bodum BISTRO 10903-565EURO лимонная"><div class="box" page="elektricheskaya-kofemolka-bodum-bistro-euro-limonnaya-5730r"><span class="title">мешки для пылесоса цена Электрическая кофемолка Bodum BISTRO 10903-565EURO лимонная</span><p>от <span class="price">5730</span> руб.</p></div></li>
						<li><img src="photos/e3db19fdd8b8e08a389b3566088c9ffc.jpeg" alt="мясорубки белорусские Zauber Мельница для специй  S-450" title="мясорубки белорусские Zauber Мельница для специй  S-450"><div class="box" page="zauber-melnica-dlya-speciy-s-1100r"><span class="title">мясорубки белорусские Zauber Мельница для специй  S-450</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li class="large"><img src="photos/b5363272b3a3c59d4980ee7e84a0ecd1.jpeg" alt="блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP" title="блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-cp-1430r"><span class="title">блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP</span><p>от <span class="price">1430</span> руб.</p></div></li>
						<li class="large"><img src="photos/99e95702b63a74224f733264159dce15.jpeg" alt="кофеварка via veneto Тостер Redmond RT-402" title="кофеварка via veneto Тостер Redmond RT-402"><div class="box" page="toster-redmond-rt-2490r"><span class="title">кофеварка via veneto Тостер Redmond RT-402</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li class="large"><img src="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" alt="как разобрать утюг Чайник электрический Maxima MК- M211" title="как разобрать утюг Чайник электрический Maxima MК- M211"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-1090r"><span class="title">как разобрать утюг Чайник электрический Maxima MК- M211</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/67898b31f2a00b51820f96bc789fed43.jpeg" alt="купить пылесос зелмер Чайник электрический Maxima MК- M281" title="купить пылесос зелмер Чайник электрический Maxima MК- M281"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r"><span class="title">купить пылесос зелмер Чайник электрический Maxima MК- M281</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/7c67b6491c0da9489fd3f2ddee3c01b1.jpeg" alt="пароварка tefal 7001 Паровая гладильная система Sofia Lux" title="пароварка tefal 7001 Паровая гладильная система Sofia Lux"><div class="box" page="parovaya-gladilnaya-sistema-sofia-lux-69000r"><span class="title">пароварка tefal 7001 Паровая гладильная система Sofia Lux</span><p>от <span class="price">69000</span> руб.</p></div></li>
						<li><img src="photos/529e8107d5e5b446ac7668ecb3b5cd4b.jpeg" alt="индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке" title="индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке"><div class="box" page="dyson-turbine-head-assy-retail-turboschetka-v-upakovke-3290r"><span class="title">индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li><img src="photos/8201fb734cec793db96d43f2e27a6cc4.jpeg" alt="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail" title="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail"><div class="box" page="nabor-dlya-doma-dyson-home-cleaning-kit-retail-2490r"><span class="title">мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-atlanta-ath-1200r.php", 0, -4); if (file_exists("comments/utyug-atlanta-ath-1200r.php")) require_once "comments/utyug-atlanta-ath-1200r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-atlanta-ath-1200r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>