<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("kuhonnyy-kombayn-vitek-vt-2750r.php","микроволновая печь киев");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("kuhonnyy-kombayn-vitek-vt-2750r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>микроволновая печь киев Кухонный комбайн Vitek VT-1622  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="микроволновая печь киев, язык в аэрогриле, щетка для пылесоса electrolux, как работает кофеварка, рецепт пельменей в хлебопечке, хлебопечка хлеб из гречневой муки, кухня микроволновой печи, щетка для пылесоса electrolux, фильтр для пылесоса thomas twin, купить кофеварку для дома, мультиварка супра инструкция, соковыжималка philips 1866, рецепт печенья в вафельнице, бытовой утюг,  как приготовить хлеб в хлебопечке">
		<meta name="description" content="микроволновая печь киев Многофункциональныйкухонный комбайн Vitek VT-1622из нержавеющей стали станет отл...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d3bcfc3d08cc302406de89eb814d0d80.jpeg" title="микроволновая печь киев Кухонный комбайн Vitek VT-1622"><img src="photos/d3bcfc3d08cc302406de89eb814d0d80.jpeg" alt="микроволновая печь киев Кухонный комбайн Vitek VT-1622" title="микроволновая печь киев Кухонный комбайн Vitek VT-1622 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-solo-pure-white-28530r.php"><img src="photos/eb4618ce7491ec77cbaa3b4b7dd675cb.jpeg" alt="язык в аэрогриле Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)" title="язык в аэрогриле Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)</h2></li>
							<li><a href="http://kitchentech.elitno.net/chasha-dlya-multivarki-redmond-iprmcm-990r.php"><img src="photos/74bbce31ddb28c5063f247363080794a.jpeg" alt="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502" title="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502"></a><h2>Чаша для мультиварки Redmond IPRMC-M4502</h2></li>
							<li><a href="http://kitchentech.elitno.net/keramicheskaya-kastryulya-maruchi-dlya-modeley-rwfz-fz-rbfc-1200r.php"><img src="photos/276b4e96e52e1526338897e899045489.jpeg" alt="как работает кофеварка Керамическая кастрюля Maruchi для моделей RW-FZ46, FZ47, RB-FC46" title="как работает кофеварка Керамическая кастрюля Maruchi для моделей RW-FZ46, FZ47, RB-FC46"></a><h2>Керамическая кастрюля Maruchi для моделей RW-FZ46, FZ47, RB-FC46</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>микроволновая печь киев Кухонный комбайн Vitek VT-1622</h1>
						<div class="tb"><p>Цена: от <span class="price">2750</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8263.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Многофункциональный<b>кухонный комбайн V</b><b>itek VT-1622</b>из нержавеющей стали станет отличным помощником в приготовлении любых блюд. С этим чудо-устройством, вы можете измельчить свежие фрукты и овощи, орехи, травы, морепродукты, мясо и многое другое. Разъемная конструкция модели позволяет мыть ее в посудомоечной машине. Среди достоинств<b>VT-1622</b>также можно отметить удобную эргономичную ручку и LED подсветку во время работы. В комплект входят несколько насадок-измельчителей для разного вида нарезок, шинковки и измельчения.</p><p><b>Особенности:</b></p><ul type=\disc\><li>Удобная эргономичная ручка, LED подсветка во время работы</li><li>Съемная насадка из нержавеющей стали подходит для приготовления холодных и горячих блюд</li><li>Разъемная конструкция пригодна для мытья в посудомоечной машине</li><li>Насадка-измельчитель 500 мл с противоскользящим основанием, 800 мл мерный стакан с крышкой, венчик из нержавеющей стали</li><li>Большой измельчитель 1250 мл, набор насадок для разного вида нарезки и шинковки, включая насадку для драников</li></ul><p><b>Технические характеристики:</b></p><ul type=\disc\><li>Тип: погружной</li><li>Мощность: 800Вт</li><li>Управление: плавная регулировка скорости</li><li>Материал корпуса: пластик</li><li>Материал погружной части: металл</li><li>Отверстие для ингредиентов есть</li><li>Измельчитель: объем 1.25л</li><li>Мерный стакан: объем 0.8л</li><li>Мельничка: объем 0.5л</li><li>Венчик для взбивания: есть</li><li>Размеры в упаковке (длина/ширина/высота): 0,35x0,28x0,265 м</li><li>Вес: 3,6 кг</li></ul><p><b>Производитель:</b>Vitek.</p><p><b>Страна:</b>Россия.</p> микроволновая печь киев</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d325e4ff8de4614af80db126de07173a.jpeg" alt="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8" title="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8"><div class="box"><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-6690r.php"><h3 class="title">рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8</h3><p>от <span class="price">6690</span> руб.</p></a></div></li>
						<li><img src="photos/7ffc20dc8107b2fc1365cfb7486e823a.jpeg" alt="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101" title="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101"><div class="box" page="indukcionnaya-plita-kitfort-kt-2700r"><span class="title">хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101</span><p>от <span class="price">2700</span> руб.</p></div></li>
						<li><img src="photos/d13e770b0f20ea7295762dcccfd88ddd.jpeg" alt="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда" title="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда"><div class="box" page="elektroplitka-indukcionnaya-maxima-mic-posuda-1790r"><span class="title">кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li><img src="photos/d0af4bd740dd75cf948a8f00224c2bee.jpeg" alt="щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White" title="щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White"><div class="box" page="chaynik-elektricheskiy-binatone-cej-white-1080r"><span class="title">щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li class="large"><img src="photos/c737b54864f365f17a12fbd2acc0e1ac.jpeg" alt="фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134" title="фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134"><div class="box" page="chaynik-elektricheskiy-vitek-vt-900r"><span class="title">фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134</span><p>от <span class="price">900</span> руб.</p></div></li>
						<li class="large"><img src="photos/b3ff9d6ec8fde71796646bd977ae1927.jpeg" alt="купить кофеварку для дома Чайник электрический Vitek VT-1147 белый" title="купить кофеварку для дома Чайник электрический Vitek VT-1147 белый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-belyy-1380r"><span class="title">купить кофеварку для дома Чайник электрический Vitek VT-1147 белый</span><p>от <span class="price">1380</span> руб.</p></div></li>
						<li class="large"><img src="photos/5a34cc2772e0feae9df6932b7f043259.jpeg" alt="мультиварка супра инструкция Чайник электрический Atlanta ATH-758" title="мультиварка супра инструкция Чайник электрический Atlanta ATH-758"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-940r"><span class="title">мультиварка супра инструкция Чайник электрический Atlanta ATH-758</span><p>от <span class="price">940</span> руб.</p></div></li>
						<li><img src="photos/ba65472be620113b82aa055e0f7c89a6.jpeg" alt="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный" title="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-krasnyy-1510r"><span class="title">соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный</span><p>от <span class="price">1510</span> руб.</p></div></li>
						<li><img src="photos/75de77ac7d47967464a4abeb2e9a64d1.jpeg" alt="рецепт печенья в вафельнице Чайник Melitta Look Aqua (Basic)" title="рецепт печенья в вафельнице Чайник Melitta Look Aqua (Basic)"><div class="box" page="chaynik-melitta-look-aqua-basic-2190r"><span class="title">рецепт печенья в вафельнице Чайник Melitta Look Aqua (Basic)</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/100a2bcb8188ff9463a9e3368c849858.jpeg" alt="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit" title="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit"><div class="box" page="nabor-dlya-uborki-v-avtomobile-dyson-car-cleaning-kit-2790r"><span class="title">бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit</span><p>от <span class="price">2790</span> руб.</p></div></li>
						<li><img src="photos/00492fb3046ec485746c0b2d1a1385eb.jpeg" alt="микроволновая печь электросхема Пылесос Thomas Inox 1545 S" title="микроволновая печь электросхема Пылесос Thomas Inox 1545 S"><div class="box" page="pylesos-thomas-inox-s-10410r"><span class="title">микроволновая печь электросхема Пылесос Thomas Inox 1545 S</span><p>от <span class="price">10410</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("kuhonnyy-kombayn-vitek-vt-2750r.php", 0, -4); if (file_exists("comments/kuhonnyy-kombayn-vitek-vt-2750r.php")) require_once "comments/kuhonnyy-kombayn-vitek-vt-2750r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="kuhonnyy-kombayn-vitek-vt-2750r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>