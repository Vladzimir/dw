<div class="header-wrap">
				<div class="header">
					<a href="index.php"><img src="images/header-logo.png" alt="logo"></a>
					<ul class="nav">
						<li><a href="index.php">Главная</a></li>
						<li><a href="contact.php">Контакты</a></li>
						<li><a href="about.php">О нас</a></li>
					</ul>
				</div>
			</div>