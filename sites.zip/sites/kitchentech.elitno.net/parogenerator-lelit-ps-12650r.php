<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("parogenerator-lelit-ps-12650r.php","haier микроволновая печь");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("parogenerator-lelit-ps-12650r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>haier микроволновая печь Парогенератор Lelit PS20  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="haier микроволновая печь, вреден ли аэрогриль, пылесос для ковролина, zelmer мясорубка отзывы, фильтр для пылесоса томас, купить кофеварку для дома, пылесос mediclean, мультиварка панасоник sr tmh18, сколько стоит пылесос, тостер philips hd 2586, что можно сделать из пылесоса, блендер philips hr 2860, кофеварка дольче густо отзывы, мультиварка телефункен,  кофемашины verobar">
		<meta name="description" content="haier микроволновая печь Парогенератор от Lelit с бойлером из нержавеющей стали INOX 18/10 может использо...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/14e5114315c1928323477764da917a61.jpeg" title="haier микроволновая печь Парогенератор Lelit PS20"><img src="photos/14e5114315c1928323477764da917a61.jpeg" alt="haier микроволновая печь Парогенератор Lelit PS20" title="haier микроволновая печь Парогенератор Lelit PS20 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-cc-5730r.php"><img src="photos/a05d83b290d1a3a85756bd16066563b1.jpeg" alt="вреден ли аэрогриль Блендер Braun MR-740 CC" title="вреден ли аэрогриль Блендер Braun MR-740 CC"></a><h2>Блендер Braun MR-740 CC</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-atlanta-atn-990r.php"><img src="photos/096e72471ef2ac122b04cd03d0d34b33.jpeg" alt="пылесос для ковролина Блендер Atlanta АТН-343" title="пылесос для ковролина Блендер Atlanta АТН-343"></a><h2>Блендер Atlanta АТН-343</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-russell-hobbs-allure-art-5490r.php"><img src="photos/ac0d13475c79f9c87e6f514f3140de60.jpeg" alt="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56" title="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56"></a><h2>Блендер Russell Hobbs Allure, арт. 18276-56</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>haier микроволновая печь Парогенератор Lelit PS20</h1>
						<div class="tb"><p>Цена: от <span class="price">12650</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16428.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Парогенератор от Lelit с бойлером из нержавеющей стали INOX 18/10 может использоваться как дома, так и в профессиональной сфере. Модель <b>PS20</b> работает на обычной водопроводной воде, внутри алюминиевой подошвы утюга плотно запаяны 32 паровые камеры.</p><p>Среди достоинств этого бытового прибора можно отметить: пробковое антискользящее покрытие рукоятки, а также уникальный нагревательный элемент утюга, который полностью запаян в подошву. При необходимости кнопку подачи пара можно настроить под левшей. </p><p><b>Технические характеристики:</b></p><ul type=disc><li>Напряжение: 220/230 В <li>Мощность: Утюг-800 кВт/ Бойлер-1000 кВт <li>Номинальный объем бойлера: 1,4 л <li>Фактический объем бойлера: 1 л <li>Время непрерывной работы: 1 час <li>Рабочее давление пара: 2,5 бар <li>Максимальное давление пара: 5,5 бар <li>Стандартная комплектация: Воронка для залива воды. Силиконовый коврик-подставка Утюг FS454-вес 1,8 к. <li>Дополнительная комплектация: Тефлоновая подошва LELIT PA 205/1. Силиконовый коврик под утюг LELIT CD363. Подставка под парогенератор LELIT PA032. Коврик для очистки утюга Puliferro. <li>Технические особенности: корпус и бойлер из нержавеющей стали INOX 18/10; Нагревательный элемент выполнен из меди; Внутренний электроклапан <li>Размер: 27х31х35 см <li>Вес: 6,8 кг</li></ul><p><b>Производитель:</b> Lelit.</p><p><b>Страна:</b> Италия.</p><p><b>Гарантия:</b> 1 год.</p> haier микроволновая печь</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/6e1b19f4e2e44aaedf95ea7e61a0919a.jpeg" alt="фильтр для пылесоса томас Хлебопечка-мультиповар Binatone BM-2170 Cream" title="фильтр для пылесоса томас Хлебопечка-мультиповар Binatone BM-2170 Cream"><div class="box"><a href="http://kitchentech.elitno.net/hlebopechkamultipovar-binatone-bm-cream-6900r.php"><h3 class="title">фильтр для пылесоса томас Хлебопечка-мультиповар Binatone BM-2170 Cream</h3><p>от <span class="price">6900</span> руб.</p></a></div></li>
						<li><img src="photos/b3ff9d6ec8fde71796646bd977ae1927.jpeg" alt="купить кофеварку для дома Чайник электрический Vitek VT-1147 белый" title="купить кофеварку для дома Чайник электрический Vitek VT-1147 белый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-belyy-1380r"><span class="title">купить кофеварку для дома Чайник электрический Vitek VT-1147 белый</span><p>от <span class="price">1380</span> руб.</p></div></li>
						<li><img src="photos/4f7eae7926bb1b2816625b5940a25b78.jpeg" alt="пылесос mediclean Чайник электрический Vitek VT-1157" title="пылесос mediclean Чайник электрический Vitek VT-1157"><div class="box" page="chaynik-elektricheskiy-vitek-vt-2150r"><span class="title">пылесос mediclean Чайник электрический Vitek VT-1157</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/463a93164abee7f214102b8fe77a244c.jpeg" alt="сколько стоит пылесос Чайник электрический Atlanta ATH-690" title="сколько стоит пылесос Чайник электрический Atlanta ATH-690"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1280r"><span class="title">сколько стоит пылесос Чайник электрический Atlanta ATH-690</span><p>от <span class="price">1280</span> руб.</p></div></li>
						<li class="large"><img src="photos/90ff0542b35952759822563a08374b1f.jpeg" alt="тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)" title="тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-v-cvete-990r"><span class="title">тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/537c78beb6320fe2c86004c22681bdc6.jpeg" alt="что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)" title="что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-l-760r"><span class="title">что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/16e3783a13e306fc3fd90925cbbcc384.jpeg" alt="блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO" title="блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO"><div class="box" page="elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r"><span class="title">блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/d360b8a0c7da5c2048584c84686650a7.jpeg" alt="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)" title="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-55r"><span class="title">кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)</span><p>от <span class="price">55</span> руб.</p></div></li>
						<li><img src="photos/2e3efb1596b4e1a5bf1803f0fd03710f.jpeg" alt="мультиварка телефункен Пылесос Thomas Inox 30 Professional" title="мультиварка телефункен Пылесос Thomas Inox 30 Professional"><div class="box" page="pylesos-thomas-inox-professional-7740r"><span class="title">мультиварка телефункен Пылесос Thomas Inox 30 Professional</span><p>от <span class="price">7740</span> руб.</p></div></li>
						<li><img src="photos/374cd707bc1b2fbce7e837896df1e0c0.jpeg" alt="курица в микроволновой печи Утюг паровой Tefal Supergliss FV3310EO" title="курица в микроволновой печи Утюг паровой Tefal Supergliss FV3310EO"><div class="box" page="utyug-parovoy-tefal-supergliss-fveo-1600r"><span class="title">курица в микроволновой печи Утюг паровой Tefal Supergliss FV3310EO</span><p>от <span class="price">1600</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("parogenerator-lelit-ps-12650r.php", 0, -4); if (file_exists("comments/parogenerator-lelit-ps-12650r.php")) require_once "comments/parogenerator-lelit-ps-12650r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="parogenerator-lelit-ps-12650r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>