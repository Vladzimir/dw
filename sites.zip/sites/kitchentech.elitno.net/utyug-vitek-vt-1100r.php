<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-vitek-vt-1100r.php","кофемашина электролюкс");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-vitek-vt-1100r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофемашина электролюкс Утюг Vitek VT-1209  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофемашина электролюкс, фильтр для кофемашины, вафельница киев, как правильно выбрать пароварку, как выбрать утюг отзывы, дозиметр радиометр мкс, измельчитель сучьев, описание пылесоса, clatronic хлебопечка, panasonic мясорубка отзывы, kenwood пароварка, мастурбирует пылесосом, хлебопечка кефир, мясорубка kenwood mg510,  мультиварка кенвуд">
		<meta name="description" content="кофемашина электролюкс Оригинальный дизайн и технологичность утюга Vitek VT-1209 с автоматическим отклю...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/b81f4815d2a9df868070af2d7b1533ee.jpeg" title="кофемашина электролюкс Утюг Vitek VT-1209"><img src="photos/b81f4815d2a9df868070af2d7b1533ee.jpeg" alt="кофемашина электролюкс Утюг Vitek VT-1209" title="кофемашина электролюкс Утюг Vitek VT-1209 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/bio-ochistitel-ot-nakipi-swirl-hg-90r.php"><img src="photos/08ef4a223c3f3825df8de9b118c05908.jpeg" alt="фильтр для кофемашины Био - очиститель от накипи Swirl, 2х20г" title="фильтр для кофемашины Био - очиститель от накипи Swirl, 2х20г"></a><h2>Био - очиститель от накипи Swirl, 2х20г</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-63790r.php"><img src="photos/7bf6714fb23984d0a15fec9274d53078.jpeg" alt="вафельница киев Кофемашина Nivona NICR830 CafeRomatica" title="вафельница киев Кофемашина Nivona NICR830 CafeRomatica"></a><h2>Кофемашина Nivona NICR830 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-atlanta-atn-1050r.php"><img src="photos/966c1a147ae7eedce6463b74d364fbff.jpeg" alt="как правильно выбрать пароварку Пароварка Atlanta АТН-602" title="как правильно выбрать пароварку Пароварка Atlanta АТН-602"></a><h2>Пароварка Atlanta АТН-602</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофемашина электролюкс Утюг Vitek VT-1209</h1>
						<div class="tb"><p>Цена: от <span class="price">1100</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8314.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Оригинальный дизайн и технологичность <b>утюга V</b><b>itek</b><b> </b><b>VT</b><b>-1209 </b>с автоматическим отключением делают его незаменимым помощником в любом доме. С ним обычная процедура глаженья белья станет приятным и легким занятием. В модели предусмотрено вертикальное отпаривание белья с паровым ударом 100 г/мин, таким образом, вы за считанные секунды разгладите даже самые капризные ткани. Продуманная функция самоочистки сделает уход за устройством<b> </b>весьма комфортным и удобным. На подошве имеется антипригарное покрытие UltraCare.</p><p><b>Особенности:</b></p><p><b></b></p><ul><li>Подошва UltraCare – уникальное антипригарное покрытие, обеспечивающее максимальную защиту ткани в процессе глажки <li>Плавная регулировка температурных режимов <li>Сухая глажка</li></ul><p><b></b></p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Паровой удар 100 г/мин <li>Резервуар для воды емкостью 2800 мл <li>Вертикальное отпаривание: есть <li>Постоянная передача пара: различные паровые режимы <li>Разбрызгивание: есть <li>Антикапельный клапан: есть <li>Система самоочистки: есть <li>Защита от накипи: есть <li>Автоматическое отключение: есть <li>Мощность: 2000Вт ( макс) <li>Электропитание: 220-240В, ~50 Гц</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> кофемашина электролюкс</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7d63a182df07dd9be547ac2724aeed46.jpeg" alt="как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO" title="как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO"><div class="box" page="elektricheskaya-sokovyzhimalka-krasnaya-bodum-bistro-euro-3340r"><span class="title">как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li><img src="photos/1b0e436d58cc28ccde91c28c400f8600.jpeg" alt="дозиметр радиометр мкс Хлебопечка Binatone BM-1008 White" title="дозиметр радиометр мкс Хлебопечка Binatone BM-1008 White"><div class="box" page="hlebopechka-binatone-bm-white-2000r"><span class="title">дозиметр радиометр мкс Хлебопечка Binatone BM-1008 White</span><p>от <span class="price">2000</span> руб.</p></div></li>
						<li><img src="photos/7b0ef0b12e5f66ec7582c9396725bc92.jpeg" alt="измельчитель сучьев Чайник электрический Vitek VT-1120" title="измельчитель сучьев Чайник электрический Vitek VT-1120"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1150r"><span class="title">измельчитель сучьев Чайник электрический Vitek VT-1120</span><p>от <span class="price">1150</span> руб.</p></div></li>
						<li><img src="photos/cfef38cef319ef880fc0959319ecdb34.jpeg" alt="описание пылесоса Чайник электрический Vitek VT-1154" title="описание пылесоса Чайник электрический Vitek VT-1154"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1010r"><span class="title">описание пылесоса Чайник электрический Vitek VT-1154</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/1bbdc32e5167c3f95a77515679aaf9df.jpeg" alt="clatronic хлебопечка Электрический чайник Atlanta АТН-700" title="clatronic хлебопечка Электрический чайник Atlanta АТН-700"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1280r"><span class="title">clatronic хлебопечка Электрический чайник Atlanta АТН-700</span><p>от <span class="price">1280</span> руб.</p></div></li>
						<li class="large"><img src="photos/0f99b07bf5e19dab36f8028f75c48889.jpeg" alt="panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735" title="panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-450r"><span class="title">panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735</span><p>от <span class="price">450</span> руб.</p></div></li>
						<li class="large"><img src="photos/97ad6f71f59b7db73d8fda12c75e94a2.jpeg" alt="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2" title="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-680r"><span class="title">kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2</span><p>от <span class="price">680</span> руб.</p></div></li>
						<li><img src="photos/c16b11d86e06570e114bf85b9cd3a864.jpeg" alt="мастурбирует пылесосом Отпариватель одежды ROVUS Garment Steamer" title="мастурбирует пылесосом Отпариватель одежды ROVUS Garment Steamer"><div class="box" page="otparivatel-odezhdy-rovus-garment-steamer-3500r"><span class="title">мастурбирует пылесосом Отпариватель одежды ROVUS Garment Steamer</span><p>от <span class="price">3500</span> руб.</p></div></li>
						<li><img src="photos/54b10604c01ad075cc189094150a1393.jpeg" alt="хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP" title="хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP"><div class="box" page="schetka-s-myagkoy-schetinoy-v-upakovke-dyson-soft-dusting-brush-assy-retail-np-1390r"><span class="title">хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP</span><p>от <span class="price">1390</span> руб.</p></div></li>
						<li><img src="photos/ebd6fc853a788b316468033f41ae3864.jpeg" alt="мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22" title="мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22"><div class="box" page="pylesos-dyson-motorhead-dc-34990r"><span class="title">мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22</span><p>от <span class="price">34990</span> руб.</p></div></li>
						<li><img src="photos/709ff92fce8d072f9f56d948427a4843.jpeg" alt="скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter" title="скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter"><div class="box" page="pylesos-thomas-genius-s-aquafilter-10000r"><span class="title">скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter</span><p>от <span class="price">10000</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-vitek-vt-1100r.php", 0, -4); if (file_exists("comments/utyug-vitek-vt-1100r.php")) require_once "comments/utyug-vitek-vt-1100r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-vitek-vt-1100r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>