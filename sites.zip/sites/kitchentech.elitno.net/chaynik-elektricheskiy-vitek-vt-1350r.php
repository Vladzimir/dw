<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-1350r.php","купить вертикальный утюг");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-1350r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>купить вертикальный утюг Чайник электрический Vitek VT-1104  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="купить вертикальный утюг, соковыжималка для моркови, аэрогриль ves инструкция, приготовление теста в хлебопечке, выбор микроволновой печи, купить утюг для волос, стоимость соковыжималки, кухонный комбайн tefal, пылесос прессующий, пельменное тесто в хлебопечке, курица в микроволновой печи, сладкая выпечка в хлебопечке, бетоносмеситель миксер, микроволновая печь bork,  мясорубка 6061">
		<meta name="description" content="купить вертикальный утюг Стильный электрический чайник Vitek VT-1104 в качественном пластиковом корпусе и...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3eefca7b285e5c7425033f0997c9145b.jpeg" title="купить вертикальный утюг Чайник электрический Vitek VT-1104"><img src="photos/3eefca7b285e5c7425033f0997c9145b.jpeg" alt="купить вертикальный утюг Чайник электрический Vitek VT-1104" title="купить вертикальный утюг Чайник электрический Vitek VT-1104 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-680r.php"><img src="photos/6e844ec2051132de84c89f71f9ba6d6a.jpeg" alt="соковыжималка для моркови Кухонный комбайн ATH-360" title="соковыжималка для моркови Кухонный комбайн ATH-360"></a><h2>Кухонный комбайн ATH-360</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-silverblack-35700r.php"><img src="photos/231121339f30404c6721c124df53c4d7.jpeg" alt="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)" title="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-ci-chernaya-65999r.php"><img src="photos/46d0cfd29014c8ec4bfb9c09c292bb23.jpeg" alt="приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная" title="приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная"></a><h2>Автоматическая кофемашина Melitta CAFFEO CI, черная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>купить вертикальный утюг Чайник электрический Vitek VT-1104</h1>
						<div class="tb"><p>Цена: от <span class="price">1350</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8385.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Стильный <b>электрический чайник V</b><b>itek</b><b> VT-1104 </b>в качественном пластиковом корпусе имеет внутреннюю подсветку резервуара для воды. Тип нагревательного элемента - закрытая спираль, находящаяся в дисковой подставке, спроектированной таким образом, что устройство может поворачиваться на ней на 360°. Также среди достоинств модели можно отметить: съемный фильтр от накипи, автоотключение при закипании и защиту от перегрева.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 1850-2200Вт <li>Нагревательный элемент: скрытый <li>Поворачивающийся корпус: 360° <li>Объем: 1,8л <li>Материал корпуса: пластик <li>Фильтр: съемный фильтр от накипи <li>Двухсторонняя шкала уровня воды <li>Автоотключение при закипании воды: есть <li>Защита от перегрева: есть <li>Световой индикатор работы: есть <li>Внутренняя подсветка резервуара для воды <li>Место для хранения шнура: есть</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> купить вертикальный утюг</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/0b57a5fa2564b3001e847ebdd45ce976.jpeg" alt="выбор микроволновой печи Вспениватель Melitta Cremio красный" title="выбор микроволновой печи Вспениватель Melitta Cremio красный"><div class="box"><a href="http://kitchentech.elitno.net/vspenivatel-melitta-cremio-krasnyy-4155r.php"><h3 class="title">выбор микроволновой печи Вспениватель Melitta Cremio красный</h3><p>от <span class="price">4155</span> руб.</p></a></div></li>
						<li><img src="photos/3bdb5a7ebf59a397ed1b6263ffa77483.jpeg" alt="купить утюг для волос Кофемолка Vitesse VS-271" title="купить утюг для волос Кофемолка Vitesse VS-271"><div class="box" page="kofemolka-vitesse-vs-1100r"><span class="title">купить утюг для волос Кофемолка Vitesse VS-271</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/ccf51377f0419f271513b485782fac2b.jpeg" alt="стоимость соковыжималки Кофемолка Maxima MCG-1602" title="стоимость соковыжималки Кофемолка Maxima MCG-1602"><div class="box" page="kofemolka-maxima-mcg-550r"><span class="title">стоимость соковыжималки Кофемолка Maxima MCG-1602</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li><img src="photos/33b43228a18b1110c1c8a14516611c99.jpeg" alt="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE" title="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE"><div class="box" page="kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r"><span class="title">кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE</span><p>от <span class="price">3570</span> руб.</p></div></li>
						<li class="large"><img src="photos/3ee610b7cf277344aaeccda38d02c2fc.jpeg" alt="пылесос прессующий Кухонный комбайн Maxima MFP-0139" title="пылесос прессующий Кухонный комбайн Maxima MFP-0139"><div class="box" page="kuhonnyy-kombayn-maxima-mfp-2190r"><span class="title">пылесос прессующий Кухонный комбайн Maxima MFP-0139</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li class="large"><img src="photos/83b963fc4661f051cc9c631952fa196f.jpeg" alt="пельменное тесто в хлебопечке Мясорубка Maxima MMG-0212" title="пельменное тесто в хлебопечке Мясорубка Maxima MMG-0212"><div class="box" page="myasorubka-maxima-mmg-2690r"><span class="title">пельменное тесто в хлебопечке Мясорубка Maxima MMG-0212</span><p>от <span class="price">2690</span> руб.</p></div></li>
						<li class="large"><img src="photos/79f71cb685066d8f2b6475b4d2f70156.jpeg" alt="курица в микроволновой печи Чайник электрический Atlanta ATH-757" title="курица в микроволновой печи Чайник электрический Atlanta ATH-757"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r"><span class="title">курица в микроволновой печи Чайник электрический Atlanta ATH-757</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/70eaaca49bbd014982b9856679d5c7e6.jpeg" alt="сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO" title="сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO"><div class="box" page="elektricheskiy-chaynik-l-bodum-bistro-euro-2740r"><span class="title">сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/569a7a448800e6c331839b4f1803d826.jpeg" alt="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502" title="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502"><div class="box" page="moyuschiy-koncentrat-thomas-protex-l-520r"><span class="title">бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" alt="микроволновая печь bork Пылесос моющий Thomas Hygiene T2" title="микроволновая печь bork Пылесос моющий Thomas Hygiene T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-t-15900r"><span class="title">микроволновая печь bork Пылесос моющий Thomas Hygiene T2</span><p>от <span class="price">15900</span> руб.</p></div></li>
						<li><img src="photos/e0fdfa431cfe6b47b04ad11ff4f6a218.jpeg" alt="бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805" title="бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805"><div class="box" page="pylesos-vitek-vt-1870r"><span class="title">бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805</span><p>от <span class="price">1870</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-1350r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-1350r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-1350r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-1350r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>