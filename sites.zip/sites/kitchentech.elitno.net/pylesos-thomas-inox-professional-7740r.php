<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-thomas-inox-professional-7740r.php","вафельница clatronic 3170");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-thomas-inox-professional-7740r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>вафельница clatronic 3170 Пылесос Thomas Inox 30 Professional  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="вафельница clatronic 3170, продам мультиварку, фиксики смотреть пылесос, грибы в мультиварке, чайник электрический bork, тостер philips hd 2586, слоеное тесто в аэрогриле, бытовые микроволновые печи, кофеварки домашние, какая мощность у пылесоса, пылесос ролсен, кофемашина saeco xsmall, аэрогриль lentel d101b, кофемашина philips hd 8745,  кофемашины verobar">
		<meta name="description" content="вафельница clatronic 3170 Пылесос Inox 30 Professional от известного немецкого бренда Thomas поможет Вам б...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/2e3efb1596b4e1a5bf1803f0fd03710f.jpeg" title="вафельница clatronic 3170 Пылесос Thomas Inox 30 Professional"><img src="photos/2e3efb1596b4e1a5bf1803f0fd03710f.jpeg" alt="вафельница clatronic 3170 Пылесос Thomas Inox 30 Professional" title="вафельница clatronic 3170 Пылесос Thomas Inox 30 Professional -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-530r.php"><img src="photos/35ee696c1c92edfebad75db4602c2861.jpeg" alt="продам мультиварку Миксер Atlanta ATH-283" title="продам мультиварку Миксер Atlanta ATH-283"></a><h2>Миксер Atlanta ATH-283</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-vitesse-vs-1290r.php"><img src="photos/acf412ca70279cda1dfad07d522f7e3c.jpeg" alt="фиксики смотреть пылесос Пароварка Vitesse VS-507" title="фиксики смотреть пылесос Пароварка Vitesse VS-507"></a><h2>Пароварка Vitesse VS-507</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektroplitka-indukcionnaya-maxima-mic-1590r.php"><img src="photos/07f90c95ce6a7ffe3129c0eb4bb8942c.jpeg" alt="грибы в мультиварке Электроплитка индукционная Maxima MIC-0146" title="грибы в мультиварке Электроплитка индукционная Maxima MIC-0146"></a><h2>Электроплитка индукционная Maxima MIC-0146</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>вафельница clatronic 3170 Пылесос Thomas Inox 30 Professional</h1>
						<div class="tb"><p>Цена: от <span class="price">7740</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14846.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Пылесос Inox 30 Professional от известного немецкого бренда Thomas поможет Вам быстро и без особых усилий справиться даже с самой глубоко въевшейся грязью. Прибор отличается надежностью и практичностью, поэтому прослужит своим обладателям долгое время. </p><p>Модель выполнена в компактном эргономичном дизайне, имеет небольшой вес, брызгозащищенный корпус, ходовую часть с пятью двойными направляющими роликами и противоударным кольцом. Кроме того, у пылесоса отличная маневренность и удобная ручка, что позволит Вам совершать уборку с максимальным комфортом. Мощность устройства составляет 1600 Вт. </p><p><b>Характеристики:</b></p><ul type=disc><li>Максимальная мощность 1600 Вт; <li>Двухступенчатая турбина большой мощности; <li>Электронный плавный разгон; <li>Компактный резервуар из высококачественной нержавеющей стали объемом 30 л; <li>Корпус двигателя из высокопрочной пластмассы; <li>Независимое байпасное охлаждение двигателя; <li>Брызгозащищенный корпус; <li>Ходовая часть с 5 двойными направляющими роликами и противоударным кольцом; <li>Удобная ручка; <li>Пластмассовые и металлические всасывающие трубы; <li>Стандартная система O 32 мм и профессиональная система O 50 мм; <li>Размеры (ВхШхГ): 49x37x37 см.</li></ul><p><b>Насадки:</b></p><ul type=disc><li>Ручка для шланга d 32 мм; <li>Ручка для шланга d 50 мм; <li>Насадка для сухой уборки ковров; <li>Универсальная насадка; <li>Щелевая насадка d 32 мм; <li>Фильтр-патрон с поверхностью 2500 см2; <li>Щелевая насадка d 50 мм; <li>Насадка для уборки крупного мусора; <li>Фильтр-патрон с поверхностью 2500 см2; <li>Бумажный фильтр-мешок.</li></ul><p><b>Дополнительно приобретается:</b></p><ul type=disc><li>Насадка для уборки паркета; <li>Турбощетка TSB 100; <li>Турбощетка с аккумулятором TSB 200; <li>Комплект для печей и каминов O 32 мм; <li>Специальный мелкодисперсный фильтр 195163; <li>Фильтр для уборки сажи.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> вафельница clatronic 3170</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/cba9fd30236faeadb264f6621c9544f6.jpeg" alt="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер" title="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер"><div class="box" page="sokovyzhimalka-maxima-mj-blender-2190r"><span class="title">чайник электрический bork Соковыжималка Maxima MJ-049 + блендер</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/90ff0542b35952759822563a08374b1f.jpeg" alt="тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)" title="тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-v-cvete-990r"><span class="title">тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/b28d3e929be020189d8c25424817be16.jpeg" alt="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO" title="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2270r"><span class="title">слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li><img src="photos/4fcdbef1e4068bc4641fdad47e086ca6.jpeg" alt="бытовые микроволновые печи Парогенератор Maxima MSC-2001" title="бытовые микроволновые печи Парогенератор Maxima MSC-2001"><div class="box" page="parogenerator-maxima-msc-1650r"><span class="title">бытовые микроволновые печи Парогенератор Maxima MSC-2001</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/f08bd4abc7ad4c0cc84da510e6f6c4d3.jpeg" alt="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт." title="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт."><div class="box" page="filtr-dlya-pylesosa-vitek-vt-vt-sht-215r"><span class="title">кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт.</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li class="large"><img src="photos/eb7760a68b0b3e85f39c2160100a5731.jpeg" alt="какая мощность у пылесоса Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008" title="какая мощность у пылесоса Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008"><div class="box" page="moyuschiy-koncentrat-thomas-profloor-l-sht-700r"><span class="title">какая мощность у пылесоса Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008</span><p>от <span class="price">700</span> руб.</p></div></li>
						<li class="large"><img src="photos/b423fb6caec639a7de8db20512fac098.jpeg" alt="пылесос ролсен Бумажные фильтры-мешки 200 (787-100) для Thomas" title="пылесос ролсен Бумажные фильтры-мешки 200 (787-100) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r"><span class="title">пылесос ролсен Бумажные фильтры-мешки 200 (787-100) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/20a6a481b9a3a072fa1293146dcb1ec9.jpeg" alt="кофемашина saeco xsmall Пылесос моющий Thomas Super 30 S Aquafilter" title="кофемашина saeco xsmall Пылесос моющий Thomas Super 30 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-super-s-aquafilter-10520r"><span class="title">кофемашина saeco xsmall Пылесос моющий Thomas Super 30 S Aquafilter</span><p>от <span class="price">10520</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
						<li><img src="photos/daa26c20552b4c54039ad44aa7ab957b.jpeg" alt="кофемашина philips hd 8745 Пылесос Thomas Inox 1530" title="кофемашина philips hd 8745 Пылесос Thomas Inox 1530"><div class="box" page="pylesos-thomas-inox-6310r"><span class="title">кофемашина philips hd 8745 Пылесос Thomas Inox 1530</span><p>от <span class="price">6310</span> руб.</p></div></li>
						<li><img src="photos/b81f4815d2a9df868070af2d7b1533ee.jpeg" alt="парогенератор aeg Утюг Vitek VT-1209" title="парогенератор aeg Утюг Vitek VT-1209"><div class="box" page="utyug-vitek-vt-1100r"><span class="title">парогенератор aeg Утюг Vitek VT-1209</span><p>от <span class="price">1100</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-thomas-inox-professional-7740r.php", 0, -4); if (file_exists("comments/pylesos-thomas-inox-professional-7740r.php")) require_once "comments/pylesos-thomas-inox-professional-7740r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-thomas-inox-professional-7740r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>