<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("avtoshampun-karcher-rm-l-ru-1000r.php","миксер kenwood mx");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("avtoshampun-karcher-rm-l-ru-1000r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>миксер kenwood mx Автошампунь Karcher RM 806 (5 л) RU  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="миксер kenwood mx, микроволновые печи уфа, термопот rolsen, конвейер мясорубки сканворд, аэрогриль ves инструкция, тесто для мантов в хлебопечке, пароварка магазин, аэрогриль hotter economy, мультиварка панасоник sr tmh18, книга рецептов для хлебопечки, daewoo микроволновая печь инструкция, сколько стоит фритюрница, бетоносмеситель миксер, семга в мультиварке,  пылесос triathlon">
		<meta name="description" content="миксер kenwood mx Приобретайте высококачественное моющее средство для бесконтактной мойки автомоби...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/35040f2562bad52e53caa0b063a02983.jpeg" title="миксер kenwood mx Автошампунь Karcher RM 806 (5 л) RU"><img src="photos/35040f2562bad52e53caa0b063a02983.jpeg" alt="миксер kenwood mx Автошампунь Karcher RM 806 (5 л) RU" title="миксер kenwood mx Автошампунь Karcher RM 806 (5 л) RU -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/filtry-bumazhnye-brigitta-razmer-sht-korichnevye-90r-2.php"><img src="photos/faec7368a9c18bee1d97e75c55772203.jpeg" alt="микроволновые печи уфа Фильтры бумажные Brigitta, размер 4, 80 шт., коричневые" title="микроволновые печи уфа Фильтры бумажные Brigitta, размер 4, 80 шт., коричневые"></a><h2>Фильтры бумажные Brigitta, размер 4, 80 шт., коричневые</h2></li>
							<li><a href="http://kitchentech.elitno.net/bioochistitel-ot-nakipi-swirl-zhidkiy-ml-185r.php"><img src="photos/314533fc5d95948fd5a6724fd21e3005.jpeg" alt="термопот rolsen Био-очиститель от накипи Swirl (жидкий), 250 мл" title="термопот rolsen Био-очиститель от накипи Swirl (жидкий), 250 мл"></a><h2>Био-очиститель от накипи Swirl (жидкий), 250 мл</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-multiquick-3360r.php"><img src="photos/94a68ac1086ff8fbedebcd6e22667c94.jpeg" alt="конвейер мясорубки сканворд Блендер Braun MR-7 730 Multiquick" title="конвейер мясорубки сканворд Блендер Braun MR-7 730 Multiquick"></a><h2>Блендер Braun MR-7 730 Multiquick</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>миксер kenwood mx Автошампунь Karcher RM 806 (5 л) RU</h1>
						<div class="tb"><p>Цена: от <span class="price">1000</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_4228.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Приобретайте высококачественное моющее средство для бесконтактной мойки автомобилей на моечных установках с самообслуживанием. Также шампунь хорош для очистки цистерн аппаратами высокого давления. </p><p>Моющее средство Karcher RM 806 предназначено для удаления дорожной пыли, копоти, глины, жира, масла, следов насекомых, антигололедных реагентов, следов насекомых и прочих загрязнений.</p><p><strong>Характеристики:</strong></p><p>Объем: 5 литров<br>Высокая моющая способность<br>Интенсивное пенообразование<br><br><strong>Производитель:</strong> Karcher (Германия)</p> миксер kenwood mx</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/231121339f30404c6721c124df53c4d7.jpeg" alt="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)" title="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)"><div class="box"><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-silverblack-35700r.php"><h3 class="title">аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)</h3><p>от <span class="price">35700</span> руб.</p></a></div></li>
						<li><img src="photos/26f6130b768cf990fa9fa11bd1f16cb3.jpeg" alt="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая" title="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-serebristaya-26999r"><span class="title">тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая</span><p>от <span class="price">26999</span> руб.</p></div></li>
						<li><img src="photos/5b2c06d57a572404f45fc75e65b42e87.jpeg" alt="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая" title="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-lattea-beloserebristaya-29530r"><span class="title">пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая</span><p>от <span class="price">29530</span> руб.</p></div></li>
						<li><img src="photos/31a34f17d596d6c34798e2946dbbde29.jpeg" alt="аэрогриль hotter economy Чайник электрический Vitek VT-1140 красный" title="аэрогриль hotter economy Чайник электрический Vitek VT-1140 красный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-krasnyy-1790r"><span class="title">аэрогриль hotter economy Чайник электрический Vitek VT-1140 красный</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li class="large"><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li class="large"><img src="photos/0acc9f01a71196d6ab7726b81327e74c.jpeg" alt="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717" title="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-390r"><span class="title">daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/49901359ef2b43e118be22a24f1caa05.jpeg" alt="сколько стоит фритюрница Minamoto R6 (AA)" title="сколько стоит фритюрница Minamoto R6 (AA)"><div class="box" page="minamoto-r-aa-3r"><span class="title">сколько стоит фритюрница Minamoto R6 (AA)</span><p>от <span class="price">3</span> руб.</p></div></li>
						<li><img src="photos/569a7a448800e6c331839b4f1803d826.jpeg" alt="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502" title="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502"><div class="box" page="moyuschiy-koncentrat-thomas-protex-l-520r"><span class="title">бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/eae88ed8d5eeac95cd1245092b541388.jpeg" alt="семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas" title="семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-3"><span class="title">семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/510105f381aa497ebe08b03499acd217.jpeg" alt="купить мультиварку в красноярске Пылесос Redmond RV-307" title="купить мультиварку в красноярске Пылесос Redmond RV-307"><div class="box" page="pylesos-redmond-rv-4490r"><span class="title">купить мультиварку в красноярске Пылесос Redmond RV-307</span><p>от <span class="price">4490</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("avtoshampun-karcher-rm-l-ru-1000r.php", 0, -4); if (file_exists("comments/avtoshampun-karcher-rm-l-ru-1000r.php")) require_once "comments/avtoshampun-karcher-rm-l-ru-1000r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="avtoshampun-karcher-rm-l-ru-1000r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>