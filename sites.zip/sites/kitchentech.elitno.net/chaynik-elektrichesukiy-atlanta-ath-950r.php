<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektrichesukiy-atlanta-ath-950r.php","турка для кофе купить");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektrichesukiy-atlanta-ath-950r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>турка для кофе купить Чайник электричесукий Atlanta ATH-756  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="турка для кофе купить, мясорубка мулинекс ме 665, вафельница со сменными, кофемолка скачать, кофеварка clatronic, купить утюг для волос, промышленный пылесос цена, описание пылесоса, посоветуйте хлебопечку, как разобрать кофемолку, фритюрница philips, мясорубка кенвуд 720, борк мешки для пылесоса, дозиметр соэкс,  соковыжималка прессового отжима">
		<meta name="description" content="турка для кофе купить Керамический электрический чайник Atlanta ATH-756 белого цвета с нарисованными ц...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d6db045bcfab03ae142ac160811c2a0a.jpeg" title="турка для кофе купить Чайник электричесукий Atlanta ATH-756"><img src="photos/d6db045bcfab03ae142ac160811c2a0a.jpeg" alt="турка для кофе купить Чайник электричесукий Atlanta ATH-756" title="турка для кофе купить Чайник электричесукий Atlanta ATH-756 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/oksiochistitel-ot-nakipi-v-tabletkah-swirl-sht-185r.php"><img src="photos/56c1fb096fb1ae10287c83891f9d01cb.jpeg" alt="мясорубка мулинекс ме 665 Окси-очиститель от накипи в таблетках Swirl, 4 шт" title="мясорубка мулинекс ме 665 Окси-очиститель от накипи в таблетках Swirl, 4 шт"></a><h2>Окси-очиститель от накипи в таблетках Swirl, 4 шт</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-bistro-bordeaux-47860r.php"><img src="photos/6b889eff1ae3a6014c4090d445e03c04.jpeg" alt="вафельница со сменными Эспрессо-кофемашина Melitta Bistro Bordeaux (4.000933)" title="вафельница со сменными Эспрессо-кофемашина Melitta Bistro Bordeaux (4.000933)"></a><h2>Эспрессо-кофемашина Melitta Bistro Bordeaux (4.000933)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-bistro-erp-chernaya-36999r.php"><img src="photos/41afe7a412ec56ea979169c39fe69fdc.jpeg" alt="кофемолка скачать Автоматическая кофемашина Melitta Caffeo Bistro ERP, черная" title="кофемолка скачать Автоматическая кофемашина Melitta Caffeo Bistro ERP, черная"></a><h2>Автоматическая кофемашина Melitta Caffeo Bistro ERP, черная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>турка для кофе купить Чайник электричесукий Atlanta ATH-756</h1>
						<div class="tb"><p>Цена: от <span class="price">950</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18120.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Керамический электрический чайник Atlanta ATH-756 белого цвета с нарисованными цветами объемом 1,2 литра, мощностью 1200 Вт с закрытой спиралью из нержавеющей стали в качестве нагревательного элемента и фильтром от накипи. Абсолютно безопасен: выключается при закипании и не включается при отсутствии воды. </p><p><b>Характеристики:</b></p><ul type=disc><li>Объем: 1,2 л <li>Мощность: 1200 Вт <li>Нагревательный элемент: закрытая спираль <li>Блокировка включения без воды <li>Автоматическое выключение </li></ul><p><b>Производитель: Китай</b></p> турка для кофе купить</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/9249d045a56a8d6e38902f959401f604.jpeg" alt="кофеварка clatronic Zauber Кофемолка  Z-490" title="кофеварка clatronic Zauber Кофемолка  Z-490"><div class="box"><a href="http://kitchentech.elitno.net/zauber-kofemolka-z-1310r.php"><h3 class="title">кофеварка clatronic Zauber Кофемолка  Z-490</h3><p>от <span class="price">1310</span> руб.</p></a></div></li>
						<li><img src="photos/3bdb5a7ebf59a397ed1b6263ffa77483.jpeg" alt="купить утюг для волос Кофемолка Vitesse VS-271" title="купить утюг для волос Кофемолка Vitesse VS-271"><div class="box" page="kofemolka-vitesse-vs-1100r"><span class="title">купить утюг для волос Кофемолка Vitesse VS-271</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/5b5325f46d1563794a5b9b1bbec3af49.jpeg" alt="промышленный пылесос цена Йогуртница Moulinex JC1" title="промышленный пылесос цена Йогуртница Moulinex JC1"><div class="box" page="yogurtnica-moulinex-jc-1650r"><span class="title">промышленный пылесос цена Йогуртница Moulinex JC1</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/cfef38cef319ef880fc0959319ecdb34.jpeg" alt="описание пылесоса Чайник электрический Vitek VT-1154" title="описание пылесоса Чайник электрический Vitek VT-1154"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1010r"><span class="title">описание пылесоса Чайник электрический Vitek VT-1154</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/0b3cd91064942c75434bb396eaa4e0d2.jpeg" alt="посоветуйте хлебопечку Redmond RK-M121D Чайник электрический" title="посоветуйте хлебопечку Redmond RK-M121D Чайник электрический"><div class="box" page="redmond-rkmd-chaynik-elektricheskiy-1990r"><span class="title">посоветуйте хлебопечку Redmond RK-M121D Чайник электрический</span><p>от <span class="price">1990</span> руб.</p></div></li>
						<li class="large"><img src="photos/dd1f2c3f8afff6bfc6d7833a3fe581f3.jpeg" alt="как разобрать кофемолку Чайник электрический  Vitesse VS-108 1,7л" title="как разобрать кофемолку Чайник электрический  Vitesse VS-108 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1970r"><span class="title">как разобрать кофемолку Чайник электрический  Vitesse VS-108 1,7л</span><p>от <span class="price">1970</span> руб.</p></div></li>
						<li class="large"><img src="photos/9b828fe53dfca2c4781201b615fd512e.jpeg" alt="фритюрница philips Чайник электрический  Vitesse VS-137 1,7л бело-синий" title="фритюрница philips Чайник электрический  Vitesse VS-137 1,7л бело-синий"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r"><span class="title">фритюрница philips Чайник электрический  Vitesse VS-137 1,7л бело-синий</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/551d442551f93894a75244967e399a27.jpeg" alt="мясорубка кенвуд 720 Чайник электрический  Vitesse VS-141 1,8л" title="мясорубка кенвуд 720 Чайник электрический  Vitesse VS-141 1,8л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-990r"><span class="title">мясорубка кенвуд 720 Чайник электрический  Vitesse VS-141 1,8л</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/6d6e50224259e87ee797b3ec79edf80e.jpeg" alt="борк мешки для пылесоса Плоская универсальная насадка в упаковке Dyson Flat Out Head Retail NP" title="борк мешки для пылесоса Плоская универсальная насадка в упаковке Dyson Flat Out Head Retail NP"><div class="box" page="ploskaya-universalnaya-nasadka-v-upakovke-dyson-flat-out-head-retail-np-2190r"><span class="title">борк мешки для пылесоса Плоская универсальная насадка в упаковке Dyson Flat Out Head Retail NP</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/0c61c04ea066965d61b957c776ac9e0d.jpeg" alt="дозиметр соэкс Вертикальный циклонический пылесос Montiss CVC5667 White" title="дозиметр соэкс Вертикальный циклонический пылесос Montiss CVC5667 White"><div class="box" page="vertikalnyy-ciklonicheskiy-pylesos-montiss-cvc-white-4850r"><span class="title">дозиметр соэкс Вертикальный циклонический пылесос Montiss CVC5667 White</span><p>от <span class="price">4850</span> руб.</p></div></li>
						<li><img src="photos/08939404bc185a897cf2a335ea28842f.jpeg" alt="пылесос вертикальный Пылесос Redmond RV-308" title="пылесос вертикальный Пылесос Redmond RV-308"><div class="box" page="pylesos-redmond-rv-7990r"><span class="title">пылесос вертикальный Пылесос Redmond RV-308</span><p>от <span class="price">7990</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektrichesukiy-atlanta-ath-950r.php", 0, -4); if (file_exists("comments/chaynik-elektrichesukiy-atlanta-ath-950r.php")) require_once "comments/chaynik-elektrichesukiy-atlanta-ath-950r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektrichesukiy-atlanta-ath-950r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>