<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("nitrattester-nitratomer-soeks-5290r.php","пылесос redmond rv 309");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("nitrattester-nitratomer-soeks-5290r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос redmond rv 309 Нитрат-тестер (нитратомер) СоЭкС  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос redmond rv 309, кофеварка делонги отзывы, обслуживание пылесоса, портативный дозиметр, хлебопечка moulinex ow 6002, насадки для мясорубки zelmer, кофеварка эспрессо для дома, купить капельную кофеварку, бамбуковая пароварка, таблетки для очистки кофемашины, тесто в хлебопечке kenwood, какой лучше парогенератор, мясорубка gorenje, куриные грудки в аэрогриле,  профессиональные кофемолки">
		<meta name="description" content="пылесос redmond rv 309 Современный! Компактный! Точный!                                                ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d50a3dd0a5055f1b90b2cf35609b3ff0.jpeg" title="пылесос redmond rv 309 Нитрат-тестер (нитратомер) СоЭкС"><img src="photos/d50a3dd0a5055f1b90b2cf35609b3ff0.jpeg" alt="пылесос redmond rv 309 Нитрат-тестер (нитратомер) СоЭкС" title="пылесос redmond rv 309 Нитрат-тестер (нитратомер) СоЭкС -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/izmelchitel-ritter-mc-2700r.php"><img src="photos/b329bc8334f65653dc9ef4683c170e62.jpeg" alt="кофеварка делонги отзывы Измельчитель Ritter MC 800" title="кофеварка делонги отзывы Измельчитель Ritter MC 800"></a><h2>Измельчитель Ritter MC 800</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-3650r.php"><img src="photos/b6481108ed00fa262329eb9b4a9a7836.jpeg" alt="обслуживание пылесоса Микроволновая печь Vitek VT-1694" title="обслуживание пылесоса Микроволновая печь Vitek VT-1694"></a><h2>Микроволновая печь Vitek VT-1694</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-480r.php"><img src="photos/ac8f90b072b89e29e700b07839541017.jpeg" alt="портативный дозиметр Миксер Atlanta ATH-293" title="портативный дозиметр Миксер Atlanta ATH-293"></a><h2>Миксер Atlanta ATH-293</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос redmond rv 309 Нитрат-тестер (нитратомер) СоЭкС</h1>
						<div class="tb"><p>Цена: от <span class="price">5290</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_807.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><h2>Современный! Компактный! Точный!</h2><p><u></u></p><p><u><object id=FlashID title=\Цифровой нитрат-тестер СОЭКС\ height=400 hspace=10 width=300 align=left vspace=10 classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000><param name=\_cx\ value=\7938\><param name=\_cy\ value=\10583\><param name=\FlashVars\ value=\\><param name=\Movie\ value=\/swf/soeks.swf\><param name=\Src\ value=\/swf/soeks.swf\><param name=\WMode\ value=\Opaque\><param name=\Play\ value=\-1\><param name=\Loop\ value=\-1\><param name=\Quality\ value=\High\><param name=\SAlign\ value=\\><param name=\Menu\ value=\-1\><param name=\Base\ value=\\><param name=\AllowScriptAccess\ value=\\><param name=\Scale\ value=\NoScale\><param name=\DeviceFont\ value=\0\><param name=\EmbedMovie\ value=\0\><param name=\BGColor\ value=\\><param name=\SWRemote\ value=\\><param name=\MovieData\ value=\\><param name=\SeamlessTabbing\ value=\1\><param name=\Profile\ value=\0\><param name=\ProfileAddress\ value=\\><param name=\ProfilePort\ value=\0\><param name=\AllowNetworking\ value=\all\><param name=\AllowFullScreen\ value=\false\>                    <!-- this param tag prompts users with flash player 6.0 r65 and higher to download the latest version of flash player. delete it if you don’t want users to see the prompt. -->        <!-- next object tag is for non-ie browsers. so hide it from ie using iecc. -->    <!--[if !ie]>-->    <object data=\/swf/soeks.swf\ type=\application/x-shockwave-flash\ vspace=\10\ width=\300\ align=\left\ height=\400\ hspace=\10\>      <!--<![endif]-->                              <!-- the browser displays the following alternative content for users with flash player 6.0 and older. --> пылесос redmond rv 309</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/014eea2e4ace248a80b3ce72354f4315.jpeg" alt="хлебопечка moulinex ow 6002 Пароварка Maxima MST-0511" title="хлебопечка moulinex ow 6002 Пароварка Maxima MST-0511"><div class="box"><a href="http://kitchentech.elitno.net/parovarka-maxima-mst-760r.php"><h3 class="title">хлебопечка moulinex ow 6002 Пароварка Maxima MST-0511</h3><p>от <span class="price">760</span> руб.</p></a></div></li>
						<li><img src="photos/7476c2912d4d9c99682e7b20dcc24385.jpeg" alt="насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192" title="насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192"><div class="box" page="elektroplita-indukcionnaya-atlanta-ath-1900r"><span class="title">насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li><img src="photos/50b32a99f8069aa25115dc1163e0b555.jpeg" alt="кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л" title="кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1760r"><span class="title">кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li><img src="photos/65194d520ec7c4edb8d9ad44bcaa26a1.jpeg" alt="купить капельную кофеварку Чайник электрический Maxima MК-105" title="купить капельную кофеварку Чайник электрический Maxima MК-105"><div class="box" page="chaynik-elektricheskiy-maxima-mk-550r"><span class="title">купить капельную кофеварку Чайник электрический Maxima MК-105</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li class="large"><img src="photos/3e5de65e23113a4dedb018c90159e3df.jpeg" alt="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной" title="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r"><span class="title">бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной</span><p>от <span class="price">1360</span> руб.</p></div></li>
						<li class="large"><img src="photos/ed1507cb4c766d544261d1f0cc2c6466.jpeg" alt="таблетки для очистки кофемашины Чайник-термос  Atlanta АТН-764" title="таблетки для очистки кофемашины Чайник-термос  Atlanta АТН-764"><div class="box" page="chayniktermos-atlanta-atn-1570r"><span class="title">таблетки для очистки кофемашины Чайник-термос  Atlanta АТН-764</span><p>от <span class="price">1570</span> руб.</p></div></li>
						<li class="large"><img src="photos/4c770d02fca0640e0452b9df7c46a9e0.jpeg" alt="тесто в хлебопечке kenwood Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)" title="тесто в хлебопечке kenwood Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r"><span class="title">тесто в хлебопечке kenwood Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)</span><p>от <span class="price">1550</span> руб.</p></div></li>
						<li><img src="photos/512f8d3c0276804b57a2729ea05d9ba6.jpeg" alt="какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas" title="какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r-2"><span class="title">какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/ebeb61ea1ddcbebc4d0a7ed9a625842f.jpeg" alt="мясорубка gorenje Бумажные фильтры-мешки 450 (787-114) для Thomas" title="мясорубка gorenje Бумажные фильтры-мешки 450 (787-114) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1150r"><span class="title">мясорубка gorenje Бумажные фильтры-мешки 450 (787-114) для Thomas</span><p>от <span class="price">1150</span> руб.</p></div></li>
						<li><img src="photos/2bd3efe5f6abbadb315d0281a9a3d70f.jpeg" alt="куриные грудки в аэрогриле Пылесос Vitek VT-1810" title="куриные грудки в аэрогриле Пылесос Vitek VT-1810"><div class="box" page="pylesos-vitek-vt-2150r"><span class="title">куриные грудки в аэрогриле Пылесос Vitek VT-1810</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/cd428dd5a0d9bc6681acf973ed19ada0.jpeg" alt="какие есть хлебопечки Утюг Atlanta ATH-470" title="какие есть хлебопечки Утюг Atlanta ATH-470"><div class="box" page="utyug-atlanta-ath-520r-2"><span class="title">какие есть хлебопечки Утюг Atlanta ATH-470</span><p>от <span class="price">520</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("nitrattester-nitratomer-soeks-5290r.php", 0, -4); if (file_exists("comments/nitrattester-nitratomer-soeks-5290r.php")) require_once "comments/nitrattester-nitratomer-soeks-5290r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="nitrattester-nitratomer-soeks-5290r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>