<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-maxima-mk-760r-2.php","запеканка картофельная в аэрогриле");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-maxima-mk-760r-2.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>запеканка картофельная в аэрогриле Чайник электрический Maxima MК-110  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="запеканка картофельная в аэрогриле, микроволновая печь вред, компактная микроволновая печь, шарлотка в мультиварке панасоник, распродажа пылесосов, соковыжималка ангел, мультиварка акции, мультиварка daewoo dmc 200, соковыжималка садовая, средство от накипи для утюга, тесто в хлебопечке kenwood, дозиметр радиоактивности, горошница в мультиварке, kress пылесос,  купить капельную кофеварку">
		<meta name="description" content="запеканка картофельная в аэрогриле Изящный и стильный электрический чайник Maxima MК-110 станет не только украшение...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/1e2ee26a34837e1fda12ed6026e21031.jpeg" title="запеканка картофельная в аэрогриле Чайник электрический Maxima MК-110"><img src="photos/1e2ee26a34837e1fda12ed6026e21031.jpeg" alt="запеканка картофельная в аэрогриле Чайник электрический Maxima MК-110" title="запеканка картофельная в аэрогриле Чайник электрический Maxima MК-110 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-omelette-hc-1960r.php"><img src="photos/9b2c766be9aca21d9cbe5748b263718f.jpeg" alt="микроволновая печь вред Блендер Braun MR-120 Omelette HC" title="микроволновая печь вред Блендер Braun MR-120 Omelette HC"></a><h2>Блендер Braun MR-120 Omelette HC</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-blender-s-aksessuarami-bodum-bistro-keuro-3780r.php"><img src="photos/a7593a9ae0c3505a2632ee9e30dcbbe0.jpeg" alt="компактная микроволновая печь Электрический блендер с аксессуарами Bodum BISTRO K11179-01EURO" title="компактная микроволновая печь Электрический блендер с аксессуарами Bodum BISTRO K11179-01EURO"></a><h2>Электрический блендер с аксессуарами Bodum BISTRO K11179-01EURO</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-33650r.php"><img src="photos/3298e4cbe4a01ff3e30b40e0178e9164.jpeg" alt="шарлотка в мультиварке панасоник Кофемашина Nivona NICR730 CafeRomatica" title="шарлотка в мультиварке панасоник Кофемашина Nivona NICR730 CafeRomatica"></a><h2>Кофемашина Nivona NICR730 CafeRomatica</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>запеканка картофельная в аэрогриле Чайник электрический Maxima MК-110</h1>
						<div class="tb"><p>Цена: от <span class="price">760</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18597.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Изящный и стильный электрический чайник Maxima MК-110 станет не только украшением современной кухни, но и отличным помощником – он вскипятит полтора литра воды за считанные минуты, автоматически выключится при закипании или при недостаточном уровне воды, а специальный фильтр защитит от накипи.<br>Классический белый цвет, корпус из жарочного пластика, спираль из нержавеющей стали, шкала воды и подсветка – весь необходимый минимум для отличного чайника.<br>Цвет на выбор: зеленый, красный или синий.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Мощность 2000 Вт; <li>Емкость: 1,7 л; <li>Нагревательный элемент из нержавеющей стали; <li>Корпус из жаропрочного пластика; <li>Автоматическое выключение при закипании; <li>Автоматическое отключение при снятии с подставки; <li>Автоматическое отключение при недостаточном количестве воды; <li>Угол вращения на подставке 360; <li>Световой индикатор работы; <li>Фильтр от накипи; <li>Шкала уровня воды; <li>Открытие крышки одним нажатием. </li></ul><p><strong>Производитель: MAXIMA (Англия)</strong><br><strong>Гарантия: 1 год</strong></p> запеканка картофельная в аэрогриле</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7b88076a90f90c4718597a4ab977cb0a.jpeg" alt="распродажа пылесосов Микроволновая печь Vitek VT-1682" title="распродажа пылесосов Микроволновая печь Vitek VT-1682"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3550r"><span class="title">распродажа пылесосов Микроволновая печь Vitek VT-1682</span><p>от <span class="price">3550</span> руб.</p></div></li>
						<li><img src="photos/21689be9dc7c8e66c7cb248c7b6f5f86.jpeg" alt="соковыжималка ангел Пароварка Maxima MST-1102" title="соковыжималка ангел Пароварка Maxima MST-1102"><div class="box" page="parovarka-maxima-mst-1290r"><span class="title">соковыжималка ангел Пароварка Maxima MST-1102</span><p>от <span class="price">1290</span> руб.</p></div></li>
						<li><img src="photos/b11b426009f0167e5ff93f5aa64ca56d.jpeg" alt="мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л" title="мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1650r"><span class="title">мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/1ce3d92d8e0391534b2eb43fa514d9a4.jpeg" alt="мультиварка daewoo dmc 200 Чайник электрический Redmond RK-М119" title="мультиварка daewoo dmc 200 Чайник электрический Redmond RK-М119"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2690r"><span class="title">мультиварка daewoo dmc 200 Чайник электрический Redmond RK-М119</span><p>от <span class="price">2690</span> руб.</p></div></li>
						<li class="large"><img src="photos/a73fe1f79d4e2459d6da89e07445f626.jpeg" alt="соковыжималка садовая Электрический чайник Atlanta АТН-738" title="соковыжималка садовая Электрический чайник Atlanta АТН-738"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-520r"><span class="title">соковыжималка садовая Электрический чайник Atlanta АТН-738</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li class="large"><img src="photos/05c48dbba69cff2727e6c1b6d1112395.jpeg" alt="средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2" title="средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2"><div class="box" page="batareyki-gp-batteries-super-alkaline-lr-abc-170r"><span class="title">средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2</span><p>от <span class="price">170</span> руб.</p></div></li>
						<li class="large"><img src="photos/4c770d02fca0640e0452b9df7c46a9e0.jpeg" alt="тесто в хлебопечке kenwood Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)" title="тесто в хлебопечке kenwood Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r"><span class="title">тесто в хлебопечке kenwood Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)</span><p>от <span class="price">1550</span> руб.</p></div></li>
						<li><img src="photos/c0a2e2be0cab06fcd64d43478c95622c.jpeg" alt="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter" title="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-tt-aquafilter-14900r"><span class="title">дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter</span><p>от <span class="price">14900</span> руб.</p></div></li>
						<li><img src="photos/6f1dc0aa11d1eda2d816fefb2df4a739.jpeg" alt="горошница в мультиварке Пылесос моющий Thomas Hygiene Plus T2" title="горошница в мультиварке Пылесос моющий Thomas Hygiene Plus T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-plus-t-19460r"><span class="title">горошница в мультиварке Пылесос моющий Thomas Hygiene Plus T2</span><p>от <span class="price">19460</span> руб.</p></div></li>
						<li><img src="photos/cfc3673046a371ff9baffb342aa8e52b.jpeg" alt="kress пылесос Пылесос моющий Thomas Twin Aquafilter" title="kress пылесос Пылесос моющий Thomas Twin Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquafilter-11550r"><span class="title">kress пылесос Пылесос моющий Thomas Twin Aquafilter</span><p>от <span class="price">11550</span> руб.</p></div></li>
						<li><img src="photos/6ad68580ca9fe51d58dccc0df51b3bb5.jpeg" alt="ржаная мука для хлебопечки Пылесос моющий Thomas Twin Aquatherm + Aquafilter" title="ржаная мука для хлебопечки Пылесос моющий Thomas Twin Aquatherm + Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquatherm-aquafilter-16720r"><span class="title">ржаная мука для хлебопечки Пылесос моющий Thomas Twin Aquatherm + Aquafilter</span><p>от <span class="price">16720</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-maxima-mk-760r-2.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-maxima-mk-760r-2.php")) require_once "comments/chaynik-elektricheskiy-maxima-mk-760r-2.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-maxima-mk-760r-2.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>