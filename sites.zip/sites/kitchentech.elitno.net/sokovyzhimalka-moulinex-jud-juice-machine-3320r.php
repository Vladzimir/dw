<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-moulinex-jud-juice-machine-3320r.php","чалды для кофемашины");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-moulinex-jud-juice-machine-3320r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>чалды для кофемашины Соковыжималка Moulinex JU570D3 Juice Machine  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="чалды для кофемашины, микроволновая печь эльдорадо, купить водяной пылесос, аэрогриль воронеж, кофемолка moulinex, контрольная закупка пылесос, лампа для аэрогриля, аэрогриль форум, какой моющий пылесос выбрать, купить кофеварку для дома, блендер металлический, венчики для миксера, запеканка в хлебопечке, соковыжималка садовая,  индукционная плита с духовкой">
		<meta name="description" content="чалды для кофемашины Универсальная соковыжималка Moulinex Juice Machine сочетает в себе мощность и ск...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d4f76a5fd1a2c3a65c40e2234f6145bc.jpeg" title="чалды для кофемашины Соковыжималка Moulinex JU570D3 Juice Machine"><img src="photos/d4f76a5fd1a2c3a65c40e2234f6145bc.jpeg" alt="чалды для кофемашины Соковыжималка Moulinex JU570D3 Juice Machine" title="чалды для кофемашины Соковыжималка Moulinex JU570D3 Juice Machine -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ochistitel-ot-nakipi-dlya-filtrkofevarok-melitta-h-gr-325r.php"><img src="photos/aa2a1360189cc3efe864ba442a1ab29c.jpeg" alt="микроволновая печь эльдорадо Очиститель от накипи для фильтр-кофеварок Melitta, 6х20 гр" title="микроволновая печь эльдорадо Очиститель от накипи для фильтр-кофеварок Melitta, 6х20 гр"></a><h2>Очиститель от накипи для фильтр-кофеварок Melitta, 6х20 гр</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-snake-n-take-900r.php"><img src="photos/3a6f8f5bcd6b4c656110981eb9f3285b.jpeg" alt="купить водяной пылесос Блендер Snake n Take" title="купить водяной пылесос Блендер Snake n Take"></a><h2>Блендер Snake n Take</h2></li>
							<li><a href="http://kitchentech.elitno.net/zauber-kofemolka-x-1250r.php"><img src="photos/13e215c432e654a40129e4a1cdc305f1.jpeg" alt="аэрогриль воронеж Zauber Кофемолка  X-480" title="аэрогриль воронеж Zauber Кофемолка  X-480"></a><h2>Zauber Кофемолка  X-480</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>чалды для кофемашины Соковыжималка Moulinex JU570D3 Juice Machine</h1>
						<div class="tb"><p>Цена: от <span class="price">3320</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_12020.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Универсальная <b>соковыжималка </b><b>Moulinex </b><b>Juice </b><b>Machine </b>сочетает в себе мощность и скорость. С ее помощью вы без труда сможете получить свежевыжатый сок из овощей и фруктов любой твердости. Благодаря широкому загрузочному отверстию можно загружать крупные фрукты и овощи, не нарезая их.</p><p>Мощность прибора составляет 800 Вт, предусмотрено два скоростных режима (максимум - 12000 оборотов в минуту). Модель оснащена технологией прямой подачи сока и системой «капля-стоп», действует автоматический выброс мякоти в резервуар объемом 3 л. В целях безопасности имеется защита от случайного включения устройства. Корпус соковыжималки выполнен из пластика, сетка центрифуги – из нержавеющей стали, ножки прорезинены. К преимуществам прибора можно отнести наличие сепаратора для отделения пены от готового сока.</p><p><b>Характеристики:</b></p><ul type=disc><li>Универсальная; <li>Мощность: 800 Вт; <li>Максимальная скорость вращения: 12000 об/мин; <li>Количество скоростей: 2; <li>Резервуар для сока: стакан; <li>Система прямой подачи сока; <li>Автоматический выброс мякоти: объем резервуара 3 л; <li>Система «капля-стоп»; <li>Материал корпуса: пластик; <li>Материал сетки центрифуги: нержавеющая сталь; <li>Круглая горловина; <li>Размер горловины: 75 мм; <li>Прорезиненные ножки; <li>Сепаратор для пены; <li>Защита от случайного включения; <li>Щеточка для чистки в комплекте.</li></ul><p><b>Производитель:</b> Moulinex.</p><p><b>Страна:</b> Франция.</p><p><b>Гарантия:</b> 2 года.</p> чалды для кофемашины</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/c585fc23a1c72232536c2283ac42fbc1.jpeg" alt="кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная" title="кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная"><div class="box" page="elektricheskaya-nozhevaya-kofemolka-bodum-bistro-euro-limonnaya-1830r"><span class="title">кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная</span><p>от <span class="price">1830</span> руб.</p></div></li>
						<li><img src="photos/b6c05d69ce9bf94410c78acce4c5e9cb.jpeg" alt="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер" title="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер"><div class="box" page="bodum-bistro-euro-elektricheskiy-mikser-2740r"><span class="title">контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/c2ec0f6a659b8874d2e6e8a30149501a.jpeg" alt="лампа для аэрогриля Мультиварка Maruchi  RW-FZ45F" title="лампа для аэрогриля Мультиварка Maruchi  RW-FZ45F"><div class="box" page="multivarka-maruchi-rwfzf-2700r"><span class="title">лампа для аэрогриля Мультиварка Maruchi  RW-FZ45F</span><p>от <span class="price">2700</span> руб.</p></div></li>
						<li><img src="photos/8c0aa6f2022172974ae917a715c05f94.jpeg" alt="аэрогриль форум Пароварка Vitek VT-1550N SR" title="аэрогриль форум Пароварка Vitek VT-1550N SR"><div class="box" page="parovarka-vitek-vtn-sr-2200r"><span class="title">аэрогриль форум Пароварка Vitek VT-1550N SR</span><p>от <span class="price">2200</span> руб.</p></div></li>
						<li class="large"><img src="photos/d2b0cc36c62095fdc525b7665e50506c.jpeg" alt="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321" title="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321"><div class="box" page="sokovyzhimalka-atlanta-ath-1010r"><span class="title">какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/b3ff9d6ec8fde71796646bd977ae1927.jpeg" alt="купить кофеварку для дома Чайник электрический Vitek VT-1147 белый" title="купить кофеварку для дома Чайник электрический Vitek VT-1147 белый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-belyy-1380r"><span class="title">купить кофеварку для дома Чайник электрический Vitek VT-1147 белый</span><p>от <span class="price">1380</span> руб.</p></div></li>
						<li class="large"><img src="photos/f2d6d870289f867bca2e3ea0f8531c8e.jpeg" alt="блендер металлический Электрический чайник  Zauber Z-350" title="блендер металлический Электрический чайник  Zauber Z-350"><div class="box" page="elektricheskiy-chaynik-zauber-z-1600r"><span class="title">блендер металлический Электрический чайник  Zauber Z-350</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/8be60bf8ecb8c08e6df4d6b339b40b58.jpeg" alt="венчики для миксера Чайник электрический Atlanta ATH-759" title="венчики для миксера Чайник электрический Atlanta ATH-759"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r-2"><span class="title">венчики для миксера Чайник электрический Atlanta ATH-759</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="запеканка в хлебопечке Чайник электрический Maxima MK-G311" title="запеканка в хлебопечке Чайник электрический Maxima MK-G311"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1650r"><span class="title">запеканка в хлебопечке Чайник электрический Maxima MK-G311</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/a73fe1f79d4e2459d6da89e07445f626.jpeg" alt="соковыжималка садовая Электрический чайник Atlanta АТН-738" title="соковыжималка садовая Электрический чайник Atlanta АТН-738"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-520r"><span class="title">соковыжималка садовая Электрический чайник Atlanta АТН-738</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/388c2880498e546d8fcebc787f1cf894.jpeg" alt="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO" title="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO"><div class="box" page="elektricheskiy-chaynik-l-chernyy-bodum-bistro-euro-2270r"><span class="title">испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-moulinex-jud-juice-machine-3320r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-moulinex-jud-juice-machine-3320r.php")) require_once "comments/sokovyzhimalka-moulinex-jud-juice-machine-3320r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-moulinex-jud-juice-machine-3320r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>