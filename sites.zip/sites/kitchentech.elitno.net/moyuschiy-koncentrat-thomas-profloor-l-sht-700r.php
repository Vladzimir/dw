<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("moyuschiy-koncentrat-thomas-profloor-l-sht-700r.php","пылесос прессующий пыль");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("moyuschiy-koncentrat-thomas-profloor-l-sht-700r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос прессующий пыль Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос прессующий пыль, хлебопечка gorenje bm 900, купить блендер кенвуд, печенье песочное через мясорубку, крышка для микроволновой печи, выбор микроволновой печи, распродажа пылесосов, измельчитель хэппи чоп, крылышки в пароварке, ремонт мясорубок мулинекс, какой моющий пылесос выбрать, пылесос mediclean, очистка кофеварки, парогенератор мобильный,  уха в мультиварке">
		<meta name="description" content="пылесос прессующий пыль Моющий концентрат Thomas Protex выпускается в бутылке объемом 1 литр. В одной уп...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/eb7760a68b0b3e85f39c2160100a5731.jpeg" title="пылесос прессующий пыль Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008"><img src="photos/eb7760a68b0b3e85f39c2160100a5731.jpeg" alt="пылесос прессующий пыль Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008" title="пылесос прессующий пыль Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/filtry-bumazhnye-h-sht-melitta-90r.php"><img src="photos/91c7accfbd25769c2cb59ce46021a324.jpeg" alt="хлебопечка gorenje bm 900 Фильтры бумажные 1х4 40 шт. Melitta" title="хлебопечка gorenje bm 900 Фильтры бумажные 1х4 40 шт. Melitta"></a><h2>Фильтры бумажные 1х4 40 шт. Melitta</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-baby-2000r.php"><img src="photos/612bb1b2d8bad8dc8e3250c8f9903851.jpeg" alt="купить блендер кенвуд Блендер Braun MR-320 Baby" title="купить блендер кенвуд Блендер Braun MR-320 Baby"></a><h2>Блендер Braun MR-320 Baby</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-hrom-3290r.php"><img src="photos/34e123d55d60377ab16c1ebb8978b506.jpeg" alt="печенье песочное через мясорубку Блендер Redmond RHB-2904 (хром)" title="печенье песочное через мясорубку Блендер Redmond RHB-2904 (хром)"></a><h2>Блендер Redmond RHB-2904 (хром)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос прессующий пыль Моющий концентрат Thomas Profloor 1 л (2 шт) 790-008</h1>
						<div class="tb"><p>Цена: от <span class="price">700</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14806.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий концентрат Thomas Protex выпускается в бутылке объемом 1 литр. В одной упаковке 2 бутылки концентрата. Средство предназначено для ухода и эффективной очистки ПВХ, керамической плитки, мозаичных и других твердых напольных поверхностей. Концентрированный состав средства с полимерным воском и поверхностно активными веществами без растворителей освежает покрытия и образует грязеотталкивающую, не скользящую при ходьбе защитную пленку. </p><p><b>Характеристики:</b></p><ul type=\disc\><li>В упаковке 2 концентрата; </li><li>Для чистки ПВХ-покрытий, керамической плитки, мозаичных и д. твердых напольных покрытий; </li><li>Приятный запах; </li><li>Образует грязеотталкивающую, нескользкую при ходьбе защитную пленку; </li><li>Концентрированный состав из полимерного воска и поверхностно активных веществ без содержания растворителей; </li><li>Объем каждой бутылки: 1 л.</li></ul><p><b>Производитель:</b> Thomas.</p> пылесос прессующий пыль</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/23396bca502057564018abfebb4d84d5.jpeg" alt="крышка для микроволновой печи Блендер Redmond RHB-2910" title="крышка для микроволновой печи Блендер Redmond RHB-2910"><div class="box" page="blender-redmond-rhb-1090r"><span class="title">крышка для микроволновой печи Блендер Redmond RHB-2910</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/0b57a5fa2564b3001e847ebdd45ce976.jpeg" alt="выбор микроволновой печи Вспениватель Melitta Cremio красный" title="выбор микроволновой печи Вспениватель Melitta Cremio красный"><div class="box" page="vspenivatel-melitta-cremio-krasnyy-4155r"><span class="title">выбор микроволновой печи Вспениватель Melitta Cremio красный</span><p>от <span class="price">4155</span> руб.</p></div></li>
						<li><img src="photos/7b88076a90f90c4718597a4ab977cb0a.jpeg" alt="распродажа пылесосов Микроволновая печь Vitek VT-1682" title="распродажа пылесосов Микроволновая печь Vitek VT-1682"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3550r"><span class="title">распродажа пылесосов Микроволновая печь Vitek VT-1682</span><p>от <span class="price">3550</span> руб.</p></div></li>
						<li><img src="photos/d4a3d850ff4d12f0511b4f02c450fad7.jpeg" alt="измельчитель хэппи чоп Микроволновая печь Vitek VT-1692" title="измельчитель хэппи чоп Микроволновая печь Vitek VT-1692"><div class="box" page="mikrovolnovaya-pech-vitek-vt-2870r"><span class="title">измельчитель хэппи чоп Микроволновая печь Vitek VT-1692</span><p>от <span class="price">2870</span> руб.</p></div></li>
						<li class="large"><img src="photos/1c1d1049958bdd0b6b9f6e6cb13db14b.jpeg" alt="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый" title="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый"><div class="box" page="mikrovolnovaya-pech-s-grilem-moulinex-mw-l-belyy-3890r"><span class="title">крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый</span><p>от <span class="price">3890</span> руб.</p></div></li>
						<li class="large"><img src="photos/dc407a1e2a485cfa91965baf93f3d5ba.jpeg" alt="ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051" title="ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051"><div class="box" page="myasorubka-elektricheskaya-moulinex-me-3820r"><span class="title">ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051</span><p>от <span class="price">3820</span> руб.</p></div></li>
						<li class="large"><img src="photos/d2b0cc36c62095fdc525b7665e50506c.jpeg" alt="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321" title="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321"><div class="box" page="sokovyzhimalka-atlanta-ath-1010r"><span class="title">какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li><img src="photos/4f7eae7926bb1b2816625b5940a25b78.jpeg" alt="пылесос mediclean Чайник электрический Vitek VT-1157" title="пылесос mediclean Чайник электрический Vitek VT-1157"><div class="box" page="chaynik-elektricheskiy-vitek-vt-2150r"><span class="title">пылесос mediclean Чайник электрический Vitek VT-1157</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/22d30b7337c9635a9decf8a39fad0a54.jpeg" alt="очистка кофеварки Электрический чайник Atlanta АТН-793" title="очистка кофеварки Электрический чайник Atlanta АТН-793"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1420r-2"><span class="title">очистка кофеварки Электрический чайник Atlanta АТН-793</span><p>от <span class="price">1420</span> руб.</p></div></li>
						<li><img src="photos/610809077bd818e574e4a814e433a999.jpeg" alt="парогенератор мобильный Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2" title="парогенератор мобильный Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2"><div class="box" page="akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r"><span class="title">парогенератор мобильный Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2</span><p>от <span class="price">220</span> руб.</p></div></li>
						<li><img src="photos/ab56fe42ec3af82144d9f5eb1f80eb4c.jpeg" alt="купить лопатку для хлебопечки Мини весы Tangent KP-103" title="купить лопатку для хлебопечки Мини весы Tangent KP-103"><div class="box" page="mini-vesy-tangent-kp-1200r"><span class="title">купить лопатку для хлебопечки Мини весы Tangent KP-103</span><p>от <span class="price">1200</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("moyuschiy-koncentrat-thomas-profloor-l-sht-700r.php", 0, -4); if (file_exists("comments/moyuschiy-koncentrat-thomas-profloor-l-sht-700r.php")) require_once "comments/moyuschiy-koncentrat-thomas-profloor-l-sht-700r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="moyuschiy-koncentrat-thomas-profloor-l-sht-700r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>