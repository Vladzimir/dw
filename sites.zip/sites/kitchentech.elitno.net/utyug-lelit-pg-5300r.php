<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-lelit-pg-5300r.php","как пользоваться кофемашиной");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-lelit-pg-5300r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>как пользоваться кофемашиной Утюг Lelit PG024/3  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="как пользоваться кофемашиной, кофемолка moulinex, микроволновые печи liberton, мультиварки киев, кухонный комбайн tefal, фиксики смотреть пылесос, дозиметр рентгеновского излучения, венчики для миксера, дженни шаптер хлебопечка скачать, соковыжималка philips 1866, мешки пылесборники для пылесосов, мультиварка panasonic магазин, бездрожжевой хлеб в хлебопечке, аэрогриль lentel d101b,  рецепты для миксера">
		<meta name="description" content="как пользоваться кофемашиной Электропаровой утюг весом 1,8 кг отлично подойдет как для домашней работы, так и...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/67822ba313ff8dc5e99b810c3c8dbe4a.jpeg" title="как пользоваться кофемашиной Утюг Lelit PG024/3"><img src="photos/67822ba313ff8dc5e99b810c3c8dbe4a.jpeg" alt="как пользоваться кофемашиной Утюг Lelit PG024/3" title="как пользоваться кофемашиной Утюг Lelit PG024/3 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-3290r.php"><img src="photos/77a7b9eee8f1b767f7912a55eb9e902b.jpeg" alt="кофемолка moulinex Блендер Redmond RHB-2904" title="кофемолка moulinex Блендер Redmond RHB-2904"></a><h2>Блендер Redmond RHB-2904</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-blender-s-aksessuarami-bodum-bistro-keuro-zelenyy-3780r.php"><img src="photos/3526059781ecc20c6df37db0e64d10f4.jpeg" alt="микроволновые печи liberton Электрический блендер с аксессуарами Bodum BISTRO K11179-565EURO зеленый" title="микроволновые печи liberton Электрический блендер с аксессуарами Bodum BISTRO K11179-565EURO зеленый"></a><h2>Электрический блендер с аксессуарами Bodum BISTRO K11179-565EURO зеленый</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-ci-black-76390r.php"><img src="photos/4c9f6fc7185095b9ee0e389df903b9c9.jpeg" alt="мультиварки киев Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)" title="мультиварки киев Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)"></a><h2>Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>как пользоваться кофемашиной Утюг Lelit PG024/3</h1>
						<div class="tb"><p>Цена: от <span class="price">5300</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16436.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электропаровой утюг весом 1,8 кг отлично подойдет как для домашней работы, так и для профессиональной сферы. Модель <b>Lelit PG024/3 </b>оснащена специальным разъемом для присоединения к моделям парогенераторов (PG024N и PG018) осуществляющих экологическую уборку. Регулируемый термостат – от 60 до 215С.</p><p><b>Технические характеристики:</b></p><ul type=\disc\><li>Напряжение: 220/230 В </li><li>Потребляемая мощность: 800 Вт </li><li>Длина моношланга: 2,1 м </li><li>Регулируемый термостат: От 60 до 215 С </li><li>Утюг по желанию покупателя может быть доукомплектован:</li><ul><li>Тефлоновой подошвой PA205/1. </li><li>Силиконовым ковриком для утюга LELIT CD363. </li><li>Чистящими салфетками для утюга и пресса, 2шт. DOMENA 413110. </li><li>Ковриком для очистки утюга Puliferro </li></ul><li>Разъем для подключения к парогенераторам PG024N и PG018 </li><li>Размер: 24х13х16 см</li></ul><p><b>Производитель:</b> Lelit.</p><p><b>Страна:</b> Италия.</p><p><b>Гарантия:</b> 1 год.</p> как пользоваться кофемашиной</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/33b43228a18b1110c1c8a14516611c99.jpeg" alt="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE" title="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE"><div class="box" page="kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r"><span class="title">кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE</span><p>от <span class="price">3570</span> руб.</p></div></li>
						<li><img src="photos/acf412ca70279cda1dfad07d522f7e3c.jpeg" alt="фиксики смотреть пылесос Пароварка Vitesse VS-507" title="фиксики смотреть пылесос Пароварка Vitesse VS-507"><div class="box" page="parovarka-vitesse-vs-1290r"><span class="title">фиксики смотреть пылесос Пароварка Vitesse VS-507</span><p>от <span class="price">1290</span> руб.</p></div></li>
						<li><img src="photos/316a6aef2ce50d76bdf9280d8e11dad1.jpeg" alt="дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230" title="дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230"><div class="box" page="hlebopechka-moulinex-ow-4790r"><span class="title">дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230</span><p>от <span class="price">4790</span> руб.</p></div></li>
						<li><img src="photos/8be60bf8ecb8c08e6df4d6b339b40b58.jpeg" alt="венчики для миксера Чайник электрический Atlanta ATH-759" title="венчики для миксера Чайник электрический Atlanta ATH-759"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r-2"><span class="title">венчики для миксера Чайник электрический Atlanta ATH-759</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/78655cc6df39885b41a8efad804df716.jpeg" alt="дженни шаптер хлебопечка скачать Чайник электрический Redmond RK-M113" title="дженни шаптер хлебопечка скачать Чайник электрический Redmond RK-M113"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2290r"><span class="title">дженни шаптер хлебопечка скачать Чайник электрический Redmond RK-M113</span><p>от <span class="price">2290</span> руб.</p></div></li>
						<li class="large"><img src="photos/ba65472be620113b82aa055e0f7c89a6.jpeg" alt="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный" title="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-krasnyy-1510r"><span class="title">соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный</span><p>от <span class="price">1510</span> руб.</p></div></li>
						<li class="large"><img src="photos/df4499dd6fe2786e58841593ed771f8f.jpeg" alt="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009" title="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009"><div class="box" page="moyuschiy-koncentrat-thomas-profloor-l-500r"><span class="title">мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009</span><p>от <span class="price">500</span> руб.</p></div></li>
						<li><img src="photos/787fcfe3b6052ac0b67b5602b473ad73.jpeg" alt="мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter" title="мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r"><span class="title">мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter</span><p>от <span class="price">18180</span> руб.</p></div></li>
						<li><img src="photos/e0fdfa431cfe6b47b04ad11ff4f6a218.jpeg" alt="бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805" title="бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805"><div class="box" page="pylesos-vitek-vt-1870r"><span class="title">бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805</span><p>от <span class="price">1870</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
						<li><img src="photos/e53e12ffaa33b8893df2fec4f59e9123.jpeg" alt="кофеварка форум Пылесос Vitek VT-1838" title="кофеварка форум Пылесос Vitek VT-1838"><div class="box" page="pylesos-vitek-vt-3400r"><span class="title">кофеварка форум Пылесос Vitek VT-1838</span><p>от <span class="price">3400</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-lelit-pg-5300r.php", 0, -4); if (file_exists("comments/utyug-lelit-pg-5300r.php")) require_once "comments/utyug-lelit-pg-5300r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-lelit-pg-5300r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>