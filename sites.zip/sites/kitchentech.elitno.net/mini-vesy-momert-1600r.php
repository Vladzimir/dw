<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("mini-vesy-momert-1600r.php","пылесос thomas s1");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("mini-vesy-momert-1600r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос thomas s1 Мини весы Momert 6000  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос thomas s1, мультиварка polaris pmc 0512ad, микроволновая печь рейтинг, кофемолка moulinex, купить электрическую кофеварку, что можно делать блендером, хлебопечка в техносиле, пылесос thomas отзывы, куриное филе в пароварке, кофемашина la cimbali, термопот toshiba, лучший пылесос с аквафильтром, magic pot мультиварка, соковыжималка россошанка,  мясорубка moulinex hv8 me625">
		<meta name="description" content="пылесос thomas s1 Складной корпус мини весов и экран с яркой подсветкой – не главные преимущества ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/351be0717cadb3b074e20c4a4dccbf50.jpeg" title="пылесос thomas s1 Мини весы Momert 6000"><img src="photos/351be0717cadb3b074e20c4a4dccbf50.jpeg" alt="пылесос thomas s1 Мини весы Momert 6000" title="пылесос thomas s1 Мини весы Momert 6000 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ochistitel-ot-nakipi-dlya-filtrkofevarok-i-chaynikov-melitta-tabletki-h-gr-295r.php"><img src="photos/0dd1486fc79c4f71a29431e6efc39b88.jpeg" alt="мультиварка polaris pmc 0512ad Очиститель от накипи для фильтр-кофеварок и чайников Melitta, таблетки, 4х12 гр." title="мультиварка polaris pmc 0512ad Очиститель от накипи для фильтр-кофеварок и чайников Melitta, таблетки, 4х12 гр."></a><h2>Очиститель от накипи для фильтр-кофеварок и чайников Melitta, таблетки, 4х12 гр.</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemolka-ath-540r.php"><img src="photos/7189b59307d880db0fc6d320b1efc4f4.jpeg" alt="микроволновая печь рейтинг Кофемолка ATH-277" title="микроволновая печь рейтинг Кофемолка ATH-277"></a><h2>Кофемолка ATH-277</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskaya-nozhevaya-kofemolka-bodum-bistro-euro-limonnaya-1830r.php"><img src="photos/c585fc23a1c72232536c2283ac42fbc1.jpeg" alt="кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная" title="кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная"></a><h2>Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос thomas s1 Мини весы Momert 6000</h1>
						<div class="tb"><p>Цена: от <span class="price">1600</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_798.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Складной корпус мини весов и экран с яркой подсветкой – не главные преимущества весов. <strong>Momert 6000 </strong>с точностью до 0,1 грамма взвесит продукты, ювелирные изделия, лекарственные средства и другие продукты и предметы. Режим автокалибровки и вычета тары являются дополнительными преимуществами этой модели весов. Примечательно, что результаты взвешивания можно запрограммировать как в граммах, так и в унциях, если это необходимо пользователю.</p><p><strong>Особенности:</strong> </p><ul type=disc><li>Раскладные карманные весы (минивесы) <li>Функция вычета тары <li>Экран с яркой подсветкой <li>Функция подсчета количества одинаковых элементов <li>Единицы измерения: граммы, унции, караты, граны <li>Режим автокалибровки <li>Защита от перегрузки <li>Платформа из нержавеющей стали <li>Удобный складной корпус для компактного хранения <li>Индикатор разряда батареи <li>Автоматическое отключение</li></ul><p><b>Технические характеристики:</b></p><ul><li>Питание: 2 батарейки ААА <li>Цена деления: 0,1 г <li>Предел взвешивания: 500 г <li>Размер платормы: 80 х 60 мм <li>Габаритные размеры: 80 x 120 x 20 мм <li>Вес: 200 г</li></ul><p style=\LINE-HEIGHT: 18pt; text-indent: -18pt; margin: 0cm 0pt mso-margin-top-alt: auto; mso-margin-bottom-alt: mso-list: l0 level1 lfo1; tab-stops: list 36.0pt\ class =MsoNormal><span style=\FONT-FAMILY: verdana; color: #222222; font-size: 10pt\><?xml:namespace prefix = st1 ns = \urn:schemas-microsoft-com:office:smarttags\ /><st1:metricconverter w:st=\on\ productid=\200 г\></st1:metricconverter><?xml:namespace prefix = o ns = \urn:schemas-microsoft-com:office:office\ /><o:p></o:p></span></p><p style=\LINE-HEIGHT: 18pt; text-indent: -18pt; margin: 0cm 0pt mso-margin-top-alt: auto; mso-margin-bottom-alt: mso-list: l0 level1 lfo1; tab-stops: list 36.0pt\ class =MsoNormal><strong>В комплект входит:</strong> основное устройство, батарейки, инструкция.</p><p><p><strong>Производство:</strong> Momert (Венгрия)</p><p><strong>Гарантия: </strong>2 года в авторизованном сервис-центре</p><p></p> пылесос thomas s1</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/197b288168a6454a97f75d0fce3ea362.jpeg" alt="купить электрическую кофеварку Электросушка Maxima MFD-0155" title="купить электрическую кофеварку Электросушка Maxima MFD-0155"><div class="box"><a href="http://kitchentech.elitno.net/elektrosushka-maxima-mfd-990r.php"><h3 class="title">купить электрическую кофеварку Электросушка Maxima MFD-0155</h3><p>от <span class="price">990</span> руб.</p></a></div></li>
						<li><img src="photos/060f95312423ba3e968eaf23618bd36d.jpeg" alt="что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White" title="что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White"><div class="box" page="myasorubka-elektricheskaya-binatone-mgr-white-3700r"><span class="title">что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White</span><p>от <span class="price">3700</span> руб.</p></div></li>
						<li><img src="photos/bbb4b27b3d39658b85227dbb77539d16.jpeg" alt="хлебопечка в техносиле Весы электронные для багажа Beurer LS 10" title="хлебопечка в техносиле Весы электронные для багажа Beurer LS 10"><div class="box" page="vesy-elektronnye-dlya-bagazha-beurer-ls-1100r"><span class="title">хлебопечка в техносиле Весы электронные для багажа Beurer LS 10</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/8e4c77fcf3cd711bd8454688ff0f7bc7.jpeg" alt="пылесос thomas отзывы Чайник электрический Vitek VT-1159" title="пылесос thomas отзывы Чайник электрический Vitek VT-1159"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1900r"><span class="title">пылесос thomas отзывы Чайник электрический Vitek VT-1159</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/c75538a0a02b722bb4d5b9c47eb925e7.jpeg" alt="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л" title="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r"><span class="title">куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л</span><p>от <span class="price">2570</span> руб.</p></div></li>
						<li class="large"><img src="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" alt="кофемашина la cimbali Электрический чайник Atlanta АТН-788" title="кофемашина la cimbali Электрический чайник Atlanta АТН-788"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1350r"><span class="title">кофемашина la cimbali Электрический чайник Atlanta АТН-788</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li class="large"><img src="photos/403a4b4ef798c09cf151962161efdcea.jpeg" alt="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый" title="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый"><div class="box" page="elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r"><span class="title">термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li><img src="photos/d509d0771406a8c20b2506d316fad0aa.jpeg" alt="лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario" title="лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario"><div class="box" page="chaynik-melitta-look-aqua-vario-2838r"><span class="title">лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario</span><p>от <span class="price">2838</span> руб.</p></div></li>
						<li><img src="photos/e2b67f21c94f08d0f992c10013ebe15c.jpeg" alt="magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26" title="magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26"><div class="box" page="pylesos-dyson-carbon-fibre-dc-23990r"><span class="title">magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26</span><p>от <span class="price">23990</span> руб.</p></div></li>
						<li><img src="photos/5363fe7d5348c517715f7be1bf400046.jpeg" alt="соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210" title="соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210"><div class="box" page="utyug-parovoy-tefal-aquaspeed-fv-2400r"><span class="title">соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210</span><p>от <span class="price">2400</span> руб.</p></div></li>
						<li><img src="photos/4c318bd3b290409dcd94808ff157a415.jpeg" alt="печенье через мясорубку рецепт Утюг паровой Tefal Ultimate Autoclean FV9450E2" title="печенье через мясорубку рецепт Утюг паровой Tefal Ultimate Autoclean FV9450E2"><div class="box" page="utyug-parovoy-tefal-ultimate-autoclean-fve-3950r"><span class="title">печенье через мясорубку рецепт Утюг паровой Tefal Ultimate Autoclean FV9450E2</span><p>от <span class="price">3950</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("mini-vesy-momert-1600r.php", 0, -4); if (file_exists("comments/mini-vesy-momert-1600r.php")) require_once "comments/mini-vesy-momert-1600r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="mini-vesy-momert-1600r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>