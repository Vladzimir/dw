<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("nabor-meshkovpylesbornikov-dlya-thomas-1100r-2.php","кофемашина bosch tca 6401");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("nabor-meshkovpylesbornikov-dlya-thomas-1100r-2.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофемашина bosch tca 6401 Набор мешков-пылесборников 35 (787-183) для Thomas  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофемашина bosch tca 6401, видео приготовление в аэрогриле, мясорубка moulinex hv, аппараты для педикюра с пылесосом, купить утюг для волос, крылышки в пароварке, кофемолка bosch, контрольная закупка пылесос, пылесосы с аквафильтром soteco, фильтр для пылесоса thomas twin, утюг с парогенератором delonghi, нож для мясорубки kenwood, микроволновая печь мощность, рецепт печенья в вафельнице,  мясорубка moulinex 2051">
		<meta name="description" content="кофемашина bosch tca 6401 Набор мешков-пылесборников включает в себя пять мешков, микрофильтр и пять освеж...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/512f8d3c0276804b57a2729ea05d9ba6.jpeg" title="кофемашина bosch tca 6401 Набор мешков-пылесборников 35 (787-183) для Thomas"><img src="photos/512f8d3c0276804b57a2729ea05d9ba6.jpeg" alt="кофемашина bosch tca 6401 Набор мешков-пылесборников 35 (787-183) для Thomas" title="кофемашина bosch tca 6401 Набор мешков-пылесборников 35 (787-183) для Thomas -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-36590r.php"><img src="photos/c26c66e7052b7c7adfb4026bf7ee1ec7.jpeg" alt="видео приготовление в аэрогриле Кофемашина Nivona NICR750 CafeRomatica" title="видео приготовление в аэрогриле Кофемашина Nivona NICR750 CafeRomatica"></a><h2>Кофемашина Nivona NICR750 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-solo-pure-silverblack-27000r.php"><img src="photos/e049963f26559d8e89e28ab3a3213f10.jpeg" alt="мясорубка moulinex hv Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)" title="мясорубка moulinex hv Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)</h2></li>
							<li><a href="http://kitchentech.elitno.net/vspenivatel-melitta-cremio-chernyy-4155r.php"><img src="photos/4e6a1db3aa397f67ece5fe8079d3244b.jpeg" alt="аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный" title="аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный"></a><h2>Вспениватель Melitta Cremio черный</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофемашина bosch tca 6401 Набор мешков-пылесборников 35 (787-183) для Thomas</h1>
						<div class="tb"><p>Цена: от <span class="price">1100</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14811.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Набор мешков-пылесборников включает в себя пять мешков, микрофильтр и пять освежающих салфеток. Они отличаются высокой прочностью, совместимы с моделями пылесосов фирмы Thomas: Thomas FONTANA, а также к пылесосам других фирм-производителей.</p><p><b>Характеристики:</b></p><ul type=disc><li>Набор: 5 мешков, 1 волокн. микрофильтр, 5 салфеток.</li></ul><p><b>Подходят к моделям пылесосов: </b></p><ul type=disc><li>Thomas Thomas FONTANA </li><li>Пылесосы других фирм</li></ul><p><b>Производитель:</b> Thomas.</p> кофемашина bosch tca 6401</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/3bdb5a7ebf59a397ed1b6263ffa77483.jpeg" alt="купить утюг для волос Кофемолка Vitesse VS-271" title="купить утюг для волос Кофемолка Vitesse VS-271"><div class="box" page="kofemolka-vitesse-vs-1100r"><span class="title">купить утюг для волос Кофемолка Vitesse VS-271</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/1c1d1049958bdd0b6b9f6e6cb13db14b.jpeg" alt="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый" title="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый"><div class="box" page="mikrovolnovaya-pech-s-grilem-moulinex-mw-l-belyy-3890r"><span class="title">крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый</span><p>от <span class="price">3890</span> руб.</p></div></li>
						<li><img src="photos/5ac0b374c54627e297ebdd1a47a1cc62.jpeg" alt="кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро" title="кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро"><div class="box" page="mikrovolnovaya-pech-s-konvekciey-moulinex-mw-hlebopechka-l-serebro-12050r"><span class="title">кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро</span><p>от <span class="price">12050</span> руб.</p></div></li>
						<li><img src="photos/b6c05d69ce9bf94410c78acce4c5e9cb.jpeg" alt="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер" title="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер"><div class="box" page="bodum-bistro-euro-elektricheskiy-mikser-2740r"><span class="title">контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li class="large"><img src="photos/03d6a39216ccd97c8a662a35f965b076.jpeg" alt="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611" title="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611"><div class="box" page="sokovyzhimalka-vitek-vt-600r"><span class="title">пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611</span><p>от <span class="price">600</span> руб.</p></div></li>
						<li class="large"><img src="photos/c737b54864f365f17a12fbd2acc0e1ac.jpeg" alt="фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134" title="фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134"><div class="box" page="chaynik-elektricheskiy-vitek-vt-900r"><span class="title">фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134</span><p>от <span class="price">900</span> руб.</p></div></li>
						<li class="large"><img src="photos/89368a4d8b53495528b047bf143af4e5.jpeg" alt="утюг с парогенератором delonghi Электрический чайник Atlanta АТН-623" title="утюг с парогенератором delonghi Электрический чайник Atlanta АТН-623"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-690r"><span class="title">утюг с парогенератором delonghi Электрический чайник Atlanta АТН-623</span><p>от <span class="price">690</span> руб.</p></div></li>
						<li><img src="photos/4aa517f040bb8f7cdf25d41fea297b7f.jpeg" alt="нож для мясорубки kenwood Электрический чайник Atlanta АТН-781" title="нож для мясорубки kenwood Электрический чайник Atlanta АТН-781"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1000r"><span class="title">нож для мясорубки kenwood Электрический чайник Atlanta АТН-781</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/6ecc580d026584b3c4a5294019191ac2.jpeg" alt="микроволновая печь мощность Vitek VT-1113 чайник, 1,7 л, цв. черный" title="микроволновая печь мощность Vitek VT-1113 чайник, 1,7 л, цв. черный"><div class="box" page="vitek-vt-chaynik-l-cv-chernyy-3150r"><span class="title">микроволновая печь мощность Vitek VT-1113 чайник, 1,7 л, цв. черный</span><p>от <span class="price">3150</span> руб.</p></div></li>
						<li><img src="photos/75de77ac7d47967464a4abeb2e9a64d1.jpeg" alt="рецепт печенья в вафельнице Чайник Melitta Look Aqua (Basic)" title="рецепт печенья в вафельнице Чайник Melitta Look Aqua (Basic)"><div class="box" page="chaynik-melitta-look-aqua-basic-2190r"><span class="title">рецепт печенья в вафельнице Чайник Melitta Look Aqua (Basic)</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/27a529eb06db7d79aab6d5d214852413.jpeg" alt="какие лучше микроволновые печи Minamoto R03 (AAA)" title="какие лучше микроволновые печи Minamoto R03 (AAA)"><div class="box" page="minamoto-r-aaa-4r"><span class="title">какие лучше микроволновые печи Minamoto R03 (AAA)</span><p>от <span class="price">4</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("nabor-meshkovpylesbornikov-dlya-thomas-1100r-2.php", 0, -4); if (file_exists("comments/nabor-meshkovpylesbornikov-dlya-thomas-1100r-2.php")) require_once "comments/nabor-meshkovpylesbornikov-dlya-thomas-1100r-2.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="nabor-meshkovpylesbornikov-dlya-thomas-1100r-2.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>