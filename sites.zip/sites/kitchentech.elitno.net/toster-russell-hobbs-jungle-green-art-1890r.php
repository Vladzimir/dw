<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("toster-russell-hobbs-jungle-green-art-1890r.php","пылесос irobot roomba");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("toster-russell-hobbs-jungle-green-art-1890r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос irobot roomba Тостер Russell Hobbs Jungle Green, арт. 18338-56  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос irobot roomba, щетка для пылесоса electrolux, пылесос samsung sc4520, белоруссия соковыжималка, утюг philips 9220, мультиварка куку 1054, запеканка в хлебопечке, шампунь для пылесоса, пылесос циклонного типа, как блендером сделать пюре, блюда с помощью блендера, мясорубка помощница, как выбрать кофеварку, утюг braun 18895,  курица в микроволновой печи">
		<meta name="description" content="пылесос irobot roomba Тостер Jungle Green, мощностью 1100 Вт,  порадует Вас двумя вкусными тостами или...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" title="пылесос irobot roomba Тостер Russell Hobbs Jungle Green, арт. 18338-56"><img src="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" alt="пылесос irobot roomba Тостер Russell Hobbs Jungle Green, арт. 18338-56" title="пылесос irobot roomba Тостер Russell Hobbs Jungle Green, арт. 18338-56 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/chasha-dlya-multivarki-redmond-iprmcm-990r.php"><img src="photos/74bbce31ddb28c5063f247363080794a.jpeg" alt="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502" title="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502"></a><h2>Чаша для мультиварки Redmond IPRMC-M4502</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-vitek-vt-serebryanaya-3650r.php"><img src="photos/7c640af98399cc1caf99796cb169cc20.jpeg" alt="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная" title="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная"></a><h2>Мясорубка электрическая Vitek VT-1672 серебряная</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-atlanta-ath-2500r.php"><img src="photos/32c26854e293b25040685f60b879a50b.jpeg" alt="белоруссия соковыжималка Мясорубка  Atlanta ATH-370" title="белоруссия соковыжималка Мясорубка  Atlanta ATH-370"></a><h2>Мясорубка  Atlanta ATH-370</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос irobot roomba Тостер Russell Hobbs Jungle Green, арт. 18338-56</h1>
						<div class="tb"><p>Цена: от <span class="price">1890</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_21515.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Тостер Jungle Green, мощностью 1100 Вт,  порадует Вас двумя вкусными тостами или багетами, приготовленными на завтрак.  Корпус тостера выполнен из металла, что обеспечит надежность и долговечность  устройства. Приятный нежно зеленый цвет. Управление тостером механическое, с возможностью  регулировки степени поджаривания. Предусмотрены функции размораживания и  разогрева. Поддон для крошек упрощает очистку устройства.</p><p><br><strong>Характеристики:</strong></p><ul><li>Мощность: 1100 Вт;</li><li>Количество отделений: 2;</li><li>Количество тостов: 2;</li><li>Тип управления: механическое;</li><li>Регулировка степени поджаривания;</li><li>Кнопка отмены;</li><li>Функция размораживания;</li><li>Функция подогрева;</li><li>Автоматическое центрирование тостов;</li><li>\Экстра-подъём\ для маленьких ломтиков  хлеба;</li><li>Решётка для подогрева булочек;</li><li>Поддон для крошек;</li><li>Материал корпуса: металл;</li><li>Отсек для сетевого шнура;</li><li>Подогрев багетов.</li></ul><p><strong>Производитель:</strong><strong>Russell</strong><strong>Hobbs (Англия)</strong></p> пылесос irobot roomba</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/f99ea88369bed621a6594f78c2508e9a.jpeg" alt="утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO" title="утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO"><div class="box" page="elektricheskaya-sokovyzhimalka-limonnaya-bodum-bistro-euro-3340r"><span class="title">утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li><img src="photos/f12c67c091dc7674e75925e27c6ee910.jpeg" alt="мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный" title="мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-chernyy-2150r"><span class="title">мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="запеканка в хлебопечке Чайник электрический Maxima MK-G311" title="запеканка в хлебопечке Чайник электрический Maxima MK-G311"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1650r"><span class="title">запеканка в хлебопечке Чайник электрический Maxima MK-G311</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/52100c33edc3ca0743ca02e24c7f8dba.jpeg" alt="шампунь для пылесоса Электрический чайник Atlanta АТН-720" title="шампунь для пылесоса Электрический чайник Atlanta АТН-720"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-550r"><span class="title">шампунь для пылесоса Электрический чайник Atlanta АТН-720</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li class="large"><img src="photos/0207c29eb474672a9dc7b75c9efd4bab.jpeg" alt="пылесос циклонного типа Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-360" title="пылесос циклонного типа Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-360"><div class="box" page="chaynik-diskovyy-keramicheskiy-l-golubye-cvety-zauber-eco-1760r-2"><span class="title">пылесос циклонного типа Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-360</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li class="large"><img src="photos/8a7e2a46651bfb4c8fa5108f6af45161.jpeg" alt="как блендером сделать пюре Детектор жучков BugHunter Professional BH-02" title="как блендером сделать пюре Детектор жучков BugHunter Professional BH-02"><div class="box" page="detektor-zhuchkov-bughunter-professional-bh-9990r"><span class="title">как блендером сделать пюре Детектор жучков BugHunter Professional BH-02</span><p>от <span class="price">9990</span> руб.</p></div></li>
						<li class="large"><img src="photos/b8e20b7d51cc5f25b0392815fadedf6e.jpeg" alt="блюда с помощью блендера Турбощетка Redmond  RTB-4801" title="блюда с помощью блендера Турбощетка Redmond  RTB-4801"><div class="box" page="turboschetka-redmond-rtb-920r"><span class="title">блюда с помощью блендера Турбощетка Redmond  RTB-4801</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/0cd736da9ac10dc7bbde0f3b6049ff52.jpeg" alt="мясорубка помощница Воздушный фильтр Redmond H10RV-308" title="мясорубка помощница Воздушный фильтр Redmond H10RV-308"><div class="box" page="vozdushnyy-filtr-redmond-hrv-390r"><span class="title">мясорубка помощница Воздушный фильтр Redmond H10RV-308</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/022434340143cfbbf0a87e93fd1fc9c0.jpeg" alt="как выбрать кофеварку Щетка для собак Dyson Groom Retail" title="как выбрать кофеварку Щетка для собак Dyson Groom Retail"><div class="box" page="schetka-dlya-sobak-dyson-groom-retail-1690r"><span class="title">как выбрать кофеварку Щетка для собак Dyson Groom Retail</span><p>от <span class="price">1690</span> руб.</p></div></li>
						<li><img src="photos/6a73d6f5ed044b39207ab31ca41595f1.jpeg" alt="утюг braun 18895 Пылесос моющий Thomas Bravo 20" title="утюг braun 18895 Пылесос моющий Thomas Bravo 20"><div class="box" page="pylesos-moyuschiy-thomas-bravo-8050r"><span class="title">утюг braun 18895 Пылесос моющий Thomas Bravo 20</span><p>от <span class="price">8050</span> руб.</p></div></li>
						<li><img src="photos/d9b92094264662e2a4b171c525a4ead7.jpeg" alt="держатель для пылесоса Пылесос Thomas Biovac 1620 C Aquafilter" title="держатель для пылесоса Пылесос Thomas Biovac 1620 C Aquafilter"><div class="box" page="pylesos-thomas-biovac-c-aquafilter-8430r"><span class="title">держатель для пылесоса Пылесос Thomas Biovac 1620 C Aquafilter</span><p>от <span class="price">8430</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("toster-russell-hobbs-jungle-green-art-1890r.php", 0, -4); if (file_exists("comments/toster-russell-hobbs-jungle-green-art-1890r.php")) require_once "comments/toster-russell-hobbs-jungle-green-art-1890r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="toster-russell-hobbs-jungle-green-art-1890r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>