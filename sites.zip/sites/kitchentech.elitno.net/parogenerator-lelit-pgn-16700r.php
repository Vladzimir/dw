<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("parogenerator-lelit-pgn-16700r.php","соковыжималки в киеве");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("parogenerator-lelit-pgn-16700r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>соковыжималки в киеве Парогенератор Lelit PG024N  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="соковыжималки в киеве, стоимость миксера, рецепт индейки в мультиварке, капельная кофеварка инструкция, каталог мясорубок, ножки в аэрогриле, какой пылесос самый лучший, микроволновая печь тест, как разобрать утюг, кофеварка интернет магазин, сервисный центр кофемашин, ремонт хлебопечки мулинекс, какой лучше парогенератор, mini пылесос,  запчасти для кофемашины">
		<meta name="description" content="соковыжималки в киеве Парогенератор на колесах, оборудованный регулятором количества пара и манометром...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/565e52ebc108aee0062c9aab0f314cab.jpeg" title="соковыжималки в киеве Парогенератор Lelit PG024N"><img src="photos/565e52ebc108aee0062c9aab0f314cab.jpeg" alt="соковыжималки в киеве Парогенератор Lelit PG024N" title="соковыжималки в киеве Парогенератор Lelit PG024N -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofemolka-nivona-nicg-cafegrano-4490r.php"><img src="photos/696246935af3c686fbf13206e4f5dbc0.jpeg" alt="стоимость миксера Кофемолка Nivona NICG120 CafeGrano" title="стоимость миксера Кофемолка Nivona NICG120 CafeGrano"></a><h2>Кофемолка Nivona NICG120 CafeGrano</h2></li>
							<li><a href="http://kitchentech.elitno.net/zauber-kofemolka-x-850r.php"><img src="photos/1c87b1da99c709915f1f2bf9d89b2035.jpeg" alt="рецепт индейки в мультиварке Zauber Кофемолка  X-470" title="рецепт индейки в мультиварке Zauber Кофемолка  X-470"></a><h2>Zauber Кофемолка  X-470</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-moulinex-fp-6140r.php"><img src="photos/59cc932c7224c4f3a91684264a52c663.jpeg" alt="капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141" title="капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141"></a><h2>Кухонный комбайн Moulinex FP711141</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>соковыжималки в киеве Парогенератор Lelit PG024N</h1>
						<div class="tb"><p>Цена: от <span class="price">16700</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16433.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Парогенератор на колесах, оборудованный регулятором количества пара и манометром, имеет разъем для подсоединения утюга, а также комплекта щеток для уборки и щетки-отпаривателя. Модель <b>PG024N </b>отлично подойдет для экологически чистой уборки и влажно-тепловой обработки.</p><p>Вы по достоинству оцените внутренний клапан с регулятором количества пара, и возможность непрерывной работы в течение 2 часов. Бойлер из нержавеющей стали покрыт специальным составом, который препятствует образованию известкового налета. Работает на обычной водопроводной воде.</p><p><b>Технические характеристики:</b></p><ul type=disc><li>Номинальный объем бойлера: 2,5 л <li>Фактический объем бойлера: 2 л <li>Время непрерывной работы бойлера: 2 часа <li>Кол-во присоединяемых утюгов/ аксессуаров: 1 <li>Потребляемая мощность: 1,4 кВт <li>Напряжение: 220-230В <li>Рабочее давление пара/Максимальное давление: 3,5 бар/4,5 бар <li>Дополнительная комплектация: Утюг LELIT PG024/3. Тефлоновая подошва LELIT PG205/1. Силиконовый коврик под утюг LELIT CD363. Набор аксессуаров для экологической чистки. LELIT PG024/2 (11 насадок) <li>Технические особенности: Корпус и бойлер из нержавеющей стали INOX 18/10, нагревательный элемент incoloy, наличие колес облегчает передвижение; регулятор количества пара. <li>Размер: 50х50х35 см <li>Вес: 7 кг</li></ul><p><b>Производитель:</b> Lelit.</p><p><b>Страна:</b> Италия.</p><p><b>Гарантия:</b> 1 год.</p> соковыжималки в киеве</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/e07564a5fe71e20051b3b21f0806536a.jpeg" alt="каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam" title="каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam"><div class="box" page="sokovyzhimalka-moulinex-jue-tom-yam-1850r"><span class="title">каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li><img src="photos/3efeed2a40b596512ea138d7f6d2f182.jpeg" alt="ножки в аэрогриле Термопот Binatone TP-4055 White" title="ножки в аэрогриле Термопот Binatone TP-4055 White"><div class="box" page="termopot-binatone-tp-white-1990r"><span class="title">ножки в аэрогриле Термопот Binatone TP-4055 White</span><p>от <span class="price">1990</span> руб.</p></div></li>
						<li><img src="photos/27ce5b772a93a2336124e9a6817baf03.jpeg" alt="какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000" title="какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000"><div class="box" page="frityurnica-tefal-actifry-fz-7700r"><span class="title">какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000</span><p>от <span class="price">7700</span> руб.</p></div></li>
						<li><img src="photos/cb5b82e2b4fb8916dd96c68408275e51.jpeg" alt="микроволновая печь тест Чайник электрический Vitek VT-1149 красный" title="микроволновая печь тест Чайник электрический Vitek VT-1149 красный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-krasnyy-1650r"><span class="title">микроволновая печь тест Чайник электрический Vitek VT-1149 красный</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" alt="как разобрать утюг Чайник электрический Maxima MК- M211" title="как разобрать утюг Чайник электрический Maxima MК- M211"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-1090r"><span class="title">как разобрать утюг Чайник электрический Maxima MК- M211</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li class="large"><img src="photos/2e4cd4da907bfa0983f22c5ac1875ffe.jpeg" alt="кофеварка интернет магазин Электрический чайник Atlanta АТН-663" title="кофеварка интернет магазин Электрический чайник Atlanta АТН-663"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-720r"><span class="title">кофеварка интернет магазин Электрический чайник Atlanta АТН-663</span><p>от <span class="price">720</span> руб.</p></div></li>
						<li class="large"><img src="photos/e19a6a84ed749d263503c61eb89d253b.jpeg" alt="сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4" title="сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-80r"><span class="title">сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4</span><p>от <span class="price">80</span> руб.</p></div></li>
						<li><img src="photos/f16a6ea5caecf1d914f1d403108995e6.jpeg" alt="ремонт хлебопечки мулинекс Насадка утюг Thomas Steam-Iron для Vaporo Trolley" title="ремонт хлебопечки мулинекс Насадка утюг Thomas Steam-Iron для Vaporo Trolley"><div class="box" page="nasadka-utyug-thomas-steamiron-dlya-vaporo-trolley-2660r"><span class="title">ремонт хлебопечки мулинекс Насадка утюг Thomas Steam-Iron для Vaporo Trolley</span><p>от <span class="price">2660</span> руб.</p></div></li>
						<li><img src="photos/512f8d3c0276804b57a2729ea05d9ba6.jpeg" alt="какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas" title="какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r-2"><span class="title">какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/28da988d46134dfe1236e7598e0579cc.jpeg" alt="mini пылесос Турбощетка Redmond  RV-308" title="mini пылесос Турбощетка Redmond  RV-308"><div class="box" page="turboschetka-redmond-rv-390r"><span class="title">mini пылесос Турбощетка Redmond  RV-308</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/db8d0d28b1b05f19385269d855039f58.jpeg" alt="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833" title="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-5580r"><span class="title">фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833</span><p>от <span class="price">5580</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("parogenerator-lelit-pgn-16700r.php", 0, -4); if (file_exists("comments/parogenerator-lelit-pgn-16700r.php")) require_once "comments/parogenerator-lelit-pgn-16700r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="parogenerator-lelit-pgn-16700r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>