<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php","нож для мясорубки kenwood");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>нож для мясорубки kenwood Кухонный комбайн Tefal Storeinn DO302 EAE  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="нож для мясорубки kenwood, рецепт пельменей в хлебопечке, пылесос с водным фильтром, грибы в мультиварке, греется пылесос, хлебопечка мистери, блендер philips hr1659, устройство блендера, clatronic хлебопечка, сладкая выпечка в хлебопечке, средство от накипи для утюга, пылесос zelmer цена, сколько стоит моющий пылесос, сколько стоит моющий пылесос,  хлебопечка клатроник">
		<meta name="description" content="нож для мясорубки kenwood Кухонный комбайн Store\'inn DO302 EAE от известного французского производителя T...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/33b43228a18b1110c1c8a14516611c99.jpeg" title="нож для мясорубки kenwood Кухонный комбайн Tefal Storeinn DO302 EAE"><img src="photos/33b43228a18b1110c1c8a14516611c99.jpeg" alt="нож для мясорубки kenwood Кухонный комбайн Tefal Storeinn DO302 EAE" title="нож для мясорубки kenwood Кухонный комбайн Tefal Storeinn DO302 EAE -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-6690r.php"><img src="photos/d325e4ff8de4614af80db126de07173a.jpeg" alt="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8" title="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8"></a><h2>Мясорубка Redmond RMG-1203-8</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-vitek-vt-1400r.php"><img src="photos/a8857bffd481b9dda4b86f6d3c6ed123.jpeg" alt="пылесос с водным фильтром Пароварка Vitek VT-1555" title="пылесос с водным фильтром Пароварка Vitek VT-1555"></a><h2>Пароварка Vitek VT-1555</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektroplitka-indukcionnaya-maxima-mic-1590r.php"><img src="photos/07f90c95ce6a7ffe3129c0eb4bb8942c.jpeg" alt="грибы в мультиварке Электроплитка индукционная Maxima MIC-0146" title="грибы в мультиварке Электроплитка индукционная Maxima MIC-0146"></a><h2>Электроплитка индукционная Maxima MIC-0146</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>нож для мясорубки kenwood Кухонный комбайн Tefal Storeinn DO302 EAE</h1>
						<div class="tb"><p>Цена: от <span class="price">3570</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_10476.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Кухонный комбайн </b><b>Store\'</b><b>inn </b><b>DO302 </b><b>EAE</b> от известного французского производителя Tefal станет вашим незаменимым помощником в быту. Кроме того, современный дизайн прибора позволит ему украсить собой интерьер любой кухни. Модель обладает мощностью 750 Вт, имеет два режима скорости, возможностью работы в импульсном режиме, оснащена основной чашей на три литра и кувшином блендера на 1,25 литра. </p><p>В комплекте с комбайном поставляется многофункциональный нож из высококачественной стали Helix blade, диск для взбивания яиц и приготовления майонеза, металлические картриджи для нарезки и терки, лопатка, а также книга с рецептами в инструкции. К преимуществам модели можно отнести запатентованную эффективную систему смешивания (изогнутое дно, смещенные ножи, асимметричная циркуляция) и наличие специального отсека для хранения аксессуаров.</p><p><b>Комплектация:</b></p><ul type=disc><li>Многофункциональный нож из нержавеющей стали Helix blade; <li>Диск для взбивания яиц, приготовления майонеза; <li>Металлические картриджи для нарезки и терки; <li>Лопатка; <li>Книга рецептов в инструкции.</li></ul><p><b></b></p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 750 Вт; <li>Количество скоростей: 2; <li>Объем: основная чаша - 3 л, кувшин блендера – 1,25 л; <li>Возможность работы в импульсном режиме; <li>Запатентованная эффективная система смешивания: изогнутое дно, смещенные ножи, асимметричная циркуляция; <li>Материал: передняя панель из нержавеющей стали; <li>Отсек для аксессуаров.</li></ul><p><b>Производитель:</b> Tefal.</p><p><b>Страна: </b>Франция.</p><p><b>Гарантия: </b>2 года.</p> нож для мясорубки kenwood</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/f529cddb8b0b7bbdfe7eea8e3d43b5b1.jpeg" alt="греется пылесос Чайник электрический Atlanta ATH-752" title="греется пылесос Чайник электрический Atlanta ATH-752"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1600r-2"><span class="title">греется пылесос Чайник электрический Atlanta ATH-752</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/aa004256b858fb51c2e43e9faff2b9a8.jpeg" alt="хлебопечка мистери Чайник электрический Maxima MК-113" title="хлебопечка мистери Чайник электрический Maxima MК-113"><div class="box" page="chaynik-elektricheskiy-maxima-mk-760r-3"><span class="title">хлебопечка мистери Чайник электрический Maxima MК-113</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/eb489286225dbbc8037e4654ee2b1544.jpeg" alt="блендер philips hr1659 Чайник электрический Redmond  RK-M114" title="блендер philips hr1659 Чайник электрический Redmond  RK-M114"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2990r"><span class="title">блендер philips hr1659 Чайник электрический Redmond  RK-M114</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/0c8f8180d11bb1b314126b1e547c3319.jpeg" alt="устройство блендера Чайник электрический  Vitesse VS-131 1,7 л" title="устройство блендера Чайник электрический  Vitesse VS-131 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1220r"><span class="title">устройство блендера Чайник электрический  Vitesse VS-131 1,7 л</span><p>от <span class="price">1220</span> руб.</p></div></li>
						<li class="large"><img src="photos/1bbdc32e5167c3f95a77515679aaf9df.jpeg" alt="clatronic хлебопечка Электрический чайник Atlanta АТН-700" title="clatronic хлебопечка Электрический чайник Atlanta АТН-700"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1280r"><span class="title">clatronic хлебопечка Электрический чайник Atlanta АТН-700</span><p>от <span class="price">1280</span> руб.</p></div></li>
						<li class="large"><img src="photos/70eaaca49bbd014982b9856679d5c7e6.jpeg" alt="сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO" title="сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO"><div class="box" page="elektricheskiy-chaynik-l-bodum-bistro-euro-2740r"><span class="title">сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li class="large"><img src="photos/05c48dbba69cff2727e6c1b6d1112395.jpeg" alt="средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2" title="средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2"><div class="box" page="batareyki-gp-batteries-super-alkaline-lr-abc-170r"><span class="title">средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2</span><p>от <span class="price">170</span> руб.</p></div></li>
						<li><img src="photos/fdcb89c9c94f7f3223bb9f8f472f7a54.jpeg" alt="пылесос zelmer цена Пятновыводитель Dyson Dyzolv" title="пылесос zelmer цена Пятновыводитель Dyson Dyzolv"><div class="box" page="pyatnovyvoditel-dyson-dyzolv-790r"><span class="title">пылесос zelmer цена Пятновыводитель Dyson Dyzolv</span><p>от <span class="price">790</span> руб.</p></div></li>
						<li><img src="photos/39a5505798446240c306b0610cc8e434.jpeg" alt="сколько стоит моющий пылесос Пылесос Vitek VT-1834" title="сколько стоит моющий пылесос Пылесос Vitek VT-1834"><div class="box" page="pylesos-vitek-vt-5890r"><span class="title">сколько стоит моющий пылесос Пылесос Vitek VT-1834</span><p>от <span class="price">5890</span> руб.</p></div></li>
						<li><img src="photos/03817b6f2ca60ce9b5c33914a6a1ea52.jpeg" alt="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter" title="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter"><div class="box" page="pylesos-thomas-genius-aquafilter-9480r"><span class="title">сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter</span><p>от <span class="price">9480</span> руб.</p></div></li>
						<li><img src="photos/eb12162abf9f68b1f020c54d55eeb406.jpeg" alt="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM" title="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-tm-7800r"><span class="title">запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM</span><p>от <span class="price">7800</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php", 0, -4); if (file_exists("comments/kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php")) require_once "comments/kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>