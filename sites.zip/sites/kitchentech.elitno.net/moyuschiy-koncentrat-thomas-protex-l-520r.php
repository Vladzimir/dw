<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("moyuschiy-koncentrat-thomas-protex-l-520r.php","пароварка горенье");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("moyuschiy-koncentrat-thomas-protex-l-520r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пароварка горенье Моющий концентрат Thomas Protex 1 л 787-502  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пароварка горенье, аэрогриль hotter инструкция, купить водяной пылесос, соковыжималка bosh, хлебопечка хлеб из гречневой муки, как приготовить в аэрогриле овощи, купить вертикальный утюг, продам вафельницу, очистка кофеварки, микроволновая печь мощность, рецепты для мультиварки cuckoo, доска для парогенератора, сосиски в мультиварке, moulinex mk7003 мультиварка,  трубка для пылесоса">
		<meta name="description" content="пароварка горенье Моющий концентрат Thomas Protex предназначен для эффективной очистки любых повер...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/569a7a448800e6c331839b4f1803d826.jpeg" title="пароварка горенье Моющий концентрат Thomas Protex 1 л 787-502"><img src="photos/569a7a448800e6c331839b4f1803d826.jpeg" alt="пароварка горенье Моющий концентрат Thomas Protex 1 л 787-502" title="пароварка горенье Моющий концентрат Thomas Protex 1 л 787-502 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/minipechkaduhovka-atlanta-atn-2860r.php"><img src="photos/99e42fd1d4a11c6642a9386db8a9c8d1.jpeg" alt="аэрогриль hotter инструкция Минипечка-духовка Atlanta АТН-1402" title="аэрогриль hotter инструкция Минипечка-духовка Atlanta АТН-1402"></a><h2>Минипечка-духовка Atlanta АТН-1402</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-snake-n-take-900r.php"><img src="photos/3a6f8f5bcd6b4c656110981eb9f3285b.jpeg" alt="купить водяной пылесос Блендер Snake n Take" title="купить водяной пылесос Блендер Snake n Take"></a><h2>Блендер Snake n Take</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-blender-s-aksessuarami-bodum-bistro-keuro-krasnyy-3780r.php"><img src="photos/cba8b4b1e5c8fd0ccc541a5e43233a90.jpeg" alt="соковыжималка bosh Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный" title="соковыжималка bosh Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный"></a><h2>Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пароварка горенье Моющий концентрат Thomas Protex 1 л 787-502</h1>
						<div class="tb"><p>Цена: от <span class="price">520</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14802.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий концентрат Thomas Protex предназначен для эффективной очистки любых поверхностей. Благодаря специальной рецептуре, с его помощью можно осуществлять глубокую очистку волокон водостойких текстильных напольных покрытий, ПВХ, обивки мягкой мебели, ковров (в том числе шерстяных). Перед тем, как приступать к уборке, необходимо развести концентрат в воде с расчетом 20 мл средства на 1 л воды. Protex совместим со всеми моющими пылесосами и моющими паровыми машинами любых фирм-производителей. Концентрат отличается высокой экологичностью (PH 5.5), приятным запахом, не влияет на цвет очищаемой поверхности. Средство выпускается в бутылке объемом 1 литр.</p><p><b>Характеристики:</b></p><ul type=\disc\><li>Для чистки пола, ковров и мягкой мебели; </li><li>Приятный запах; </li><li>Совместим со всеми моющими, а также моющими паровыми пылесосами любых фирм-производителей; </li><li>Экологичность: PH 5.5; </li><li>Состав: менее 5% анионных и неионогенных поверхностно-активных веществ, менее 5% фосфатов, фосфанатов и нитротриуксной кислоты, агенты растворения, ароматические вещества; </li><li>Дозировка: 20 мл на 1 л воды; </li><li>Объем: 1 л.</li></ul><p><b>Производитель:</b> Thomas.</p> пароварка горенье</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7ffc20dc8107b2fc1365cfb7486e823a.jpeg" alt="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101" title="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101"><div class="box"><a href="http://kitchentech.elitno.net/indukcionnaya-plita-kitfort-kt-2700r.php"><h3 class="title">хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101</h3><p>от <span class="price">2700</span> руб.</p></a></div></li>
						<li><img src="photos/86f0983e51433a2aeee203a14fbe12b2.jpeg" alt="как приготовить в аэрогриле овощи A&D SF-15KC Торговые весы до 15кг" title="как приготовить в аэрогриле овощи A&D SF-15KC Торговые весы до 15кг"><div class="box" page="ad-sfkc-torgovye-vesy-do-kg-10800r"><span class="title">как приготовить в аэрогриле овощи A&D SF-15KC Торговые весы до 15кг</span><p>от <span class="price">10800</span> руб.</p></div></li>
						<li><img src="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" alt="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56" title="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56"><div class="box" page="toster-russell-hobbs-jungle-green-art-1890r"><span class="title">купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li><img src="photos/47745aa09108a6bfabc67b839ea476bd.jpeg" alt="продам вафельницу Чайник электрический Vitek VT-1114" title="продам вафельницу Чайник электрический Vitek VT-1114"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1030r"><span class="title">продам вафельницу Чайник электрический Vitek VT-1114</span><p>от <span class="price">1030</span> руб.</p></div></li>
						<li class="large"><img src="photos/22d30b7337c9635a9decf8a39fad0a54.jpeg" alt="очистка кофеварки Электрический чайник Atlanta АТН-793" title="очистка кофеварки Электрический чайник Atlanta АТН-793"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1420r-2"><span class="title">очистка кофеварки Электрический чайник Atlanta АТН-793</span><p>от <span class="price">1420</span> руб.</p></div></li>
						<li class="large"><img src="photos/6ecc580d026584b3c4a5294019191ac2.jpeg" alt="микроволновая печь мощность Vitek VT-1113 чайник, 1,7 л, цв. черный" title="микроволновая печь мощность Vitek VT-1113 чайник, 1,7 л, цв. черный"><div class="box" page="vitek-vt-chaynik-l-cv-chernyy-3150r"><span class="title">микроволновая печь мощность Vitek VT-1113 чайник, 1,7 л, цв. черный</span><p>от <span class="price">3150</span> руб.</p></div></li>
						<li class="large"><img src="photos/5b880c439b70bdcfe7580a48a2aa9fb4.jpeg" alt="рецепты для мультиварки cuckoo Melitta Enjoy Aqua Чайник" title="рецепты для мультиварки cuckoo Melitta Enjoy Aqua Чайник"><div class="box" page="melitta-enjoy-aqua-chaynik-0r"><span class="title">рецепты для мультиварки cuckoo Melitta Enjoy Aqua Чайник</span><p>от <span class="price">0</span> руб.</p></div></li>
						<li><img src="photos/b29beb2174e6fe7aaeffea7945e79604.jpeg" alt="доска для парогенератора Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G" title="доска для парогенератора Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G"><div class="box" page="akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r"><span class="title">доска для парогенератора Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li><img src="photos/9e96bced898e611bddc3653f39cf1ccf.jpeg" alt="сосиски в мультиварке Пылесос KARCHER WD 3.300 M EU-I" title="сосиски в мультиварке Пылесос KARCHER WD 3.300 M EU-I"><div class="box" page="pylesos-karcher-wd-m-eui-4490r"><span class="title">сосиски в мультиварке Пылесос KARCHER WD 3.300 M EU-I</span><p>от <span class="price">4490</span> руб.</p></div></li>
						<li><img src="photos/63eadb71b95851c3e7f26e5885bd43ae.jpeg" alt="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832" title="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-6900r"><span class="title">moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832</span><p>от <span class="price">6900</span> руб.</p></div></li>
						<li><img src="photos/b81f4815d2a9df868070af2d7b1533ee.jpeg" alt="парогенератор aeg Утюг Vitek VT-1209" title="парогенератор aeg Утюг Vitek VT-1209"><div class="box" page="utyug-vitek-vt-1100r"><span class="title">парогенератор aeg Утюг Vitek VT-1209</span><p>от <span class="price">1100</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("moyuschiy-koncentrat-thomas-protex-l-520r.php", 0, -4); if (file_exists("comments/moyuschiy-koncentrat-thomas-protex-l-520r.php")) require_once "comments/moyuschiy-koncentrat-thomas-protex-l-520r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="moyuschiy-koncentrat-thomas-protex-l-520r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>