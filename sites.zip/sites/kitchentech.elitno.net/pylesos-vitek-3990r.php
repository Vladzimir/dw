<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-vitek-3990r.php","соковыжималка s510");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-vitek-3990r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>соковыжималка s510 Пылесос Vitek 1843  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="соковыжималка s510, самый дорогой пылесос, пылесос энергия, микроволновая печь работа, какой пылесос самый лучший, микроволновая печь тест, моющий пылесос для дома, мясорубка белвар отзывы, тостер philips hd 2586, шампунь для пылесоса, brand аэрогриль, индукционная плита с духовкой, кубань 8 вафельница, слоеное тесто в аэрогриле,  печенье через мясорубку рецепт">
		<meta name="description" content="соковыжималка s510 При покупке этого товара Вы в подарок получаете фирменный радиоприемник Vitek VT...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/7660e64f2f5c029aab5d6fad25c29084.jpeg" title="соковыжималка s510 Пылесос Vitek 1843"><img src="photos/7660e64f2f5c029aab5d6fad25c29084.jpeg" alt="соковыжималка s510 Пылесос Vitek 1843" title="соковыжималка s510 Пылесос Vitek 1843 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/multivarka-moulinex-ce-minute-cook-5850r.php"><img src="photos/8b7adfef9e224f5e6ff3fcdd084f6869.jpeg" alt="самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook" title="самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook"></a><h2>Мультиварка Moulinex CE4000 Minute Cook</h2></li>
							<li><a href="http://kitchentech.elitno.net/sokovyzhimalka-g-wn-6150r.php"><img src="photos/236219e0f937d3aff2a413880136e4e3.jpeg" alt="пылесос энергия Соковыжималка G 299-WN" title="пылесос энергия Соковыжималка G 299-WN"></a><h2>Соковыжималка G 299-WN</h2></li>
							<li><a href="http://kitchentech.elitno.net/bodum-bistro-euro-toster-belyy-3660r.php"><img src="photos/ac081ce5674939d79667b2759a2f84a8.jpeg" alt="микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый" title="микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый"></a><h2>Bodum BISTRO 10709-913EURO Тостер белый</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>соковыжималка s510 Пылесос Vitek 1843</h1>
						<div class="tb"><p>Цена: от <span class="price">3990</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_25602.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>При покупке этого товара Вы в подарок получаете фирменный радиоприемник Vitek VT-3583</b> <br/> </p> <img src='/images/podarok.jpg'/>   <p>Несомненно, одним из самых востребованных предметов бытовой  техники в современном мире является пылесос – именно он во многом помогает нам  сохранять чистоту в доме. Пылесос Vitek 1843 эффективно сочетает в себя широкую функциональность и  оригинальный дизайн. Пылесос Vitek  1843 в действительности соответствует всем современным требованиям к бытовой  технике: 6-ступенчатая система фильтрации с НЕРА-фильтром способна задерживать  до 99,97% всех частиц размерами от 0,3 мкм и больше, тем самым, обеспечивая  идеальную чистоту в вашем доме. К данной модели пылесоса прилагается несколько  специальных насадок (щетка для пыли, насадка для мебели и щелевая насадка), а  также универсальная щетка «ковер/пол». Кроме того, пылесос Vitek 1843 по-настоящему привлекателен  внешне – данная модель представлена в двух цветах на ваш выбор: сером и  оранжевом.</p> <p><strong>Характеристики:</strong></p> <ul type=disc>   <li>Мощность       1600 Вт;                                           </li>   <li>Мощность       всасывания 300 Вт;</li>   <li>6-ступенчатая       система фильтрации c HEPA-фильтром;</li>   <li>Мультициклонная       система без потери мощности всасывания;</li>   <li>Прозрачный       пластмассовый пылесборник с антистатическим покрытием;</li>   <li>Емкость       пылесборника 3 л;</li>   <li>Индикатор       заполнения пылесборника;</li>   <li>Автоматическая       смотка шнура;</li>   <li>Стальная       телескопическая трубка;</li>   <li>Tурбощетка;</li>   <li>Универсальная       щетка с переключателем «ковер/пол»;</li>   <li>Насадки:       щетка для пыли, насадка для мебели, щелевая насадка;</li>   <li>Ручка       горизонтальной переноски;</li>   <li>Электропитание       220-240 В, ~50 Гц.</li>   <li>Цвет:       серый, оранжевый.</li> </ul> <p><strong>Производитель:</strong> <strong>Vitek (Россия)</strong><br/> <strong>Гарантия:  1 год</strong></p> соковыжималка s510</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/27ce5b772a93a2336124e9a6817baf03.jpeg" alt="какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000" title="какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000"><div class="box" page="frityurnica-tefal-actifry-fz-7700r"><span class="title">какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000</span><p>от <span class="price">7700</span> руб.</p></div></li>
						<li><img src="photos/cb5b82e2b4fb8916dd96c68408275e51.jpeg" alt="микроволновая печь тест Чайник электрический Vitek VT-1149 красный" title="микроволновая печь тест Чайник электрический Vitek VT-1149 красный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-krasnyy-1650r"><span class="title">микроволновая печь тест Чайник электрический Vitek VT-1149 красный</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/b6d12be4b9eb96a31c69e83c45163c6c.jpeg" alt="моющий пылесос для дома Чайник электрический Atlanta ATH-751" title="моющий пылесос для дома Чайник электрический Atlanta ATH-751"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1600r"><span class="title">моющий пылесос для дома Чайник электрический Atlanta ATH-751</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/10b8ffb3398d2d300d11c2e37221e09e.jpeg" alt="мясорубка белвар отзывы Чайник электрический Maxima МК-G114" title="мясорубка белвар отзывы Чайник электрический Maxima МК-G114"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-990r"><span class="title">мясорубка белвар отзывы Чайник электрический Maxima МК-G114</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/90ff0542b35952759822563a08374b1f.jpeg" alt="тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)" title="тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-v-cvete-990r"><span class="title">тостер philips hd 2586 Чайник электрический Maxima MК- M191 (в цвете)</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/52100c33edc3ca0743ca02e24c7f8dba.jpeg" alt="шампунь для пылесоса Электрический чайник Atlanta АТН-720" title="шампунь для пылесоса Электрический чайник Atlanta АТН-720"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-550r"><span class="title">шампунь для пылесоса Электрический чайник Atlanta АТН-720</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li class="large"><img src="photos/26befd04ebef6df7b3db2c4e6ee2357f.jpeg" alt="brand аэрогриль Фильтры для пылесоса Vitek VT-1864 (VT-1844)" title="brand аэрогриль Фильтры для пылесоса Vitek VT-1864 (VT-1844)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-215r-2"><span class="title">brand аэрогриль Фильтры для пылесоса Vitek VT-1864 (VT-1844)</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li><img src="photos/529e8107d5e5b446ac7668ecb3b5cd4b.jpeg" alt="индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке" title="индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке"><div class="box" page="dyson-turbine-head-assy-retail-turboschetka-v-upakovke-3290r"><span class="title">индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li><img src="photos/4fbb8e89e08e4c6965da2c5a458072d3.jpeg" alt="кубань 8 вафельница Пылесос Vitek VT-1836 красный" title="кубань 8 вафельница Пылесос Vitek VT-1836 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3600r"><span class="title">кубань 8 вафельница Пылесос Vitek VT-1836 красный</span><p>от <span class="price">3600</span> руб.</p></div></li>
						<li><img src="photos/d7fa090f24693c48046f13309873130c.jpeg" alt="слоеное тесто в аэрогриле Утюг Vitek VT-1241 серый" title="слоеное тесто в аэрогриле Утюг Vitek VT-1241 серый"><div class="box" page="utyug-vitek-vt-seryy-1250r"><span class="title">слоеное тесто в аэрогриле Утюг Vitek VT-1241 серый</span><p>от <span class="price">1250</span> руб.</p></div></li>
						<li><img src="photos/ab56eb3e56d0f0d6cbcdc267b86f71a7.jpeg" alt="панасоник соковыжималка Утюг паровой Tefal Aquaspeed Ultracord FV5257" title="панасоник соковыжималка Утюг паровой Tefal Aquaspeed Ultracord FV5257"><div class="box" page="utyug-parovoy-tefal-aquaspeed-ultracord-fv-2800r"><span class="title">панасоник соковыжималка Утюг паровой Tefal Aquaspeed Ultracord FV5257</span><p>от <span class="price">2800</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-vitek-3990r.php", 0, -4); if (file_exists("comments/pylesos-vitek-3990r.php")) require_once "comments/pylesos-vitek-3990r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-vitek-3990r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>