<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("mikrovolnovaya-pech-vitek-vt-3870r.php","кухонный комбайн мрия купить");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("mikrovolnovaya-pech-vitek-vt-3870r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кухонный комбайн мрия купить Микроволновая печь Vitek VT-1684  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кухонный комбайн мрия купить, хорошая кухня мультиварка, соковыжималка bosh, тесто для мантов в хлебопечке, приготовление теста в хлебопечке, купить электрическую кофеварку, сепараторный пылесос, пароварка vitek отзывы, делонги кофемашина примадонна, марки микроволновых печей, кофемашина bosch 5201, купить блендер braun mr 6550, хлебопечка ow 5004, мясорубка the chemodan clan,  мясорубка для столовой">
		<meta name="description" content="кухонный комбайн мрия купить Микроволновая печь Vitek VT-1684 – незаменимый предмет на современной кухне, вед...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" title="кухонный комбайн мрия купить Микроволновая печь Vitek VT-1684"><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="кухонный комбайн мрия купить Микроволновая печь Vitek VT-1684" title="кухонный комбайн мрия купить Микроволновая печь Vitek VT-1684 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-pogruzhnoy-moulinex-dd-3350r.php"><img src="photos/b48d978d3a6e9e560ddd3f28a86214f1.jpeg" alt="хорошая кухня мультиварка Блендер погружной Moulinex DD906143" title="хорошая кухня мультиварка Блендер погружной Moulinex DD906143"></a><h2>Блендер погружной Moulinex DD906143</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-blender-s-aksessuarami-bodum-bistro-keuro-krasnyy-3780r.php"><img src="photos/cba8b4b1e5c8fd0ccc541a5e43233a90.jpeg" alt="соковыжималка bosh Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный" title="соковыжималка bosh Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный"></a><h2>Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-serebristaya-26999r.php"><img src="photos/26f6130b768cf990fa9fa11bd1f16cb3.jpeg" alt="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая" title="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кухонный комбайн мрия купить Микроволновая печь Vitek VT-1684</h1>
						<div class="tb"><p>Цена: от <span class="price">3870</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8268.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Микроволновая печь <b>Vitek VT-1684</b> – незаменимый предмет на современной кухне, ведь она может разогреть и приготовить пищу за считанные минуты. В автоматическом меню содержится 9 уникальных программ с фиксированными настройками работы устройства. Вам достаточно будет просто поместить необходимые ингредиенты в микроволновку и выбрать понравившейся режим, «умный» прибор все сделает сам. В модели VT-1684 также предусмотрен режим грили. </p><p><b>Технические характеристики:</b></p><ul type=disc><li>Объем: 20л <li>Гриль: есть <li>Столик: 235мм <li>Режимы мощности: 5 <li>Режим размораживания: вес/время <li>Автоматическое меню: 9 программ <li>Функция программирования приготовления: нет <li>Функция экспресс-приготовления: есть <li>Таймер: 60 (макс) <li>Цифровые часы: есть <li>Тип управления: тактовое <li>Защита от доступа детей: есть <li>Мощность гриля: 900Вт <li>Выходная мощность: 800Вт <li>Потребляемая мощность: 1200Вт</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна:</b> Россия.</p> кухонный комбайн мрия купить</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/46d0cfd29014c8ec4bfb9c09c292bb23.jpeg" alt="приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная" title="приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-ci-chernaya-65999r"><span class="title">приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная</span><p>от <span class="price">65999</span> руб.</p></div></li>
						<li><img src="photos/197b288168a6454a97f75d0fce3ea362.jpeg" alt="купить электрическую кофеварку Электросушка Maxima MFD-0155" title="купить электрическую кофеварку Электросушка Maxima MFD-0155"><div class="box" page="elektrosushka-maxima-mfd-990r"><span class="title">купить электрическую кофеварку Электросушка Maxima MFD-0155</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/df340437daa709a0dfc3dc87ab1880bc.jpeg" alt="сепараторный пылесос Индукционная плита Kitfort KT-102" title="сепараторный пылесос Индукционная плита Kitfort KT-102"><div class="box" page="indukcionnaya-plita-kitfort-kt-3000r"><span class="title">сепараторный пылесос Индукционная плита Kitfort KT-102</span><p>от <span class="price">3000</span> руб.</p></div></li>
						<li><img src="photos/8f284ff93a3e936b77bc58d13a970910.jpeg" alt="пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075" title="пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075"><div class="box" page="bezmen-cifrovoy-do-kg-rst-pro-1600r"><span class="title">пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li class="large"><img src="photos/46a5120709bf99f581bc7ea7569bd649.png" alt="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902" title="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902"><div class="box" page="hlebopech-redmond-rbmm-3990r"><span class="title">делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li class="large"><img src="photos/d6db045bcfab03ae142ac160811c2a0a.jpeg" alt="марки микроволновых печей Чайник электричесукий Atlanta ATH-756" title="марки микроволновых печей Чайник электричесукий Atlanta ATH-756"><div class="box" page="chaynik-elektrichesukiy-atlanta-ath-950r"><span class="title">марки микроволновых печей Чайник электричесукий Atlanta ATH-756</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/ad9a939cae5c8a1c68f17220dbb422a8.jpeg" alt="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый" title="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belyy-1080r"><span class="title">кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li><img src="photos/df7a2601f4d7471689f34a2d1cbcf14f.jpeg" alt="купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO" title="купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r"><span class="title">купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/7988dddbd843f4e2d125562952a86736.jpeg" alt="хлебопечка ow 5004 Паровая гладильная система TOBI" title="хлебопечка ow 5004 Паровая гладильная система TOBI"><div class="box" page="parovaya-gladilnaya-sistema-tobi-2500r"><span class="title">хлебопечка ow 5004 Паровая гладильная система TOBI</span><p>от <span class="price">2500</span> руб.</p></div></li>
						<li><img src="photos/4cf080cddf806d93288abd396c7938d4.jpeg" alt="мясорубка the chemodan clan Комплект насадок Dyson Tool Kit Retail" title="мясорубка the chemodan clan Комплект насадок Dyson Tool Kit Retail"><div class="box" page="komplekt-nasadok-dyson-tool-kit-retail-2490r"><span class="title">мясорубка the chemodan clan Комплект насадок Dyson Tool Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/9e96bced898e611bddc3653f39cf1ccf.jpeg" alt="сосиски в мультиварке Пылесос KARCHER WD 3.300 M EU-I" title="сосиски в мультиварке Пылесос KARCHER WD 3.300 M EU-I"><div class="box" page="pylesos-karcher-wd-m-eui-4490r"><span class="title">сосиски в мультиварке Пылесос KARCHER WD 3.300 M EU-I</span><p>от <span class="price">4490</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("mikrovolnovaya-pech-vitek-vt-3870r.php", 0, -4); if (file_exists("comments/mikrovolnovaya-pech-vitek-vt-3870r.php")) require_once "comments/mikrovolnovaya-pech-vitek-vt-3870r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="mikrovolnovaya-pech-vitek-vt-3870r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>