<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-l-1820r.php","хлебопечка мультиварка bm 2170");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-l-1820r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>хлебопечка мультиварка bm 2170 Чайник электрический  Vitesse VS-139 1,7л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="хлебопечка мультиварка bm 2170, купить пароварку в москве, где отремонтировать утюг, обслуживание пылесоса, пылесос с электрощеткой, пароварка vitek отзывы, кофемашина rowenta, каша на воде в мультиварке, как пользоваться мультиваркой, самодельный пылесос, мешки пылесборники для пылесосов, mini пылесос, купить миксер в минске, блендер braun mx 2050,  лучшая вафельница">
		<meta name="description" content="хлебопечка мультиварка bm 2170 Стильный электрический чайник Vitesse VS-139 с красивым  дизайном подсветки вски...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/795752aa9995ffddbd65e841f9d26c51.jpeg" title="хлебопечка мультиварка bm 2170 Чайник электрический  Vitesse VS-139 1,7л"><img src="photos/795752aa9995ffddbd65e841f9d26c51.jpeg" alt="хлебопечка мультиварка bm 2170 Чайник электрический  Vitesse VS-139 1,7л" title="хлебопечка мультиварка bm 2170 Чайник электрический  Vitesse VS-139 1,7л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-binatone-nb-black-1750r.php"><img src="photos/33b7a9c07b1ba187d5807d0b266c7389.jpeg" alt="купить пароварку в москве Блендер Binatone NB-7703 Black" title="купить пароварку в москве Блендер Binatone NB-7703 Black"></a><h2>Блендер Binatone NB-7703 Black</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-processor-redmond-rfp-2990r.php"><img src="photos/470cf0a1bfd5b3c4e3890030dcd4cf8d.jpeg" alt="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901" title="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901"></a><h2>Кухонный процессор Redmond  RFP-3901</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-3650r.php"><img src="photos/b6481108ed00fa262329eb9b4a9a7836.jpeg" alt="обслуживание пылесоса Микроволновая печь Vitek VT-1694" title="обслуживание пылесоса Микроволновая печь Vitek VT-1694"></a><h2>Микроволновая печь Vitek VT-1694</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>хлебопечка мультиварка bm 2170 Чайник электрический  Vitesse VS-139 1,7л</h1>
						<div class="tb"><p>Цена: от <span class="price">1820</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19644.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Стильный электрический чайник Vitesse VS-139 с красивым  дизайном подсветки вскипятит 1,7 литра воды буквально за минуту.<br>Дополнительными плюсами являются автоматическая блокировка  включения без воды, специальный фильтр защиты от накипи и отсек для хранения  шнура.</p><p><strong>Характеристики:</strong></p><ul type=\disc\><li>Объем: 1.7 л;</li><li>Мощность: 2200 Вт;</li><li>Тип  нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал  корпуса: пластик;</li><li>Блокировка включения без воды;</li><li>Фильтр;</li><li>Индикатор  уровня воды;</li><li>Подсветка  воды при работе.</li><li>Отсек для шнура.</li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong></p> хлебопечка мультиварка bm 2170</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/872dadec17e7e9283341241f27cccee5.jpeg" alt="пылесос с электрощеткой Zauber Пароварка  S-530" title="пылесос с электрощеткой Zauber Пароварка  S-530"><div class="box" page="zauber-parovarka-s-1440r"><span class="title">пылесос с электрощеткой Zauber Пароварка  S-530</span><p>от <span class="price">1440</span> руб.</p></div></li>
						<li><img src="photos/8f284ff93a3e936b77bc58d13a970910.jpeg" alt="пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075" title="пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075"><div class="box" page="bezmen-cifrovoy-do-kg-rst-pro-1600r"><span class="title">пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/65ddf318df091ecf01e6a4b331f1492d.jpeg" alt="кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л" title="кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1950r"><span class="title">кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/480398a0d650a7b1a9641ca193d5ca18.jpeg" alt="каша на воде в мультиварке Чайник электрический Vitek VT-1156 1,7 л" title="каша на воде в мультиварке Чайник электрический Vitek VT-1156 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitek-vt-l-2350r"><span class="title">каша на воде в мультиварке Чайник электрический Vitek VT-1156 1,7 л</span><p>от <span class="price">2350</span> руб.</p></div></li>
						<li class="large"><img src="photos/1e85a6f32a0f78265e06897930cad48c.jpeg" alt="как пользоваться мультиваркой Электрический чайник Atlanta АТН-660" title="как пользоваться мультиваркой Электрический чайник Atlanta АТН-660"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-650r"><span class="title">как пользоваться мультиваркой Электрический чайник Atlanta АТН-660</span><p>от <span class="price">650</span> руб.</p></div></li>
						<li class="large"><img src="photos/168b510551b7b82d928917487d7b9c68.jpeg" alt="самодельный пылесос Батарейка GP Batteries Super alkaline LR03 24A-BC2" title="самодельный пылесос Батарейка GP Batteries Super alkaline LR03 24A-BC2"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-45r-2"><span class="title">самодельный пылесос Батарейка GP Batteries Super alkaline LR03 24A-BC2</span><p>от <span class="price">45</span> руб.</p></div></li>
						<li class="large"><img src="photos/df4499dd6fe2786e58841593ed771f8f.jpeg" alt="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009" title="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009"><div class="box" page="moyuschiy-koncentrat-thomas-profloor-l-500r"><span class="title">мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009</span><p>от <span class="price">500</span> руб.</p></div></li>
						<li><img src="photos/28da988d46134dfe1236e7598e0579cc.jpeg" alt="mini пылесос Турбощетка Redmond  RV-308" title="mini пылесос Турбощетка Redmond  RV-308"><div class="box" page="turboschetka-redmond-rv-390r"><span class="title">mini пылесос Турбощетка Redmond  RV-308</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/14869a38df9662e7970cc9dcb59c8e70.jpeg" alt="купить миксер в минске Пылесос моющий Thomas Vario 20 S" title="купить миксер в минске Пылесос моющий Thomas Vario 20 S"><div class="box" page="pylesos-moyuschiy-thomas-vario-s-6190r"><span class="title">купить миксер в минске Пылесос моющий Thomas Vario 20 S</span><p>от <span class="price">6190</span> руб.</p></div></li>
						<li><img src="photos/508d5d97fb58fc95875b08492316946f.jpeg" alt="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29" title="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29"><div class="box" page="pylesos-dyson-allergy-db-dc-19990r"><span class="title">блендер braun mx 2050 Пылесос Dyson allergy dB DC 29</span><p>от <span class="price">19990</span> руб.</p></div></li>
						<li><img src="photos/1eb6f76381a5fb4cda553623ce90ead6.jpeg" alt="рецепты для мультиварки dex Пылесос с аквафильтром Vitek VT-1832 красный" title="рецепты для мультиварки dex Пылесос с аквафильтром Vitek VT-1832 красный"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-krasnyy-6900r"><span class="title">рецепты для мультиварки dex Пылесос с аквафильтром Vitek VT-1832 красный</span><p>от <span class="price">6900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-l-1820r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-l-1820r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-l-1820r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-l-1820r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>