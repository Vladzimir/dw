<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r.php","кофемашины харьков");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофемашины харьков Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофемашины харьков, пылесос bosch logo, мультиварка виконте купить, микроволновая печь польза, эльдорадо кофемашины, кофемолка bosch, джем в хлебопечке рецепт, пылесосы с аквафильтром soteco, ремонт аэрогриля ves, каша на воде в мультиварке, курица в микроволновой печи, мультиварка киев купить, для чего нужен блендер, блюда с помощью блендера,  пылесос с электрощеткой">
		<meta name="description" content="кофемашины харьков В комплект входит зарядное устройство и четыре никель-металлогидридных аккумулят...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/4c770d02fca0640e0452b9df7c46a9e0.jpeg" title="кофемашины харьков Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)"><img src="photos/4c770d02fca0640e0452b9df7c46a9e0.jpeg" alt="кофемашины харьков Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)" title="кофемашины харьков Зарядное устройство GP Batteries PB27-BС4+(4х270AAH) -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-bistro-42000r.php"><img src="photos/dd8035ed578a002d9a18bf964fac9dd9.jpeg" alt="пылесос bosch logo Эспрессо-кофемашина Melitta Caffeo Bistro (4.0008.66)" title="пылесос bosch logo Эспрессо-кофемашина Melitta Caffeo Bistro (4.0008.66)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Bistro (4.0008.66)</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-violet-35700r.php"><img src="photos/2c16cbe8f56a0f4bc3c211204b3a9f27.jpeg" alt="мультиварка виконте купить Эспрессо-кофемашина Melitta Caffeo Lattea Violet (4.0009.93)" title="мультиварка виконте купить Эспрессо-кофемашина Melitta Caffeo Lattea Violet (4.0009.93)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Violet (4.0009.93)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-krasnaya-29530r.php"><img src="photos/39e04c91cf56d7c949379d4f2e2d6076.jpeg" alt="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная" title="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, красная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофемашины харьков Зарядное устройство GP Batteries PB27-BС4+(4х270AAH)</h1>
						<div class="tb"><p>Цена: от <span class="price">1550</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16539.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>В комплект входит зарядное устройство и четыре никель-металлогидридных аккумулятора типа АА. Время зарядки составляет 8 часов. На устройстве расположено четыре слота для элементов питания класса АА и ААА. Отличное сочетание цены и качества.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: Аккумулятор + зарядное устройство <li>Тип аккумуляторов: NiMH <li>Длительность заряда: 8 часов <li>Каналов для заряда: 2 <li>Подключение к сети: Устанавливается в розетку <li>Размер аккумуляторов: AA / AAA <li>Зарядный ток: AA 360 мА; AAА 160 мА <li>Компенсационный заряд: Да <li>Индикаторы: 1 <li>Размеры (ДхШхВ): 11,9x8,0x3,7 см</li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p><p><b>Гарантия: </b>6 месяцев.</p> кофемашины харьков</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="эльдорадо кофемашины Микроволновая печь Vitek VT-1684" title="эльдорадо кофемашины Микроволновая печь Vitek VT-1684"><div class="box"><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-3870r.php"><h3 class="title">эльдорадо кофемашины Микроволновая печь Vitek VT-1684</h3><p>от <span class="price">3870</span> руб.</p></a></div></li>
						<li><img src="photos/5ac0b374c54627e297ebdd1a47a1cc62.jpeg" alt="кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро" title="кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро"><div class="box" page="mikrovolnovaya-pech-s-konvekciey-moulinex-mw-hlebopechka-l-serebro-12050r"><span class="title">кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро</span><p>от <span class="price">12050</span> руб.</p></div></li>
						<li><img src="photos/8dac9aeadde6a6d95b71abb890265199.jpeg" alt="джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB" title="джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB"><div class="box" page="mikser-atlanta-ath-wb-630r"><span class="title">джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB</span><p>от <span class="price">630</span> руб.</p></div></li>
						<li><img src="photos/78e004a504b51dca5b370513a73854ac.jpeg" alt="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373" title="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373"><div class="box" page="myasorubka-atlanta-ath-2150r"><span class="title">пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li class="large"><img src="photos/076c9c98f1af9b02a64dd68bf22e26cd.jpeg" alt="ремонт аэрогриля ves Пароварка Binatone FS-302 White Blue" title="ремонт аэрогриля ves Пароварка Binatone FS-302 White Blue"><div class="box" page="parovarka-binatone-fs-white-blue-1760r"><span class="title">ремонт аэрогриля ves Пароварка Binatone FS-302 White Blue</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li class="large"><img src="photos/480398a0d650a7b1a9641ca193d5ca18.jpeg" alt="каша на воде в мультиварке Чайник электрический Vitek VT-1156 1,7 л" title="каша на воде в мультиварке Чайник электрический Vitek VT-1156 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitek-vt-l-2350r"><span class="title">каша на воде в мультиварке Чайник электрический Vitek VT-1156 1,7 л</span><p>от <span class="price">2350</span> руб.</p></div></li>
						<li class="large"><img src="photos/79f71cb685066d8f2b6475b4d2f70156.jpeg" alt="курица в микроволновой печи Чайник электрический Atlanta ATH-757" title="курица в микроволновой печи Чайник электрический Atlanta ATH-757"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r"><span class="title">курица в микроволновой печи Чайник электрический Atlanta ATH-757</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/1b3cfce3fc4c2602ab4206bda1961e7d.jpeg" alt="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный" title="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belolazurnyy-920r"><span class="title">мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/14e5114315c1928323477764da917a61.jpeg" alt="для чего нужен блендер Парогенератор Lelit PS20" title="для чего нужен блендер Парогенератор Lelit PS20"><div class="box" page="parogenerator-lelit-ps-12650r"><span class="title">для чего нужен блендер Парогенератор Lelit PS20</span><p>от <span class="price">12650</span> руб.</p></div></li>
						<li><img src="photos/b8e20b7d51cc5f25b0392815fadedf6e.jpeg" alt="блюда с помощью блендера Турбощетка Redmond  RTB-4801" title="блюда с помощью блендера Турбощетка Redmond  RTB-4801"><div class="box" page="turboschetka-redmond-rtb-920r"><span class="title">блюда с помощью блендера Турбощетка Redmond  RTB-4801</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r.php", 0, -4); if (file_exists("comments/zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r.php")) require_once "comments/zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="zaryadnoe-ustroystvo-gp-batteries-pbbshaah-1550r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>