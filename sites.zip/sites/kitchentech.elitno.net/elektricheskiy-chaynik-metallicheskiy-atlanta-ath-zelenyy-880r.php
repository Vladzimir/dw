<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r.php","модели пылесосов lg");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>модели пылесосов lg Электрический чайник металлический ATLANTA ATH-784, зеленый  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="модели пылесосов lg, мясорубка мулинекс ме 665, пылесос samsung sc 4326, запчасти пылесос томас, пельменное тесто в хлебопечке, блюда в хлебопечке, пылесос томас твин т1, пылесос thomas отзывы, мультиварка панасоник sr tmh18, пылесос биматек, хлебопечка panasonic 256, какой лучше парогенератор, как выбрать кофеварку, мясорубка 6061,  трубка для пылесоса">
		<meta name="description" content="модели пылесосов lg Электрический чайник – незаменимая вещь на любой кухне. Металлический электрочай...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/403a4b4ef798c09cf151962161efdcea.jpeg" title="модели пылесосов lg Электрический чайник металлический ATLANTA ATH-784, зеленый"><img src="photos/403a4b4ef798c09cf151962161efdcea.jpeg" alt="модели пылесосов lg Электрический чайник металлический ATLANTA ATH-784, зеленый" title="модели пылесосов lg Электрический чайник металлический ATLANTA ATH-784, зеленый -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/oksiochistitel-ot-nakipi-v-tabletkah-swirl-sht-185r.php"><img src="photos/56c1fb096fb1ae10287c83891f9d01cb.jpeg" alt="мясорубка мулинекс ме 665 Окси-очиститель от накипи в таблетках Swirl, 4 шт" title="мясорубка мулинекс ме 665 Окси-очиститель от накипи в таблетках Swirl, 4 шт"></a><h2>Окси-очиститель от накипи в таблетках Swirl, 4 шт</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-1090r.php"><img src="photos/c18872267b9c6c7f4de2b2c0d2d5e8a8.jpeg" alt="пылесос samsung sc 4326 Блендер Maxima MHB-0229" title="пылесос samsung sc 4326 Блендер Maxima MHB-0229"></a><h2>Блендер Maxima MHB-0229</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-s-grilem-moulinex-mw-parovarka-l-serebro-6110r.php"><img src="photos/a9b561236bfa7747af43043cb7d43b52.jpeg" alt="запчасти пылесос томас Микроволновая печь с грилем Moulinex MW531030 пароварка, 23 л, серебро" title="запчасти пылесос томас Микроволновая печь с грилем Moulinex MW531030 пароварка, 23 л, серебро"></a><h2>Микроволновая печь с грилем Moulinex MW531030 пароварка, 23 л, серебро</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>модели пылесосов lg Электрический чайник металлический ATLANTA ATH-784, зеленый</h1>
						<div class="tb"><p>Цена: от <span class="price">880</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20759.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник – незаменимая вещь на любой кухне. Металлический электрочайник ATLANTA ATH-784 не только отвечает всем техническими требованиям, но к тому же обладает широкой функциональностью и привлекательным дизайном. Чайник ATLANTA ATH-784 имеет оптимальный объем (2 литра), систему быстрого закипания, автоматическое отключение и специальный фильтр от накипи. Безопасность же использования данной модель обеспечивается функцией защиты от перегрева воды. Внешне чайник выполнен в удачном сочетании блестящего зеленого и черного цветов, что позволяет ему стать не только по-настоящему нужной вещью, но и эффектной деталью кухонного интерьера. Также стоит отметить, что данное изделие сертифицировано Госстандартом РФ, соответствует американским и европейским нормам безопасности.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Объем: 2 литра;<strong></strong> <li>Мощность: 1800W;<strong></strong> <li>230V, 50Hz;<strong></strong> <li>Поворот на подставке на 360;<strong></strong> <li>Быстрое закипание;<strong></strong> <li>Фильтр от накипи;<strong></strong> <li>Закрытый нагревательный элемент;<strong></strong> <li>Автоматическое отключение;<strong></strong> <li>Защита от перегрева без воды;<strong></strong> <li>Электрошнур в цокольной подставке;<strong></strong> <li>Цвет: зеленый;<strong></strong> </li></ul><p><strong>Производитель: США</strong></p> модели пылесосов lg</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/83b963fc4661f051cc9c631952fa196f.jpeg" alt="пельменное тесто в хлебопечке Мясорубка Maxima MMG-0212" title="пельменное тесто в хлебопечке Мясорубка Maxima MMG-0212"><div class="box" page="myasorubka-maxima-mmg-2690r"><span class="title">пельменное тесто в хлебопечке Мясорубка Maxima MMG-0212</span><p>от <span class="price">2690</span> руб.</p></div></li>
						<li><img src="photos/b5363272b3a3c59d4980ee7e84a0ecd1.jpeg" alt="блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP" title="блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-cp-1430r"><span class="title">блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP</span><p>от <span class="price">1430</span> руб.</p></div></li>
						<li><img src="photos/58caa49e2e5c4bf06cfbf9dcdde29448.jpeg" alt="пылесос томас твин т1 Чайник электрический Vitek VT-1142" title="пылесос томас твин т1 Чайник электрический Vitek VT-1142"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1950r"><span class="title">пылесос томас твин т1 Чайник электрический Vitek VT-1142</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/8e4c77fcf3cd711bd8454688ff0f7bc7.jpeg" alt="пылесос thomas отзывы Чайник электрический Vitek VT-1159" title="пылесос thomas отзывы Чайник электрический Vitek VT-1159"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1900r"><span class="title">пылесос thomas отзывы Чайник электрический Vitek VT-1159</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/d23d3c42279f2a4fe0ce1702af341b90.jpeg" alt="пылесос биматек Чайник электрический Atlanta ATH-755" title="пылесос биматек Чайник электрический Atlanta ATH-755"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-950r"><span class="title">пылесос биматек Чайник электрический Atlanta ATH-755</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/f5d552f595352df6a881129a694e04b1.jpeg" alt="хлебопечка panasonic 256 Чайник электрический Redmond RK-M112" title="хлебопечка panasonic 256 Чайник электрический Redmond RK-M112"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-990r"><span class="title">хлебопечка panasonic 256 Чайник электрический Redmond RK-M112</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/512f8d3c0276804b57a2729ea05d9ba6.jpeg" alt="какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas" title="какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r-2"><span class="title">какой лучше парогенератор Набор мешков-пылесборников 35 (787-183) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/022434340143cfbbf0a87e93fd1fc9c0.jpeg" alt="как выбрать кофеварку Щетка для собак Dyson Groom Retail" title="как выбрать кофеварку Щетка для собак Dyson Groom Retail"><div class="box" page="schetka-dlya-sobak-dyson-groom-retail-1690r"><span class="title">как выбрать кофеварку Щетка для собак Dyson Groom Retail</span><p>от <span class="price">1690</span> руб.</p></div></li>
						<li><img src="photos/9ae1fe09fe7308adffccf86c925a5fca.jpeg" alt="мясорубка 6061 Пылесос Thomas Inox 20 Professional" title="мясорубка 6061 Пылесос Thomas Inox 20 Professional"><div class="box" page="pylesos-thomas-inox-professional-6220r"><span class="title">мясорубка 6061 Пылесос Thomas Inox 20 Professional</span><p>от <span class="price">6220</span> руб.</p></div></li>
						<li><img src="photos/45b64b122ef998f1bbed00c81620bedc.jpeg" alt="соковыжималка прессового отжима Vitesse VS-656 Утюг" title="соковыжималка прессового отжима Vitesse VS-656 Утюг"><div class="box" page="vitesse-vs-utyug-1800r"><span class="title">соковыжималка прессового отжима Vitesse VS-656 Утюг</span><p>от <span class="price">1800</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r.php")) require_once "comments/elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>