<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-vitek-vt-1000r.php","black decker пылесос автомобильный");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-vitek-vt-1000r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>black decker пылесос автомобильный Утюг Vitek VT-1201  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="black decker пылесос автомобильный, мясорубки белорусские, крылышки в пароварке, утюг какой фирмы лучше, купить хлебопечку мулинекс, пылесосы с аквафильтром soteco, мультиварка супра инструкция, утюг с тефлоновым покрытием, мультиварка киев купить, очистка кофеварки, кофемашина incanto de luxe, мини соковыжималка, блендер рецепты видео, пылесос компрессор отзывы,  пылесос самсунг sc отзывы">
		<meta name="description" content="black decker пылесос автомобильный Продуманный дизайн и технологичность утюга Vitek VT-1201 порадуют любую хозяйку,...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/80654612b51c4afe89f637d443e9b883.jpeg" title="black decker пылесос автомобильный Утюг Vitek VT-1201"><img src="photos/80654612b51c4afe89f637d443e9b883.jpeg" alt="black decker пылесос автомобильный Утюг Vitek VT-1201" title="black decker пылесос автомобильный Утюг Vitek VT-1201 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/zauber-melnica-dlya-speciy-s-1100r.php"><img src="photos/e3db19fdd8b8e08a389b3566088c9ffc.jpeg" alt="мясорубки белорусские Zauber Мельница для специй  S-450" title="мясорубки белорусские Zauber Мельница для специй  S-450"></a><h2>Zauber Мельница для специй  S-450</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-s-grilem-moulinex-mw-l-belyy-3890r.php"><img src="photos/1c1d1049958bdd0b6b9f6e6cb13db14b.jpeg" alt="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый" title="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый"></a><h2>Микроволновая печь с грилем Moulinex MW220131 20 л, белый</h2></li>
							<li><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-zelenyy-2740r.php"><img src="photos/ff295724863185ff22e2c85236f25515.jpeg" alt="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый" title="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый"></a><h2>Bodum BISTRO 11151-565EURO Электрический миксер зеленый</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>black decker пылесос автомобильный Утюг Vitek VT-1201</h1>
						<div class="tb"><p>Цена: от <span class="price">1000</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8311.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Продуманный дизайн и технологичность <b>утюга V</b><b>itek</b><b> </b><b>VT</b><b>-1201 </b>порадуют любую хозяйку, и сделают рутинную процедуру глаженья белья приятным и легким занятием. В модели предусмотрено вертикальное отпаривание белья с паровым ударом 100 г/мин, с помощью которого вы за считанные секунды сможете разгладить даже самые капризные ткани. Продуманная функция самоочистки сделает уход за устройством<b> </b>чрезвычайно удобным. На подошве имеется антипригарное покрытие.</p><p><b>Особенности:</b></p><p><b></b></p><ul><li>Подошва с антипригарным покрытием <li>Плавная регулировка температурных режимов <li>Сухая глажка</li></ul><p><b></b></p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Паровой удар: 100 г/мин <li>Резервуар для воды емкостью 2800 мл <li>Вертикальное отпаривание: есть <li>Постоянная передача пара: различные паровые режимы <li>Разбрызгивание: есть <li>Антикапельный клапан: функция \Антикапля\ <li>Система самоочистки: есть <li>Защита от накипи: есть <li>Мощность: 2000Вт ( макс) <li>Электропитание: 220-240 В, 50 Гц</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> black decker пылесос автомобильный</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/42b635368f5179e970d08ec7c08cbc10.jpeg" alt="купить хлебопечку мулинекс Мультиварка Maruchi RW-FZ47 в комплекте с керамической кастрюлей" title="купить хлебопечку мулинекс Мультиварка Maruchi RW-FZ47 в комплекте с керамической кастрюлей"><div class="box"><a href="http://kitchentech.elitno.net/multivarka-maruchi-rwfz-v-komplekte-s-keramicheskoy-kastryuley-4500r.php"><h3 class="title">купить хлебопечку мулинекс Мультиварка Maruchi RW-FZ47 в комплекте с керамической кастрюлей</h3><p>от <span class="price">4500</span> руб.</p></a></div></li>
						<li><img src="photos/78e004a504b51dca5b370513a73854ac.jpeg" alt="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373" title="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373"><div class="box" page="myasorubka-atlanta-ath-2150r"><span class="title">пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/5a34cc2772e0feae9df6932b7f043259.jpeg" alt="мультиварка супра инструкция Чайник электрический Atlanta ATH-758" title="мультиварка супра инструкция Чайник электрический Atlanta ATH-758"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-940r"><span class="title">мультиварка супра инструкция Чайник электрический Atlanta ATH-758</span><p>от <span class="price">940</span> руб.</p></div></li>
						<li><img src="photos/9886fb8aa4d27a4c0947d702e96f79ee.jpeg" alt="утюг с тефлоновым покрытием Чайник электрический Maxima MК- M291" title="утюг с тефлоновым покрытием Чайник электрический Maxima MК- M291"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r-2"><span class="title">утюг с тефлоновым покрытием Чайник электрический Maxima MК- M291</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/1b3cfce3fc4c2602ab4206bda1961e7d.jpeg" alt="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный" title="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belolazurnyy-920r"><span class="title">мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li class="large"><img src="photos/22d30b7337c9635a9decf8a39fad0a54.jpeg" alt="очистка кофеварки Электрический чайник Atlanta АТН-793" title="очистка кофеварки Электрический чайник Atlanta АТН-793"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1420r-2"><span class="title">очистка кофеварки Электрический чайник Atlanta АТН-793</span><p>от <span class="price">1420</span> руб.</p></div></li>
						<li class="large"><img src="photos/56eef2b8f5929fc5948323a8a5a2e051.jpeg" alt="кофемашина incanto de luxe Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)" title="кофемашина incanto de luxe Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r"><span class="title">кофемашина incanto de luxe Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)</span><p>от <span class="price">1220</span> руб.</p></div></li>
						<li><img src="photos/8201fb734cec793db96d43f2e27a6cc4.jpeg" alt="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail" title="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail"><div class="box" page="nabor-dlya-doma-dyson-home-cleaning-kit-retail-2490r"><span class="title">мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/7e736b7b32dea00ff19d5eefa59427b8.jpeg" alt="блендер рецепты видео Пылесос Thomas Power Pack 1620" title="блендер рецепты видео Пылесос Thomas Power Pack 1620"><div class="box" page="pylesos-thomas-power-pack-4300r"><span class="title">блендер рецепты видео Пылесос Thomas Power Pack 1620</span><p>от <span class="price">4300</span> руб.</p></div></li>
						<li><img src="photos/28ebbb0322a7eac61313d0d41391d394.jpeg" alt="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий" title="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-siniy-6900r"><span class="title">пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий</span><p>от <span class="price">6900</span> руб.</p></div></li>
						<li><img src="photos/e1389eb03e943fe040843f1f9d6c693c.jpeg" alt="центральный пылесос Утюг Vitek VT-1251 синий" title="центральный пылесос Утюг Vitek VT-1251 синий"><div class="box" page="utyug-vitek-vt-siniy-1500r"><span class="title">центральный пылесос Утюг Vitek VT-1251 синий</span><p>от <span class="price">1500</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-vitek-vt-1000r.php", 0, -4); if (file_exists("comments/utyug-vitek-vt-1000r.php")) require_once "comments/utyug-vitek-vt-1000r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-vitek-vt-1000r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>