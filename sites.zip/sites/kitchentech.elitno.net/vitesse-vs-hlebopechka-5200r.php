<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("vitesse-vs-hlebopechka-5200r.php","соковыжималка profi cook");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("vitesse-vs-hlebopechka-5200r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>соковыжималка profi cook Vitesse VS-422 Хлебопечка  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="соковыжималка profi cook, пылесос samsung vc 5853, кофеварка нескафе дольче густо, пылесос mediclean, мультиварка описание, daewoo микроволновая печь инструкция, сервисный центр кофемашин, купить хлебопечку bork, бытовые микроволновые печи, купить мультиварку панасоник, утюг braun texstyle control, дозиметр радиоактивности, купить капельную кофеварку, пылесос компрессор отзывы,  пылесос самсунг sc отзывы">
		<meta name="description" content="соковыжималка profi cook Если Вы хотите каждый день есть вкусный домашний хлеб и удивлять  гостей различн...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/0a3cf9abc3fc820de574913fb2ebcdd1.jpeg" title="соковыжималка profi cook Vitesse VS-422 Хлебопечка"><img src="photos/0a3cf9abc3fc820de574913fb2ebcdd1.jpeg" alt="соковыжималка profi cook Vitesse VS-422 Хлебопечка" title="соковыжималка profi cook Vitesse VS-422 Хлебопечка -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhbm-chernyy-3790r.php"><img src="photos/3c3fb3bc3e413c2b55272e4aa6c67fdc.jpeg" alt="пылесос samsung vc 5853 Блендер Redmond RHB-M2904 (черный)" title="пылесос samsung vc 5853 Блендер Redmond RHB-M2904 (черный)"></a><h2>Блендер Redmond RHB-M2904 (черный)</h2></li>
							<li><a href="http://kitchentech.elitno.net/porcionnye-vesy-nps-5260r.php"><img src="photos/5ddb7c0074c19c7852a8997f3b296d03.jpeg" alt="кофеварка нескафе дольче густо Порционные весы NP-5001S" title="кофеварка нескафе дольче густо Порционные весы NP-5001S"></a><h2>Порционные весы NP-5001S</h2></li>
							<li><a href="http://kitchentech.elitno.net/chaynik-elektricheskiy-vitek-vt-2150r.php"><img src="photos/4f7eae7926bb1b2816625b5940a25b78.jpeg" alt="пылесос mediclean Чайник электрический Vitek VT-1157" title="пылесос mediclean Чайник электрический Vitek VT-1157"></a><h2>Чайник электрический Vitek VT-1157</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>соковыжималка profi cook Vitesse VS-422 Хлебопечка</h1>
						<div class="tb"><p>Цена: от <span class="price">5200</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19706.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Если Вы хотите каждый день есть вкусный домашний хлеб и удивлять  гостей различными добавками, то для Вас - хлебопечка Vitesse VS-422. С ней  приготовить хлеб дома не сложнее чем купить его, также она может сварить  варенье и испечь кексы.<br>12 программ выпечки, выбор цвета корочки, поддержание хлеба  теплым в течение часа, ускоренная программа приготовления и многие другие плюсы  определенно сделают этот прибор одним из любимых на кухне.</p><p><strong>Характеристики:</strong></p><ul type=\disc\><li>Мощность:  600 Вт;</li><li>Максимальный  вес выпечки: 900 г;</li><li>Регулировка  веса выпечки;</li><li>Форма  выпечки: буханка;</li><li>Выбор  цвета корочки;</li><li>Таймер:  до 13 ч;</li><li>Поддержание температуры: до 1 ч</li><li>Количество программ выпечки: 12</li><li>Ускоренная  выпечка;</li><li>Варка  джема;</li><li>Выпекание  кекса;</li><li>Запас  памяти при сбое электропитания: 15 мин;</li><li>Подсветка дисплея;</li><li>Съемная  крышка;</li><li>Материал  корпуса: пластик;</li><li>Мерная чаша, ложка.</li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong><strong></strong></p> соковыжималка profi cook</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/01e798cd02e35629810cab1b511976bc.jpeg" alt="мультиварка описание Чайник электрический Tefal Reminisce KI201540 1,7 л" title="мультиварка описание Чайник электрический Tefal Reminisce KI201540 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r"><span class="title">мультиварка описание Чайник электрический Tefal Reminisce KI201540 1,7 л</span><p>от <span class="price">2370</span> руб.</p></div></li>
						<li><img src="photos/0acc9f01a71196d6ab7726b81327e74c.jpeg" alt="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717" title="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-390r"><span class="title">daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/e19a6a84ed749d263503c61eb89d253b.jpeg" alt="сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4" title="сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-80r"><span class="title">сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4</span><p>от <span class="price">80</span> руб.</p></div></li>
						<li><img src="photos/a6da0d6d0378629b8c50bad1795840bf.jpeg" alt="купить хлебопечку bork Мини весы Tangent KP-104-200" title="купить хлебопечку bork Мини весы Tangent KP-104-200"><div class="box" page="mini-vesy-tangent-kp-1300r"><span class="title">купить хлебопечку bork Мини весы Tangent KP-104-200</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li class="large"><img src="photos/4fcdbef1e4068bc4641fdad47e086ca6.jpeg" alt="бытовые микроволновые печи Парогенератор Maxima MSC-2001" title="бытовые микроволновые печи Парогенератор Maxima MSC-2001"><div class="box" page="parogenerator-maxima-msc-1650r"><span class="title">бытовые микроволновые печи Парогенератор Maxima MSC-2001</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/0c7359cf223fcc5ee81c11e13e2fdc99.jpeg" alt="купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый" title="купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый"><div class="box" page="parogenerator-maxima-msc-zheltyy-1650r"><span class="title">купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/a9173acd4bbfab2975fc7d7fd7dd2bd2.jpeg" alt="утюг braun texstyle control Пылесос моющий Thomas Twin T1 Aquafilter" title="утюг braun texstyle control Пылесос моющий Thomas Twin T1 Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-t-aquafilter-13080r"><span class="title">утюг braun texstyle control Пылесос моющий Thomas Twin T1 Aquafilter</span><p>от <span class="price">13080</span> руб.</p></div></li>
						<li><img src="photos/c0a2e2be0cab06fcd64d43478c95622c.jpeg" alt="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter" title="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-tt-aquafilter-14900r"><span class="title">дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter</span><p>от <span class="price">14900</span> руб.</p></div></li>
						<li><img src="photos/f7d34d9031a1da8552cb5d880691212c.jpeg" alt="купить капельную кофеварку Пылесос Redmond RV-312" title="купить капельную кофеварку Пылесос Redmond RV-312"><div class="box" page="pylesos-redmond-rv-8990r"><span class="title">купить капельную кофеварку Пылесос Redmond RV-312</span><p>от <span class="price">8990</span> руб.</p></div></li>
						<li><img src="photos/28ebbb0322a7eac61313d0d41391d394.jpeg" alt="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий" title="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-siniy-6900r"><span class="title">пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий</span><p>от <span class="price">6900</span> руб.</p></div></li>
						<li><img src="photos/e1389eb03e943fe040843f1f9d6c693c.jpeg" alt="центральный пылесос Утюг Vitek VT-1251 синий" title="центральный пылесос Утюг Vitek VT-1251 синий"><div class="box" page="utyug-vitek-vt-siniy-1500r"><span class="title">центральный пылесос Утюг Vitek VT-1251 синий</span><p>от <span class="price">1500</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("vitesse-vs-hlebopechka-5200r.php", 0, -4); if (file_exists("comments/vitesse-vs-hlebopechka-5200r.php")) require_once "comments/vitesse-vs-hlebopechka-5200r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="vitesse-vs-hlebopechka-5200r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>