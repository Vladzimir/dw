<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-atlanta-atn-650r.php","накипь в электрическом чайнике");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-atlanta-atn-650r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>накипь в электрическом чайнике Электрический чайник Atlanta АТН-660  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="накипь в электрическом чайнике, электрочайники из нержавейки, чоппер измельчитель, соковыжималка profi cook, рецепт батона для хлебопечки, курица во фритюрнице, белоруссия соковыжималка, самоочистка аэрогриля, ножки в аэрогриле, рецепты кофе в кофемашине, кофемашина krups dolce gusto, аренда промышленного пылесоса, мультиварка скороварка moulinex, мультиварка panasonic магазин,  мясорубка с овощерезкой">
		<meta name="description" content="накипь в электрическом чайнике Электрический чайник Atlanta АТН-660 – стильный кухонный прибор, мощностью 2000 ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/1e85a6f32a0f78265e06897930cad48c.jpeg" title="накипь в электрическом чайнике Электрический чайник Atlanta АТН-660"><img src="photos/1e85a6f32a0f78265e06897930cad48c.jpeg" alt="накипь в электрическом чайнике Электрический чайник Atlanta АТН-660" title="накипь в электрическом чайнике Электрический чайник Atlanta АТН-660 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2080r.php"><img src="photos/f1ec794f7123a5cfc892f85d1cd7e4e0.jpeg" alt="электрочайники из нержавейки Блендер Redmond RHB-2907" title="электрочайники из нержавейки Блендер Redmond RHB-2907"></a><h2>Блендер Redmond RHB-2907</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-blender-s-aksessuarami-belyy-bodum-bistro-keuro-3780r.php"><img src="photos/679fdf23622402a201c5b519c3350ce4.jpeg" alt="чоппер измельчитель Электрический блендер с аксессуарами белый Bodum Bistro K11179-913EURO" title="чоппер измельчитель Электрический блендер с аксессуарами белый Bodum Bistro K11179-913EURO"></a><h2>Электрический блендер с аксессуарами белый Bodum Bistro K11179-913EURO</h2></li>
							<li><a href="http://kitchentech.elitno.net/mylopoglotitel-nepriyatnyh-zapahov-vitesse-vs-530r.php"><img src="photos/b3484386aa5de93840c27e2c8187adfa.jpeg" alt="соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293" title="соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293"></a><h2>Мыло-поглотитель неприятных запахов Vitesse VS-1293</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>накипь в электрическом чайнике Электрический чайник Atlanta АТН-660</h1>
						<div class="tb"><p>Цена: от <span class="price">650</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19939.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Atlanta АТН-660 – стильный кухонный прибор, мощностью 2000 Вт и объемом 1,7 л. воды. Может поворачиваться на подставке на 360 градусов. Имеет фильтр от накипи и функцию быстрого закипания. Используется защищенный закрытый нагревательный элемент, который гораздо проще мыть, чем открытую спираль. Безопасен, т. к. имеет защиту от перегрева, а также блокировку крышки и блокировку включения без воды. Предусмотрено место для электрошнура в цокольной подставке. Снабжен функцией «100% готовность». </p><p><strong>Характеристики:</strong></p><ul type=disc><li>Функция \100% готовность\ <li>Поворот на подставке на 360  <li>Быстрое закипание <li>Фильтр от накипи <li>Закрытый нагревательный элемент <li>Автоматическое отключение <li>Защита от перегрева без воды <li>Электрошнур в цокольной подставке <li>Мощность 2000W <li>230V, 50Hz <li>19.5 x 18 x 23.5 см </li></ul><p><strong>Производитель: США</strong></p> накипь в электрическом чайнике</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/2e2056e7ef45f5df85840ea8253e7c4c.jpeg" alt="рецепт батона для хлебопечки Электроплитка Maxima MES-0252-2" title="рецепт батона для хлебопечки Электроплитка Maxima MES-0252-2"><div class="box" page="elektroplitka-maxima-mes-880r"><span class="title">рецепт батона для хлебопечки Электроплитка Maxima MES-0252-2</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li><img src="photos/d3bcfc3d08cc302406de89eb814d0d80.jpeg" alt="курица во фритюрнице Кухонный комбайн Vitek VT-1622" title="курица во фритюрнице Кухонный комбайн Vitek VT-1622"><div class="box" page="kuhonnyy-kombayn-vitek-vt-2750r"><span class="title">курица во фритюрнице Кухонный комбайн Vitek VT-1622</span><p>от <span class="price">2750</span> руб.</p></div></li>
						<li><img src="photos/32c26854e293b25040685f60b879a50b.jpeg" alt="белоруссия соковыжималка Мясорубка  Atlanta ATH-370" title="белоруссия соковыжималка Мясорубка  Atlanta ATH-370"><div class="box" page="myasorubka-atlanta-ath-2500r"><span class="title">белоруссия соковыжималка Мясорубка  Atlanta ATH-370</span><p>от <span class="price">2500</span> руб.</p></div></li>
						<li><img src="photos/948f1a9b44ef51dbbf106577d1753c25.jpeg" alt="самоочистка аэрогриля Соковыжималка" title="самоочистка аэрогриля Соковыжималка"><div class="box" page="sokovyzhimalka-3320r"><span class="title">самоочистка аэрогриля Соковыжималка</span><p>от <span class="price">3320</span> руб.</p></div></li>
						<li class="large"><img src="photos/3efeed2a40b596512ea138d7f6d2f182.jpeg" alt="ножки в аэрогриле Термопот Binatone TP-4055 White" title="ножки в аэрогриле Термопот Binatone TP-4055 White"><div class="box" page="termopot-binatone-tp-white-1990r"><span class="title">ножки в аэрогриле Термопот Binatone TP-4055 White</span><p>от <span class="price">1990</span> руб.</p></div></li>
						<li class="large"><img src="photos/03c71bbf8b5f2d86f3ae6ce6e9e77e58.jpeg" alt="рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая" title="рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая"><div class="box" page="frityurnica-vitek-vt-belaya-2950r"><span class="title">рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая</span><p>от <span class="price">2950</span> руб.</p></div></li>
						<li class="large"><img src="photos/10045e221774030a9f06ef65dc2f63de.jpeg" alt="кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024" title="кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024"><div class="box" page="frityurnica-tefal-minute-snack-ff-2220r"><span class="title">кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024</span><p>от <span class="price">2220</span> руб.</p></div></li>
						<li><img src="photos/61cc3edb3bfd24a6709976ba33646660.jpeg" alt="аренда промышленного пылесоса Зарядное устройство GP Batteries PB350GS-UE1" title="аренда промышленного пылесоса Зарядное устройство GP Batteries PB350GS-UE1"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r"><span class="title">аренда промышленного пылесоса Зарядное устройство GP Batteries PB350GS-UE1</span><p>от <span class="price">340</span> руб.</p></div></li>
						<li><img src="photos/96ed77acce770bf04afcf29723d61326.jpeg" alt="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas" title="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-2"><span class="title">мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/787fcfe3b6052ac0b67b5602b473ad73.jpeg" alt="мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter" title="мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r"><span class="title">мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter</span><p>от <span class="price">18180</span> руб.</p></div></li>
						<li><img src="photos/53cb90a2ebb4ca3e913558aa9650be1d.jpeg" alt="пылесос bosch 82425 Пылесос Thomas Inox 1520 Plus" title="пылесос bosch 82425 Пылесос Thomas Inox 1520 Plus"><div class="box" page="pylesos-thomas-inox-plus-4730r"><span class="title">пылесос bosch 82425 Пылесос Thomas Inox 1520 Plus</span><p>от <span class="price">4730</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-atlanta-atn-650r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-atlanta-atn-650r.php")) require_once "comments/elektricheskiy-chaynik-atlanta-atn-650r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-atlanta-atn-650r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>