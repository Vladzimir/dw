<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r.php","вафельница интернет магазин");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>вафельница интернет магазин Пылесос моющий Thomas Twin T2 Aquafilter  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="вафельница интернет магазин, zelmer мясорубка отзывы, утюг какой фирмы лучше, мультиварка redmond 4504, как выбрать утюг отзывы, пылесос bork v500, микроволновая печь saturn, разборка утюга tefal, курица с грибами в мультиварке, покрытие микроволновой печи, бетоносмеситель миксер, солянка в мультиварке, диски для кухонного комбайна, kress пылесос,  панасоник соковыжималка">
		<meta name="description" content="вафельница интернет магазин Моющий пылесос Twin T2 Aquafilter от известной немецкой торговой марки Thomas ра...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/787fcfe3b6052ac0b67b5602b473ad73.jpeg" title="вафельница интернет магазин Пылесос моющий Thomas Twin T2 Aquafilter"><img src="photos/787fcfe3b6052ac0b67b5602b473ad73.jpeg" alt="вафельница интернет магазин Пылесос моющий Thomas Twin T2 Aquafilter" title="вафельница интернет магазин Пылесос моющий Thomas Twin T2 Aquafilter -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-russell-hobbs-allure-art-5490r.php"><img src="photos/ac0d13475c79f9c87e6f514f3140de60.jpeg" alt="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56" title="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56"></a><h2>Блендер Russell Hobbs Allure, арт. 18276-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-zelenyy-2740r.php"><img src="photos/ff295724863185ff22e2c85236f25515.jpeg" alt="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый" title="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый"></a><h2>Bodum BISTRO 11151-565EURO Электрический миксер зеленый</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-3290r.php"><img src="photos/696c3eff6d4752e21e651f3d4b34c0a7.jpeg" alt="мультиварка redmond 4504 Мясорубка Redmond RMG-1204" title="мультиварка redmond 4504 Мясорубка Redmond RMG-1204"></a><h2>Мясорубка Redmond RMG-1204</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>вафельница интернет магазин Пылесос моющий Thomas Twin T2 Aquafilter</h1>
						<div class="tb"><p>Цена: от <span class="price">18180</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14618.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий пылесос Twin T2 Aquafilter от известной немецкой торговой марки Thomas разработан на основе технологии многоступенчатой водяной фильтрации. Благодаря этой технологии пылесборники больше не нужны, так как вся грязь собирается в специальную емкость. Необходимо наполнить емкость водой перед тем, как пропылесосить помещение. По окончании уборки нужно вылить грязную воду и промыть резервуар. Таким образом, микрочастицы пыли, пыльца и различные вредоносные бактерии больше не будут оседать на мягкой мебели и коврах, а останутся в воде.</p><p>Пылесос способен выполнять не только влажную, но и сухую. Кроме аквафильтра, задерживающего крупные частицы грязи, он снабжен НЕРА-фильтром, который служит для очистки воздуха от микрочастиц и микрофильтром для выдуваемого воздуха. Модель оснащена системой электронного управления «Touch-Tronic», благодаря которой можно установить необходимую мощность одним легким прикосновением. Уборку можно осуществлять в режиме «ECO» - самым нижним по уровню мощности.</p><p>Моющий пылесос Thomas поможет Вам с легкостью справиться с любой грязью. Прибор прекрасно подойдет для людей, страдающих аллергией, поскольку очень тщательно вымывает пыльцу и клещей.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип уборки: сухая/влажная; <li>Мощность: 1700 Вт; <li>Мощность всасывания: 400 Вт; <li>Регулировка мощности на корпусе (тип регулятора мощности электронный); <li>Тип выходного фильтра: НЕРА (моющийся); <li>Пылесборник: аквафильтр; <li>Объем пылесборника: 2,4 л (емкость для моющего средства); <li>Индикатор заполнения пылесборника; <li>Труба всасывания стальная телескопическая; <li>Авто сматывание шнура; <li>Производительность насоса моющего средства макс.: 0,7 л/мин; <li>Электронное управление «Touch-Tronic»; <li>Макс. давление насоса: 4 бар; <li>Бампер для защиты мебели; <li>Электронное управление «Touch-Tronic»; <li>Цвет корпуса: синий / серый; <li>Инжекторный фильтр + циклонная система водной фильтрации; <li>Микрофильтр выходящего воздуха; <li>Двухступенчатая турбина большой мощности; <li>Легкосъемный резервуар для грязной воды; <li>Предельная простота в обращении; <li>Ступень «ЕСО», нижний уровень мощности двигателя; <li>Управление функциональным переключателем «Softtouch»; <li>Интегрированный шланг подачи моющего раствора с запорным клапаном; <li>Два положения парковки; <li>Брызгозащищенный корпус; <li>Уровень шума: 86 дБ; <li>Длина сетевого шнура: 6 м; <li>Вес: 10 кг.</li></ul><p><b>Насадки:</b><b></b></p><ul type=disc><li>Насадка для уборки паркета; <li>Мебельная кисточка; <li>Насадка для сухой уборки мягкой мебели; <li>Насадка служит для тщательной очистки углов, швов и других труднодоступных мест; <li>Насадка для влажной уборки ковров с адаптером для твердых покрытий; <li>Насадка для влажной уборки мягкой мебели; <li>Адаптер для мытья окон; <li>Концентрат Thomas Protex для приготовления моющего раствора, позволяет производить эффективную очистку любых поверхностей. Экологичен (PH 5.5), не влияет на цвет ковров, обладает приятным запахом.</li></ul><p><b>Приобретается дополнительно:</b></p><ul type=disc><li>Турбощетка с аккумулятором TSB 200; <li>Турбощетка TSB 100; <li>Турбощетка для мягкой мебели TSB 50; <li>Моющий концентрат Thomas ProFloor; <li>Моющий концентрат Thomas ProTex V; <li>Моющий концентрат Thomas ProTex M; <li>Средство для ухода за кожаной мебелью.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> вафельница интернет магазин</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7d63a182df07dd9be547ac2724aeed46.jpeg" alt="как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO" title="как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO"><div class="box" page="elektricheskaya-sokovyzhimalka-krasnaya-bodum-bistro-euro-3340r"><span class="title">как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li><img src="photos/aad075f22e1967e01f21286f7d5da33a.jpeg" alt="пылесос bork v500 Чайник Vitek VT-1161 с керамическим корпусом" title="пылесос bork v500 Чайник Vitek VT-1161 с керамическим корпусом"><div class="box" page="chaynik-vitek-vt-s-keramicheskim-korpusom-3450r"><span class="title">пылесос bork v500 Чайник Vitek VT-1161 с керамическим корпусом</span><p>от <span class="price">3450</span> руб.</p></div></li>
						<li><img src="photos/2e45225f75584b99ef16cc23171266ef.jpeg" alt="микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л" title="микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1740r"><span class="title">микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л</span><p>от <span class="price">1740</span> руб.</p></div></li>
						<li><img src="photos/05e1cbbaa69c29b12d76f08b9352b558.jpeg" alt="разборка утюга tefal Электрический чайник Atlanta АТН-630" title="разборка утюга tefal Электрический чайник Atlanta АТН-630"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-600r"><span class="title">разборка утюга tefal Электрический чайник Atlanta АТН-630</span><p>от <span class="price">600</span> руб.</p></div></li>
						<li class="large"><img src="photos/d5bfaa3b5f694911004b112b3792a6d5.jpeg" alt="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130" title="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130"><div class="box" page="komplekt-filtrovmeshkov-karcher-480r"><span class="title">курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li class="large"><img src="photos/e60d974a9eb12d238a3e8bae6f4ce905.jpeg" alt="покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)" title="покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-670r"><span class="title">покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)</span><p>от <span class="price">670</span> руб.</p></div></li>
						<li class="large"><img src="photos/569a7a448800e6c331839b4f1803d826.jpeg" alt="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502" title="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502"><div class="box" page="moyuschiy-koncentrat-thomas-protex-l-520r"><span class="title">бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/39b908a415c11ffadfa5f63c6981b9e7.jpeg" alt="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail" title="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail"><div class="box" page="universalnaya-miniturboschetka-v-upakovke-dyson-mini-turbine-head-ir-cl-retail-2290r"><span class="title">солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail</span><p>от <span class="price">2290</span> руб.</p></div></li>
						<li><img src="photos/6eaac51c54fbf44dce471193ec6d5c18.jpeg" alt="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail" title="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail"><div class="box" page="nabor-dlya-udaleniya-pyaten-s-kovrovyh-pokrytiy-i-myagkoy-mebeli-dyson-party-cleanup-kit-ir-cl-retail-2490r"><span class="title">диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/cfc3673046a371ff9baffb342aa8e52b.jpeg" alt="kress пылесос Пылесос моющий Thomas Twin Aquafilter" title="kress пылесос Пылесос моющий Thomas Twin Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquafilter-11550r"><span class="title">kress пылесос Пылесос моющий Thomas Twin Aquafilter</span><p>от <span class="price">11550</span> руб.</p></div></li>
						<li><img src="photos/e2b67f21c94f08d0f992c10013ebe15c.jpeg" alt="magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26" title="magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26"><div class="box" page="pylesos-dyson-carbon-fibre-dc-23990r"><span class="title">magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26</span><p>от <span class="price">23990</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r.php", 0, -4); if (file_exists("comments/pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r.php")) require_once "comments/pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>