<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-atlanta-ath-1350r.php","нарезной хлебопечка");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-atlanta-ath-1350r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>нарезной хлебопечка Утюг Atlanta ATH-497  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="нарезной хлебопечка, продажа моющих пылесосов, лестничные перила, маленькие мультиварки, чайник электрический bork, фильтр для пылесоса томас, аэрогриль hotter 1037, пылесос автомобильный купить, запчасти пылесос томас, пароварка tefal vc 1016, пылесос thomas genius s2, курица с грибами в мультиварке, индукционная плита вредна, микроволновая печь электросхема,  панасоник соковыжималка">
		<meta name="description" content="нарезной хлебопечка Утюг Atlanta ATH-497 с цифровым контролером температуры, мощностью 2500 Вт –стил...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/ad2a05fc3c7b9378855e19056906dcd0.jpeg" title="нарезной хлебопечка Утюг Atlanta ATH-497"><img src="photos/ad2a05fc3c7b9378855e19056906dcd0.jpeg" alt="нарезной хлебопечка Утюг Atlanta ATH-497" title="нарезной хлебопечка Утюг Atlanta ATH-497 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-bar-44180r.php"><img src="photos/c9a7a5b3ad41669087cce987bbc510ac.jpeg" alt="продажа моющих пылесосов Эспрессо-кофемашина Melitta Caffeo Bar (4.0008.68)" title="продажа моющих пылесосов Эспрессо-кофемашина Melitta Caffeo Bar (4.0008.68)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Bar (4.0008.68)</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikser-russell-hobbs-desire-art-1290r.php"><img src="photos/7e647600a38b01c48fb301e5b6c41520.jpeg" alt="лестничные перила Миксер Russell Hobbs Desire, арт. 18507-56" title="лестничные перила Миксер Russell Hobbs Desire, арт. 18507-56"></a><h2>Миксер Russell Hobbs Desire, арт. 18507-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-4990r.php"><img src="photos/ab8e324f37683fb482e2239bd528b88e.jpeg" alt="маленькие мультиварки Мясорубка Redmond RMG-1203" title="маленькие мультиварки Мясорубка Redmond RMG-1203"></a><h2>Мясорубка Redmond RMG-1203</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>нарезной хлебопечка Утюг Atlanta ATH-497</h1>
						<div class="tb"><p>Цена: от <span class="price">1350</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19767.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Утюг Atlanta ATH-497 с цифровым контролером температуры, мощностью 2500 Вт –стильный мощный прибор бело-фиолетового цвета для глажки. Абсолютно безопасен, т. к. имеет функцию автоматического отключения. Также есть функция самоочистки. 202 паровых отверстия в подошве. Кроме того, он имеет функцию парового удара. Иногда для проглаживания сильно пересушенных или толстых тканей не хватает даже максимальной модности постоянного пара. Специально для таких случаев в этом утюге есть паровой удар. При нажатии на кнопку происходит мощная подача пара, находящегося под высоким давлением. Сильный удар горячего пара размягчает волокна и быстро разглаживает даже глубокие складки. А подача вертикального пара позволяет гладить пиджаки, пальто и другие вещи прямо на вешалке или манекене.</p><p>Характеристики:</p><ul><li>Цифровой t-контроллер с ЖКИ дисплеем <li>Высокая мощность <li>202 паровых отверстия в подошве <li>Функция самоотключения <li>Противокапельный механизм <li>Система против накипи <li>Режим самоочистки <li>Сухой или паровой режим глаженья <li>Функция вертикального пара <li>Функция увлажнения <li>Дополнительная подача пара <li>Максимальная мощность 2500 Вт 230 В, 50 Гц </li></ul><p><strong>Производитель: США</strong></p> нарезной хлебопечка</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/cba9fd30236faeadb264f6621c9544f6.jpeg" alt="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер" title="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер"><div class="box" page="sokovyzhimalka-maxima-mj-blender-2190r"><span class="title">чайник электрический bork Соковыжималка Maxima MJ-049 + блендер</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/6e1b19f4e2e44aaedf95ea7e61a0919a.jpeg" alt="фильтр для пылесоса томас Хлебопечка-мультиповар Binatone BM-2170 Cream" title="фильтр для пылесоса томас Хлебопечка-мультиповар Binatone BM-2170 Cream"><div class="box" page="hlebopechkamultipovar-binatone-bm-cream-6900r"><span class="title">фильтр для пылесоса томас Хлебопечка-мультиповар Binatone BM-2170 Cream</span><p>от <span class="price">6900</span> руб.</p></div></li>
						<li><img src="photos/e9322568d654cf02152dc451f13376f9.jpeg" alt="аэрогриль hotter 1037 Чайник электрический  Vitesse VS-113 1,5л красный" title="аэрогриль hotter 1037 Чайник электрический  Vitesse VS-113 1,5л красный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-krasnyy-1950r"><span class="title">аэрогриль hotter 1037 Чайник электрический  Vitesse VS-113 1,5л красный</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/b2f5222e6fab12eeb526363895bfe319.jpeg" alt="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л" title="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-950r"><span class="title">пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/140994d3679b87017beef134272baa56.jpeg" alt="запчасти пылесос томас Чайник дисковый керамический 1,7л, цветы Zauber ECO-340" title="запчасти пылесос томас Чайник дисковый керамический 1,7л, цветы Zauber ECO-340"><div class="box" page="chaynik-diskovyy-keramicheskiy-l-cvety-zauber-eco-1790r"><span class="title">запчасти пылесос томас Чайник дисковый керамический 1,7л, цветы Zauber ECO-340</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li class="large"><img src="photos/59caa0f57be012636d82040c68bfc641.jpeg" alt="пароварка tefal vc 1016 Батарейка GP Batteries Super alkaline LR6 15A-BC2" title="пароварка tefal vc 1016 Батарейка GP Batteries Super alkaline LR6 15A-BC2"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-45r"><span class="title">пароварка tefal vc 1016 Батарейка GP Batteries Super alkaline LR6 15A-BC2</span><p>от <span class="price">45</span> руб.</p></div></li>
						<li class="large"><img src="photos/94de14730b416ab6939a25c5af76e14e.jpeg" alt="пылесос thomas genius s2 Парогенератор Lelit PS11N" title="пылесос thomas genius s2 Парогенератор Lelit PS11N"><div class="box" page="parogenerator-lelit-psn-12000r"><span class="title">пылесос thomas genius s2 Парогенератор Lelit PS11N</span><p>от <span class="price">12000</span> руб.</p></div></li>
						<li><img src="photos/d5bfaa3b5f694911004b112b3792a6d5.jpeg" alt="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130" title="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130"><div class="box" page="komplekt-filtrovmeshkov-karcher-480r"><span class="title">курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li><img src="photos/f508d547808db2bce707d6b2135eb926.jpeg" alt="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter" title="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r"><span class="title">индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter</span><p>от <span class="price">10800</span> руб.</p></div></li>
						<li><img src="photos/00492fb3046ec485746c0b2d1a1385eb.jpeg" alt="микроволновая печь электросхема Пылесос Thomas Inox 1545 S" title="микроволновая печь электросхема Пылесос Thomas Inox 1545 S"><div class="box" page="pylesos-thomas-inox-s-10410r"><span class="title">микроволновая печь электросхема Пылесос Thomas Inox 1545 S</span><p>от <span class="price">10410</span> руб.</p></div></li>
						<li><img src="photos/b19d13e15e623a65d384ae31dfb72492.jpeg" alt="мясорубки отечественные Утюг Vitek VT-1203 серый" title="мясорубки отечественные Утюг Vitek VT-1203 серый"><div class="box" page="utyug-vitek-vt-seryy-940r"><span class="title">мясорубки отечественные Утюг Vitek VT-1203 серый</span><p>от <span class="price">940</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-atlanta-ath-1350r.php", 0, -4); if (file_exists("comments/utyug-atlanta-ath-1350r.php")) require_once "comments/utyug-atlanta-ath-1350r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-atlanta-ath-1350r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>