<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r.php","новые мультиварки");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>новые мультиварки Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="новые мультиварки, хлебопечка цены moulinex, мясорубка в посудомойке, аэрогриль воронеж, что можно делать блендером, кофеварка нескафе дольче густо, пылесос lg с контейнером, ремень для хлебопечки, как разобрать утюг, тостер philips hd, десерты в блендере, термопот toshiba, мультиварка скороварка land life, кофеварка дольче густо отзывы,  стимер для аэрогриля">
		<meta name="description" content="новые мультиварки Незаменимым предметом на любой кухне является, без сомнений,  современный и удоб...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/16e3783a13e306fc3fd90925cbbcc384.jpeg" title="новые мультиварки Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO"><img src="photos/16e3783a13e306fc3fd90925cbbcc384.jpeg" alt="новые мультиварки Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO" title="новые мультиварки Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/filtry-bumazhnye-h-sht-melitta-natura-155r.php"><img src="photos/8d1e6a9f68c28d6a1278058dcc2842f9.jpeg" alt="хлебопечка цены moulinex Фильтры бумажные 1х4 80 шт. Melitta Natura" title="хлебопечка цены moulinex Фильтры бумажные 1х4 80 шт. Melitta Natura"></a><h2>Фильтры бумажные 1х4 80 шт. Melitta Natura</h2></li>
							<li><a href="http://kitchentech.elitno.net/aerogril-maxima-mag-2290r.php"><img src="photos/50504b425a4036964e7c0cdd2137107c.jpeg" alt="мясорубка в посудомойке Аэрогриль Maxima MAG-0247" title="мясорубка в посудомойке Аэрогриль Maxima MAG-0247"></a><h2>Аэрогриль Maxima MAG-0247</h2></li>
							<li><a href="http://kitchentech.elitno.net/zauber-kofemolka-x-1250r.php"><img src="photos/13e215c432e654a40129e4a1cdc305f1.jpeg" alt="аэрогриль воронеж Zauber Кофемолка  X-480" title="аэрогриль воронеж Zauber Кофемолка  X-480"></a><h2>Zauber Кофемолка  X-480</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>новые мультиварки Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO</h1>
						<div class="tb"><p>Цена: от <span class="price">2740</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_26404.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Незаменимым предметом на любой кухне является, без сомнений,  современный и удобный в использовании электрический чайник. Электрический  чайник BISTRO 11138-294EURO от  швейцарской компании Bodum обладает не только отличными техническими  характеристиками, но и привлекательным дизайном. Чайник Bodum BISTRO 11138-294EURO имеет оптимальный объем (1,5  литра), специальный съемный фильтр, индикатор уровня воды, а также функцию  блокировки включения без воды. Внешне данная модель выполнена в насыщенном  красном цвете, что позволит ей легко вписаться в интерьер вашей кухни.    </p> <p><strong>Характеристики:</strong></p> <ul type=disc>   <li>Тип:       электрический;</li>   <li>Объем:       1,5 л;</li>   <li>Материал       корпуса: пластик;</li>   <li>Мощность:       2200 Вт;</li>   <li>Нагревательный       элемент: дисковый нагреватель (скрытый);</li>   <li>Съемный       фильтр;</li>   <li>Индикатор       уровня воды;</li>   <li>Блокировка       включения без воды;</li>   <li>Цвет:       красный.</li> </ul> <p><strong>Производитель: Bodum  (Швейцария)</strong></p> новые мультиварки</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/060f95312423ba3e968eaf23618bd36d.jpeg" alt="что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White" title="что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White"><div class="box" page="myasorubka-elektricheskaya-binatone-mgr-white-3700r"><span class="title">что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White</span><p>от <span class="price">3700</span> руб.</p></div></li>
						<li><img src="photos/5ddb7c0074c19c7852a8997f3b296d03.jpeg" alt="кофеварка нескафе дольче густо Порционные весы NP-5001S" title="кофеварка нескафе дольче густо Порционные весы NP-5001S"><div class="box" page="porcionnye-vesy-nps-5260r"><span class="title">кофеварка нескафе дольче густо Порционные весы NP-5001S</span><p>от <span class="price">5260</span> руб.</p></div></li>
						<li><img src="photos/d78a5eb7926a57e3a6daeb54a8fc1659.jpeg" alt="пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine" title="пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine"><div class="box" page="sokovyzhimalka-moulinex-juae-juice-machine-4300r"><span class="title">пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine</span><p>от <span class="price">4300</span> руб.</p></div></li>
						<li><img src="photos/46f63d5550ab774c363b5ff4ba202c31.jpeg" alt="ремень для хлебопечки Чайник электрический Maxima MK- M191" title="ремень для хлебопечки Чайник электрический Maxima MK- M191"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-990r"><span class="title">ремень для хлебопечки Чайник электрический Maxima MK- M191</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" alt="как разобрать утюг Чайник электрический Maxima MК- M211" title="как разобрать утюг Чайник электрический Maxima MК- M211"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-1090r"><span class="title">как разобрать утюг Чайник электрический Maxima MК- M211</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li class="large"><img src="photos/0e0d48622ca21267b7347abd2a6edbfa.jpeg" alt="тостер philips hd Redmond RK-M120D Чайник электрический" title="тостер philips hd Redmond RK-M120D Чайник электрический"><div class="box" page="redmond-rkmd-chaynik-elektricheskiy-4950r"><span class="title">тостер philips hd Redmond RK-M120D Чайник электрический</span><p>от <span class="price">4950</span> руб.</p></div></li>
						<li class="large"><img src="photos/133af075f6993e048350b753f5c2c798.jpeg" alt="десерты в блендере Электрический чайник Atlanta АТН-727" title="десерты в блендере Электрический чайник Atlanta АТН-727"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r-2"><span class="title">десерты в блендере Электрический чайник Atlanta АТН-727</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li><img src="photos/403a4b4ef798c09cf151962161efdcea.jpeg" alt="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый" title="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый"><div class="box" page="elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r"><span class="title">термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li><img src="photos/351be0717cadb3b074e20c4a4dccbf50.jpeg" alt="мультиварка скороварка land life Мини весы Momert 6000" title="мультиварка скороварка land life Мини весы Momert 6000"><div class="box" page="mini-vesy-momert-1600r"><span class="title">мультиварка скороварка land life Мини весы Momert 6000</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/d360b8a0c7da5c2048584c84686650a7.jpeg" alt="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)" title="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-55r"><span class="title">кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)</span><p>от <span class="price">55</span> руб.</p></div></li>
						<li><img src="photos/39b908a415c11ffadfa5f63c6981b9e7.jpeg" alt="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail" title="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail"><div class="box" page="universalnaya-miniturboschetka-v-upakovke-dyson-mini-turbine-head-ir-cl-retail-2290r"><span class="title">солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail</span><p>от <span class="price">2290</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r.php")) require_once "comments/elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>