<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-binatone-cej-magic-white-1100r.php","пароварка panasonic sr tmh18");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-binatone-cej-magic-white-1100r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пароварка panasonic sr tmh18 Чайник электрический Binatone CEJ-1745 Magic White  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пароварка panasonic sr tmh18, электрочайники из нержавейки, magic pot мультиварка, ручной блендер hr1659, мультиварка скороварка landlife, рожок для кофеварки, книга рецептов для хлебопечки, чем отличаются пылесосы, бездрожжевой хлеб в хлебопечке, держатель для пылесоса, фильтр для пылесоса самсунг, бытовая техника пылесосы, скороварка мультиварка cuckoo, хлебопечка клатроник,  соковыжималка прессового отжима">
		<meta name="description" content="пароварка panasonic sr tmh18 Чайник электрический Binatone CEJ-1745 Magic White создан для того, чтобы сделат...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/601488d11fe95f07b0e7e96c29a4ca5c.jpeg" title="пароварка panasonic sr tmh18 Чайник электрический Binatone CEJ-1745 Magic White"><img src="photos/601488d11fe95f07b0e7e96c29a4ca5c.jpeg" alt="пароварка panasonic sr tmh18 Чайник электрический Binatone CEJ-1745 Magic White" title="пароварка panasonic sr tmh18 Чайник электрический Binatone CEJ-1745 Magic White -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2080r.php"><img src="photos/f1ec794f7123a5cfc892f85d1cd7e4e0.jpeg" alt="электрочайники из нержавейки Блендер Redmond RHB-2907" title="электрочайники из нержавейки Блендер Redmond RHB-2907"></a><h2>Блендер Redmond RHB-2907</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-mikser-krasnyy-bodum-bistro-euro-2740r.php"><img src="photos/be6b78c2525e9286d015556c4db7013b.jpeg" alt="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO" title="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO"></a><h2>Электрический миксер красный Bodum BISTRO 11151-294EURO</h2></li>
							<li><a href="http://kitchentech.elitno.net/multivarka-maruchi-rwfz-4000r.php"><img src="photos/2118e94c9f54fd8ac8f1f2abebe50fe3.jpeg" alt="ручной блендер hr1659 Мультиварка Maruchi RW-FZ47" title="ручной блендер hr1659 Мультиварка Maruchi RW-FZ47"></a><h2>Мультиварка Maruchi RW-FZ47</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пароварка panasonic sr tmh18 Чайник электрический Binatone CEJ-1745 Magic White</h1>
						<div class="tb"><p>Цена: от <span class="price">1100</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_6820.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический </b><b>Binatone </b><b>CEJ-1745 </b><b>Magic </b><b>White </b>создан для того, чтобы сделать наш быт проще и приятнее. Прибор легко впишется в любой интерьер, благодаря стильному дизайну. Мощность чайника составляет 2200 Вт, вместимость стандартная: 1,7 л, материал корпуса – пластик. Модель снабжена закрытым нагревательным элементом из нержавеющей стали, индикатором уровня воды, внутренней подсветкой (синяя - чайник отключен, красная - чайник включен), съемным фильтром для удобства чистки, продуманной подставкой с возможностью поворота на ней чайника на 360є и местом для хранения шнура. Предусмотрены функции автоотключения при закипании, отключения при снятии с подставки, блокировки включения без воды. Компания Binatone - один из ведущих мировых производителей мелкой и средней бытовой техники, представляющий широкий ассортимент различных товаров для дома и офиса. Продукция фирмы отличается высоким качеством, оригинальным дизайном и интересными цветовыми решениями.</p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность 2200 Вт; <li>Вместимость 1,7 л; <li>Возможность поворота на подставке на 360є; <li>Материал корпуса: пластик; <li>Крышка со специальным лифт-механизмом; <li>Тип нагревательного элемента: закрытая спираль (центральный контакт); <li>Покрытие нагревательного элемента: нержавеющая сталь; <li>Съемный фильтр для удобства чистки; <li>Автоотключение при закипании; <li>Блокировка включения без воды; <li>Отключение при снятии с подставки; <li>Большое окно со шкалой уровня воды; <li>Подставка с местом для хранения шнура; <li>Внутренняя подсветка чайника: синяя - чайник отключен, красная - чайник включен; <li>Цвет: белый; <li>Вес: 1,35 кг.</li></ul><p><b>Производитель: </b>Binatone.</p> пароварка panasonic sr tmh18</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/b61be34fe70b570a69e06c3fa76d4fff.jpeg" alt="мультиварка скороварка landlife Мясорубка Redmond RMG-1201" title="мультиварка скороварка landlife Мясорубка Redmond RMG-1201"><div class="box"><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-3490r.php"><h3 class="title">мультиварка скороварка landlife Мясорубка Redmond RMG-1201</h3><p>от <span class="price">3490</span> руб.</p></a></div></li>
						<li><img src="photos/5fe7a070a54ac64269e20fb9f52ff92c.jpeg" alt="рожок для кофеварки Zauber Цитрусовая соковыжималка  X 850" title="рожок для кофеварки Zauber Цитрусовая соковыжималка  X 850"><div class="box" page="zauber-citrusovaya-sokovyzhimalka-x-1000r"><span class="title">рожок для кофеварки Zauber Цитрусовая соковыжималка  X 850</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li><img src="photos/da3b8026757740acd31c2844cf598d4a.jpeg" alt="чем отличаются пылесосы Батарейка GP Batteries Super alkaline LR03 24A-BC4" title="чем отличаются пылесосы Батарейка GP Batteries Super alkaline LR03 24A-BC4"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-80r-2"><span class="title">чем отличаются пылесосы Батарейка GP Batteries Super alkaline LR03 24A-BC4</span><p>от <span class="price">80</span> руб.</p></div></li>
						<li class="large"><img src="photos/7660e64f2f5c029aab5d6fad25c29084.jpeg" alt="бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843" title="бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843"><div class="box" page="pylesos-vitek-3990r"><span class="title">бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li class="large"><img src="photos/edc4236e3a4947da96211057e15ad9d5.jpeg" alt="держатель для пылесоса Пылесос Vitek VT-1847 красный" title="держатель для пылесоса Пылесос Vitek VT-1847 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3650r"><span class="title">держатель для пылесоса Пылесос Vitek VT-1847 красный</span><p>от <span class="price">3650</span> руб.</p></div></li>
						<li class="large"><img src="photos/db8d0d28b1b05f19385269d855039f58.jpeg" alt="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833" title="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-5580r"><span class="title">фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833</span><p>от <span class="price">5580</span> руб.</p></div></li>
						<li><img src="photos/2bc01cf0e5d557324370d108b991f168.jpeg" alt="бытовая техника пылесосы Пылесос Thomas Inox 45 S Professional" title="бытовая техника пылесосы Пылесос Thomas Inox 45 S Professional"><div class="box" page="pylesos-thomas-inox-s-professional-11290r"><span class="title">бытовая техника пылесосы Пылесос Thomas Inox 45 S Professional</span><p>от <span class="price">11290</span> руб.</p></div></li>
						<li><img src="photos/709ff92fce8d072f9f56d948427a4843.jpeg" alt="скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter" title="скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter"><div class="box" page="pylesos-thomas-genius-s-aquafilter-10000r"><span class="title">скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter</span><p>от <span class="price">10000</span> руб.</p></div></li>
						<li><img src="photos/517e5c14445485917f65d44ac20c8bd1.jpeg" alt="хлебопечка клатроник Утюг паровой Tefal Prima FV2115" title="хлебопечка клатроник Утюг паровой Tefal Prima FV2115"><div class="box" page="utyug-parovoy-tefal-prima-fv-1330r"><span class="title">хлебопечка клатроник Утюг паровой Tefal Prima FV2115</span><p>от <span class="price">1330</span> руб.</p></div></li>
						<li><img src="photos/5363fe7d5348c517715f7be1bf400046.jpeg" alt="соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210" title="соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210"><div class="box" page="utyug-parovoy-tefal-aquaspeed-fv-2400r"><span class="title">соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210</span><p>от <span class="price">2400</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-binatone-cej-magic-white-1100r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-binatone-cej-magic-white-1100r.php")) require_once "comments/chaynik-elektricheskiy-binatone-cej-magic-white-1100r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-binatone-cej-magic-white-1100r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>