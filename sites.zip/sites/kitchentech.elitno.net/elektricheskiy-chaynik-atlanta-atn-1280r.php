<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-atlanta-atn-1280r.php","чайник электрический тефаль");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-atlanta-atn-1280r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>чайник электрический тефаль Электрический чайник Atlanta АТН-700  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="чайник электрический тефаль, соковыжималка bosh, соковыжималка для моркови, пылесос для ногтей, соковыжималки выбор, мотор пылесоса самсунг, ремонт мясорубок мулинекс, рецепты для мультиварки viconte, измельчитель сена, хлебопечка panasonic 255 купить, курица в микроволновой печи, книга рецептов для хлебопечки, кофемашина la cimbali, пылесос thomas genius s2,  мясорубка moulinex hv8 me625">
		<meta name="description" content="чайник электрический тефаль Электрический чайник Atlanta АТН-700 с заварным чайником – стильный кухонный при...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/1bbdc32e5167c3f95a77515679aaf9df.jpeg" title="чайник электрический тефаль Электрический чайник Atlanta АТН-700"><img src="photos/1bbdc32e5167c3f95a77515679aaf9df.jpeg" alt="чайник электрический тефаль Электрический чайник Atlanta АТН-700" title="чайник электрический тефаль Электрический чайник Atlanta АТН-700 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-blender-s-aksessuarami-bodum-bistro-keuro-krasnyy-3780r.php"><img src="photos/cba8b4b1e5c8fd0ccc541a5e43233a90.jpeg" alt="соковыжималка bosh Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный" title="соковыжималка bosh Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный"></a><h2>Электрический блендер с аксессуарами Bodum BISTRO K11179-294EURO красный</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-680r.php"><img src="photos/6e844ec2051132de84c89f71f9ba6d6a.jpeg" alt="соковыжималка для моркови Кухонный комбайн ATH-360" title="соковыжималка для моркови Кухонный комбайн ATH-360"></a><h2>Кухонный комбайн ATH-360</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lounge-white-45500r.php"><img src="photos/45055ec55f153a8a82f9cf1191933a0c.jpeg" alt="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)" title="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>чайник электрический тефаль Электрический чайник Atlanta АТН-700</h1>
						<div class="tb"><p>Цена: от <span class="price">1280</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19959.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Atlanta АТН-700 с заварным чайником – стильный кухонный прибор из стекла с красивой подсветкой. Его мощность составляет 2260 Вт, а объемом 1,7 л. Может поворачиваться на подставке на 360 градусов. Имеет фильтр от накипи и функцию быстрого закипания. Используется защищенный закрытый нагревательный элемент, который гораздо проще мыть, чем открытую спираль. Безопасен, т. к. имеет защиту от перегрева, а также блокировку крышки и блокировку включения без воды. Предусмотрено место для электрошнура в цокольной подставке. Есть функция подогрева заварного чайника.</p><p><strong>Характеристики:</strong></p><ul><li>Объем 1.7 л <li>Мощность 2260 Вт <li>Тип нагревательного элемента: закрытая спираль (центральный контакт) <li>Заварочный чайник <li>Материал корпуса: пластик <li>Блокировка крышки <li>Блокировка включения без воды <li>Индикатор уровня воды <li>Индикация включения <li>Подсветка воды при работе <li>Функция подогрева заварочного чайника </li></ul><p><strong>Производитель: США</strong></p> чайник электрический тефаль</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/3c4c438093f284e24176255dd4b7658c.jpeg" alt="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная" title="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-chernaya-26999r"><span class="title">соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная</span><p>от <span class="price">26999</span> руб.</p></div></li>
						<li><img src="photos/99f24579a4151d885006823a70346b26.jpeg" alt="мотор пылесоса самсунг Электроплитка Maxima MES-0152-1" title="мотор пылесоса самсунг Электроплитка Maxima MES-0152-1"><div class="box" page="elektroplitka-maxima-mes-550r"><span class="title">мотор пылесоса самсунг Электроплитка Maxima MES-0152-1</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li><img src="photos/dc407a1e2a485cfa91965baf93f3d5ba.jpeg" alt="ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051" title="ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051"><div class="box" page="myasorubka-elektricheskaya-moulinex-me-3820r"><span class="title">ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051</span><p>от <span class="price">3820</span> руб.</p></div></li>
						<li><img src="photos/602afbefdc154f32c668e628ed57301c.jpeg" alt="рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903" title="рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903"><div class="box" page="sokovyzhimalka-maxima-mjm-1850r"><span class="title">рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li class="large"><img src="photos/b563c2d22903c88ab1496d97329bc5bf.jpeg" alt="измельчитель сена Тостер Atlanta ATH-234" title="измельчитель сена Тостер Atlanta ATH-234"><div class="box" page="toster-atlanta-ath-690r"><span class="title">измельчитель сена Тостер Atlanta ATH-234</span><p>от <span class="price">690</span> руб.</p></div></li>
						<li class="large"><img src="photos/0f5208729d1f126a03ea2f6dcc581158.jpeg" alt="хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430" title="хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430"><div class="box" page="hlebopechka-moulinex-ow-7500r"><span class="title">хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430</span><p>от <span class="price">7500</span> руб.</p></div></li>
						<li class="large"><img src="photos/79f71cb685066d8f2b6475b4d2f70156.jpeg" alt="курица в микроволновой печи Чайник электрический Atlanta ATH-757" title="курица в микроволновой печи Чайник электрический Atlanta ATH-757"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r"><span class="title">курица в микроволновой печи Чайник электрический Atlanta ATH-757</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li><img src="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" alt="кофемашина la cimbali Электрический чайник Atlanta АТН-788" title="кофемашина la cimbali Электрический чайник Atlanta АТН-788"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1350r"><span class="title">кофемашина la cimbali Электрический чайник Atlanta АТН-788</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li><img src="photos/94de14730b416ab6939a25c5af76e14e.jpeg" alt="пылесос thomas genius s2 Парогенератор Lelit PS11N" title="пылесос thomas genius s2 Парогенератор Lelit PS11N"><div class="box" page="parogenerator-lelit-psn-12000r"><span class="title">пылесос thomas genius s2 Парогенератор Lelit PS11N</span><p>от <span class="price">12000</span> руб.</p></div></li>
						<li><img src="photos/4cf080cddf806d93288abd396c7938d4.jpeg" alt="мясорубка the chemodan clan Комплект насадок Dyson Tool Kit Retail" title="мясорубка the chemodan clan Комплект насадок Dyson Tool Kit Retail"><div class="box" page="komplekt-nasadok-dyson-tool-kit-retail-2490r"><span class="title">мясорубка the chemodan clan Комплект насадок Dyson Tool Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-atlanta-atn-1280r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-atlanta-atn-1280r.php")) require_once "comments/elektricheskiy-chaynik-atlanta-atn-1280r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-atlanta-atn-1280r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>