<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-binatone-nk-black-1200r.php","где купить утюг");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-binatone-nk-black-1200r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>где купить утюг Чайник электрический Binatone NK-7700 Black  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="где купить утюг, пылесос русский, пылесос thomas black ocean, binatone хлебопечка отзывы, тесто для мантов в хлебопечке, хлебопечка мулинекс 3101, кофеварка эспрессо krups, кофемашина bosch 5201, бамбуковая пароварка, куриные грудки в аэрогриле, сколько стоит соковыжималка, скороварка мультиварка cuckoo, moulinex mk7003 мультиварка, запчасти для пароварки,  кофемашины verobar">
		<meta name="description" content="где купить утюг Чайник электрический Binatone NK-7700 Black поможет сделать наш быт проще и прия...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/aca42b878e4277b1730672f4f845a597.jpeg" title="где купить утюг Чайник электрический Binatone NK-7700 Black"><img src="photos/aca42b878e4277b1730672f4f845a597.jpeg" alt="где купить утюг Чайник электрический Binatone NK-7700 Black" title="где купить утюг Чайник электрический Binatone NK-7700 Black -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ochistitel-ot-nakipi-dlya-avtomaticheskih-kofemashin-melitta-h-gr-370r.php"><img src="photos/d471e6416e615c9ba8a65d072074d514.jpeg" alt="пылесос русский Очиститель от накипи для автоматических кофемашин Melitta, 2х40 гр" title="пылесос русский Очиститель от накипи для автоматических кофемашин Melitta, 2х40 гр"></a><h2>Очиститель от накипи для автоматических кофемашин Melitta, 2х40 гр</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-pogruzhnoy-moulinex-dd-2300r.php"><img src="photos/b0d11dfbaf618701d7d5cdf29d1db36e.jpeg" alt="пылесос thomas black ocean Блендер погружной Moulinex DD904143" title="пылесос thomas black ocean Блендер погружной Moulinex DD904143"></a><h2>Блендер погружной Moulinex DD904143</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-39590r.php"><img src="photos/93a66ef135566c3ae659c72709d3515e.jpeg" alt="binatone хлебопечка отзывы Кофемашина Nivona NICR770 CafeRomatica" title="binatone хлебопечка отзывы Кофемашина Nivona NICR770 CafeRomatica"></a><h2>Кофемашина Nivona NICR770 CafeRomatica</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>где купить утюг Чайник электрический Binatone NK-7700 Black</h1>
						<div class="tb"><p>Цена: от <span class="price">1200</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_6818.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический </b><b>Binatone </b><b>NK-7700 </b><b>Black </b>поможет сделать наш быт проще и приятнее. Прибор легко впишется в любой интерьер, благодаря стильному дизайну. Мощность чайника составляет 2200 Вт, вместимость стандартная: 1,7 л, материал корпуса – пластик. Модель снабжена закрытым нагревательным элементом из нержавеющей стали, индикатором уровня воды, окошком с индикацией температуры воды, съемным фильтром для удобства чистки, продуманной подставкой с возможностью поворота на ней чайника на 360є и местом для хранения шнура. Предусмотрены функции автоотключения при закипании, отключения при снятии с подставки, блокировки включения без воды. Компания Binatone - один из ведущих мировых производителей мелкой и средней бытовой техники, представляющий широкий ассортимент различных товаров для дома и офиса. Продукция фирмы отличается высоким качеством, оригинальным дизайном и интересными цветовыми решениями.</p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность 2200 Вт; <li>Вместимость 1,7 л; <li>Возможность поворота на подставке на 360є; <li>Окошко с индикацией температуры воды; <li>Материал корпуса: пластик; <li>Тип нагревательного элемента: закрытая спираль (центральный контакт); <li>Покрытие нагревательного элемента: нержавеющая сталь; <li>Съемный фильтр для удобства чистки; <li>Автоотключение при закипании; <li>Блокировка включения без воды; <li>Отключение при снятии с подставки; <li>Шкала уровня воды; <li>Подставка с местом для хранения шнура; <li>Цвет: черный; <li>Вес: 1,4 кг.</li></ul><p><b>Производитель: </b>Binatone.</p> где купить утюг</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/26f6130b768cf990fa9fa11bd1f16cb3.jpeg" alt="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая" title="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая"><div class="box"><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-serebristaya-26999r.php"><h3 class="title">тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая</h3><p>от <span class="price">26999</span> руб.</p></a></div></li>
						<li><img src="photos/7903c21b4883d9e9c99d0a478392fee7.jpeg" alt="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906" title="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906"><div class="box" page="sokovyzhimalka-redmond-rjm-4990r"><span class="title">хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/0fb0d4eda0d01d4692f2fbd689f6f46f.jpeg" alt="кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л" title="кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitek-vt-l-1890r"><span class="title">кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li><img src="photos/ad9a939cae5c8a1c68f17220dbb422a8.jpeg" alt="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый" title="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belyy-1080r"><span class="title">кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li class="large"><img src="photos/3e5de65e23113a4dedb018c90159e3df.jpeg" alt="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной" title="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r"><span class="title">бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной</span><p>от <span class="price">1360</span> руб.</p></div></li>
						<li class="large"><img src="photos/2bd3efe5f6abbadb315d0281a9a3d70f.jpeg" alt="куриные грудки в аэрогриле Пылесос Vitek VT-1810" title="куриные грудки в аэрогриле Пылесос Vitek VT-1810"><div class="box" page="pylesos-vitek-vt-2150r"><span class="title">куриные грудки в аэрогриле Пылесос Vitek VT-1810</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li class="large"><img src="photos/b82293cd9bb86384904268699e41b0f9.jpeg" alt="сколько стоит соковыжималка Пылесос Thomas Power Pack 1630 Se" title="сколько стоит соковыжималка Пылесос Thomas Power Pack 1630 Se"><div class="box" page="pylesos-thomas-power-pack-se-7010r"><span class="title">сколько стоит соковыжималка Пылесос Thomas Power Pack 1630 Se</span><p>от <span class="price">7010</span> руб.</p></div></li>
						<li><img src="photos/709ff92fce8d072f9f56d948427a4843.jpeg" alt="скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter" title="скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter"><div class="box" page="pylesos-thomas-genius-s-aquafilter-10000r"><span class="title">скороварка мультиварка cuckoo Пылесос Thomas Genius S1 Aquafilter</span><p>от <span class="price">10000</span> руб.</p></div></li>
						<li><img src="photos/63eadb71b95851c3e7f26e5885bd43ae.jpeg" alt="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832" title="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-6900r"><span class="title">moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832</span><p>от <span class="price">6900</span> руб.</p></div></li>
						<li><img src="photos/eb12162abf9f68b1f020c54d55eeb406.jpeg" alt="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM" title="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-tm-7800r"><span class="title">запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM</span><p>от <span class="price">7800</span> руб.</p></div></li>
						<li><img src="photos/9c44667cf58b669d98b20d3675bbd856.jpeg" alt="дорогая мультиварка Утюг Vitek VT-1221 серый" title="дорогая мультиварка Утюг Vitek VT-1221 серый"><div class="box" page="utyug-vitek-vt-seryy-1680r"><span class="title">дорогая мультиварка Утюг Vitek VT-1221 серый</span><p>от <span class="price">1680</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-binatone-nk-black-1200r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-binatone-nk-black-1200r.php")) require_once "comments/chaynik-elektricheskiy-binatone-nk-black-1200r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-binatone-nk-black-1200r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>