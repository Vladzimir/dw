<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r.php","кофемашина philips saeco hd 8838");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофемашина philips saeco hd 8838 Электрическая кофемолка Bodum BISTRO 10903-913EURO белая  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофемашина philips saeco hd 8838, пароварка scarlett is 550, аэрогриль сервисный центр, пакеты для пылесоса, блендер braun mr 530 ca, пароварка тефаль цена, продам хлебопечку, запеканка в хлебопечке, пылесос автомобильный купить, bamix блендер отзывы, купить блендер braun mr 6550, кекс в хлебопечке панасоник, измельчитель сучьев, качество пылесосов,  индукционная керамическая плита">
		<meta name="description" content="кофемашина philips saeco hd 8838 Отличным приобретением для всех любителей вкусного  свежесваренного кофе станет ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/7182cc256e7e3343e3aec4d550f1f314.jpeg" title="кофемашина philips saeco hd 8838 Электрическая кофемолка Bodum BISTRO 10903-913EURO белая"><img src="photos/7182cc256e7e3343e3aec4d550f1f314.jpeg" alt="кофемашина philips saeco hd 8838 Электрическая кофемолка Bodum BISTRO 10903-913EURO белая" title="кофемашина philips saeco hd 8838 Электрическая кофемолка Bodum BISTRO 10903-913EURO белая -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-870r.php"><img src="photos/08c15d1f7a465f949f829449dc3e88eb.jpeg" alt="пароварка scarlett is 550 Блендер Maxima MHB-0429" title="пароварка scarlett is 550 Блендер Maxima MHB-0429"></a><h2>Блендер Maxima MHB-0429</h2></li>
							<li><a href="http://kitchentech.elitno.net/zauber-kuhonnyy-kombayn-z-4250r.php"><img src="photos/dbd2c7c20aaeedc830453cfd862f3b68.jpeg" alt="аэрогриль сервисный центр Zauber Кухонный комбайн  Z-890" title="аэрогриль сервисный центр Zauber Кухонный комбайн  Z-890"></a><h2>Zauber Кухонный комбайн  Z-890</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-braun-g-mn-wh-4980r.php"><img src="photos/2cdb40f493d1b8360833641d1048d5de.jpeg" alt="пакеты для пылесоса Мясорубка Braun G1300 MN WH" title="пакеты для пылесоса Мясорубка Braun G1300 MN WH"></a><h2>Мясорубка Braun G1300 MN WH</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофемашина philips saeco hd 8838 Электрическая кофемолка Bodum BISTRO 10903-913EURO белая</h1>
						<div class="tb"><p>Цена: от <span class="price">5730</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_26369.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Отличным приобретением для всех любителей вкусного  свежесваренного кофе станет функциональная и удобная в использовании кофемолка.  Электрическая кофемолка BISTRO 10903-913EURO от швейцарской компании Bodum изготовлена из качественных  материалов (пластик, резина, стекло, силикон, нержавеющая сталь), имеет  отличную комплектацию и оптимальные габариты (12х15,6х27,5 см). Более того,  данная модель весьма привлекательна внешне – за счет элегантного белого цвета  корпуса. Без сомнения, электрическая кофемолка BISTRO 10903-913EURO отлично впишется в  интерьер вашей кухни! </p> <p><strong>Характеристики:</strong></p> <ul type=disc>   <li>Тип:       жерновая мельница;</li>   <li>Материал:       пластик, резина, стекло, силикон, нержавеющая сталь;</li>   <li>Объем:       220 гр (кофейных зерен);</li>   <li>Режим       ожидания;</li>   <li>Автоматическое       отключение при попадании кмешков;</li>   <li>Отсек       для шнура;</li>   <li>Комплектация:       регулятор степени помола, регулятор времени/объема помола, емкость для       молотого кофе;</li>   <li>Длина       шнура: 80 см;</li>   <li>Размер       кофемолки: 12х15,6х27,5 см;</li>   <li>Цвет:       белый.</li> </ul> <p><strong>Производитель: Bodum  (Швейцария)</strong></p> кофемашина philips saeco hd 8838</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/aca42b878e4277b1730672f4f845a597.jpeg" alt="блендер braun mr 530 ca Чайник электрический Binatone NK-7700 Black" title="блендер braun mr 530 ca Чайник электрический Binatone NK-7700 Black"><div class="box" page="chaynik-elektricheskiy-binatone-nk-black-1200r"><span class="title">блендер braun mr 530 ca Чайник электрический Binatone NK-7700 Black</span><p>от <span class="price">1200</span> руб.</p></div></li>
						<li><img src="photos/fd3d354d6633b81b504bbc499f3c5989.jpeg" alt="пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый" title="пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-zheltyy-1120r"><span class="title">пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый</span><p>от <span class="price">1120</span> руб.</p></div></li>
						<li><img src="photos/357a4e7af6a4eca2e30275a2d5d14351.jpeg" alt="продам хлебопечку Чайник электрический Binatone CEJ-1744 White" title="продам хлебопечку Чайник электрический Binatone CEJ-1744 White"><div class="box" page="chaynik-elektricheskiy-binatone-cej-white-880r"><span class="title">продам хлебопечку Чайник электрический Binatone CEJ-1744 White</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="запеканка в хлебопечке Чайник электрический Maxima MK-G311" title="запеканка в хлебопечке Чайник электрический Maxima MK-G311"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1650r"><span class="title">запеканка в хлебопечке Чайник электрический Maxima MK-G311</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/b2f5222e6fab12eeb526363895bfe319.jpeg" alt="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л" title="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-950r"><span class="title">пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/795752aa9995ffddbd65e841f9d26c51.jpeg" alt="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л" title="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1820r"><span class="title">bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л</span><p>от <span class="price">1820</span> руб.</p></div></li>
						<li class="large"><img src="photos/df7a2601f4d7471689f34a2d1cbcf14f.jpeg" alt="купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO" title="купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r"><span class="title">купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/95ee2f83dd665559125032ef461af475.jpeg" alt="кекс в хлебопечке панасоник Фильтры для пылесоса Vitek VT-1866 (VT-1836)" title="кекс в хлебопечке панасоник Фильтры для пылесоса Vitek VT-1866 (VT-1836)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-175r"><span class="title">кекс в хлебопечке панасоник Фильтры для пылесоса Vitek VT-1866 (VT-1836)</span><p>от <span class="price">175</span> руб.</p></div></li>
						<li><img src="photos/59a8dfc6750ee21e49e7e4126ec09217.jpeg" alt="измельчитель сучьев Пылесос Dyson all floors DC 25" title="измельчитель сучьев Пылесос Dyson all floors DC 25"><div class="box" page="pylesos-dyson-all-floors-dc-28990r"><span class="title">измельчитель сучьев Пылесос Dyson all floors DC 25</span><p>от <span class="price">28990</span> руб.</p></div></li>
						<li><img src="photos/dcfd8cc55439cd877d074c0e060c75d4.jpeg" alt="качество пылесосов Пылесос Vitek VT-1809 красный" title="качество пылесосов Пылесос Vitek VT-1809 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2600r"><span class="title">качество пылесосов Пылесос Vitek VT-1809 красный</span><p>от <span class="price">2600</span> руб.</p></div></li>
						<li><img src="photos/c760072d30fa7e68aaaf26403c36f72a.jpeg" alt="соковыжималка сатурн Пылесос Thomas Genius S2 Aquafilter" title="соковыжималка сатурн Пылесос Thomas Genius S2 Aquafilter"><div class="box" page="pylesos-thomas-genius-s-aquafilter-10840r"><span class="title">соковыжималка сатурн Пылесос Thomas Genius S2 Aquafilter</span><p>от <span class="price">10840</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r.php", 0, -4); if (file_exists("comments/elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r.php")) require_once "comments/elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>