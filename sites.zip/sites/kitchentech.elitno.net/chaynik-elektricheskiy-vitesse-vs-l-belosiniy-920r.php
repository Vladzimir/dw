<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r.php","хлебопечка lg hb 202ce");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>хлебопечка lg hb 202ce Чайник электрический  Vitesse VS-137 1,7л бело-синий  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="хлебопечка lg hb 202ce, сломалась мясорубка, bierhof кухонный комбайн, пылесос bosch logo, купить хлебопечку мулинекс, насадки для мясорубки zelmer, грибы в мультиварке, блюда в хлебопечке, пылесосы с аквафильтром soteco, описание пылесоса, кофемашина rowenta, венчики для миксера, bamix блендер отзывы, индукционная плита вредна,  профессиональные кофемолки">
		<meta name="description" content="хлебопечка lg hb 202ce Мощный электрический чайник Vitesse VS-137 в бело-синем  корпусе вскипятит 1,7 л...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/9b828fe53dfca2c4781201b615fd512e.jpeg" title="хлебопечка lg hb 202ce Чайник электрический  Vitesse VS-137 1,7л бело-синий"><img src="photos/9b828fe53dfca2c4781201b615fd512e.jpeg" alt="хлебопечка lg hb 202ce Чайник электрический  Vitesse VS-137 1,7л бело-синий" title="хлебопечка lg hb 202ce Чайник электрический  Vitesse VS-137 1,7л бело-синий -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rbp-1490r.php"><img src="photos/54c015da9ba000a4c33278978300bae5.jpeg" alt="сломалась мясорубка Блендер Redmond RB-P1301" title="сломалась мясорубка Блендер Redmond RB-P1301"></a><h2>Блендер Redmond RB-P1301</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-73690r.php"><img src="photos/502f3c027327d4b33adc28c2b2f5d085.jpeg" alt="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica" title="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica"></a><h2>Кофемашина Nivona NICR850 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-bistro-42000r.php"><img src="photos/dd8035ed578a002d9a18bf964fac9dd9.jpeg" alt="пылесос bosch logo Эспрессо-кофемашина Melitta Caffeo Bistro (4.0008.66)" title="пылесос bosch logo Эспрессо-кофемашина Melitta Caffeo Bistro (4.0008.66)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Bistro (4.0008.66)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>хлебопечка lg hb 202ce Чайник электрический  Vitesse VS-137 1,7л бело-синий</h1>
						<div class="tb"><p>Цена: от <span class="price">920</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19639.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Мощный электрический чайник Vitesse VS-137 в бело-синем  корпусе вскипятит 1,7 литра воды практически за минуту.<br>Дополнительными плюсами являются автоматическая блокировка  включения без воды, специальный фильтр защиты от накипи и отсек для хранения  шнура.</p><p><strong>Характеристики:</strong></p><ul type=\disc\><li>Объем:  1.7 л;</li><li>Мощность:  2200 Вт</li><li>Тип  нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал корпуса: пластик;</li><li>Блокировка включения без воды;</li><li>Индикатор  уровня воды;</li><li>Индикация включения;</li><li>Отсек  для шнура.</li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong></p> хлебопечка lg hb 202ce</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/42b635368f5179e970d08ec7c08cbc10.jpeg" alt="купить хлебопечку мулинекс Мультиварка Maruchi RW-FZ47 в комплекте с керамической кастрюлей" title="купить хлебопечку мулинекс Мультиварка Maruchi RW-FZ47 в комплекте с керамической кастрюлей"><div class="box"><a href="http://kitchentech.elitno.net/multivarka-maruchi-rwfz-v-komplekte-s-keramicheskoy-kastryuley-4500r.php"><h3 class="title">купить хлебопечку мулинекс Мультиварка Maruchi RW-FZ47 в комплекте с керамической кастрюлей</h3><p>от <span class="price">4500</span> руб.</p></a></div></li>
						<li><img src="photos/7476c2912d4d9c99682e7b20dcc24385.jpeg" alt="насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192" title="насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192"><div class="box" page="elektroplita-indukcionnaya-atlanta-ath-1900r"><span class="title">насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li><img src="photos/07f90c95ce6a7ffe3129c0eb4bb8942c.jpeg" alt="грибы в мультиварке Электроплитка индукционная Maxima MIC-0146" title="грибы в мультиварке Электроплитка индукционная Maxima MIC-0146"><div class="box" page="elektroplitka-indukcionnaya-maxima-mic-1590r"><span class="title">грибы в мультиварке Электроплитка индукционная Maxima MIC-0146</span><p>от <span class="price">1590</span> руб.</p></div></li>
						<li><img src="photos/b5363272b3a3c59d4980ee7e84a0ecd1.jpeg" alt="блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP" title="блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-cp-1430r"><span class="title">блюда в хлебопечке Соковыжималка для цитрусовых (6020120/21) 307-CP</span><p>от <span class="price">1430</span> руб.</p></div></li>
						<li class="large"><img src="photos/03d6a39216ccd97c8a662a35f965b076.jpeg" alt="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611" title="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611"><div class="box" page="sokovyzhimalka-vitek-vt-600r"><span class="title">пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611</span><p>от <span class="price">600</span> руб.</p></div></li>
						<li class="large"><img src="photos/cfef38cef319ef880fc0959319ecdb34.jpeg" alt="описание пылесоса Чайник электрический Vitek VT-1154" title="описание пылесоса Чайник электрический Vitek VT-1154"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1010r"><span class="title">описание пылесоса Чайник электрический Vitek VT-1154</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/65ddf318df091ecf01e6a4b331f1492d.jpeg" alt="кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л" title="кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1950r"><span class="title">кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/8be60bf8ecb8c08e6df4d6b339b40b58.jpeg" alt="венчики для миксера Чайник электрический Atlanta ATH-759" title="венчики для миксера Чайник электрический Atlanta ATH-759"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r-2"><span class="title">венчики для миксера Чайник электрический Atlanta ATH-759</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/795752aa9995ffddbd65e841f9d26c51.jpeg" alt="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л" title="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1820r"><span class="title">bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л</span><p>от <span class="price">1820</span> руб.</p></div></li>
						<li><img src="photos/f508d547808db2bce707d6b2135eb926.jpeg" alt="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter" title="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r"><span class="title">индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter</span><p>от <span class="price">10800</span> руб.</p></div></li>
						<li><img src="photos/e2b67f21c94f08d0f992c10013ebe15c.jpeg" alt="magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26" title="magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26"><div class="box" page="pylesos-dyson-carbon-fibre-dc-23990r"><span class="title">magic pot мультиварка Пылесос Dyson Carbon Fibre DC 26</span><p>от <span class="price">23990</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>