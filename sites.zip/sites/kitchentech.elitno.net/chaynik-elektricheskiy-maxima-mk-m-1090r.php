<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-maxima-mk-m-1090r.php","мультиварка мэджик под");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-maxima-mk-m-1090r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мультиварка мэджик под Чайник электрический Maxima MК- M211  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мультиварка мэджик под, сравнить пылесосы, соковыжималка для моркови, капельная кофеварка инструкция, отважный тостер скачать, купить блендер bosch, пельмени в мультиварке на пару, мультиварка в новосибирске, рожок для кофеварки, пылесос для сбора стружки, делонги кофемашина примадонна, scarlett утюг отзывы, мультиварка панасоник sr tmh18, чайник электрический тефаль,  мини соковыжималка">
		<meta name="description" content="мультиварка мэджик под Стильный электрический чайник MК- M211 мощностью 2000 Вт легко вскипятит за счит...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" title="мультиварка мэджик под Чайник электрический Maxima MК- M211"><img src="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" alt="мультиварка мэджик под Чайник электрический Maxima MК- M211" title="мультиварка мэджик под Чайник электрический Maxima MК- M211 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-atlanta-atn-900r.php"><img src="photos/fdaa728b5765994d8f9d4b5b1575efcd.jpeg" alt="сравнить пылесосы Блендер Atlanta АТН-333" title="сравнить пылесосы Блендер Atlanta АТН-333"></a><h2>Блендер Atlanta АТН-333</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-680r.php"><img src="photos/6e844ec2051132de84c89f71f9ba6d6a.jpeg" alt="соковыжималка для моркови Кухонный комбайн ATH-360" title="соковыжималка для моркови Кухонный комбайн ATH-360"></a><h2>Кухонный комбайн ATH-360</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-moulinex-fp-6140r.php"><img src="photos/59cc932c7224c4f3a91684264a52c663.jpeg" alt="капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141" title="капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141"></a><h2>Кухонный комбайн Moulinex FP711141</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мультиварка мэджик под Чайник электрический Maxima MК- M211</h1>
						<div class="tb"><p>Цена: от <span class="price">1090</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18618.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Стильный электрический чайник MК- M211 мощностью 2000 Вт легко вскипятит за считанные минуты 1,7 литра, специальный съемный фильтр защитит от накипи, а автоматика заблокирует включение при отсутствии воды.<br>Стальной корпус и спираль чайника выполнены из нержавеющей стали, шнур легко спрятать в подставку, а внутренняя подсветка служит настоящим украшением.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Мощность 2000 Вт; <li>Емкость: 1,7 л; <li>Корпус из нержавеющей стали; <li>Нагревательный элемент из нержавеющей стали; <li>Автоматическое выключение при закипании; <li>Угол вращения на подставке 360; <li>Световой индикатор воды <li>Внутренняя подсветка; <li>Съемный фильтр против накипи; <li>Шкала уровня воды; <li>Удобное хранение шнура. </li></ul><p><strong>Производитель: MAXIMA (Англия)</strong><br><strong>Гарантия: 1 год</strong></p> мультиварка мэджик под</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/09368438bc3c0f6d8d6445abd5f08674.jpeg" alt="отважный тостер скачать Микроволновая печь Vitek VT-1693" title="отважный тостер скачать Микроволновая печь Vitek VT-1693"><div class="box" page="mikrovolnovaya-pech-vitek-vt-4150r"><span class="title">отважный тостер скачать Микроволновая печь Vitek VT-1693</span><p>от <span class="price">4150</span> руб.</p></div></li>
						<li><img src="photos/90a7d250cd580e7f7dad10ef41c4fe3e.jpeg" alt="купить блендер bosch Миксер Atlanta ATH-280" title="купить блендер bosch Миксер Atlanta ATH-280"><div class="box" page="mikser-atlanta-ath-510r"><span class="title">купить блендер bosch Миксер Atlanta ATH-280</span><p>от <span class="price">510</span> руб.</p></div></li>
						<li><img src="photos/7b810f6db4d02163ddaea09283048313.jpeg" alt="пельмени в мультиварке на пару Электрический миксер Bodum BISTRO 11151-913EURO белый" title="пельмени в мультиварке на пару Электрический миксер Bodum BISTRO 11151-913EURO белый"><div class="box" page="elektricheskiy-mikser-bodum-bistro-euro-belyy-2740r"><span class="title">пельмени в мультиварке на пару Электрический миксер Bodum BISTRO 11151-913EURO белый</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/5a5674539caee9c3fc9dbe29847298d4.jpeg" alt="мультиварка в новосибирске Мясорубка электрическая Vitek VT-1671 белая" title="мультиварка в новосибирске Мясорубка электрическая Vitek VT-1671 белая"><div class="box" page="myasorubka-elektricheskaya-vitek-vt-belaya-3300r"><span class="title">мультиварка в новосибирске Мясорубка электрическая Vitek VT-1671 белая</span><p>от <span class="price">3300</span> руб.</p></div></li>
						<li class="large"><img src="photos/5fe7a070a54ac64269e20fb9f52ff92c.jpeg" alt="рожок для кофеварки Zauber Цитрусовая соковыжималка  X 850" title="рожок для кофеварки Zauber Цитрусовая соковыжималка  X 850"><div class="box" page="zauber-citrusovaya-sokovyzhimalka-x-1000r"><span class="title">рожок для кофеварки Zauber Цитрусовая соковыжималка  X 850</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li class="large"><img src="photos/25bac4b45e0e97c9b045c0e23eb08977.jpeg" alt="пылесос для сбора стружки Хлебопечка Binatone BM-2169 Black с функцией «Домашний пекарь»" title="пылесос для сбора стружки Хлебопечка Binatone BM-2169 Black с функцией «Домашний пекарь»"><div class="box" page="hlebopechka-binatone-bm-black-s-funkciey-«domashniy-pekar»-4500r"><span class="title">пылесос для сбора стружки Хлебопечка Binatone BM-2169 Black с функцией «Домашний пекарь»</span><p>от <span class="price">4500</span> руб.</p></div></li>
						<li class="large"><img src="photos/46a5120709bf99f581bc7ea7569bd649.png" alt="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902" title="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902"><div class="box" page="hlebopech-redmond-rbmm-3990r"><span class="title">делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li><img src="photos/3eefca7b285e5c7425033f0997c9145b.jpeg" alt="scarlett утюг отзывы Чайник электрический Vitek VT-1104" title="scarlett утюг отзывы Чайник электрический Vitek VT-1104"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1350r"><span class="title">scarlett утюг отзывы Чайник электрический Vitek VT-1104</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li><img src="photos/396dcef56ae58a2fdd710c34b32d6011.jpeg" alt="чайник электрический тефаль Чайник электрический Maxima MК- M221 (1,8л)" title="чайник электрический тефаль Чайник электрический Maxima MК- M221 (1,8л)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-l-760r-2"><span class="title">чайник электрический тефаль Чайник электрический Maxima MК- M221 (1,8л)</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/96ed77acce770bf04afcf29723d61326.jpeg" alt="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas" title="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-2"><span class="title">мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-maxima-mk-m-1090r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-maxima-mk-m-1090r.php")) require_once "comments/chaynik-elektricheskiy-maxima-mk-m-1090r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-maxima-mk-m-1090r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>