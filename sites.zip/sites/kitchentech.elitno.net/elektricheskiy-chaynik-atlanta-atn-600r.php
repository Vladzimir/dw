<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-atlanta-atn-600r.php","рейтинг кофемашин для дома");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-atlanta-atn-600r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>рейтинг кофемашин для дома Электрический чайник Atlanta АТН-630  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="рейтинг кофемашин для дома, аэрогриль сервисный центр, кофемашина philips hd 8745, контрольная закупка пылесос, электрическая мультиварка, каталог мясорубок, кофеварка tefal express, мультиварка sr tmh 10, продам хлебопечку, ремень для хлебопечки, книга рецептов для хлебопечки, hyla пылесос цена, ремонт хлебопечки мулинекс, курица в микроволновой печи,  мясорубка для столовой">
		<meta name="description" content="рейтинг кофемашин для дома Электрический чайник Atlanta АТН-630 – стильный кухонный прибор выполненный из б...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/05e1cbbaa69c29b12d76f08b9352b558.jpeg" title="рейтинг кофемашин для дома Электрический чайник Atlanta АТН-630"><img src="photos/05e1cbbaa69c29b12d76f08b9352b558.jpeg" alt="рейтинг кофемашин для дома Электрический чайник Atlanta АТН-630" title="рейтинг кофемашин для дома Электрический чайник Atlanta АТН-630 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/zauber-kuhonnyy-kombayn-z-4250r.php"><img src="photos/dbd2c7c20aaeedc830453cfd862f3b68.jpeg" alt="аэрогриль сервисный центр Zauber Кухонный комбайн  Z-890" title="аэрогриль сервисный центр Zauber Кухонный комбайн  Z-890"></a><h2>Zauber Кухонный комбайн  Z-890</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-ci-silver-76390r.php"><img src="photos/c1f8cc6aba8e400d609d0ece06ae850b.jpeg" alt="кофемашина philips hd 8745 Эспрессо-кофемашина Melitta Caffeo CI Silver (4.0009.98)" title="кофемашина philips hd 8745 Эспрессо-кофемашина Melitta Caffeo CI Silver (4.0009.98)"></a><h2>Эспрессо-кофемашина Melitta Caffeo CI Silver (4.0009.98)</h2></li>
							<li><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-2740r.php"><img src="photos/b6c05d69ce9bf94410c78acce4c5e9cb.jpeg" alt="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер" title="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер"></a><h2>Bodum BISTRO 11151-01EURO Электрический миксер</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>рейтинг кофемашин для дома Электрический чайник Atlanta АТН-630</h1>
						<div class="tb"><p>Цена: от <span class="price">600</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19890.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Atlanta АТН-630 – стильный кухонный прибор выполненный из белого пластика мощностью 2000 Вт. За раз может кипятить до 2 литров воды. Может поворачиваться на подставке на 360 градусов. Имеет фильтр от накипи и функцию быстрого закипания. Используется защищенный закрытый нагревательный элемент, который гораздо проще мыть, чем открытую спираль. Безопасен, т. к. имеет защиту от перегрева, а также блокировку крышки и блокировку включения без воды. Предусмотрено место для электрошнура в цокольной подставке. </p><p><strong>Характеристики:</strong></p><ul type=disc><li>объем 2 л <li>мощность 2000 Вт <li>закрытая спираль из нержавеющей стали <li>установка на подставку в любом положении <li>пластиковый корпус <li>нейлоновый фильтр <li>индикатор уровня воды <li>автоматическое отключение <li>защита от перегрева воды <li>отсек для шнура <li>питание: ~ 220 В </li></ul><p><strong>Производитель: США</strong></p> рейтинг кофемашин для дома</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" alt="электрическая мультиварка Йогуртница Maxima MYM-0154" title="электрическая мультиварка Йогуртница Maxima MYM-0154"><div class="box"><a href="http://kitchentech.elitno.net/yogurtnica-maxima-mym-990r.php"><h3 class="title">электрическая мультиварка Йогуртница Maxima MYM-0154</h3><p>от <span class="price">990</span> руб.</p></a></div></li>
						<li><img src="photos/e07564a5fe71e20051b3b21f0806536a.jpeg" alt="каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam" title="каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam"><div class="box" page="sokovyzhimalka-moulinex-jue-tom-yam-1850r"><span class="title">каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li><img src="photos/7c9f70f739cded90e6e6da5bcbc9e960.jpeg" alt="кофеварка tefal express Чайник электрический Vitek VT-1138 серебряный" title="кофеварка tefal express Чайник электрический Vitek VT-1138 серебряный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-serebryanyy-1910r"><span class="title">кофеварка tefal express Чайник электрический Vitek VT-1138 серебряный</span><p>от <span class="price">1910</span> руб.</p></div></li>
						<li><img src="photos/b18048af79224983f1e624ba7e264cff.jpeg" alt="мультиварка sr tmh 10 Чайник электрический Vitek VT-1144 серебряный" title="мультиварка sr tmh 10 Чайник электрический Vitek VT-1144 серебряный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r"><span class="title">мультиварка sr tmh 10 Чайник электрический Vitek VT-1144 серебряный</span><p>от <span class="price">1550</span> руб.</p></div></li>
						<li class="large"><img src="photos/357a4e7af6a4eca2e30275a2d5d14351.jpeg" alt="продам хлебопечку Чайник электрический Binatone CEJ-1744 White" title="продам хлебопечку Чайник электрический Binatone CEJ-1744 White"><div class="box" page="chaynik-elektricheskiy-binatone-cej-white-880r"><span class="title">продам хлебопечку Чайник электрический Binatone CEJ-1744 White</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li class="large"><img src="photos/46f63d5550ab774c363b5ff4ba202c31.jpeg" alt="ремень для хлебопечки Чайник электрический Maxima MK- M191" title="ремень для хлебопечки Чайник электрический Maxima MK- M191"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-990r"><span class="title">ремень для хлебопечки Чайник электрический Maxima MK- M191</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li><img src="photos/d50a3dd0a5055f1b90b2cf35609b3ff0.jpeg" alt="hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС" title="hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС"><div class="box" page="nitrattester-nitratomer-soeks-5290r"><span class="title">hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС</span><p>от <span class="price">5290</span> руб.</p></div></li>
						<li><img src="photos/f16a6ea5caecf1d914f1d403108995e6.jpeg" alt="ремонт хлебопечки мулинекс Насадка утюг Thomas Steam-Iron для Vaporo Trolley" title="ремонт хлебопечки мулинекс Насадка утюг Thomas Steam-Iron для Vaporo Trolley"><div class="box" page="nasadka-utyug-thomas-steamiron-dlya-vaporo-trolley-2660r"><span class="title">ремонт хлебопечки мулинекс Насадка утюг Thomas Steam-Iron для Vaporo Trolley</span><p>от <span class="price">2660</span> руб.</p></div></li>
						<li><img src="photos/374cd707bc1b2fbce7e837896df1e0c0.jpeg" alt="курица в микроволновой печи Утюг паровой Tefal Supergliss FV3310EO" title="курица в микроволновой печи Утюг паровой Tefal Supergliss FV3310EO"><div class="box" page="utyug-parovoy-tefal-supergliss-fveo-1600r"><span class="title">курица в микроволновой печи Утюг паровой Tefal Supergliss FV3310EO</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/4a1c0420fc8819aad4437c29c4e568bd.jpeg" alt="пылесосы филлипс Утюг паровой Tefal Aquaspeed Ultracord FV5276" title="пылесосы филлипс Утюг паровой Tefal Aquaspeed Ultracord FV5276"><div class="box" page="utyug-parovoy-tefal-aquaspeed-ultracord-fv-3050r"><span class="title">пылесосы филлипс Утюг паровой Tefal Aquaspeed Ultracord FV5276</span><p>от <span class="price">3050</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-atlanta-atn-600r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-atlanta-atn-600r.php")) require_once "comments/elektricheskiy-chaynik-atlanta-atn-600r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-atlanta-atn-600r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>