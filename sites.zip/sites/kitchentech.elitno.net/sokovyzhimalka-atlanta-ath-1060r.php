<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-atlanta-ath-1060r.php","какой кухонный комбайн купить");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-atlanta-ath-1060r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>какой кухонный комбайн купить Соковыжималка Atlanta ATH-311  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="какой кухонный комбайн купить, где купить пароварку, мини пылесос божья коровка, мультиварка redmond 4504, утюг с парогенератором philips, пылесосы с аквафильтром soteco, кофеварка via veneto, стоит ли покупать мультиварку, бамбуковая пароварка, кофеварка полуавтомат, утюг tefal с парогенератором, бытовые микроволновые печи, хлебопечка советы, кофеварки домашние,  мини пылесос для дома">
		<meta name="description" content="какой кухонный комбайн купить Соковыжималка Atlanta ATH-311 бежевого цвета мощностью 300 Вт – простой и доступ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d5827497ec49ae3fe3cb85705f428a83.jpeg" title="какой кухонный комбайн купить Соковыжималка Atlanta ATH-311"><img src="photos/d5827497ec49ae3fe3cb85705f428a83.jpeg" alt="какой кухонный комбайн купить Соковыжималка Atlanta ATH-311" title="какой кухонный комбайн купить Соковыжималка Atlanta ATH-311 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-tefal-le-hachoir-me-5100r.php"><img src="photos/1a39977506779af8e80d3d2045a86d6b.jpeg" alt="где купить пароварку Мясорубка электрическая Tefal Le Hachoir ME7001" title="где купить пароварку Мясорубка электрическая Tefal Le Hachoir ME7001"></a><h2>Мясорубка электрическая Tefal Le Hachoir ME7001</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-tefal-le-hachoir-me-5880r.php"><img src="photos/a719c7f9b9161eaae5e6d50552aa1d04.jpeg" alt="мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011" title="мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011"></a><h2>Мясорубка электрическая Tefal Le Hachoir ME7011</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-3290r.php"><img src="photos/696c3eff6d4752e21e651f3d4b34c0a7.jpeg" alt="мультиварка redmond 4504 Мясорубка Redmond RMG-1204" title="мультиварка redmond 4504 Мясорубка Redmond RMG-1204"></a><h2>Мясорубка Redmond RMG-1204</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>какой кухонный комбайн купить Соковыжималка Atlanta ATH-311</h1>
						<div class="tb"><p>Цена: от <span class="price">1060</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19671.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Соковыжималка Atlanta ATH-311 бежевого цвета мощностью 300 Вт – простой и доступный прибор для приготовления сока в домашних условиях. Если вас не устраивают соки в магазине и вы хотите быть уверенными в качестве и полезности того что пьете, то используйте эту электрическую соковыжималку. Она предназначена, для приготовления сока не только из цитрусовых, но также из любых фруктов и ягод. Сок подается прямо в стакан, а мякоть автоматически выбрасывается.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Для всех видов фруктов <li>Мощность 300 Вт <li>Подача сока сразу в стакан <li>Автоматический выброс мякоти <li>Корпус из пластика <li>В x Ш x Г: 290 x 230 x 190 мм <li>Тип: универсальная <li>1 скорость <li>Комплектация: загрузочный лоток <li>Прорезиненные ножки <li>Резиновые ножки </li></ul><p><strong>Производитель: США</strong></p> какой кухонный комбайн купить</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/a5a669656630312240d0cb17c653dfea.jpeg" alt="утюг с парогенератором philips Соковыжималка Maxima MJ-059" title="утюг с парогенератором philips Соковыжималка Maxima MJ-059"><div class="box" page="sokovyzhimalka-maxima-mj-1090r"><span class="title">утюг с парогенератором philips Соковыжималка Maxima MJ-059</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/03d6a39216ccd97c8a662a35f965b076.jpeg" alt="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611" title="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611"><div class="box" page="sokovyzhimalka-vitek-vt-600r"><span class="title">пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611</span><p>от <span class="price">600</span> руб.</p></div></li>
						<li><img src="photos/99e95702b63a74224f733264159dce15.jpeg" alt="кофеварка via veneto Тостер Redmond RT-402" title="кофеварка via veneto Тостер Redmond RT-402"><div class="box" page="toster-redmond-rt-2490r"><span class="title">кофеварка via veneto Тостер Redmond RT-402</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/5a4405159d0c690183630df2cbdbbd36.jpeg" alt="стоит ли покупать мультиварку Чайник электрический Tefal VitesseS BF66224 1,7 л" title="стоит ли покупать мультиварку Чайник электрический Tefal VitesseS BF66224 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r"><span class="title">стоит ли покупать мультиварку Чайник электрический Tefal VitesseS BF66224 1,7 л</span><p>от <span class="price">1620</span> руб.</p></div></li>
						<li class="large"><img src="photos/3e5de65e23113a4dedb018c90159e3df.jpeg" alt="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной" title="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r"><span class="title">бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной</span><p>от <span class="price">1360</span> руб.</p></div></li>
						<li class="large"><img src="photos/8964576110671ffcda667fca45b4c191.jpeg" alt="кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л" title="кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1560r"><span class="title">кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л</span><p>от <span class="price">1560</span> руб.</p></div></li>
						<li class="large"><img src="photos/7f879f1e565356e4de3c725635f57ee6.jpeg" alt="утюг tefal с парогенератором Зарядное устройство GP Batteries PB360GS-UE1" title="утюг tefal с парогенератором Зарядное устройство GP Batteries PB360GS-UE1"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-270r"><span class="title">утюг tefal с парогенератором Зарядное устройство GP Batteries PB360GS-UE1</span><p>от <span class="price">270</span> руб.</p></div></li>
						<li><img src="photos/4fcdbef1e4068bc4641fdad47e086ca6.jpeg" alt="бытовые микроволновые печи Парогенератор Maxima MSC-2001" title="бытовые микроволновые печи Парогенератор Maxima MSC-2001"><div class="box" page="parogenerator-maxima-msc-1650r"><span class="title">бытовые микроволновые печи Парогенератор Maxima MSC-2001</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/cc9208f636d59db8c6c0a8ac95064dc7.jpeg" alt="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0" title="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0"><div class="box" page="shlang-podachi-vody-c-filtrom-karcher-1750r"><span class="title">хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0</span><p>от <span class="price">1750</span> руб.</p></div></li>
						<li><img src="photos/f08bd4abc7ad4c0cc84da510e6f6c4d3.jpeg" alt="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт." title="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт."><div class="box" page="filtr-dlya-pylesosa-vitek-vt-vt-sht-215r"><span class="title">кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт.</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li><img src="photos/d53c2ed7dc8f0cab982dc0b1633d551f.jpeg" alt="желтый пылесос Пылесос Atlanta АТН-3400" title="желтый пылесос Пылесос Atlanta АТН-3400"><div class="box" page="pylesos-atlanta-atn-3400r"><span class="title">желтый пылесос Пылесос Atlanta АТН-3400</span><p>от <span class="price">3400</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-atlanta-ath-1060r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-atlanta-ath-1060r.php")) require_once "comments/sokovyzhimalka-atlanta-ath-1060r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-atlanta-ath-1060r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>