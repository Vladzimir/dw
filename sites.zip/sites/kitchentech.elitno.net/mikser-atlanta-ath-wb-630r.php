<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("mikser-atlanta-ath-wb-630r.php","девушка с пылесосом");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("mikser-atlanta-ath-wb-630r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>девушка с пылесосом Миксер Atlanta ATH-263 WB  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="девушка с пылесосом, микроволновая печь эльдорадо, рецепты для хлебопечки sd 2500, электрочайник braun, чалдовые кофеварки, распродажа пылесосов, пылесосы с аквафильтром soteco, соковыжималка ангел, утюг с парогенератором philips, микроволновая печь работа, рецепты кофе в кофемашине, моющий пылесос для дома, соковыжималка philips 1866, пароварка tefal 7001,  купить рецепты для мультиварки">
		<meta name="description" content="девушка с пылесосом Стационарный миксер Atlanta ATH-263 WB с чашей – это хорошее качество, современн...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/8dac9aeadde6a6d95b71abb890265199.jpeg" title="девушка с пылесосом Миксер Atlanta ATH-263 WB"><img src="photos/8dac9aeadde6a6d95b71abb890265199.jpeg" alt="девушка с пылесосом Миксер Atlanta ATH-263 WB" title="девушка с пылесосом Миксер Atlanta ATH-263 WB -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ochistitel-ot-nakipi-dlya-filtrkofevarok-melitta-h-gr-325r.php"><img src="photos/aa2a1360189cc3efe864ba442a1ab29c.jpeg" alt="микроволновая печь эльдорадо Очиститель от накипи для фильтр-кофеварок Melitta, 6х20 гр" title="микроволновая печь эльдорадо Очиститель от накипи для фильтр-кофеварок Melitta, 6х20 гр"></a><h2>Очиститель от накипи для фильтр-кофеварок Melitta, 6х20 гр</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-1190r.php"><img src="photos/84ca91dc781f0bf5092809f8f5c5bf57.jpeg" alt="рецепты для хлебопечки sd 2500 Блендер Maxima MHB-0529" title="рецепты для хлебопечки sd 2500 Блендер Maxima MHB-0529"></a><h2>Блендер Maxima MHB-0529</h2></li>
							<li><a href="http://kitchentech.elitno.net/chopper-vitek-vt-1790r.php"><img src="photos/ab6d4d55ecf241ffc9d0ef81c9ea44bc.jpeg" alt="электрочайник braun Чоппер Vitek VT-1641" title="электрочайник braun Чоппер Vitek VT-1641"></a><h2>Чоппер Vitek VT-1641</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>девушка с пылесосом Миксер Atlanta ATH-263 WB</h1>
						<div class="tb"><p>Цена: от <span class="price">630</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19606.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Стационарный миксер Atlanta ATH-263 WB с чашей – это хорошее качество, современный дизайн, удобство и комфорт. С таким миксером вы откроете для себя много новых разнообразных блюд. Он компактный, поэтому не займет много места на кухне. Имеет 5 скоростей и кнопку для легкого извлечения насадок. Обладает мощностью 100 Вт. Поставляется с двумя комплектами металлических насадок.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Эргономичный дизайн <li>Разборная конструкция для легкой чистки <li>Вместительная чаша <li>Два комплекта металлических насадок <li>Кнопка легкого извлечения насадок <li>Пять скоростей <li>Размеры: 29x19.5x23.5 см </li></ul><p><strong>Производитель: США</strong></p> девушка с пылесосом</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/a59c30a3b2d8957f43e9fce5f7b6e0f5.jpeg" alt="чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная" title="чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-gourmet-chernaya-43999r"><span class="title">чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная</span><p>от <span class="price">43999</span> руб.</p></div></li>
						<li><img src="photos/7b88076a90f90c4718597a4ab977cb0a.jpeg" alt="распродажа пылесосов Микроволновая печь Vitek VT-1682" title="распродажа пылесосов Микроволновая печь Vitek VT-1682"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3550r"><span class="title">распродажа пылесосов Микроволновая печь Vitek VT-1682</span><p>от <span class="price">3550</span> руб.</p></div></li>
						<li><img src="photos/78e004a504b51dca5b370513a73854ac.jpeg" alt="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373" title="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373"><div class="box" page="myasorubka-atlanta-ath-2150r"><span class="title">пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/21689be9dc7c8e66c7cb248c7b6f5f86.jpeg" alt="соковыжималка ангел Пароварка Maxima MST-1102" title="соковыжималка ангел Пароварка Maxima MST-1102"><div class="box" page="parovarka-maxima-mst-1290r"><span class="title">соковыжималка ангел Пароварка Maxima MST-1102</span><p>от <span class="price">1290</span> руб.</p></div></li>
						<li class="large"><img src="photos/a5a669656630312240d0cb17c653dfea.jpeg" alt="утюг с парогенератором philips Соковыжималка Maxima MJ-059" title="утюг с парогенератором philips Соковыжималка Maxima MJ-059"><div class="box" page="sokovyzhimalka-maxima-mj-1090r"><span class="title">утюг с парогенератором philips Соковыжималка Maxima MJ-059</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li class="large"><img src="photos/ac081ce5674939d79667b2759a2f84a8.jpeg" alt="микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый" title="микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый"><div class="box" page="bodum-bistro-euro-toster-belyy-3660r"><span class="title">микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый</span><p>от <span class="price">3660</span> руб.</p></div></li>
						<li class="large"><img src="photos/03c71bbf8b5f2d86f3ae6ce6e9e77e58.jpeg" alt="рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая" title="рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая"><div class="box" page="frityurnica-vitek-vt-belaya-2950r"><span class="title">рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая</span><p>от <span class="price">2950</span> руб.</p></div></li>
						<li><img src="photos/b6d12be4b9eb96a31c69e83c45163c6c.jpeg" alt="моющий пылесос для дома Чайник электрический Atlanta ATH-751" title="моющий пылесос для дома Чайник электрический Atlanta ATH-751"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1600r"><span class="title">моющий пылесос для дома Чайник электрический Atlanta ATH-751</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/ba65472be620113b82aa055e0f7c89a6.jpeg" alt="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный" title="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-krasnyy-1510r"><span class="title">соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный</span><p>от <span class="price">1510</span> руб.</p></div></li>
						<li><img src="photos/7c67b6491c0da9489fd3f2ddee3c01b1.jpeg" alt="пароварка tefal 7001 Паровая гладильная система Sofia Lux" title="пароварка tefal 7001 Паровая гладильная система Sofia Lux"><div class="box" page="parovaya-gladilnaya-sistema-sofia-lux-69000r"><span class="title">пароварка tefal 7001 Паровая гладильная система Sofia Lux</span><p>от <span class="price">69000</span> руб.</p></div></li>
						<li><img src="photos/ab56fe42ec3af82144d9f5eb1f80eb4c.jpeg" alt="купить лопатку для хлебопечки Мини весы Tangent KP-103" title="купить лопатку для хлебопечки Мини весы Tangent KP-103"><div class="box" page="mini-vesy-tangent-kp-1200r"><span class="title">купить лопатку для хлебопечки Мини весы Tangent KP-103</span><p>от <span class="price">1200</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("mikser-atlanta-ath-wb-630r.php", 0, -4); if (file_exists("comments/mikser-atlanta-ath-wb-630r.php")) require_once "comments/mikser-atlanta-ath-wb-630r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="mikser-atlanta-ath-wb-630r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>