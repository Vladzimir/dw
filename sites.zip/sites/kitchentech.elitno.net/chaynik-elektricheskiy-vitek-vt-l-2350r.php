<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-l-2350r.php","российские пылесосы");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-l-2350r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>российские пылесосы Чайник электрический Vitek VT-1156 1,7 л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="российские пылесосы, рецепты для хлебопечки sd 2500, кофемашина saeco инструкция, zelmer мясорубка отзывы, тесто для мантов в хлебопечке, соковыжималки выбор, хлебопечка борк отзывы, покупка пылесоса, взбить сливки блендером, соковыжималка садовая, купить мясорубку панасоник, индукционная плита вредна, утюг braun 18895, держатель для пылесоса,  мясорубка moulinex hv8 me625">
		<meta name="description" content="российские пылесосы Электрический чайник Vitek VT-1156, рассчитанный на 1,7 л, обладает мощностью 22...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/480398a0d650a7b1a9641ca193d5ca18.jpeg" title="российские пылесосы Чайник электрический Vitek VT-1156 1,7 л"><img src="photos/480398a0d650a7b1a9641ca193d5ca18.jpeg" alt="российские пылесосы Чайник электрический Vitek VT-1156 1,7 л" title="российские пылесосы Чайник электрический Vitek VT-1156 1,7 л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-1190r.php"><img src="photos/84ca91dc781f0bf5092809f8f5c5bf57.jpeg" alt="рецепты для хлебопечки sd 2500 Блендер Maxima MHB-0529" title="рецепты для хлебопечки sd 2500 Блендер Maxima MHB-0529"></a><h2>Блендер Maxima MHB-0529</h2></li>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-blender-v-russell-hobbs-allure-art-3490r.php"><img src="photos/8eb90b2c93f90da38a9a78776cb9380e.jpeg" alt="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56" title="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56"></a><h2>Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-russell-hobbs-allure-art-5490r.php"><img src="photos/ac0d13475c79f9c87e6f514f3140de60.jpeg" alt="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56" title="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56"></a><h2>Блендер Russell Hobbs Allure, арт. 18276-56</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>российские пылесосы Чайник электрический Vitek VT-1156 1,7 л</h1>
						<div class="tb"><p>Цена: от <span class="price">2350</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_11216.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Электрический чайник </b><b>Vitek </b><b>VT-1156</b>, рассчитанный на 1,7 л, обладает мощностью 2200 Вт. Он обладает стильным современным дизайном, качественным исполнением и приемлемой ценой. Прибор не только украсит собой интерьер любой кухни, но и сделает быт проще и комфортнее. Чайник снабжен функцией поддержания температуры, имеет скрытый нагревательный элемент, оснащен нейлоновым фильтром, индикаторами включения и уровня воды, отсеком для удобного хранения шнура. В целях безопасности предусмотрена функция блокировки включения без воды.</p><p><b>Характеристики:</b></p><ul type=\disc\><li>Мощность: 2200 Вт; </li><li>Объем: 1,7 л; </li><li>Тип нагревательного элемента: закрытая спираль (центральный контакт); </li><li>Материал корпуса: пластик/стекло; </li><li>Блокировка включения без воды; </li><li>Фильтр из нейлона; </li><li>Индикатор уровня воды; </li><li>Индикация включения; </li><li>Подсветка воды при работе; </li><li>Отсек для шнура; </li><li>Функция поддержания температуры.</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна:</b> Россия.</p> российские пылесосы</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/26f6130b768cf990fa9fa11bd1f16cb3.jpeg" alt="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая" title="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-serebristaya-26999r"><span class="title">тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая</span><p>от <span class="price">26999</span> руб.</p></div></li>
						<li><img src="photos/3c4c438093f284e24176255dd4b7658c.jpeg" alt="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная" title="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-chernaya-26999r"><span class="title">соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная</span><p>от <span class="price">26999</span> руб.</p></div></li>
						<li><img src="photos/5cd90ccf1383ae054567f8f62fe579ca.jpeg" alt="хлебопечка борк отзывы Тостер Atlanta ATH-237" title="хлебопечка борк отзывы Тостер Atlanta ATH-237"><div class="box" page="toster-atlanta-ath-740r"><span class="title">хлебопечка борк отзывы Тостер Atlanta ATH-237</span><p>от <span class="price">740</span> руб.</p></div></li>
						<li><img src="photos/a6fb3c6ce325a3d2e51b29fc0035a27d.jpeg" alt="покупка пылесоса Чайник электрический Redmond RK-M107" title="покупка пылесоса Чайник электрический Redmond RK-M107"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1790r"><span class="title">покупка пылесоса Чайник электрический Redmond RK-M107</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li class="large"><img src="photos/3a6317b1e5aa0207019da754f6c2351b.jpeg" alt="взбить сливки блендером Электрический чайник Atlanta АТН-673" title="взбить сливки блендером Электрический чайник Atlanta АТН-673"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-560r"><span class="title">взбить сливки блендером Электрический чайник Atlanta АТН-673</span><p>от <span class="price">560</span> руб.</p></div></li>
						<li class="large"><img src="photos/a73fe1f79d4e2459d6da89e07445f626.jpeg" alt="соковыжималка садовая Электрический чайник Atlanta АТН-738" title="соковыжималка садовая Электрический чайник Atlanta АТН-738"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-520r"><span class="title">соковыжималка садовая Электрический чайник Atlanta АТН-738</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li class="large"><img src="photos/35040f2562bad52e53caa0b063a02983.jpeg" alt="купить мясорубку панасоник Автошампунь Karcher RM 806 (5 л) RU" title="купить мясорубку панасоник Автошампунь Karcher RM 806 (5 л) RU"><div class="box" page="avtoshampun-karcher-rm-l-ru-1000r"><span class="title">купить мясорубку панасоник Автошампунь Karcher RM 806 (5 л) RU</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/f508d547808db2bce707d6b2135eb926.jpeg" alt="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter" title="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r"><span class="title">индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter</span><p>от <span class="price">10800</span> руб.</p></div></li>
						<li><img src="photos/6a73d6f5ed044b39207ab31ca41595f1.jpeg" alt="утюг braun 18895 Пылесос моющий Thomas Bravo 20" title="утюг braun 18895 Пылесос моющий Thomas Bravo 20"><div class="box" page="pylesos-moyuschiy-thomas-bravo-8050r"><span class="title">утюг braun 18895 Пылесос моющий Thomas Bravo 20</span><p>от <span class="price">8050</span> руб.</p></div></li>
						<li><img src="photos/edc4236e3a4947da96211057e15ad9d5.jpeg" alt="держатель для пылесоса Пылесос Vitek VT-1847 красный" title="держатель для пылесоса Пылесос Vitek VT-1847 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3650r"><span class="title">держатель для пылесоса Пылесос Vitek VT-1847 красный</span><p>от <span class="price">3650</span> руб.</p></div></li>
						<li><img src="photos/c63cd71f0f3bdf494b47ddb76e88865f.jpeg" alt="мясорубка для столовой Утюг паровой Tefal Ultimate Autoclean FV9447E2" title="мясорубка для столовой Утюг паровой Tefal Ultimate Autoclean FV9447E2"><div class="box" page="utyug-parovoy-tefal-ultimate-autoclean-fve-4100r"><span class="title">мясорубка для столовой Утюг паровой Tefal Ultimate Autoclean FV9447E2</span><p>от <span class="price">4100</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-l-2350r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-l-2350r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-l-2350r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-l-2350r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>