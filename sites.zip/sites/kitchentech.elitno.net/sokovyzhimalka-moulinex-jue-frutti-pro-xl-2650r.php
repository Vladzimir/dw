<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-moulinex-jue-frutti-pro-xl-2650r.php","измельчитель кукурузы");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-moulinex-jue-frutti-pro-xl-2650r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>измельчитель кукурузы Соковыжималка Moulinex JU40013E Frutti Pro XL  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="измельчитель кукурузы, пылесос русский, пылесос thomas genius s2, мультиварка виконте купить, эльдорадо кофемашины, мультиварка ярославль, кофеварка нескафе дольче густо, хлебопечка борк отзывы, описание пылесоса, греется пылесос, карандаш для чистки утюга, кофеварка в киеве, пылесос thomas genius s2, мешки пылесборники для пылесосов,  соковыжималка сатурн">
		<meta name="description" content="измельчитель кукурузы Соковыжималка Moulinex Frutti Pro XL обладает стильным современным дизайном, кот...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/c1dcbf2233d55738f171a0b13874cec2.jpeg" title="измельчитель кукурузы Соковыжималка Moulinex JU40013E Frutti Pro XL"><img src="photos/c1dcbf2233d55738f171a0b13874cec2.jpeg" alt="измельчитель кукурузы Соковыжималка Moulinex JU40013E Frutti Pro XL" title="измельчитель кукурузы Соковыжималка Moulinex JU40013E Frutti Pro XL -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ochistitel-ot-nakipi-dlya-avtomaticheskih-kofemashin-melitta-h-gr-370r.php"><img src="photos/d471e6416e615c9ba8a65d072074d514.jpeg" alt="пылесос русский Очиститель от накипи для автоматических кофемашин Melitta, 2х40 гр" title="пылесос русский Очиститель от накипи для автоматических кофемашин Melitta, 2х40 гр"></a><h2>Очиститель от накипи для автоматических кофемашин Melitta, 2х40 гр</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2180r.php"><img src="photos/a1f8cd769afd06226b32e6fb44474c86.jpeg" alt="пылесос thomas genius s2 Блендер Redmond RHB-2908" title="пылесос thomas genius s2 Блендер Redmond RHB-2908"></a><h2>Блендер Redmond RHB-2908</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-violet-35700r.php"><img src="photos/2c16cbe8f56a0f4bc3c211204b3a9f27.jpeg" alt="мультиварка виконте купить Эспрессо-кофемашина Melitta Caffeo Lattea Violet (4.0009.93)" title="мультиварка виконте купить Эспрессо-кофемашина Melitta Caffeo Lattea Violet (4.0009.93)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Violet (4.0009.93)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>измельчитель кукурузы Соковыжималка Moulinex JU40013E Frutti Pro XL</h1>
						<div class="tb"><p>Цена: от <span class="price">2650</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_12018.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Соковыжималка </b><b>Moulinex </b><b>Frutti </b><b>Pro </b><b>XL</b> обладает стильным современным дизайном, который отлично впишется в интерьер любой кухни. Благодаря безупречному исполнению, прибор прослужит своим обладателям верой и правдой на протяжении долгого времени.</p><p>Мощность устройства - 700 Вт, имеется два скоростных режима для эффективной экстракции из разных по твердости фруктов и овощей, съемный резервуар для готового сока объемом 0,8 л. Широкое загрузочное отверстие позволяет загружать крупные фрукты без необходимости нарезать их. Система Direct Serve осуществляет прямую подачу свежевыжатого сока прямо в стакан. Соковыжималка оснащена тройной системой защиты, которая действует так: прибор не включится, если собран не правильно; отключится, если во время работы сместилось крепление или случится перегрев.</p><p><b>Характеристики:</b></p><ul type=disc><li>Универсальная; <li>Мощность: 700 Вт; <li>Максимальная скорость вращения: 11100 об/мин; <li>Количество скоростей: 2; <li>Диаметр загрузочного отверстия: 75 мм; <li>Резервуар для сока: стакан, объем 0,8 л; <li>Система прямой подачи сока; <li>Автоматический выброс мякоти: объем резервуара 1,35 л; <li>Система Direct Serve; <li>Материал корпуса: пластик; <li>Материал сетки центрифуги: нержавеющая сталь; <li>Круглая горловина; <li>Тройная система защиты; <li>Отсек для сетевого шнура; <li>Цвет: белый. </li></ul><p><b>Производитель:</b> Moulinex.</p><p><b>Страна:</b> Франция.</p><p><b>Гарантия:</b> 2 года.</p> измельчитель кукурузы</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="эльдорадо кофемашины Микроволновая печь Vitek VT-1684" title="эльдорадо кофемашины Микроволновая печь Vitek VT-1684"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3870r"><span class="title">эльдорадо кофемашины Микроволновая печь Vitek VT-1684</span><p>от <span class="price">3870</span> руб.</p></div></li>
						<li><img src="photos/9b1d673d9b457ad6c9a587ce93c1d42a.jpeg" alt="мультиварка ярославль Пароварка Tefal VitaCuisine Compact VC4003" title="мультиварка ярославль Пароварка Tefal VitaCuisine Compact VC4003"><div class="box" page="parovarka-tefal-vitacuisine-compact-vc-3530r"><span class="title">мультиварка ярославль Пароварка Tefal VitaCuisine Compact VC4003</span><p>от <span class="price">3530</span> руб.</p></div></li>
						<li><img src="photos/5ddb7c0074c19c7852a8997f3b296d03.jpeg" alt="кофеварка нескафе дольче густо Порционные весы NP-5001S" title="кофеварка нескафе дольче густо Порционные весы NP-5001S"><div class="box" page="porcionnye-vesy-nps-5260r"><span class="title">кофеварка нескафе дольче густо Порционные весы NP-5001S</span><p>от <span class="price">5260</span> руб.</p></div></li>
						<li><img src="photos/5cd90ccf1383ae054567f8f62fe579ca.jpeg" alt="хлебопечка борк отзывы Тостер Atlanta ATH-237" title="хлебопечка борк отзывы Тостер Atlanta ATH-237"><div class="box" page="toster-atlanta-ath-740r"><span class="title">хлебопечка борк отзывы Тостер Atlanta ATH-237</span><p>от <span class="price">740</span> руб.</p></div></li>
						<li class="large"><img src="photos/cfef38cef319ef880fc0959319ecdb34.jpeg" alt="описание пылесоса Чайник электрический Vitek VT-1154" title="описание пылесоса Чайник электрический Vitek VT-1154"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1010r"><span class="title">описание пылесоса Чайник электрический Vitek VT-1154</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/f529cddb8b0b7bbdfe7eea8e3d43b5b1.jpeg" alt="греется пылесос Чайник электрический Atlanta ATH-752" title="греется пылесос Чайник электрический Atlanta ATH-752"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1600r-2"><span class="title">греется пылесос Чайник электрический Atlanta ATH-752</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li class="large"><img src="photos/ab7fd4cacdc88b690decc0d20bd53770.jpeg" alt="карандаш для чистки утюга Чайник-термос Atlanta АТН-768" title="карандаш для чистки утюга Чайник-термос Atlanta АТН-768"><div class="box" page="chayniktermos-atlanta-atn-1700r"><span class="title">карандаш для чистки утюга Чайник-термос Atlanta АТН-768</span><p>от <span class="price">1700</span> руб.</p></div></li>
						<li><img src="photos/ef5f34c264e9ba8f2acfacd6c8c1863a.jpeg" alt="кофеварка в киеве Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-330" title="кофеварка в киеве Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-330"><div class="box" page="chaynik-diskovyy-keramicheskiy-l-golubye-cvety-zauber-eco-1760r"><span class="title">кофеварка в киеве Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-330</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li><img src="photos/94de14730b416ab6939a25c5af76e14e.jpeg" alt="пылесос thomas genius s2 Парогенератор Lelit PS11N" title="пылесос thomas genius s2 Парогенератор Lelit PS11N"><div class="box" page="parogenerator-lelit-psn-12000r"><span class="title">пылесос thomas genius s2 Парогенератор Lelit PS11N</span><p>от <span class="price">12000</span> руб.</p></div></li>
						<li><img src="photos/df4499dd6fe2786e58841593ed771f8f.jpeg" alt="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009" title="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009"><div class="box" page="moyuschiy-koncentrat-thomas-profloor-l-500r"><span class="title">мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009</span><p>от <span class="price">500</span> руб.</p></div></li>
						<li><img src="photos/a24b7e04e12ea5cc75354fc2b5ebd18d.jpeg" alt="фильтры для моющего пылесоса Пылесос Vitek VT-1809 черный" title="фильтры для моющего пылесоса Пылесос Vitek VT-1809 черный"><div class="box" page="pylesos-vitek-vt-chernyy-2600r"><span class="title">фильтры для моющего пылесоса Пылесос Vitek VT-1809 черный</span><p>от <span class="price">2600</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-moulinex-jue-frutti-pro-xl-2650r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-moulinex-jue-frutti-pro-xl-2650r.php")) require_once "comments/sokovyzhimalka-moulinex-jue-frutti-pro-xl-2650r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-moulinex-jue-frutti-pro-xl-2650r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>