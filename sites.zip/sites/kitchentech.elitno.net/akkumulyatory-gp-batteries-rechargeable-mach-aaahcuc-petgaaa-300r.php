<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r.php","кофемашины для чалд");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофемашины для чалд Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофемашины для чалд, тольятти мультиварка, пылесос прессующий, борщ в мультиварке панасоник, электрическая мультиварка, кофеварка espresso, микроволновая печь saturn, творожник в мультиварке, испечь черный хлеб в хлебопечке, как выбрать кофеварку, микроволновая печь электросхема, блендер vita mix, запчасти для пароварки, мясорубка с овощерезкой,  трубка для пылесоса">
		<meta name="description" content="кофемашины для чалд Аккумуляторы NiMh типа ААА разработаны в соответствии с современными особенностя...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/51ac41098d88811e7ab3241e4fa31a8c.jpeg" title="кофемашины для чалд Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA"><img src="photos/51ac41098d88811e7ab3241e4fa31a8c.jpeg" alt="кофемашины для чалд Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA" title="кофемашины для чалд Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofemolka-maxima-mcg-650r.php"><img src="photos/833ae77791168206a3b151985fda9a0b.jpeg" alt="тольятти мультиварка Кофемолка Maxima MCG-0316" title="тольятти мультиварка Кофемолка Maxima MCG-0316"></a><h2>Кофемолка Maxima MCG-0316</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-maxima-mfp-2190r.php"><img src="photos/3ee610b7cf277344aaeccda38d02c2fc.jpeg" alt="пылесос прессующий Кухонный комбайн Maxima MFP-0139" title="пылесос прессующий Кухонный комбайн Maxima MFP-0139"></a><h2>Кухонный комбайн Maxima MFP-0139</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikser-moulinex-hm-easy-max-2050r.php"><img src="photos/5254af3bd6ab9ae98e8b312cfa811acd.jpeg" alt="борщ в мультиварке панасоник Миксер Moulinex HM5500 Easy Max" title="борщ в мультиварке панасоник Миксер Moulinex HM5500 Easy Max"></a><h2>Миксер Moulinex HM5500 Easy Max</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофемашины для чалд Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA</h1>
						<div class="tb"><p>Цена: от <span class="price">300</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16537.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Аккумуляторы NiMh типа ААА разработаны в соответствии с современными особенностями портативных устройств. К примеру, зарядка цифрового фотоаппарата с такими элементами питания обеспечит непрерывную работу в 4 раза дольше, чем алкалиновые модели.</p><p>Среди особенностей можно отметить: отличную способность разряжаться большими токами, быструю зарядку, до 1000 циклов заряда-разряда, а также экологическую безопасность. В комплекте 2 штуки.</p><p><b>Характеристики:</b></p><ul type=\disc\><li>Технология производства: NiMh </li><li>Типоразмер: AAА </li><li>Максимальная емкость: 1300мАч </li><li>Напряжение: 1,2V </li><li>Имеют длительный срок службы (до 1000 циклов заряд/разряд) </li><li>Характеризуются стабильной работой в широком диапазоне температур (от –20 до +50С) </li><li>Полностью отсутствует \эффект памяти\ </li><li>Оснащены предохранительными клапанами (для избегания последствий нарушения условий эксплуатации) </li><li>Не содержат ртути и кадмия – безопасны для окружающей среды </li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p> кофемашины для чалд</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" alt="электрическая мультиварка Йогуртница Maxima MYM-0154" title="электрическая мультиварка Йогуртница Maxima MYM-0154"><div class="box" page="yogurtnica-maxima-mym-990r"><span class="title">электрическая мультиварка Йогуртница Maxima MYM-0154</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/ab2f5443010f5db248e8ed93f21ddbdb.jpeg" alt="кофеварка espresso Чайник электрический Binatone CEJ-3300 T Magic Thermo White Blue" title="кофеварка espresso Чайник электрический Binatone CEJ-3300 T Magic Thermo White Blue"><div class="box" page="chaynik-elektricheskiy-binatone-cej-t-magic-thermo-white-blue-1300r"><span class="title">кофеварка espresso Чайник электрический Binatone CEJ-3300 T Magic Thermo White Blue</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li><img src="photos/2e45225f75584b99ef16cc23171266ef.jpeg" alt="микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л" title="микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1740r"><span class="title">микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л</span><p>от <span class="price">1740</span> руб.</p></div></li>
						<li><img src="photos/737a030606bea9ae62642592848f785a.jpeg" alt="творожник в мультиварке Электрический чайник Atlanta АТН-650" title="творожник в мультиварке Электрический чайник Atlanta АТН-650"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-750r-2"><span class="title">творожник в мультиварке Электрический чайник Atlanta АТН-650</span><p>от <span class="price">750</span> руб.</p></div></li>
						<li class="large"><img src="photos/388c2880498e546d8fcebc787f1cf894.jpeg" alt="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO" title="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO"><div class="box" page="elektricheskiy-chaynik-l-chernyy-bodum-bistro-euro-2270r"><span class="title">испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li class="large"><img src="photos/022434340143cfbbf0a87e93fd1fc9c0.jpeg" alt="как выбрать кофеварку Щетка для собак Dyson Groom Retail" title="как выбрать кофеварку Щетка для собак Dyson Groom Retail"><div class="box" page="schetka-dlya-sobak-dyson-groom-retail-1690r"><span class="title">как выбрать кофеварку Щетка для собак Dyson Groom Retail</span><p>от <span class="price">1690</span> руб.</p></div></li>
						<li class="large"><img src="photos/00492fb3046ec485746c0b2d1a1385eb.jpeg" alt="микроволновая печь электросхема Пылесос Thomas Inox 1545 S" title="микроволновая печь электросхема Пылесос Thomas Inox 1545 S"><div class="box" page="pylesos-thomas-inox-s-10410r"><span class="title">микроволновая печь электросхема Пылесос Thomas Inox 1545 S</span><p>от <span class="price">10410</span> руб.</p></div></li>
						<li><img src="photos/2784b5cdf9478bbd2439685d61179e80.jpeg" alt="блендер vita mix Сушилка для рук AEG Haustehnik HE 181" title="блендер vita mix Сушилка для рук AEG Haustehnik HE 181"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-5900r"><span class="title">блендер vita mix Сушилка для рук AEG Haustehnik HE 181</span><p>от <span class="price">5900</span> руб.</p></div></li>
						<li><img src="photos/eb12162abf9f68b1f020c54d55eeb406.jpeg" alt="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM" title="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-tm-7800r"><span class="title">запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM</span><p>от <span class="price">7800</span> руб.</p></div></li>
						<li><img src="photos/ee03f1721014fcaa8f40d146634cc194.jpeg" alt="мясорубка с овощерезкой Утюг Vitek VT-1210" title="мясорубка с овощерезкой Утюг Vitek VT-1210"><div class="box" page="utyug-vitek-vt-850r"><span class="title">мясорубка с овощерезкой Утюг Vitek VT-1210</span><p>от <span class="price">850</span> руб.</p></div></li>
						<li><img src="photos/fce59058aae36b814631525a3763b63c.jpeg" alt="парогенератор видео Утюг Atlanta ATH-491" title="парогенератор видео Утюг Atlanta ATH-491"><div class="box" page="utyug-atlanta-ath-1100r"><span class="title">парогенератор видео Утюг Atlanta ATH-491</span><p>от <span class="price">1100</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r.php", 0, -4); if (file_exists("comments/akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r.php")) require_once "comments/akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>