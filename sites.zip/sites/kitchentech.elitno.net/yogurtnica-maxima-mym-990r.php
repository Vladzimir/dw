<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("yogurtnica-maxima-mym-990r.php","российские мясорубки");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("yogurtnica-maxima-mym-990r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>российские мясорубки Йогуртница Maxima MYM-0154  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="российские мясорубки, пароварка zelmer, сломалась мясорубка, аэрогриль ves инструкция, обслуживание пылесоса, крылышки в пароварке, пылесос karcher цена, куриное филе в пароварке, купить рецепты для мультиварки, пылесосы филипс отзывы, мясорубку panasonic купить, сколько стоит моющий пылесос, хлебопечки в новосибирске, пылесос bosch 82425,  панасоник соковыжималка">
		<meta name="description" content="российские мясорубки В конструкции йогуртницы предусмотрено 4 баночки,  выполненные из стекла (матери...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" title="российские мясорубки Йогуртница Maxima MYM-0154"><img src="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" alt="российские мясорубки Йогуртница Maxima MYM-0154" title="российские мясорубки Йогуртница Maxima MYM-0154 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-menu-bc-hc-4470r.php"><img src="photos/1f1d932d180978b8688482ed678b1aae.jpeg" alt="пароварка zelmer Блендер Braun MR-540 Menu BC HC" title="пароварка zelmer Блендер Braun MR-540 Menu BC HC"></a><h2>Блендер Braun MR-540 Menu BC HC</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rbp-1490r.php"><img src="photos/54c015da9ba000a4c33278978300bae5.jpeg" alt="сломалась мясорубка Блендер Redmond RB-P1301" title="сломалась мясорубка Блендер Redmond RB-P1301"></a><h2>Блендер Redmond RB-P1301</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-silverblack-35700r.php"><img src="photos/231121339f30404c6721c124df53c4d7.jpeg" alt="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)" title="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>российские мясорубки Йогуртница Maxima MYM-0154</h1>
						<div class="tb"><p>Цена: от <span class="price">990</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20497.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>В конструкции йогуртницы предусмотрено 4 баночки,  выполненные из стекла (материал корпуса самой йогуртницы выполнен из  гигиенического пластика). Емкость каждой баночки для йогурта 180 мл.  Светодиодная индикация работы и прозрачная крышка прибора позволяет  осуществлять контроль за приготовлением продукта.</p><p><br><strong>Характеристики:</strong></p><ul><li>Мощность: 10 Вт;</li><li>Материал: стекло/гигиенический пластик;</li><li>Светодиодная индикация;</li><li>Установка даты срока годности;</li><li>Общая емкость: 720 мл;</li></ul><p><strong>Производитель:</strong><strong> Maxima (Китай)</strong><br><strong>Изготовитель: Китай</strong><br><strong>Гарантия: 12 месяцев</strong></p> российские мясорубки</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/b6481108ed00fa262329eb9b4a9a7836.jpeg" alt="обслуживание пылесоса Микроволновая печь Vitek VT-1694" title="обслуживание пылесоса Микроволновая печь Vitek VT-1694"><div class="box"><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-3650r.php"><h3 class="title">обслуживание пылесоса Микроволновая печь Vitek VT-1694</h3><p>от <span class="price">3650</span> руб.</p></a></div></li>
						<li><img src="photos/1c1d1049958bdd0b6b9f6e6cb13db14b.jpeg" alt="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый" title="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый"><div class="box" page="mikrovolnovaya-pech-s-grilem-moulinex-mw-l-belyy-3890r"><span class="title">крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый</span><p>от <span class="price">3890</span> руб.</p></div></li>
						<li><img src="photos/6572a3244fa07fc4dc4c915b3dd0a9ff.jpeg" alt="пылесос karcher цена Хлебопечка Moulinex OW200033" title="пылесос karcher цена Хлебопечка Moulinex OW200033"><div class="box" page="hlebopechka-moulinex-ow-3800r"><span class="title">пылесос karcher цена Хлебопечка Moulinex OW200033</span><p>от <span class="price">3800</span> руб.</p></div></li>
						<li><img src="photos/c75538a0a02b722bb4d5b9c47eb925e7.jpeg" alt="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л" title="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r"><span class="title">куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л</span><p>от <span class="price">2570</span> руб.</p></div></li>
						<li class="large"><img src="photos/c4ed1ed9a910d5dd5d3b4d4cba707112.jpeg" alt="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP" title="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP"><div class="box" page="nasadka-dlya-matrasov-v-upakovke-dyson-mattress-tool-assy-retail-np-1090r"><span class="title">купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li class="large"><img src="photos/20c033d3c85583b2e6a71a21254a84f6.jpeg" alt="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail" title="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail"><div class="box" page="schetka-dlya-tverdyh-poverhnostey-v-upakovke-dyson-hard-floor-tool-assy-retail-1590r"><span class="title">пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail</span><p>от <span class="price">1590</span> руб.</p></div></li>
						<li class="large"><img src="photos/07ba23dd2664a1f6554e1b4f71151996.jpeg" alt="мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R" title="мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R"><div class="box" page="pylesos-moyuschiy-thomas-compact-r-7790r"><span class="title">мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R</span><p>от <span class="price">7790</span> руб.</p></div></li>
						<li><img src="photos/39a5505798446240c306b0610cc8e434.jpeg" alt="сколько стоит моющий пылесос Пылесос Vitek VT-1834" title="сколько стоит моющий пылесос Пылесос Vitek VT-1834"><div class="box" page="pylesos-vitek-vt-5890r"><span class="title">сколько стоит моющий пылесос Пылесос Vitek VT-1834</span><p>от <span class="price">5890</span> руб.</p></div></li>
						<li><img src="photos/a5307e77bbd77d05fd1bf891a3eeb5d0.jpeg" alt="хлебопечки в новосибирске Пылесос Vitek VT-1845 красный" title="хлебопечки в новосибирске Пылесос Vitek VT-1845 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-4590r"><span class="title">хлебопечки в новосибирске Пылесос Vitek VT-1845 красный</span><p>от <span class="price">4590</span> руб.</p></div></li>
						<li><img src="photos/53cb90a2ebb4ca3e913558aa9650be1d.jpeg" alt="пылесос bosch 82425 Пылесос Thomas Inox 1520 Plus" title="пылесос bosch 82425 Пылесос Thomas Inox 1520 Plus"><div class="box" page="pylesos-thomas-inox-plus-4730r"><span class="title">пылесос bosch 82425 Пылесос Thomas Inox 1520 Plus</span><p>от <span class="price">4730</span> руб.</p></div></li>
						<li><img src="photos/28ebbb0322a7eac61313d0d41391d394.jpeg" alt="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий" title="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-siniy-6900r"><span class="title">пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий</span><p>от <span class="price">6900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("yogurtnica-maxima-mym-990r.php", 0, -4); if (file_exists("comments/yogurtnica-maxima-mym-990r.php")) require_once "comments/yogurtnica-maxima-mym-990r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="yogurtnica-maxima-mym-990r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>