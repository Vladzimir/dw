<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chayniktermos-atlanta-atn-1570r.php","пылесосы производственные");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chayniktermos-atlanta-atn-1570r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесосы производственные Чайник-термос  Atlanta АТН-764  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесосы производственные, кофеварка делонги отзывы, bierhof кухонный комбайн, пылесос для ногтей, стоимость миксера, мотор пылесоса самсунг, самсунг пылесос робот, magic pot мультиварка, кофеварка нескафе дольче густо, схема пылесоса самсунг, турбощетка для пылесоса dyson, кофеварка эспрессо для дома, взбить сливки блендером, сравнение блендеров,  измельчитель сучьев">
		<meta name="description" content="пылесосы производственные Чайник-термос Atlanta АТН-764 – функциональный и стильный кухонный прибор, предн...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/ed1507cb4c766d544261d1f0cc2c6466.jpeg" title="пылесосы производственные Чайник-термос  Atlanta АТН-764"><img src="photos/ed1507cb4c766d544261d1f0cc2c6466.jpeg" alt="пылесосы производственные Чайник-термос  Atlanta АТН-764" title="пылесосы производственные Чайник-термос  Atlanta АТН-764 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/izmelchitel-ritter-mc-2700r.php"><img src="photos/b329bc8334f65653dc9ef4683c170e62.jpeg" alt="кофеварка делонги отзывы Измельчитель Ritter MC 800" title="кофеварка делонги отзывы Измельчитель Ritter MC 800"></a><h2>Измельчитель Ritter MC 800</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-73690r.php"><img src="photos/502f3c027327d4b33adc28c2b2f5d085.jpeg" alt="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica" title="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica"></a><h2>Кофемашина Nivona NICR850 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lounge-white-45500r.php"><img src="photos/45055ec55f153a8a82f9cf1191933a0c.jpeg" alt="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)" title="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесосы производственные Чайник-термос  Atlanta АТН-764</h1>
						<div class="tb"><p>Цена: от <span class="price">1570</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20011.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Чайник-термос Atlanta АТН-764 – функциональный и стильный кухонный прибор, предназначенный для кипячения и нагревания воды. Его мощность составляет 800 Вт при объеме 3 литра. Есть функция автоматической и ручной подачи воды. Используется защищенный закрытый нагревательный элемент, который гораздо проще мыть, чем открытую спираль. Безопасен, т. к. имеет защиту от перегрева, а также блокировку включения без воды. Установлена шкала уровня воды и индикатор работы. Соответствует европейским и американским нормам безопасности. Изделие сертифицировано Госстандартом РФ.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Функция автоматической подачи воды <li>Возможность ручной подачи воды <li>Функция автоматического подогрева <li>Шкала уровня воды <li>Автоматическое отключение при закипании <li>Защита от перегрева без воды <li>Индикатор работы <li>Быстрое закипание <li>Изделие сертифицировано Госстандартом РФ <li>Соответствует Европейским нормам безопасности <li>Емкость 3 литра <li>Мощность 800W <li>230V, 50Hz <li>27 x 27 x 35 см </li></ul><p><strong>Производитель: США</strong></p> пылесосы производственные</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/696246935af3c686fbf13206e4f5dbc0.jpeg" alt="стоимость миксера Кофемолка Nivona NICG120 CafeGrano" title="стоимость миксера Кофемолка Nivona NICG120 CafeGrano"><div class="box" page="kofemolka-nivona-nicg-cafegrano-4490r"><span class="title">стоимость миксера Кофемолка Nivona NICG120 CafeGrano</span><p>от <span class="price">4490</span> руб.</p></div></li>
						<li><img src="photos/99f24579a4151d885006823a70346b26.jpeg" alt="мотор пылесоса самсунг Электроплитка Maxima MES-0152-1" title="мотор пылесоса самсунг Электроплитка Maxima MES-0152-1"><div class="box" page="elektroplitka-maxima-mes-550r"><span class="title">мотор пылесоса самсунг Электроплитка Maxima MES-0152-1</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li><img src="photos/131f031076f016a5b0e85b06b57d0206.jpeg" alt="самсунг пылесос робот Микроволновая печь Vitek VT-1680" title="самсунг пылесос робот Микроволновая печь Vitek VT-1680"><div class="box" page="mikrovolnovaya-pech-vitek-vt-2200r"><span class="title">самсунг пылесос робот Микроволновая печь Vitek VT-1680</span><p>от <span class="price">2200</span> руб.</p></div></li>
						<li><img src="photos/be6b78c2525e9286d015556c4db7013b.jpeg" alt="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO" title="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO"><div class="box" page="elektricheskiy-mikser-krasnyy-bodum-bistro-euro-2740r"><span class="title">magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li class="large"><img src="photos/5ddb7c0074c19c7852a8997f3b296d03.jpeg" alt="кофеварка нескафе дольче густо Порционные весы NP-5001S" title="кофеварка нескафе дольче густо Порционные весы NP-5001S"><div class="box" page="porcionnye-vesy-nps-5260r"><span class="title">кофеварка нескафе дольче густо Порционные весы NP-5001S</span><p>от <span class="price">5260</span> руб.</p></div></li>
						<li class="large"><img src="photos/d5827497ec49ae3fe3cb85705f428a83.jpeg" alt="схема пылесоса самсунг Соковыжималка Atlanta ATH-311" title="схема пылесоса самсунг Соковыжималка Atlanta ATH-311"><div class="box" page="sokovyzhimalka-atlanta-ath-1060r"><span class="title">схема пылесоса самсунг Соковыжималка Atlanta ATH-311</span><p>от <span class="price">1060</span> руб.</p></div></li>
						<li class="large"><img src="photos/451a747bf2e464db6624d3824215adbf.jpeg" alt="турбощетка для пылесоса dyson Bodum BISTRO 11149-913EURO Электрическая соковыжималка белая" title="турбощетка для пылесоса dyson Bodum BISTRO 11149-913EURO Электрическая соковыжималка белая"><div class="box" page="bodum-bistro-euro-elektricheskaya-sokovyzhimalka-belaya-3340r"><span class="title">турбощетка для пылесоса dyson Bodum BISTRO 11149-913EURO Электрическая соковыжималка белая</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li><img src="photos/50b32a99f8069aa25115dc1163e0b555.jpeg" alt="кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л" title="кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1760r"><span class="title">кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li><img src="photos/3a6317b1e5aa0207019da754f6c2351b.jpeg" alt="взбить сливки блендером Электрический чайник Atlanta АТН-673" title="взбить сливки блендером Электрический чайник Atlanta АТН-673"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-560r"><span class="title">взбить сливки блендером Электрический чайник Atlanta АТН-673</span><p>от <span class="price">560</span> руб.</p></div></li>
						<li><img src="photos/41efedb38089aeb46a210ce7ff30eedc.jpeg" alt="сравнение блендеров Детектор жучков BugHunter Professional BH-01" title="сравнение блендеров Детектор жучков BugHunter Professional BH-01"><div class="box" page="detektor-zhuchkov-bughunter-professional-bh-7990r"><span class="title">сравнение блендеров Детектор жучков BugHunter Professional BH-01</span><p>от <span class="price">7990</span> руб.</p></div></li>
						<li><img src="photos/f08bd4abc7ad4c0cc84da510e6f6c4d3.jpeg" alt="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт." title="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт."><div class="box" page="filtr-dlya-pylesosa-vitek-vt-vt-sht-215r"><span class="title">кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт.</span><p>от <span class="price">215</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chayniktermos-atlanta-atn-1570r.php", 0, -4); if (file_exists("comments/chayniktermos-atlanta-atn-1570r.php")) require_once "comments/chayniktermos-atlanta-atn-1570r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chayniktermos-atlanta-atn-1570r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>