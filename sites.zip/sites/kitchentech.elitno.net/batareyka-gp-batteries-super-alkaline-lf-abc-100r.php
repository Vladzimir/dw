<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("batareyka-gp-batteries-super-alkaline-lf-abc-100r.php","микроволновая печь эльдорадо");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("batareyka-gp-batteries-super-alkaline-lf-abc-100r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>микроволновая печь эльдорадо Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="микроволновая печь эльдорадо, пылесос для ковролина, рецепт курицы в мультиварке, аэрогриль pag 1205d, кофемолка moulinex, купить кофеварку krups, как правильно выбрать пароварку, хлебопечка мулинекс 3101, купить вертикальный утюг, пылесос томас твин т1, рецепты для хлебопечки борк, индукционная плита с духовкой, ржаная мука для хлебопечки, мультиварка телефункен,  соковыжималка прессового отжима">
		<meta name="description" content="микроволновая печь эльдорадо Алкалиновая батарейка корунд обладает повышенной электрической емкостью, а также...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/c8d95936ceb77257c40da032828b68b2.jpeg" title="микроволновая печь эльдорадо Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1"><img src="photos/c8d95936ceb77257c40da032828b68b2.jpeg" alt="микроволновая печь эльдорадо Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1" title="микроволновая печь эльдорадо Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-atlanta-atn-990r.php"><img src="photos/096e72471ef2ac122b04cd03d0d34b33.jpeg" alt="пылесос для ковролина Блендер Atlanta АТН-343" title="пылесос для ковролина Блендер Atlanta АТН-343"></a><h2>Блендер Atlanta АТН-343</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-750r.php"><img src="photos/4a8644a2c29f22e2d9c92389f96ff2ab.jpeg" alt="рецепт курицы в мультиварке Кухонный комбайн ATH-350" title="рецепт курицы в мультиварке Кухонный комбайн ATH-350"></a><h2>Кухонный комбайн ATH-350</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-fioletovaya-29530r.php"><img src="photos/d992bf4d2cd488df4b63963039c83898.jpeg" alt="аэрогриль pag 1205d Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая" title="аэрогриль pag 1205d Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>микроволновая печь эльдорадо Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1</h1>
						<div class="tb"><p>Цена: от <span class="price">100</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16532.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Алкалиновая батарейка корунд обладает повышенной электрической емкостью, а также является экологически чистым продуктом, т.к. не содержит ртуть. Этот элемент питания будет особо эффективен в устройствах с высоким потреблением энергии, таких как: фонарики, пульты ДУ, фотовспышки и т.д. В комплекте 1 штука.</p><p><b>Характеристики:</b></p><ul type=disc><li>Технология производства: алкалиновая <li>Типоразмер: Корунд <li>Напряжение: 9V <li>Не содержат кадмия и ртути - экологически чистый продукт. <li>Обладают повышенной электрической емкостью. <li>Батарейки идеально подходят для устройств с высоким потреблением энергии. <li>Особенно эффективны в изделиях с высоким током потребления, таких как плееры, фонари, фотовспышки, электронные игрушки, переносные ТВ и т.д.</li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p> микроволновая печь эльдорадо</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/c585fc23a1c72232536c2283ac42fbc1.jpeg" alt="кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная" title="кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная"><div class="box" page="elektricheskaya-nozhevaya-kofemolka-bodum-bistro-euro-limonnaya-1830r"><span class="title">кофемолка moulinex Электрическая ножевая кофемолка Bodum BISTRO 11160-565EURO лимонная</span><p>от <span class="price">1830</span> руб.</p></div></li>
						<li><img src="photos/50077cb721bf68554cfd92d5a37bd83d.jpeg" alt="купить кофеварку krups Микроволновая печь Vitek VT-1686" title="купить кофеварку krups Микроволновая печь Vitek VT-1686"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3250r"><span class="title">купить кофеварку krups Микроволновая печь Vitek VT-1686</span><p>от <span class="price">3250</span> руб.</p></div></li>
						<li><img src="photos/966c1a147ae7eedce6463b74d364fbff.jpeg" alt="как правильно выбрать пароварку Пароварка Atlanta АТН-602" title="как правильно выбрать пароварку Пароварка Atlanta АТН-602"><div class="box" page="parovarka-atlanta-atn-1050r"><span class="title">как правильно выбрать пароварку Пароварка Atlanta АТН-602</span><p>от <span class="price">1050</span> руб.</p></div></li>
						<li><img src="photos/7903c21b4883d9e9c99d0a478392fee7.jpeg" alt="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906" title="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906"><div class="box" page="sokovyzhimalka-redmond-rjm-4990r"><span class="title">хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li class="large"><img src="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" alt="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56" title="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56"><div class="box" page="toster-russell-hobbs-jungle-green-art-1890r"><span class="title">купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li class="large"><img src="photos/58caa49e2e5c4bf06cfbf9dcdde29448.jpeg" alt="пылесос томас твин т1 Чайник электрический Vitek VT-1142" title="пылесос томас твин т1 Чайник электрический Vitek VT-1142"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1950r"><span class="title">пылесос томас твин т1 Чайник электрический Vitek VT-1142</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li class="large"><img src="photos/557cbb94f1e22c2ffcbdf56f26cfcf68.jpeg" alt="рецепты для хлебопечки борк Чайник электрический  Vitesse VS-101 1,7л, кремовый" title="рецепты для хлебопечки борк Чайник электрический  Vitesse VS-101 1,7л, кремовый"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-kremovyy-1120r"><span class="title">рецепты для хлебопечки борк Чайник электрический  Vitesse VS-101 1,7л, кремовый</span><p>от <span class="price">1120</span> руб.</p></div></li>
						<li><img src="photos/529e8107d5e5b446ac7668ecb3b5cd4b.jpeg" alt="индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке" title="индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке"><div class="box" page="dyson-turbine-head-assy-retail-turboschetka-v-upakovke-3290r"><span class="title">индукционная плита с духовкой Dyson Turbine Head Assy Retail Турбощетка в упаковке</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li><img src="photos/6ad68580ca9fe51d58dccc0df51b3bb5.jpeg" alt="ржаная мука для хлебопечки Пылесос моющий Thomas Twin Aquatherm + Aquafilter" title="ржаная мука для хлебопечки Пылесос моющий Thomas Twin Aquatherm + Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquatherm-aquafilter-16720r"><span class="title">ржаная мука для хлебопечки Пылесос моющий Thomas Twin Aquatherm + Aquafilter</span><p>от <span class="price">16720</span> руб.</p></div></li>
						<li><img src="photos/2e3efb1596b4e1a5bf1803f0fd03710f.jpeg" alt="мультиварка телефункен Пылесос Thomas Inox 30 Professional" title="мультиварка телефункен Пылесос Thomas Inox 30 Professional"><div class="box" page="pylesos-thomas-inox-professional-7740r"><span class="title">мультиварка телефункен Пылесос Thomas Inox 30 Professional</span><p>от <span class="price">7740</span> руб.</p></div></li>
						<li><img src="photos/84ad6b2565cb0b9ff7fa82ecd0bb4600.jpeg" alt="индукционная керамическая плита Утюг Vitek VT-1252" title="индукционная керамическая плита Утюг Vitek VT-1252"><div class="box" page="utyug-vitek-vt-1800r"><span class="title">индукционная керамическая плита Утюг Vitek VT-1252</span><p>от <span class="price">1800</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("batareyka-gp-batteries-super-alkaline-lf-abc-100r.php", 0, -4); if (file_exists("comments/batareyka-gp-batteries-super-alkaline-lf-abc-100r.php")) require_once "comments/batareyka-gp-batteries-super-alkaline-lf-abc-100r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="batareyka-gp-batteries-super-alkaline-lf-abc-100r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>