<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2.php","кастрюли для индукционных плит");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кастрюли для индукционных плит Чайник электрический Tefal Reminisce KI2016 1,7 л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кастрюли для индукционных плит, печенье песочное через мясорубку, мешки для пылесоса цена, продам мультиварку, запчасти для утюгов, спагетти в мультиварке, мясорубки в санкт петербурге, кофеварка espresso, daewoo микроволновая печь инструкция, кофеварки домашние, купить рецепты для мультиварки, овощи гриль в аэрогриле, аэрогриль lentel d101b, фильтр для пылесоса самсунг,  профессиональные кофемолки">
		<meta name="description" content="кастрюли для индукционных плит Стильный электрический чайник Tefal Reminisce KI2016 займет достойное место на в...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/92677a851872ec83258943db2c5f8e10.jpeg" title="кастрюли для индукционных плит Чайник электрический Tefal Reminisce KI2016 1,7 л"><img src="photos/92677a851872ec83258943db2c5f8e10.jpeg" alt="кастрюли для индукционных плит Чайник электрический Tefal Reminisce KI2016 1,7 л" title="кастрюли для индукционных плит Чайник электрический Tefal Reminisce KI2016 1,7 л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-hrom-3290r.php"><img src="photos/34e123d55d60377ab16c1ebb8978b506.jpeg" alt="печенье песочное через мясорубку Блендер Redmond RHB-2904 (хром)" title="печенье песочное через мясорубку Блендер Redmond RHB-2904 (хром)"></a><h2>Блендер Redmond RHB-2904 (хром)</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskaya-kofemolka-bodum-bistro-euro-limonnaya-5730r.php"><img src="photos/ebf4f38956f30ceea82d2b188167ae53.jpeg" alt="мешки для пылесоса цена Электрическая кофемолка Bodum BISTRO 10903-565EURO лимонная" title="мешки для пылесоса цена Электрическая кофемолка Bodum BISTRO 10903-565EURO лимонная"></a><h2>Электрическая кофемолка Bodum BISTRO 10903-565EURO лимонная</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-530r.php"><img src="photos/35ee696c1c92edfebad75db4602c2861.jpeg" alt="продам мультиварку Миксер Atlanta ATH-283" title="продам мультиварку Миксер Atlanta ATH-283"></a><h2>Миксер Atlanta ATH-283</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кастрюли для индукционных плит Чайник электрический Tefal Reminisce KI2016 1,7 л</h1>
						<div class="tb"><p>Цена: от <span class="price">2370</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_10475.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Стильный <b>электрический чайник </b><b>Tefal </b><b>Reminisce </b><b>KI2016</b> займет достойное место на вашей кухне, благодаря современному дизайну и безупречному исполнению. Он оформлен в практичном черном цвете, обладает мощностью 2400 Вт, рассчитан на стандартный объем жидкости – 1,7 л. Модель оснащена закрытым нагревательным элементом – спиралью (центральный контакт), съемным фильтром от накипи, индикацией включения, шкалой уровня воды. Также имеется блокировка крышки и отсек для хранения шнура. Отключается чайник автоматически.</p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 2400 Вт; <li>Объем: 1,7 л; <li>Тип нагревательного элемента: закрытая спираль (центральный контакт); <li>Съемный фильтр против накипи; <li>Индикатор уровня воды; <li>Индикация включения; <li>Блокировка крышки; <li>Автоотключение; <li>Отсек для шнура; <li>Цвет: черный.</li></ul><p><b>Производитель:</b> Tefal.</p><p><b>Страна: </b>Франция.</p><p><b>Гарантия: </b>2 года.</p> кастрюли для индукционных плит</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/785647aa8682372d107781ac6f9a4974.jpeg" alt="запчасти для утюгов Мультиварка Redmond RMC-M4504" title="запчасти для утюгов Мультиварка Redmond RMC-M4504"><div class="box" page="multivarka-redmond-rmcm-4490r"><span class="title">запчасти для утюгов Мультиварка Redmond RMC-M4504</span><p>от <span class="price">4490</span> руб.</p></div></li>
						<li><img src="photos/b4972945a0247403022f6df03f16440c.jpeg" alt="спагетти в мультиварке Пароварка-блендер Philips Avent 85300" title="спагетти в мультиварке Пароварка-блендер Philips Avent 85300"><div class="box" page="parovarkablender-philips-avent-5600r"><span class="title">спагетти в мультиварке Пароварка-блендер Philips Avent 85300</span><p>от <span class="price">5600</span> руб.</p></div></li>
						<li><img src="photos/54c54bed2f103aac514687168a05cb1f.jpeg" alt="мясорубки в санкт петербурге Тостер Russell Hobbs Cottage Floral, арт. 18513-56" title="мясорубки в санкт петербурге Тостер Russell Hobbs Cottage Floral, арт. 18513-56"><div class="box" page="toster-russell-hobbs-cottage-floral-art-2790r"><span class="title">мясорубки в санкт петербурге Тостер Russell Hobbs Cottage Floral, арт. 18513-56</span><p>от <span class="price">2790</span> руб.</p></div></li>
						<li><img src="photos/ab2f5443010f5db248e8ed93f21ddbdb.jpeg" alt="кофеварка espresso Чайник электрический Binatone CEJ-3300 T Magic Thermo White Blue" title="кофеварка espresso Чайник электрический Binatone CEJ-3300 T Magic Thermo White Blue"><div class="box" page="chaynik-elektricheskiy-binatone-cej-t-magic-thermo-white-blue-1300r"><span class="title">кофеварка espresso Чайник электрический Binatone CEJ-3300 T Magic Thermo White Blue</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li class="large"><img src="photos/0acc9f01a71196d6ab7726b81327e74c.jpeg" alt="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717" title="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-390r"><span class="title">daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li class="large"><img src="photos/f08bd4abc7ad4c0cc84da510e6f6c4d3.jpeg" alt="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт." title="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт."><div class="box" page="filtr-dlya-pylesosa-vitek-vt-vt-sht-215r"><span class="title">кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт.</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li class="large"><img src="photos/c4ed1ed9a910d5dd5d3b4d4cba707112.jpeg" alt="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP" title="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP"><div class="box" page="nasadka-dlya-matrasov-v-upakovke-dyson-mattress-tool-assy-retail-np-1090r"><span class="title">купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/d8b76d5d925f2e48955ce7204e57a699.jpeg" alt="овощи гриль в аэрогриле Набор для профилактики аллергии Dyson Allergy Kit Retail" title="овощи гриль в аэрогриле Набор для профилактики аллергии Dyson Allergy Kit Retail"><div class="box" page="nabor-dlya-profilaktiki-allergii-dyson-allergy-kit-retail-2490r"><span class="title">овощи гриль в аэрогриле Набор для профилактики аллергии Dyson Allergy Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
						<li><img src="photos/db8d0d28b1b05f19385269d855039f58.jpeg" alt="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833" title="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-5580r"><span class="title">фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833</span><p>от <span class="price">5580</span> руб.</p></div></li>
						<li><img src="photos/b5afd7c51355e06ff913b79a852afc55.jpeg" alt="пылесос с электрощеткой Утюг Binatone SI-4040 Blue" title="пылесос с электрощеткой Утюг Binatone SI-4040 Blue"><div class="box" page="utyug-binatone-si-blue-1600r"><span class="title">пылесос с электрощеткой Утюг Binatone SI-4040 Blue</span><p>от <span class="price">1600</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2.php")) require_once "comments/chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>