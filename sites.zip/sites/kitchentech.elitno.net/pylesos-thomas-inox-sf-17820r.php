<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-thomas-inox-sf-17820r.php","отечественные пылесосы");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-thomas-inox-sf-17820r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>отечественные пылесосы Пылесос Thomas Inox 1560 Sf  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="отечественные пылесосы, микроволновая печь польза, картофель во фритюрнице, электрическая мультиварка, рецепты для хлебопечки с сыром, утюг philips 4420, манник в мультиварке панасоник, купить кофемашину bosch, турбощетка для пылесоса dyson, запеканка в хлебопечке, как варить гречку в пароварке, купить лопатку для хлебопечки, купить кофемашину jura, кофемашина philips hd 8745,  профессиональные кофемолки">
		<meta name="description" content="отечественные пылесосы Пылесос Inox 1560 Sf от Thomas обладает практичным брызгозащищенным корпусом, вм...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/2ff9a2b5a9fe0fab492b8e041d2f7740.jpeg" title="отечественные пылесосы Пылесос Thomas Inox 1560 Sf"><img src="photos/2ff9a2b5a9fe0fab492b8e041d2f7740.jpeg" alt="отечественные пылесосы Пылесос Thomas Inox 1560 Sf" title="отечественные пылесосы Пылесос Thomas Inox 1560 Sf -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-krasnaya-29530r.php"><img src="photos/39e04c91cf56d7c949379d4f2e2d6076.jpeg" alt="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная" title="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, красная</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofevarka-ath-560r.php"><img src="photos/d1b139f63086ad817c04622c294f1224.jpeg" alt="картофель во фритюрнице Кофеварка  ATH-278" title="картофель во фритюрнице Кофеварка  ATH-278"></a><h2>Кофеварка  ATH-278</h2></li>
							<li><a href="http://kitchentech.elitno.net/yogurtnica-maxima-mym-990r.php"><img src="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" alt="электрическая мультиварка Йогуртница Maxima MYM-0154" title="электрическая мультиварка Йогуртница Maxima MYM-0154"></a><h2>Йогуртница Maxima MYM-0154</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>отечественные пылесосы Пылесос Thomas Inox 1560 Sf</h1>
						<div class="tb"><p>Цена: от <span class="price">17820</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14844.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Пылесос Inox 1560 Sf от Thomas обладает практичным брызгозащищенным корпусом, вместительным резервуаром объемом 60 литров, розеткой для подключения инструментов 2000 Вт, ходовой частью, оборудованной пластмассовым шасси. Мощность устройства – 1500 Вт.</p><p>Неважно, насколько сильно успела въесться грязь, или в каких уголках она «спряталась» - пылесос Thomas относится к поколению приборов, разработанных и созданных специально для выполнения самых сложных задач по удалению загрязнений. Благодаря продуманному дизайну, компактным размерам и удобной ручке, работать с этим пылесосом будет максимально комфортно.</p><p><b>Характеристики:</b></p><ul type=disc><li>Максимальная мощность 1500 Вт; <li>Двухступенчатая турбина большой мощности; <li>Компактный резервуар из высококачественной нержавеющей стали объемом 60 л; <li>Независимое байпасное охлаждение двигателя; <li>Брызгозащищенный корпус; <li>Розетка для подключения электроинструмента 2000 Вт; <li>Ходовая часть с пластмассовым шасси; <li>Два больших резиновых колеса сзади и два ходовых ролика спереди; <li>Пластмассовые и металлические всасывающие трубы; <li>Специальная металлическая насадка для промышленного использования Томас 1560 СФ; <li>Специальный тканевый фильтр; <li>Двойная комплектация; <li>Насадки: многоцелевая, для мягкой мебели, щелевая.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> отечественные пылесосы</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/f522dce957deccc1ec8ad4658577e80b.jpeg" alt="рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330" title="рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330"><div class="box" page="multivarka-moulinex-mk-4170r"><span class="title">рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330</span><p>от <span class="price">4170</span> руб.</p></div></li>
						<li><img src="photos/8e06126566eae5ed349414b3b9cfd8ea.jpeg" alt="утюг philips 4420 Мультиварка Maruchi RB-FC46" title="утюг philips 4420 Мультиварка Maruchi RB-FC46"><div class="box" page="multivarka-maruchi-rbfc-2500r"><span class="title">утюг philips 4420 Мультиварка Maruchi RB-FC46</span><p>от <span class="price">2500</span> руб.</p></div></li>
						<li><img src="photos/1f738d1ec8329b2501736d61b71f3914.jpeg" alt="манник в мультиварке панасоник Пароварка Tefal Invent VC1014" title="манник в мультиварке панасоник Пароварка Tefal Invent VC1014"><div class="box" page="parovarka-tefal-invent-vc-3930r"><span class="title">манник в мультиварке панасоник Пароварка Tefal Invent VC1014</span><p>от <span class="price">3930</span> руб.</p></div></li>
						<li><img src="photos/60dff82992355ef436c4e763a78c1f99.jpeg" alt="купить кофемашину bosch Соковыжималка для цитрусовых" title="купить кофемашину bosch Соковыжималка для цитрусовых"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-760r"><span class="title">купить кофемашину bosch Соковыжималка для цитрусовых</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/451a747bf2e464db6624d3824215adbf.jpeg" alt="турбощетка для пылесоса dyson Bodum BISTRO 11149-913EURO Электрическая соковыжималка белая" title="турбощетка для пылесоса dyson Bodum BISTRO 11149-913EURO Электрическая соковыжималка белая"><div class="box" page="bodum-bistro-euro-elektricheskaya-sokovyzhimalka-belaya-3340r"><span class="title">турбощетка для пылесоса dyson Bodum BISTRO 11149-913EURO Электрическая соковыжималка белая</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li class="large"><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="запеканка в хлебопечке Чайник электрический Maxima MK-G311" title="запеканка в хлебопечке Чайник электрический Maxima MK-G311"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1650r"><span class="title">запеканка в хлебопечке Чайник электрический Maxima MK-G311</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/c8d95936ceb77257c40da032828b68b2.jpeg" alt="как варить гречку в пароварке Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1" title="как варить гречку в пароварке Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1"><div class="box" page="batareyka-gp-batteries-super-alkaline-lf-abc-100r"><span class="title">как варить гречку в пароварке Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1</span><p>от <span class="price">100</span> руб.</p></div></li>
						<li><img src="photos/ab56fe42ec3af82144d9f5eb1f80eb4c.jpeg" alt="купить лопатку для хлебопечки Мини весы Tangent KP-103" title="купить лопатку для хлебопечки Мини весы Tangent KP-103"><div class="box" page="mini-vesy-tangent-kp-1200r"><span class="title">купить лопатку для хлебопечки Мини весы Tangent KP-103</span><p>от <span class="price">1200</span> руб.</p></div></li>
						<li><img src="photos/9fd5ef54211079a33ba5cc9bfbb9bfcf.jpeg" alt="купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter" title="купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-bravo-s-aquafilter-9270r"><span class="title">купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter</span><p>от <span class="price">9270</span> руб.</p></div></li>
						<li><img src="photos/daa26c20552b4c54039ad44aa7ab957b.jpeg" alt="кофемашина philips hd 8745 Пылесос Thomas Inox 1530" title="кофемашина philips hd 8745 Пылесос Thomas Inox 1530"><div class="box" page="pylesos-thomas-inox-6310r"><span class="title">кофемашина philips hd 8745 Пылесос Thomas Inox 1530</span><p>от <span class="price">6310</span> руб.</p></div></li>
						<li><img src="photos/03817b6f2ca60ce9b5c33914a6a1ea52.jpeg" alt="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter" title="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter"><div class="box" page="pylesos-thomas-genius-aquafilter-9480r"><span class="title">сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter</span><p>от <span class="price">9480</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-thomas-inox-sf-17820r.php", 0, -4); if (file_exists("comments/pylesos-thomas-inox-sf-17820r.php")) require_once "comments/pylesos-thomas-inox-sf-17820r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-thomas-inox-sf-17820r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>