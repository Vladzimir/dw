<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-atlanta-atn-560r.php","купить детский пылесос");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-atlanta-atn-560r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>купить детский пылесос Электрический чайник Atlanta АТН-673  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="купить детский пылесос, пылесос roomy gold, аэрогриль ves инструкция, аэрогриль pag 1205d, лестничные перила, соковыжималка ангел, сепараторный пылесос, сравнить пароварки, блендер бош купить, кофемашина jura impressa c5, пылесос thomas отзывы, принцип микроволновой печи, чайник электрический тефаль, мясорубка кенвуд 720,  хлебопечка кефир">
		<meta name="description" content="купить детский пылесос Электрический чайник Atlanta АТН-673 – стильный кухонный прибор, мощностью 2000 ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3a6317b1e5aa0207019da754f6c2351b.jpeg" title="купить детский пылесос Электрический чайник Atlanta АТН-673"><img src="photos/3a6317b1e5aa0207019da754f6c2351b.jpeg" alt="купить детский пылесос Электрический чайник Atlanta АТН-673" title="купить детский пылесос Электрический чайник Atlanta АТН-673 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-35190r.php"><img src="photos/df4de2da7d663a4198320cc2af72f271.jpeg" alt="пылесос roomy gold Кофемашина Nivona NICR650 CafeRomatica" title="пылесос roomy gold Кофемашина Nivona NICR650 CafeRomatica"></a><h2>Кофемашина Nivona NICR650 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-silverblack-35700r.php"><img src="photos/231121339f30404c6721c124df53c4d7.jpeg" alt="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)" title="аэрогриль ves инструкция Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Silver-Black (4.0009.96)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-fioletovaya-29530r.php"><img src="photos/d992bf4d2cd488df4b63963039c83898.jpeg" alt="аэрогриль pag 1205d Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая" title="аэрогриль pag 1205d Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>купить детский пылесос Электрический чайник Atlanta АТН-673</h1>
						<div class="tb"><p>Цена: от <span class="price">560</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19952.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Atlanta АТН-673 – стильный кухонный прибор, мощностью 2000 Вт и объемом 1,7 л. воды. Может поворачиваться на подставке на 360 градусов. Имеет фильтр от накипи и функцию быстрого закипания. Используется защищенный закрытый нагревательный элемент, который гораздо проще мыть, чем открытую спираль. Безопасен, т. к. имеет защиту от перегрева, а также блокировку крышки и блокировку включения без воды. Предусмотрено место для электрошнура в цокольной подставке.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Объем чайника 1.7 литра <li>Поворот на подставке на 360  <li>Быстрое закипание <li>Фильтр от накипи <li>Закрытый нагревательный элемент <li>Автоматическое отключение <li>Защита от перегрева без воды <li>Электрошнур в цокольной подставке <li>Мощность 2000W <li>230V, 50Hz <li>20 x 18 x 24.5 см </li></ul><p><strong>Производитель: США</strong></p> купить детский пылесос</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7e647600a38b01c48fb301e5b6c41520.jpeg" alt="лестничные перила Миксер Russell Hobbs Desire, арт. 18507-56" title="лестничные перила Миксер Russell Hobbs Desire, арт. 18507-56"><div class="box" page="mikser-russell-hobbs-desire-art-1290r"><span class="title">лестничные перила Миксер Russell Hobbs Desire, арт. 18507-56</span><p>от <span class="price">1290</span> руб.</p></div></li>
						<li><img src="photos/21689be9dc7c8e66c7cb248c7b6f5f86.jpeg" alt="соковыжималка ангел Пароварка Maxima MST-1102" title="соковыжималка ангел Пароварка Maxima MST-1102"><div class="box" page="parovarka-maxima-mst-1290r"><span class="title">соковыжималка ангел Пароварка Maxima MST-1102</span><p>от <span class="price">1290</span> руб.</p></div></li>
						<li><img src="photos/df340437daa709a0dfc3dc87ab1880bc.jpeg" alt="сепараторный пылесос Индукционная плита Kitfort KT-102" title="сепараторный пылесос Индукционная плита Kitfort KT-102"><div class="box" page="indukcionnaya-plita-kitfort-kt-3000r"><span class="title">сепараторный пылесос Индукционная плита Kitfort KT-102</span><p>от <span class="price">3000</span> руб.</p></div></li>
						<li><img src="photos/a5a944903050174bbca074a40d4e65fa.jpeg" alt="сравнить пароварки Соковыжималка Atlanta ATH-325" title="сравнить пароварки Соковыжималка Atlanta ATH-325"><div class="box" page="sokovyzhimalka-atlanta-ath-520r"><span class="title">сравнить пароварки Соковыжималка Atlanta ATH-325</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li class="large"><img src="photos/76b45e609e76d0f51a02bc816db807a1.jpeg" alt="блендер бош купить Тостер Maxima MT-014" title="блендер бош купить Тостер Maxima MT-014"><div class="box" page="toster-maxima-mt-540r"><span class="title">блендер бош купить Тостер Maxima MT-014</span><p>от <span class="price">540</span> руб.</p></div></li>
						<li class="large"><img src="photos/35bc2a6ec9e7fd46ce73f8c296c53df9.jpeg" alt="кофемашина jura impressa c5 Чайник электрический Vitek VT-1102 черный" title="кофемашина jura impressa c5 Чайник электрический Vitek VT-1102 черный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-chernyy-2000r"><span class="title">кофемашина jura impressa c5 Чайник электрический Vitek VT-1102 черный</span><p>от <span class="price">2000</span> руб.</p></div></li>
						<li class="large"><img src="photos/8e4c77fcf3cd711bd8454688ff0f7bc7.jpeg" alt="пылесос thomas отзывы Чайник электрический Vitek VT-1159" title="пылесос thomas отзывы Чайник электрический Vitek VT-1159"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1900r"><span class="title">пылесос thomas отзывы Чайник электрический Vitek VT-1159</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li><img src="photos/3db103a42b99a0a770887670f28f5ba2.jpeg" alt="принцип микроволновой печи Чайник электрический Moulinex BY5101 1,5 л" title="принцип микроволновой печи Чайник электрический Moulinex BY5101 1,5 л"><div class="box" page="chaynik-elektricheskiy-moulinex-by-l-1950r"><span class="title">принцип микроволновой печи Чайник электрический Moulinex BY5101 1,5 л</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/396dcef56ae58a2fdd710c34b32d6011.jpeg" alt="чайник электрический тефаль Чайник электрический Maxima MК- M221 (1,8л)" title="чайник электрический тефаль Чайник электрический Maxima MК- M221 (1,8л)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-l-760r-2"><span class="title">чайник электрический тефаль Чайник электрический Maxima MК- M221 (1,8л)</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/551d442551f93894a75244967e399a27.jpeg" alt="мясорубка кенвуд 720 Чайник электрический  Vitesse VS-141 1,8л" title="мясорубка кенвуд 720 Чайник электрический  Vitesse VS-141 1,8л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-990r"><span class="title">мясорубка кенвуд 720 Чайник электрический  Vitesse VS-141 1,8л</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/06055c0461eed094ac9207cd105de4ec.jpeg" alt="микроволновые печи с духовкой Электрический чайник 1.5л белый Bodum Bistro 11138-913EURO" title="микроволновые печи с духовкой Электрический чайник 1.5л белый Bodum Bistro 11138-913EURO"><div class="box" page="elektricheskiy-chaynik-l-belyy-bodum-bistro-euro-2740r"><span class="title">микроволновые печи с духовкой Электрический чайник 1.5л белый Bodum Bistro 11138-913EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-atlanta-atn-560r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-atlanta-atn-560r.php")) require_once "comments/elektricheskiy-chaynik-atlanta-atn-560r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-atlanta-atn-560r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>