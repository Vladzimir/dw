<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r.php","пароварка tefal vc 1016");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пароварка tefal vc 1016 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пароварка tefal vc 1016, хлебопечка ру рецепты, пылесос для ковролина, схема пылесоса самсунг, рецепты кофе в кофемашине, какой пылесос самый лучший, аэрогриль pag 1205d, мультиварка киев купить, фритюрница philips, лучшие рецепты для мультиварки, баклажаны в пароварке, индукционная плита вредна, кофемашина philips hd 8745, утюг в туле,  профессиональные кофемолки">
		<meta name="description" content="пароварка tefal vc 1016 Незаменимым предметом на любой кухне является, без сомнений,  современный и удоб...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/df7a2601f4d7471689f34a2d1cbcf14f.jpeg" title="пароварка tefal vc 1016 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO"><img src="photos/df7a2601f4d7471689f34a2d1cbcf14f.jpeg" alt="пароварка tefal vc 1016 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO" title="пароварка tefal vc 1016 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/oksiochistitel-ot-nakipi-swirl-hg-90r.php"><img src="photos/b1940086e49964580ca58fbacc9f1c79.jpeg" alt="хлебопечка ру рецепты Окси-очиститель от накипи Swirl, 2х15г" title="хлебопечка ру рецепты Окси-очиститель от накипи Swirl, 2х15г"></a><h2>Окси-очиститель от накипи Swirl, 2х15г</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-atlanta-atn-990r.php"><img src="photos/096e72471ef2ac122b04cd03d0d34b33.jpeg" alt="пылесос для ковролина Блендер Atlanta АТН-343" title="пылесос для ковролина Блендер Atlanta АТН-343"></a><h2>Блендер Atlanta АТН-343</h2></li>
							<li><a href="http://kitchentech.elitno.net/sokovyzhimalka-atlanta-ath-1060r.php"><img src="photos/d5827497ec49ae3fe3cb85705f428a83.jpeg" alt="схема пылесоса самсунг Соковыжималка Atlanta ATH-311" title="схема пылесоса самсунг Соковыжималка Atlanta ATH-311"></a><h2>Соковыжималка Atlanta ATH-311</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пароварка tefal vc 1016 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO</h1>
						<div class="tb"><p>Цена: от <span class="price">2740</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_26398.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Незаменимым предметом на любой кухне является, без сомнений,  современный и удобный в использовании электрический чайник. Электрический  чайник BISTRO 11138-565EURO от швейцарской компании Bodum обладает не  только отличными техническими характеристиками, но и привлекательным дизайном.  Чайник Bodum BISTRO 11138-565EURO имеет оптимальный объем (1,5 литра),  специальный съемный фильтр, индикатор уровня воды, а также функцию блокировки  включения без воды. Внешне данная модель выполнена в экстравагантном зеленом  цвете, что позволит ей легко вписаться в интерьер вашей кухни.  </p> <p><strong>Характеристики:</strong></p> <ul type=disc>   <li>Тип:       электрический;</li>   <li>Объем:       1,5 л;</li>   <li>Материал       корпуса: пластик;</li>   <li>Мощность:       2200 Вт;</li>   <li>Нагревательный       элемент: дисковый нагреватель (скрытый);</li>   <li>Съемный       фильтр;</li>   <li>Индикатор       уровня воды;</li>   <li>Блокировка       включения без воды;</li>   <li>Цвет:       зеленый.</li> </ul> <p><strong>Производитель: Bodum  (Швейцария)</strong></p> пароварка tefal vc 1016</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/03c71bbf8b5f2d86f3ae6ce6e9e77e58.jpeg" alt="рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая" title="рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая"><div class="box"><a href="http://kitchentech.elitno.net/frityurnica-vitek-vt-belaya-2950r.php"><h3 class="title">рецепты кофе в кофемашине Фритюрница Vitek VT-1531 белая</h3><p>от <span class="price">2950</span> руб.</p></a></div></li>
						<li><img src="photos/27ce5b772a93a2336124e9a6817baf03.jpeg" alt="какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000" title="какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000"><div class="box" page="frityurnica-tefal-actifry-fz-7700r"><span class="title">какой пылесос самый лучший Фритюрница Tefal Actifry FZ7000</span><p>от <span class="price">7700</span> руб.</p></div></li>
						<li><img src="photos/823ffa497493bf85b62e76ddeebc1296.jpeg" alt="аэрогриль pag 1205d Чайник электрический Redmond  RK-М117 white" title="аэрогриль pag 1205d Чайник электрический Redmond  RK-М117 white"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-white-1190r"><span class="title">аэрогриль pag 1205d Чайник электрический Redmond  RK-М117 white</span><p>от <span class="price">1190</span> руб.</p></div></li>
						<li><img src="photos/1b3cfce3fc4c2602ab4206bda1961e7d.jpeg" alt="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный" title="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belolazurnyy-920r"><span class="title">мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li class="large"><img src="photos/9b828fe53dfca2c4781201b615fd512e.jpeg" alt="фритюрница philips Чайник электрический  Vitesse VS-137 1,7л бело-синий" title="фритюрница philips Чайник электрический  Vitesse VS-137 1,7л бело-синий"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belosiniy-920r"><span class="title">фритюрница philips Чайник электрический  Vitesse VS-137 1,7л бело-синий</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li class="large"><img src="photos/bf71bbc1609948054c42cfa52f5f228d.jpeg" alt="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas" title="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r"><span class="title">лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li class="large"><img src="photos/916a75c3d4cbc8ec64d3ba505b733ba5.jpeg" alt="баклажаны в пароварке Воздушный фильтр Redmond  HEPA-фильтр RV-312" title="баклажаны в пароварке Воздушный фильтр Redmond  HEPA-фильтр RV-312"><div class="box" page="vozdushnyy-filtr-redmond-hepafiltr-rv-390r"><span class="title">баклажаны в пароварке Воздушный фильтр Redmond  HEPA-фильтр RV-312</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/f508d547808db2bce707d6b2135eb926.jpeg" alt="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter" title="индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r"><span class="title">индукционная плита вредна Пылесос моющий Thomas Prestige 20 S Aquafilter</span><p>от <span class="price">10800</span> руб.</p></div></li>
						<li><img src="photos/daa26c20552b4c54039ad44aa7ab957b.jpeg" alt="кофемашина philips hd 8745 Пылесос Thomas Inox 1530" title="кофемашина philips hd 8745 Пылесос Thomas Inox 1530"><div class="box" page="pylesos-thomas-inox-6310r"><span class="title">кофемашина philips hd 8745 Пылесос Thomas Inox 1530</span><p>от <span class="price">6310</span> руб.</p></div></li>
						<li><img src="photos/d7f319eafa0a03def3b072699daeccdd.jpeg" alt="утюг в туле Утюг Vitek VT-1235" title="утюг в туле Утюг Vitek VT-1235"><div class="box" page="utyug-vitek-vt-970r"><span class="title">утюг в туле Утюг Vitek VT-1235</span><p>от <span class="price">970</span> руб.</p></div></li>
						<li><img src="photos/7fe394e6e0402a674ba207691524344d.jpeg" alt="мясорубка moulinex hv8 me625 Утюг Atlanta ATH-434" title="мясорубка moulinex hv8 me625 Утюг Atlanta ATH-434"><div class="box" page="utyug-atlanta-ath-680r"><span class="title">мясорубка moulinex hv8 me625 Утюг Atlanta ATH-434</span><p>от <span class="price">680</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r.php")) require_once "comments/elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>