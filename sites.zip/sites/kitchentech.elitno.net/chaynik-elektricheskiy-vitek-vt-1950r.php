<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-1950r.php","какой робот пылесос");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-1950r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>какой робот пылесос Чайник электрический Vitek VT-1142  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="какой робот пылесос, купить блендер кенвуд, кофеварка делонги отзывы, пылесос lg с контейнером, сравнить пароварки, соковыжималка филипс, где купить ручную мясорубку, продам вафельницу, кофеварка tefal express, мультиварка панасоник sr tmh18, сварить кофе в кофеварке, кофемашина la cimbali, panasonic блендер, блендер vita mix,  соковыжималка прессового отжима">
		<meta name="description" content="какой робот пылесос Чайник электрический Vitek VT-1142 в стильном корпусе из нержавеющей стали с дву...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/58caa49e2e5c4bf06cfbf9dcdde29448.jpeg" title="какой робот пылесос Чайник электрический Vitek VT-1142"><img src="photos/58caa49e2e5c4bf06cfbf9dcdde29448.jpeg" alt="какой робот пылесос Чайник электрический Vitek VT-1142" title="какой робот пылесос Чайник электрический Vitek VT-1142 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-baby-2000r.php"><img src="photos/612bb1b2d8bad8dc8e3250c8f9903851.jpeg" alt="купить блендер кенвуд Блендер Braun MR-320 Baby" title="купить блендер кенвуд Блендер Braun MR-320 Baby"></a><h2>Блендер Braun MR-320 Baby</h2></li>
							<li><a href="http://kitchentech.elitno.net/izmelchitel-ritter-mc-2700r.php"><img src="photos/b329bc8334f65653dc9ef4683c170e62.jpeg" alt="кофеварка делонги отзывы Измельчитель Ritter MC 800" title="кофеварка делонги отзывы Измельчитель Ritter MC 800"></a><h2>Измельчитель Ritter MC 800</h2></li>
							<li><a href="http://kitchentech.elitno.net/sokovyzhimalka-moulinex-juae-juice-machine-4300r.php"><img src="photos/d78a5eb7926a57e3a6daeb54a8fc1659.jpeg" alt="пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine" title="пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine"></a><h2>Соковыжималка Moulinex JU599A3E Juice Machine</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>какой робот пылесос Чайник электрический Vitek VT-1142</h1>
						<div class="tb"><p>Цена: от <span class="price">1950</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8403.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический Vitek VT-1142</b> в стильном корпусе из нержавеющей стали с двухсторонней шкалой уровня воды – превосходное сочетание цены и качества. Модель имеет скрытый нагревательный элемент, съемный фильтр от накипи, а также оснащена системой автоотключения при закипании и защитой от перегрева. Отличительной особенностью <b>VT-1142 </b>является наличие 2 режимов внутренней подсветки: синий в режиме ожидания, красный – при кипячении воды.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 1850-2200Вт </li><li>Нагревательный элемент: скрытый </li><li>Поворачивающийся корпус: 360° </li><li>Объем: 1,7л </li><li>Материал корпуса: нержавеющая сталь </li><li>Фильтр: съемный фильтр от накипи </li><li>Двухсторонняя шкала уровня воды </li><li>Автоотключение при закипании воды: есть </li><li>Защита от перегрева: есть </li><li>Подсветка корпуса 2 режима внутренней подсветки: синий в режиме ожидания, красный – при кипячении воды </li><li>Место для хранения шнура: есть</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> какой робот пылесос</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/a5a944903050174bbca074a40d4e65fa.jpeg" alt="сравнить пароварки Соковыжималка Atlanta ATH-325" title="сравнить пароварки Соковыжималка Atlanta ATH-325"><div class="box" page="sokovyzhimalka-atlanta-ath-520r"><span class="title">сравнить пароварки Соковыжималка Atlanta ATH-325</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/e3e70209e76fc59518f6178cf23e1266.jpeg" alt="соковыжималка филипс Тостер Redmond RT-M401" title="соковыжималка филипс Тостер Redmond RT-M401"><div class="box" page="toster-redmond-rtm-1850r"><span class="title">соковыжималка филипс Тостер Redmond RT-M401</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li><img src="photos/16c51a83d3b90dc92106b51b933b769e.jpeg" alt="где купить ручную мясорубку Чайник электрический Binatone MEJ-1780 Mat Metal" title="где купить ручную мясорубку Чайник электрический Binatone MEJ-1780 Mat Metal"><div class="box" page="chaynik-elektricheskiy-binatone-mej-mat-metal-1500r"><span class="title">где купить ручную мясорубку Чайник электрический Binatone MEJ-1780 Mat Metal</span><p>от <span class="price">1500</span> руб.</p></div></li>
						<li><img src="photos/47745aa09108a6bfabc67b839ea476bd.jpeg" alt="продам вафельницу Чайник электрический Vitek VT-1114" title="продам вафельницу Чайник электрический Vitek VT-1114"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1030r"><span class="title">продам вафельницу Чайник электрический Vitek VT-1114</span><p>от <span class="price">1030</span> руб.</p></div></li>
						<li class="large"><img src="photos/7c9f70f739cded90e6e6da5bcbc9e960.jpeg" alt="кофеварка tefal express Чайник электрический Vitek VT-1138 серебряный" title="кофеварка tefal express Чайник электрический Vitek VT-1138 серебряный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-serebryanyy-1910r"><span class="title">кофеварка tefal express Чайник электрический Vitek VT-1138 серебряный</span><p>от <span class="price">1910</span> руб.</p></div></li>
						<li class="large"><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/0e343e4ed2bc192a59c6c92535860524.jpeg" alt="сварить кофе в кофеварке Электрический чайник Atlanta АТН-633" title="сварить кофе в кофеварке Электрический чайник Atlanta АТН-633"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-750r"><span class="title">сварить кофе в кофеварке Электрический чайник Atlanta АТН-633</span><p>от <span class="price">750</span> руб.</p></div></li>
						<li><img src="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" alt="кофемашина la cimbali Электрический чайник Atlanta АТН-788" title="кофемашина la cimbali Электрический чайник Atlanta АТН-788"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1350r"><span class="title">кофемашина la cimbali Электрический чайник Atlanta АТН-788</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li><img src="photos/a72d69a17b01ae0c39e3992b04fd72d5.jpeg" alt="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)" title="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-750r"><span class="title">panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)</span><p>от <span class="price">750</span> руб.</p></div></li>
						<li><img src="photos/2784b5cdf9478bbd2439685d61179e80.jpeg" alt="блендер vita mix Сушилка для рук AEG Haustehnik HE 181" title="блендер vita mix Сушилка для рук AEG Haustehnik HE 181"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-5900r"><span class="title">блендер vita mix Сушилка для рук AEG Haustehnik HE 181</span><p>от <span class="price">5900</span> руб.</p></div></li>
						<li><img src="photos/5363fe7d5348c517715f7be1bf400046.jpeg" alt="соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210" title="соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210"><div class="box" page="utyug-parovoy-tefal-aquaspeed-fv-2400r"><span class="title">соковыжималка россошанка Утюг паровой Tefal Aquaspeed FV5210</span><p>от <span class="price">2400</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-1950r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-1950r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-1950r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-1950r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>