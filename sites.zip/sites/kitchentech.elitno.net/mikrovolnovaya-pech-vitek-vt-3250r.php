<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("mikrovolnovaya-pech-vitek-vt-3250r.php","аэрогриль hotter 1087 tiger");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("mikrovolnovaya-pech-vitek-vt-3250r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>аэрогриль hotter 1087 tiger Микроволновая печь Vitek VT-1686  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="аэрогриль hotter 1087 tiger, кофемашина saeco инструкция, соковыжималки выбор, микроволновые печи elenberg, сепараторный пылесос, пароварка vitek отзывы, самоочистка аэрогриля, кофемашина krups dolce gusto, мультиварка куку 1054, красноярск микроволновая печь, что можно сделать из пылесоса, измельчитель kenwood, hyla пылесос цена, магазин запчастей для мясорубок,  ролсен аэрогриль">
		<meta name="description" content="аэрогриль hotter 1087 tiger Современная жизнь не мыслима без бытовой техники. С помощью микроволновой печи V...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/50077cb721bf68554cfd92d5a37bd83d.jpeg" title="аэрогриль hotter 1087 tiger Микроволновая печь Vitek VT-1686"><img src="photos/50077cb721bf68554cfd92d5a37bd83d.jpeg" alt="аэрогриль hotter 1087 tiger Микроволновая печь Vitek VT-1686" title="аэрогриль hotter 1087 tiger Микроволновая печь Vitek VT-1686 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-blender-v-russell-hobbs-allure-art-3490r.php"><img src="photos/8eb90b2c93f90da38a9a78776cb9380e.jpeg" alt="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56" title="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56"></a><h2>Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-chernaya-26999r.php"><img src="photos/3c4c438093f284e24176255dd4b7658c.jpeg" alt="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная" title="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная"></a><h2>Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemolka-ath-450r.php"><img src="photos/a5bbc6e64af24877cdab95c62f91247a.jpeg" alt="микроволновые печи elenberg Кофемолка ATH-276" title="микроволновые печи elenberg Кофемолка ATH-276"></a><h2>Кофемолка ATH-276</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>аэрогриль hotter 1087 tiger Микроволновая печь Vitek VT-1686</h1>
						<div class="tb"><p>Цена: от <span class="price">3250</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8269.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Современная жизнь не мыслима без бытовой техники. С помощью микроволновой печи <b>Vitek VT-1686</b> вы легко можете разогреть или приготовить пищу. Отличительными особенностями модели являются: 10 уровней мощности, антипригарное покрытие, 9 уникальных автоматических меню и сенсорное управление. Специальная защита от детей не даст вашему чаду использовать прибор в отсутствии взрослых.</p><p><b>Технические характеристики:</b></p><ul type=disc><li>Объем: 17л <li>Столик: 245мм <li>Режимы мощности: 10 <li>Режим размораживания: вес/время <li>Автоматическое меню: 9 программ <li>Функция программирования приготовления: есть <li>Функция экспресс-приготовления: есть <li>Антипригарное покрытие <li>Таймер цифровой (на 99 мин. 99 сек.) <li>Цифровые часы: есть <li>Тип управления: сенсорное <li>Защита от доступа детей: есть <li>Выходная мощность: 700Вт <li>Потребляемая мощность: 1200Вт <li>Электропитание: 220В,~50Гц</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна:</b> Россия.</p> аэрогриль hotter 1087 tiger</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/df340437daa709a0dfc3dc87ab1880bc.jpeg" alt="сепараторный пылесос Индукционная плита Kitfort KT-102" title="сепараторный пылесос Индукционная плита Kitfort KT-102"><div class="box" page="indukcionnaya-plita-kitfort-kt-3000r"><span class="title">сепараторный пылесос Индукционная плита Kitfort KT-102</span><p>от <span class="price">3000</span> руб.</p></div></li>
						<li><img src="photos/8f284ff93a3e936b77bc58d13a970910.jpeg" alt="пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075" title="пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075"><div class="box" page="bezmen-cifrovoy-do-kg-rst-pro-1600r"><span class="title">пароварка vitek отзывы Безмен цифровой до 20 кг RST PRO 08075</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/948f1a9b44ef51dbbf106577d1753c25.jpeg" alt="самоочистка аэрогриля Соковыжималка" title="самоочистка аэрогриля Соковыжималка"><div class="box" page="sokovyzhimalka-3320r"><span class="title">самоочистка аэрогриля Соковыжималка</span><p>от <span class="price">3320</span> руб.</p></div></li>
						<li><img src="photos/10045e221774030a9f06ef65dc2f63de.jpeg" alt="кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024" title="кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024"><div class="box" page="frityurnica-tefal-minute-snack-ff-2220r"><span class="title">кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024</span><p>от <span class="price">2220</span> руб.</p></div></li>
						<li class="large"><img src="photos/f12c67c091dc7674e75925e27c6ee910.jpeg" alt="мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный" title="мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-chernyy-2150r"><span class="title">мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li class="large"><img src="photos/d816a9ba34d3c4cbee3c0f60a1fb92cf.jpeg" alt="красноярск микроволновая печь Чайник электрический Vitek VT-1158" title="красноярск микроволновая печь Чайник электрический Vitek VT-1158"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1770r"><span class="title">красноярск микроволновая печь Чайник электрический Vitek VT-1158</span><p>от <span class="price">1770</span> руб.</p></div></li>
						<li class="large"><img src="photos/537c78beb6320fe2c86004c22681bdc6.jpeg" alt="что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)" title="что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-l-760r"><span class="title">что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/d221c08cbc7532258ec107ff315e3516.jpeg" alt="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)" title="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)"><div class="box" page="personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r"><span class="title">измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)</span><p>от <span class="price">20500</span> руб.</p></div></li>
						<li><img src="photos/d50a3dd0a5055f1b90b2cf35609b3ff0.jpeg" alt="hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС" title="hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС"><div class="box" page="nitrattester-nitratomer-soeks-5290r"><span class="title">hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС</span><p>от <span class="price">5290</span> руб.</p></div></li>
						<li><img src="photos/ed6cccd8ae597a978fe91c415f9d06d3.jpeg" alt="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)" title="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-135r"><span class="title">магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)</span><p>от <span class="price">135</span> руб.</p></div></li>
						<li><img src="photos/f9a55510217a53f128abac36303fad21.jpeg" alt="кашеварка panasonic Пылесос Dyson all floors DC 22" title="кашеварка panasonic Пылесос Dyson all floors DC 22"><div class="box" page="pylesos-dyson-all-floors-dc-26990r"><span class="title">кашеварка panasonic Пылесос Dyson all floors DC 22</span><p>от <span class="price">26990</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("mikrovolnovaya-pech-vitek-vt-3250r.php", 0, -4); if (file_exists("comments/mikrovolnovaya-pech-vitek-vt-3250r.php")) require_once "comments/mikrovolnovaya-pech-vitek-vt-3250r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="mikrovolnovaya-pech-vitek-vt-3250r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>