<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-maxima-mk-m-l-760r-2.php","мультиварка вред");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-maxima-mk-m-l-760r-2.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мультиварка вред Чайник электрический Maxima MК- M221 (1,8л)  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мультиварка вред, соковыжималка для моркови, микроволновые печи elenberg, рецепты для пароварки тефаль, эльдорадо кофемашины, отзывы мультиварка kromax, мультиварка minute cook, продам вафельницу, испечь черный хлеб в хлебопечке, как использовать пароварку, пылесос ролсен, принцип работы кофемашины, мясорубку panasonic купить, соковыжималка tefal отзывы,  индукционная керамическая плита">
		<meta name="description" content="мультиварка вред Классический матово-стальной электрический чайник MК- M271 мощностью 2000 Вт быс...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/396dcef56ae58a2fdd710c34b32d6011.jpeg" title="мультиварка вред Чайник электрический Maxima MК- M221 (1,8л)"><img src="photos/396dcef56ae58a2fdd710c34b32d6011.jpeg" alt="мультиварка вред Чайник электрический Maxima MК- M221 (1,8л)" title="мультиварка вред Чайник электрический Maxima MК- M221 (1,8л) -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-680r.php"><img src="photos/6e844ec2051132de84c89f71f9ba6d6a.jpeg" alt="соковыжималка для моркови Кухонный комбайн ATH-360" title="соковыжималка для моркови Кухонный комбайн ATH-360"></a><h2>Кухонный комбайн ATH-360</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemolka-ath-450r.php"><img src="photos/a5bbc6e64af24877cdab95c62f91247a.jpeg" alt="микроволновые печи elenberg Кофемолка ATH-276" title="микроволновые печи elenberg Кофемолка ATH-276"></a><h2>Кофемолка ATH-276</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskaya-kofemolka-krasnaya-bodum-bistro-euro-5730r.php"><img src="photos/a685203e8ea8fb080bb213d2c8d8a964.jpeg" alt="рецепты для пароварки тефаль Электрическая кофемолка красная Bodum BISTRO 10903-294EURO" title="рецепты для пароварки тефаль Электрическая кофемолка красная Bodum BISTRO 10903-294EURO"></a><h2>Электрическая кофемолка красная Bodum BISTRO 10903-294EURO</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мультиварка вред Чайник электрический Maxima MК- M221 (1,8л)</h1>
						<div class="tb"><p>Цена: от <span class="price">760</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18620.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Классический матово-стальной электрический чайник MК- M271 мощностью 2000 Вт быстро вскипятит за считанные минуты 1,8 литра, и автоматика сама выключит прибор.<br>Стальной корпус и спираль чайника выполнены из нержавеющей стали, а шнур легко спрятать в подставку. А за счет надежной конструкции блокировки кнопки можно не бояться облиться кипятком при случайном открытии крышки</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Мощность 2000 Вт; <li>Емкость: 1,8 л; <li>Корпус из нержавеющей стали; <li>Нагревательный элемент из нержавеющей стали; <li>Автоматическое выключение при закипании; <li>Угол вращения на подставке 360; <li>Световой индикатор воды; <li>Съемный фильтр против накипи; </li></ul><p><strong>Производитель: MAXIMA (Англия)</strong><br><strong>Гарантия: 1 год</strong></p> мультиварка вред</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="эльдорадо кофемашины Микроволновая печь Vitek VT-1684" title="эльдорадо кофемашины Микроволновая печь Vitek VT-1684"><div class="box"><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-3870r.php"><h3 class="title">эльдорадо кофемашины Микроволновая печь Vitek VT-1684</h3><p>от <span class="price">3870</span> руб.</p></a></div></li>
						<li><img src="photos/6fe5b4190ebaf728c4d5f2d1788f453b.jpeg" alt="отзывы мультиварка kromax Мясорубка электрическая Vitek VT-1670" title="отзывы мультиварка kromax Мясорубка электрическая Vitek VT-1670"><div class="box" page="myasorubka-elektricheskaya-vitek-vt-2950r"><span class="title">отзывы мультиварка kromax Мясорубка электрическая Vitek VT-1670</span><p>от <span class="price">2950</span> руб.</p></div></li>
						<li><img src="photos/96ffa32e5276885766eccd4b00ddf567.jpeg" alt="мультиварка minute cook Соковыжималка цитрусовая дизайнерская Zauber X-860" title="мультиварка minute cook Соковыжималка цитрусовая дизайнерская Zauber X-860"><div class="box" page="sokovyzhimalka-citrusovaya-dizaynerskaya-zauber-x-1550r"><span class="title">мультиварка minute cook Соковыжималка цитрусовая дизайнерская Zauber X-860</span><p>от <span class="price">1550</span> руб.</p></div></li>
						<li><img src="photos/47745aa09108a6bfabc67b839ea476bd.jpeg" alt="продам вафельницу Чайник электрический Vitek VT-1114" title="продам вафельницу Чайник электрический Vitek VT-1114"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1030r"><span class="title">продам вафельницу Чайник электрический Vitek VT-1114</span><p>от <span class="price">1030</span> руб.</p></div></li>
						<li class="large"><img src="photos/388c2880498e546d8fcebc787f1cf894.jpeg" alt="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO" title="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO"><div class="box" page="elektricheskiy-chaynik-l-chernyy-bodum-bistro-euro-2270r"><span class="title">испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li class="large"><img src="photos/2604c204c493f1487a5255f83dc099af.jpeg" alt="как использовать пароварку Зарядное устройство GP Batteries PB350GS210-UE4" title="как использовать пароварку Зарядное устройство GP Batteries PB350GS210-UE4"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-1025r"><span class="title">как использовать пароварку Зарядное устройство GP Batteries PB350GS210-UE4</span><p>от <span class="price">1025</span> руб.</p></div></li>
						<li class="large"><img src="photos/b423fb6caec639a7de8db20512fac098.jpeg" alt="пылесос ролсен Бумажные фильтры-мешки 200 (787-100) для Thomas" title="пылесос ролсен Бумажные фильтры-мешки 200 (787-100) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r"><span class="title">пылесос ролсен Бумажные фильтры-мешки 200 (787-100) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/e961b6308ccdf7d3b60d75fd50d3cfe9.jpeg" alt="принцип работы кофемашины Порошок для сухой чистки ковровых покрытий Dyson Zorb Pouch UK EU" title="принцип работы кофемашины Порошок для сухой чистки ковровых покрытий Dyson Zorb Pouch UK EU"><div class="box" page="poroshok-dlya-suhoy-chistki-kovrovyh-pokrytiy-dyson-zorb-pouch-uk-eu-890r"><span class="title">принцип работы кофемашины Порошок для сухой чистки ковровых покрытий Dyson Zorb Pouch UK EU</span><p>от <span class="price">890</span> руб.</p></div></li>
						<li><img src="photos/07ba23dd2664a1f6554e1b4f71151996.jpeg" alt="мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R" title="мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R"><div class="box" page="pylesos-moyuschiy-thomas-compact-r-7790r"><span class="title">мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R</span><p>от <span class="price">7790</span> руб.</p></div></li>
						<li><img src="photos/93023d88a25f41b8fefb8504a248a750.jpeg" alt="соковыжималка tefal отзывы Пылесос Vitek VT-1814" title="соковыжималка tefal отзывы Пылесос Vitek VT-1814"><div class="box" page="pylesos-vitek-vt-2200r"><span class="title">соковыжималка tefal отзывы Пылесос Vitek VT-1814</span><p>от <span class="price">2200</span> руб.</p></div></li>
						<li><img src="photos/39a5505798446240c306b0610cc8e434.jpeg" alt="сколько стоит моющий пылесос Пылесос Vitek VT-1834" title="сколько стоит моющий пылесос Пылесос Vitek VT-1834"><div class="box" page="pylesos-vitek-vt-5890r"><span class="title">сколько стоит моющий пылесос Пылесос Vitek VT-1834</span><p>от <span class="price">5890</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-maxima-mk-m-l-760r-2.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-maxima-mk-m-l-760r-2.php")) require_once "comments/chaynik-elektricheskiy-maxima-mk-m-l-760r-2.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-maxima-mk-m-l-760r-2.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>