<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-thomas-inox-6310r.php","использование аэрогриля");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-thomas-inox-6310r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>использование аэрогриля Пылесос Thomas Inox 1530  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="использование аэрогриля, сломалась мясорубка, кофеварка делонги отзывы, dolce gusto кофеварка, купить электрическую кофеварку, микроволновая печь daewoo koc, устройство блендера, утюг с парогенератором delonghi, сколько стоит фритюрница, хлебопечка советы, дозиметр соэкс, аэрогриль lentel d101b, фильтр для пылесоса самсунг, микроволновая печь электросхема,  трубка для пылесоса">
		<meta name="description" content="использование аэрогриля Пылесос Inox 1530 от Thomas представляет собой универсальный прибор для професси...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/daa26c20552b4c54039ad44aa7ab957b.jpeg" title="использование аэрогриля Пылесос Thomas Inox 1530"><img src="photos/daa26c20552b4c54039ad44aa7ab957b.jpeg" alt="использование аэрогриля Пылесос Thomas Inox 1530" title="использование аэрогриля Пылесос Thomas Inox 1530 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofeynoe-zerno-v-belom-shokolade-melitta-60r.php"><img src="photos/25dcd96d6af309287cb8d754259182bf.png" alt="сломалась мясорубка Кофейное зерно в белом шоколаде Melitta" title="сломалась мясорубка Кофейное зерно в белом шоколаде Melitta"></a><h2>Кофейное зерно в белом шоколаде Melitta</h2></li>
							<li><a href="http://kitchentech.elitno.net/izmelchitel-ritter-mc-2700r.php"><img src="photos/b329bc8334f65653dc9ef4683c170e62.jpeg" alt="кофеварка делонги отзывы Измельчитель Ritter MC 800" title="кофеварка делонги отзывы Измельчитель Ritter MC 800"></a><h2>Измельчитель Ritter MC 800</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-29530r.php"><img src="photos/ce24725d95df3bf470057f25a41297ef.jpeg" alt="dolce gusto кофеварка Автоматическая кофемашина Melitta CAFFEO Lattea" title="dolce gusto кофеварка Автоматическая кофемашина Melitta CAFFEO Lattea"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>использование аэрогриля Пылесос Thomas Inox 1530</h1>
						<div class="tb"><p>Цена: от <span class="price">6310</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14841.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Пылесос Inox 1530 от Thomas представляет собой универсальный прибор для профессиональной уборки помещений. Модель отличается высокой надежностью и прочностью, поэтому прослужит Вам на протяжении долгого времени, превосходно сохраняя свои свойства. Пылесос снабжен компактным резервуаром вместимостью 30 литров, выполненным из нержавеющей стали, имеет брызгозащищенный корпус, ходовая часть оснащена пятью направляющими роликами и противоударным кольцом. Мощность прибора – 1500 Вт.</p><p><b>Характеристики:</b></p><ul type=disc><li>Максимальная мощность 1500 Вт; <li>Двухступенчатая турбина большой мощности; <li>Компактный резервуар из высококачественной нержавеющей стали объемом 30 л; <li>Корпус двигателя из высокопрочной пластмассы; <li>Хорошая звукоизоляция; <li>Независимое байпасное охлаждение двигателя; <li>Брызгозащищенный корпус <li>Ходовая часть с 5 двойными направляющими роликами и противоударным кольцом; <li>Удобная ручка; <li>Профессиональная система O 50 мм; <li>Размеры: 43,5x43,5x54,4 cм; <li>Вес: 8,4 кг.</li></ul><p><b>Насадки:</b></p><ul type=disc><li>Ручка для шланга d 50 мм; <li>Щелевая насадка d 32 мм; <li>Сифонная насадка; <li>Переходник с d 50 на d 32 мм; <li>Универсальная насадка; <li>Насадка со скошенным краем d 50 мм; <li>Фильтр-патрон с поверхностью 2500 см2; <li>Бумажный фильтр-мешок.</li></ul><p><b>Дополнительно приобретается:</b></p><ul type=disc><li>Насадка для уборки паркета; <li>Комплект для печей и каминов d 32 мм; <li>Специальный мелкодисперсный фильтр 195163; <li>Фильтр для уборки сажи.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> использование аэрогриля</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/197b288168a6454a97f75d0fce3ea362.jpeg" alt="купить электрическую кофеварку Электросушка Maxima MFD-0155" title="купить электрическую кофеварку Электросушка Maxima MFD-0155"><div class="box" page="elektrosushka-maxima-mfd-990r"><span class="title">купить электрическую кофеварку Электросушка Maxima MFD-0155</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/82af66b2cc61bc47984a0dc33b3b0565.jpeg" alt="микроволновая печь daewoo koc Соковыжималка Atlanta ATH-310" title="микроволновая печь daewoo koc Соковыжималка Atlanta ATH-310"><div class="box" page="sokovyzhimalka-atlanta-ath-1050r"><span class="title">микроволновая печь daewoo koc Соковыжималка Atlanta ATH-310</span><p>от <span class="price">1050</span> руб.</p></div></li>
						<li><img src="photos/0c8f8180d11bb1b314126b1e547c3319.jpeg" alt="устройство блендера Чайник электрический  Vitesse VS-131 1,7 л" title="устройство блендера Чайник электрический  Vitesse VS-131 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1220r"><span class="title">устройство блендера Чайник электрический  Vitesse VS-131 1,7 л</span><p>от <span class="price">1220</span> руб.</p></div></li>
						<li><img src="photos/89368a4d8b53495528b047bf143af4e5.jpeg" alt="утюг с парогенератором delonghi Электрический чайник Atlanta АТН-623" title="утюг с парогенератором delonghi Электрический чайник Atlanta АТН-623"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-690r"><span class="title">утюг с парогенератором delonghi Электрический чайник Atlanta АТН-623</span><p>от <span class="price">690</span> руб.</p></div></li>
						<li class="large"><img src="photos/49901359ef2b43e118be22a24f1caa05.jpeg" alt="сколько стоит фритюрница Minamoto R6 (AA)" title="сколько стоит фритюрница Minamoto R6 (AA)"><div class="box" page="minamoto-r-aa-3r"><span class="title">сколько стоит фритюрница Minamoto R6 (AA)</span><p>от <span class="price">3</span> руб.</p></div></li>
						<li class="large"><img src="photos/cc9208f636d59db8c6c0a8ac95064dc7.jpeg" alt="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0" title="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0"><div class="box" page="shlang-podachi-vody-c-filtrom-karcher-1750r"><span class="title">хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0</span><p>от <span class="price">1750</span> руб.</p></div></li>
						<li class="large"><img src="photos/0c61c04ea066965d61b957c776ac9e0d.jpeg" alt="дозиметр соэкс Вертикальный циклонический пылесос Montiss CVC5667 White" title="дозиметр соэкс Вертикальный циклонический пылесос Montiss CVC5667 White"><div class="box" page="vertikalnyy-ciklonicheskiy-pylesos-montiss-cvc-white-4850r"><span class="title">дозиметр соэкс Вертикальный циклонический пылесос Montiss CVC5667 White</span><p>от <span class="price">4850</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
						<li><img src="photos/db8d0d28b1b05f19385269d855039f58.jpeg" alt="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833" title="фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-5580r"><span class="title">фильтр для пылесоса самсунг Пылесос с аквафильтром Vitek VT-1833</span><p>от <span class="price">5580</span> руб.</p></div></li>
						<li><img src="photos/00492fb3046ec485746c0b2d1a1385eb.jpeg" alt="микроволновая печь электросхема Пылесос Thomas Inox 1545 S" title="микроволновая печь электросхема Пылесос Thomas Inox 1545 S"><div class="box" page="pylesos-thomas-inox-s-10410r"><span class="title">микроволновая печь электросхема Пылесос Thomas Inox 1545 S</span><p>от <span class="price">10410</span> руб.</p></div></li>
						<li><img src="photos/ad2a05fc3c7b9378855e19056906dcd0.jpeg" alt="многоразовые мешки для пылесоса Утюг Atlanta ATH-497" title="многоразовые мешки для пылесоса Утюг Atlanta ATH-497"><div class="box" page="utyug-atlanta-ath-1350r"><span class="title">многоразовые мешки для пылесоса Утюг Atlanta ATH-497</span><p>от <span class="price">1350</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-thomas-inox-6310r.php", 0, -4); if (file_exists("comments/pylesos-thomas-inox-6310r.php")) require_once "comments/pylesos-thomas-inox-6310r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-thomas-inox-6310r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>