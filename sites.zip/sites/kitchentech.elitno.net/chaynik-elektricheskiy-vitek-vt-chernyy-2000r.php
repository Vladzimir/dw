<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-chernyy-2000r.php","аэрогриль киев");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-chernyy-2000r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>аэрогриль киев Чайник электрический Vitek VT-1102 черный  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="аэрогриль киев, кофемолка скачать, картофель микроволновая печь, самсунг пылесос робот, хлебопечка мулинекс 3101, quigg хлебопечка, приготовление теста в хлебопечке, кофеварка via veneto, кофеварка эспрессо krups, запеканка в хлебопечке, десерты в блендере, купить лопатку для хлебопечки, купить хлебопечку bork, пылесосы филипс отзывы,  мини пылесос для дома">
		<meta name="description" content="аэрогриль киев Чайник электрический Vitek VT-1102 изготовлен из немецкого термостойкого стекла ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/35bc2a6ec9e7fd46ce73f8c296c53df9.jpeg" title="аэрогриль киев Чайник электрический Vitek VT-1102 черный"><img src="photos/35bc2a6ec9e7fd46ce73f8c296c53df9.jpeg" alt="аэрогриль киев Чайник электрический Vitek VT-1102 черный" title="аэрогриль киев Чайник электрический Vitek VT-1102 черный -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-bistro-erp-chernaya-36999r.php"><img src="photos/41afe7a412ec56ea979169c39fe69fdc.jpeg" alt="кофемолка скачать Автоматическая кофемашина Melitta Caffeo Bistro ERP, черная" title="кофемолка скачать Автоматическая кофемашина Melitta Caffeo Bistro ERP, черная"></a><h2>Автоматическая кофемашина Melitta Caffeo Bistro ERP, черная</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemolka-vitesse-vs-1980r.php"><img src="photos/127a383548663b9c155664559c9c2000.jpeg" alt="картофель микроволновая печь Кофемолка Vitesse VS-272" title="картофель микроволновая печь Кофемолка Vitesse VS-272"></a><h2>Кофемолка Vitesse VS-272</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-2200r.php"><img src="photos/131f031076f016a5b0e85b06b57d0206.jpeg" alt="самсунг пылесос робот Микроволновая печь Vitek VT-1680" title="самсунг пылесос робот Микроволновая печь Vitek VT-1680"></a><h2>Микроволновая печь Vitek VT-1680</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>аэрогриль киев Чайник электрический Vitek VT-1102 черный</h1>
						<div class="tb"><p>Цена: от <span class="price">2000</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8384.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический V</b><b>itek</b><b> VT-1102</b> изготовлен из немецкого термостойкого стекла фирмы Sсhott, которое сохраняет природный вкус и натуральные свойства воды. Среди достоинств модели можно отметить: функцию поддержания температуры, съемный фильтр от накипи, автоотключение при закипании воды, защиту от перегрева и блокировку включения при отсутствии жидкости в резервуаре. Устройство стоит на дисковой подставке со скрытым нагревательным элементом и может поворачиваться на 360°.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 2200Вт (максимальная) </li><li>Нагревательный элемент: скрытый </li><li>Поворачивающийся корпус: 360° </li><li>Объем: 1,7л </li><li>Материал корпуса: высококачественное термостойкое стекло “Schott” </li><li>Фильтр: съемный фильтр от накипи </li><li>Индикатор уровня воды: легко определяемый уровень воды через прозрачную колбу </li><li>Автоотключение при закипании воды: есть </li><li>Защита от перегрева и блокировка включения при отсутствии воды </li><li>Световой индикатор работы: есть </li><li>Функция подержания температуры: есть </li><li>Место для хранения шнура: есть</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> аэрогриль киев</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7903c21b4883d9e9c99d0a478392fee7.jpeg" alt="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906" title="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906"><div class="box" page="sokovyzhimalka-redmond-rjm-4990r"><span class="title">хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/ba4426ec9ff105596978c39d5f7ff4de.jpeg" alt="quigg хлебопечка Соковыжималка для цитрусовых 304-CP" title="quigg хлебопечка Соковыжималка для цитрусовых 304-CP"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-cp-1300r"><span class="title">quigg хлебопечка Соковыжималка для цитрусовых 304-CP</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li><img src="photos/d22138cc84c807c5e3a9b5e6c25af3e9.jpeg" alt="приготовление теста в хлебопечке Сэндвич-тостер Redmond RSM-M1402" title="приготовление теста в хлебопечке Сэндвич-тостер Redmond RSM-M1402"><div class="box" page="sendvichtoster-redmond-rsmm-1090r"><span class="title">приготовление теста в хлебопечке Сэндвич-тостер Redmond RSM-M1402</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/99e95702b63a74224f733264159dce15.jpeg" alt="кофеварка via veneto Тостер Redmond RT-402" title="кофеварка via veneto Тостер Redmond RT-402"><div class="box" page="toster-redmond-rt-2490r"><span class="title">кофеварка via veneto Тостер Redmond RT-402</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li class="large"><img src="photos/0fb0d4eda0d01d4692f2fbd689f6f46f.jpeg" alt="кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л" title="кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitek-vt-l-1890r"><span class="title">кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li class="large"><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="запеканка в хлебопечке Чайник электрический Maxima MK-G311" title="запеканка в хлебопечке Чайник электрический Maxima MK-G311"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1650r"><span class="title">запеканка в хлебопечке Чайник электрический Maxima MK-G311</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/133af075f6993e048350b753f5c2c798.jpeg" alt="десерты в блендере Электрический чайник Atlanta АТН-727" title="десерты в блендере Электрический чайник Atlanta АТН-727"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r-2"><span class="title">десерты в блендере Электрический чайник Atlanta АТН-727</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li><img src="photos/ab56fe42ec3af82144d9f5eb1f80eb4c.jpeg" alt="купить лопатку для хлебопечки Мини весы Tangent KP-103" title="купить лопатку для хлебопечки Мини весы Tangent KP-103"><div class="box" page="mini-vesy-tangent-kp-1200r"><span class="title">купить лопатку для хлебопечки Мини весы Tangent KP-103</span><p>от <span class="price">1200</span> руб.</p></div></li>
						<li><img src="photos/a6da0d6d0378629b8c50bad1795840bf.jpeg" alt="купить хлебопечку bork Мини весы Tangent KP-104-200" title="купить хлебопечку bork Мини весы Tangent KP-104-200"><div class="box" page="mini-vesy-tangent-kp-1300r"><span class="title">купить хлебопечку bork Мини весы Tangent KP-104-200</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li><img src="photos/20c033d3c85583b2e6a71a21254a84f6.jpeg" alt="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail" title="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail"><div class="box" page="schetka-dlya-tverdyh-poverhnostey-v-upakovke-dyson-hard-floor-tool-assy-retail-1590r"><span class="title">пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail</span><p>от <span class="price">1590</span> руб.</p></div></li>
						<li><img src="photos/c0a2e2be0cab06fcd64d43478c95622c.jpeg" alt="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter" title="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-tt-aquafilter-14900r"><span class="title">дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter</span><p>от <span class="price">14900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-chernyy-2000r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-chernyy-2000r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-chernyy-2000r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-chernyy-2000r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>