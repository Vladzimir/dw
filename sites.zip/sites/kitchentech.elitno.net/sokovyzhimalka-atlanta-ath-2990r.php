<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-atlanta-ath-2990r.php","вкусно в мультиварке");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-atlanta-ath-2990r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>вкусно в мультиварке Соковыжималка Atlanta ATH-329  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="вкусно в мультиварке, соковыжималка для моркови, купить электрическую кофеварку, миксер bosch mfq 4020, контрольная закупка пылесос, микроволновая печь daewoo koc, пылесос mediclean, кофемашина krups nescafe dolce gusto, купить пылесос зелмер, ремонт пылесосов samsung, пылесос автомобильный купить, электронная мясорубка, термопот toshiba, kenwood пароварка,  мясорубка moulinex 2051">
		<meta name="description" content="вкусно в мультиварке Соковыжималка Atlanta ATH-329 мощностью 560 Вт – прибор в стильном и современном...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/151cdbb0e55d78748fdd51a7bbe40bf0.jpeg" title="вкусно в мультиварке Соковыжималка Atlanta ATH-329"><img src="photos/151cdbb0e55d78748fdd51a7bbe40bf0.jpeg" alt="вкусно в мультиварке Соковыжималка Atlanta ATH-329" title="вкусно в мультиварке Соковыжималка Atlanta ATH-329 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-680r.php"><img src="photos/6e844ec2051132de84c89f71f9ba6d6a.jpeg" alt="соковыжималка для моркови Кухонный комбайн ATH-360" title="соковыжималка для моркови Кухонный комбайн ATH-360"></a><h2>Кухонный комбайн ATH-360</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektrosushka-maxima-mfd-990r.php"><img src="photos/197b288168a6454a97f75d0fce3ea362.jpeg" alt="купить электрическую кофеварку Электросушка Maxima MFD-0155" title="купить электрическую кофеварку Электросушка Maxima MFD-0155"></a><h2>Электросушка Maxima MFD-0155</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-s-grilem-moulinex-mw-l-serebro-4430r.php"><img src="photos/30122165cbc4e4755f8a550e028ecb69.jpeg" alt="миксер bosch mfq 4020 Микроволновая печь с грилем Moulinex MW221031 20 л, серебро" title="миксер bosch mfq 4020 Микроволновая печь с грилем Moulinex MW221031 20 л, серебро"></a><h2>Микроволновая печь с грилем Moulinex MW221031 20 л, серебро</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>вкусно в мультиварке Соковыжималка Atlanta ATH-329</h1>
						<div class="tb"><p>Цена: от <span class="price">2990</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19675.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Соковыжималка Atlanta ATH-329 мощностью 560 Вт – прибор в стильном и современном дизайне для приготовления сока в домашних условиях с мощным мотором. Если вас не устраивают соки в магазине и вы хотите быть уверенными в качестве и полезности того что пьете, то используйте эту электрическую соковыжималку. Она очень проста и удобна в использовании, очистке и хранении. Она предназначена, для приготовления сока не только из цитрусовых, но также из любых фруктов и ягод. Ее габариты, внешний вид и вес позволят идеально вписаться в интерьер любой кухни. Она станет вашим незаменимым другом. Ее корпус выполнен из высокопрочного пластика. Предусмотрены две скорости работы. Оснащена тихо работающим мощным мотором. Центрифуга выполнена из нержавеющей стали. Для жмыха и сока устанавливаются съемные контейнеры. </p><p><strong>Характеристики:</strong></p><ul type=disc><li>Диаметр приемного жерла 7,5 см <li>Съемные контейнеры для жмыха и сока  <li>Мощный мотор <li>Удобно мыть  <li>Две скорости  <li>Центрифуга из нержавеющей стали <li>Мощность 560 Вт  <li>230 В, 50 Гц <li>35 x 20 x 37.5 см </li></ul><p><strong>Производитель: США</strong></p> вкусно в мультиварке</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/b6c05d69ce9bf94410c78acce4c5e9cb.jpeg" alt="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер" title="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер"><div class="box"><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-2740r.php"><h3 class="title">контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер</h3><p>от <span class="price">2740</span> руб.</p></a></div></li>
						<li><img src="photos/82af66b2cc61bc47984a0dc33b3b0565.jpeg" alt="микроволновая печь daewoo koc Соковыжималка Atlanta ATH-310" title="микроволновая печь daewoo koc Соковыжималка Atlanta ATH-310"><div class="box" page="sokovyzhimalka-atlanta-ath-1050r"><span class="title">микроволновая печь daewoo koc Соковыжималка Atlanta ATH-310</span><p>от <span class="price">1050</span> руб.</p></div></li>
						<li><img src="photos/4f7eae7926bb1b2816625b5940a25b78.jpeg" alt="пылесос mediclean Чайник электрический Vitek VT-1157" title="пылесос mediclean Чайник электрический Vitek VT-1157"><div class="box" page="chaynik-elektricheskiy-vitek-vt-2150r"><span class="title">пылесос mediclean Чайник электрический Vitek VT-1157</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/5eacb893fe5269a15baee9e1dcce1404.jpeg" alt="кофемашина krups nescafe dolce gusto Чайник электрический Tefal VitesseS Inox BI962513 1,7 л" title="кофемашина krups nescafe dolce gusto Чайник электрический Tefal VitesseS Inox BI962513 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-inox-bi-l-2990r"><span class="title">кофемашина krups nescafe dolce gusto Чайник электрический Tefal VitesseS Inox BI962513 1,7 л</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li class="large"><img src="photos/67898b31f2a00b51820f96bc789fed43.jpeg" alt="купить пылесос зелмер Чайник электрический Maxima MК- M281" title="купить пылесос зелмер Чайник электрический Maxima MК- M281"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r"><span class="title">купить пылесос зелмер Чайник электрический Maxima MК- M281</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/a6c36bfdd77b4f18d6fcadc6e3824cf1.jpeg" alt="ремонт пылесосов samsung Чайник электрический  Vitesse VS-127 2л золотой" title="ремонт пылесосов samsung Чайник электрический  Vitesse VS-127 2л золотой"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-zolotoy-960r"><span class="title">ремонт пылесосов samsung Чайник электрический  Vitesse VS-127 2л золотой</span><p>от <span class="price">960</span> руб.</p></div></li>
						<li class="large"><img src="photos/b2f5222e6fab12eeb526363895bfe319.jpeg" alt="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л" title="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-950r"><span class="title">пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li><img src="photos/f056d129bd10f6cbcdccf3b119b91dc8.jpeg" alt="электронная мясорубка Чайник электрический  Vitesse VS-143 стеклянный 1,7л" title="электронная мясорубка Чайник электрический  Vitesse VS-143 стеклянный 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r"><span class="title">электронная мясорубка Чайник электрический  Vitesse VS-143 стеклянный 1,7л</span><p>от <span class="price">2280</span> руб.</p></div></li>
						<li><img src="photos/403a4b4ef798c09cf151962161efdcea.jpeg" alt="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый" title="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый"><div class="box" page="elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r"><span class="title">термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li><img src="photos/97ad6f71f59b7db73d8fda12c75e94a2.jpeg" alt="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2" title="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-680r"><span class="title">kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2</span><p>от <span class="price">680</span> руб.</p></div></li>
						<li><img src="photos/ef2885939f9c24bf748f6b2d7462e40b.jpeg" alt="блендер бош купить Щетка для уборки твердых поверхностей Dyson Articulating Hard Floor Tool Retail" title="блендер бош купить Щетка для уборки твердых поверхностей Dyson Articulating Hard Floor Tool Retail"><div class="box" page="schetka-dlya-uborki-tverdyh-poverhnostey-dyson-articulating-hard-floor-tool-retail-1790r"><span class="title">блендер бош купить Щетка для уборки твердых поверхностей Dyson Articulating Hard Floor Tool Retail</span><p>от <span class="price">1790</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-atlanta-ath-2990r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-atlanta-ath-2990r.php")) require_once "comments/sokovyzhimalka-atlanta-ath-2990r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-atlanta-ath-2990r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>