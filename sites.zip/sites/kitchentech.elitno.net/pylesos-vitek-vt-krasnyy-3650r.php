<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-vitek-vt-krasnyy-3650r.php","измельчитель веток садовый");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-vitek-vt-krasnyy-3650r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>измельчитель веток садовый Пылесос Vitek VT-1847 красный  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="измельчитель веток садовый, пылесос tomas twin, блендер bosch msm 6150, пароварка магазин, купить утюг для волос, кухонный комбайн tefal, рецепты для хлебопечки с сыром, мультиварка redmond 4504, продам вафельницу, ремень для хлебопечки, бамбуковая пароварка, соковыжималка садовая, семга в мультиварке, блюда с помощью блендера,  мультиварка кенвуд">
		<meta name="description" content="измельчитель веток садовый Пылесос Vitek VT-1847 в стильном красном корпусе, обладает не только ярким дизай...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/edc4236e3a4947da96211057e15ad9d5.jpeg" title="измельчитель веток садовый Пылесос Vitek VT-1847 красный"><img src="photos/edc4236e3a4947da96211057e15ad9d5.jpeg" alt="измельчитель веток садовый Пылесос Vitek VT-1847 красный" title="измельчитель веток садовый Пылесос Vitek VT-1847 красный -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-pogruzhnoy-moulinex-ddg-click-and-mix-2900r.php"><img src="photos/795ef5ec8b21fcb23efce51ba4b9959a.jpeg" alt="пылесос tomas twin Блендер погружной Moulinex DD406G42 Click and Mix" title="пылесос tomas twin Блендер погружной Moulinex DD406G42 Click and Mix"></a><h2>Блендер погружной Moulinex DD406G42 Click and Mix</h2></li>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-blender-russell-hobbs-allure-art-2790r.php"><img src="photos/422d665429610f080e15aaf4bb75409d.jpeg" alt="блендер bosch msm 6150 Ручной блендер Russell Hobbs Allure, арт. 18273-56" title="блендер bosch msm 6150 Ручной блендер Russell Hobbs Allure, арт. 18273-56"></a><h2>Ручной блендер Russell Hobbs Allure, арт. 18273-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-beloserebristaya-29530r.php"><img src="photos/5b2c06d57a572404f45fc75e65b42e87.jpeg" alt="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая" title="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>измельчитель веток садовый Пылесос Vitek VT-1847 красный</h1>
						<div class="tb"><p>Цена: от <span class="price">3650</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8303.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Пылесос <b>V</b><b>itek</b><b> VT-1847</b> в стильном красном корпусе, обладает не только ярким дизайном, но и всеми необходимыми качествами современных чистящих устройств. Среди достоинств устройства можно отметить возможность ионизации воздуха и 6-ступенчатую систему фильтрации с НЕРА-фильром, который задерживает 99,97% всех частиц размерами от 0,3 мкм и больше. Модель<b>VT-1847</b> рекомендуют в первую очередь аллергикам, т.к. размеры большинства аллергенов более 1 мкм. В качестве пылесборника выступает циклонный фильтр емкостью 2,5 литра.</p><p><b>Особенности:</b></p><p><b></b></p><ul><li>Пониженный уровень шума <li>HEPA фильтр с предварительным фильтром <li>Функция ионизации <li>Плавная регулировка мощности <li>Стальная телескопическая трубка <li>Насадки: турбо-щетка; щетка с переключателем «ПОЛ/КОВЕР»; щетка для очистки мягкой мебели; щетка для пыли; щелевая насадка <li>Удобная ручка для переноски</li></ul><p><b></b></p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Максимальная мощность: 2000Вт <li>Мощность всасывание: 350Вт <li>Система фильтрации: 6-ступенчатая <li>Индикатор заполнения: есть <li>Длина сетевого шнура: 5 м <li>Пылесборник емкостью: 2.5л <li>Электропитание: 230В, ~50 Гц</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> измельчитель веток садовый</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/3bdb5a7ebf59a397ed1b6263ffa77483.jpeg" alt="купить утюг для волос Кофемолка Vitesse VS-271" title="купить утюг для волос Кофемолка Vitesse VS-271"><div class="box" page="kofemolka-vitesse-vs-1100r"><span class="title">купить утюг для волос Кофемолка Vitesse VS-271</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/33b43228a18b1110c1c8a14516611c99.jpeg" alt="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE" title="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE"><div class="box" page="kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r"><span class="title">кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE</span><p>от <span class="price">3570</span> руб.</p></div></li>
						<li><img src="photos/f522dce957deccc1ec8ad4658577e80b.jpeg" alt="рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330" title="рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330"><div class="box" page="multivarka-moulinex-mk-4170r"><span class="title">рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330</span><p>от <span class="price">4170</span> руб.</p></div></li>
						<li><img src="photos/696c3eff6d4752e21e651f3d4b34c0a7.jpeg" alt="мультиварка redmond 4504 Мясорубка Redmond RMG-1204" title="мультиварка redmond 4504 Мясорубка Redmond RMG-1204"><div class="box" page="myasorubka-redmond-rmg-3290r"><span class="title">мультиварка redmond 4504 Мясорубка Redmond RMG-1204</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li class="large"><img src="photos/47745aa09108a6bfabc67b839ea476bd.jpeg" alt="продам вафельницу Чайник электрический Vitek VT-1114" title="продам вафельницу Чайник электрический Vitek VT-1114"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1030r"><span class="title">продам вафельницу Чайник электрический Vitek VT-1114</span><p>от <span class="price">1030</span> руб.</p></div></li>
						<li class="large"><img src="photos/46f63d5550ab774c363b5ff4ba202c31.jpeg" alt="ремень для хлебопечки Чайник электрический Maxima MK- M191" title="ремень для хлебопечки Чайник электрический Maxima MK- M191"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-990r"><span class="title">ремень для хлебопечки Чайник электрический Maxima MK- M191</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/3e5de65e23113a4dedb018c90159e3df.jpeg" alt="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной" title="бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r"><span class="title">бамбуковая пароварка Чайник электрический  Vitesse VS-115 1,7л стальной</span><p>от <span class="price">1360</span> руб.</p></div></li>
						<li><img src="photos/a73fe1f79d4e2459d6da89e07445f626.jpeg" alt="соковыжималка садовая Электрический чайник Atlanta АТН-738" title="соковыжималка садовая Электрический чайник Atlanta АТН-738"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-520r"><span class="title">соковыжималка садовая Электрический чайник Atlanta АТН-738</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/eae88ed8d5eeac95cd1245092b541388.jpeg" alt="семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas" title="семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-3"><span class="title">семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/b8e20b7d51cc5f25b0392815fadedf6e.jpeg" alt="блюда с помощью блендера Турбощетка Redmond  RTB-4801" title="блюда с помощью блендера Турбощетка Redmond  RTB-4801"><div class="box" page="turboschetka-redmond-rtb-920r"><span class="title">блюда с помощью блендера Турбощетка Redmond  RTB-4801</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/c97072b686d00422f9e5b9490c04caab.jpeg" alt="кофеварка espresso Пылесос Thomas Inox 1545 Sfe" title="кофеварка espresso Пылесос Thomas Inox 1545 Sfe"><div class="box" page="pylesos-thomas-inox-sfe-13350r"><span class="title">кофеварка espresso Пылесос Thomas Inox 1545 Sfe</span><p>от <span class="price">13350</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-vitek-vt-krasnyy-3650r.php", 0, -4); if (file_exists("comments/pylesos-vitek-vt-krasnyy-3650r.php")) require_once "comments/pylesos-vitek-vt-krasnyy-3650r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-vitek-vt-krasnyy-3650r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>