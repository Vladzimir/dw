<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-l-bodum-bistro-euro-2740r.php","миксера для производства");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-l-bodum-bistro-euro-2740r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>миксера для производства Электрический чайник 1,5л Bodum BISTRO 11138-01EURO  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="миксера для производства, пылесос для ногтей, как убрать блеск от утюга, контрольная закупка пылесос, как выбрать утюг отзывы, джем в хлебопечке, микроволновая печь работа, блендер металлический, книга рецептов для хлебопечки, десерты в блендере, нож для мясорубки kenwood, карандаш для чистки утюга, утюг braun 18895, купить кофемашину jura,  курица в микроволновой печи">
		<meta name="description" content="миксера для производства Незаменимым предметом на любой кухне является, без сомнений,  современный и удоб...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/70eaaca49bbd014982b9856679d5c7e6.jpeg" title="миксера для производства Электрический чайник 1,5л Bodum BISTRO 11138-01EURO"><img src="photos/70eaaca49bbd014982b9856679d5c7e6.jpeg" alt="миксера для производства Электрический чайник 1,5л Bodum BISTRO 11138-01EURO" title="миксера для производства Электрический чайник 1,5л Bodum BISTRO 11138-01EURO -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lounge-white-45500r.php"><img src="photos/45055ec55f153a8a82f9cf1191933a0c.jpeg" alt="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)" title="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-moulinex-fp-adventio-4350r.php"><img src="photos/83b6a1cde8ae8331d8aaec70b8a93652.jpeg" alt="как убрать блеск от утюга Кухонный комбайн Moulinex FP60314 Адвентио" title="как убрать блеск от утюга Кухонный комбайн Moulinex FP60314 Адвентио"></a><h2>Кухонный комбайн Moulinex FP60314 Адвентио</h2></li>
							<li><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-2740r.php"><img src="photos/b6c05d69ce9bf94410c78acce4c5e9cb.jpeg" alt="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер" title="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер"></a><h2>Bodum BISTRO 11151-01EURO Электрический миксер</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>миксера для производства Электрический чайник 1,5л Bodum BISTRO 11138-01EURO</h1>
						<div class="tb"><p>Цена: от <span class="price">2740</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_26395.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Незаменимым предметом на любой кухне является, без сомнений,  современный и удобный в использовании электрический чайник. Электрический  чайник BISTRO 11138-01EURO от  швейцарской компании Bodum обладает не только отличными техническими  характеристиками, но и привлекательным дизайном. Чайник Bodum BISTRO 11138-01EURO имеет оптимальный объем (1,5  литра), специальный съемный фильтр, индикатор уровня воды, а также функцию  блокировки включения без воды. Внешне данная модель выполнена в благородном  черном цвете, что позволит ей легко вписаться в интерьер вашей кухни. </p> <p><strong>Характеристики:</strong></p> <ul type=disc>   <li>Тип:       электрический;</li>   <li>Объем:       1,5 л;</li>   <li>Материал       корпуса: пластик;</li>   <li>Мощность:       2200 Вт;</li>   <li>Нагревательный       элемент: дисковый нагреватель (скрытый);</li>   <li>Съемный       фильтр;</li>   <li>Индикатор       уровня воды;</li>   <li>Блокировка       включения без воды;</li>   <li>Цвет:       черный.</li> </ul> <p><strong>Производитель: Bodum  (Швейцария)</strong></p> миксера для производства</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7d63a182df07dd9be547ac2724aeed46.jpeg" alt="как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO" title="как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO"><div class="box"><a href="http://kitchentech.elitno.net/elektricheskaya-sokovyzhimalka-krasnaya-bodum-bistro-euro-3340r.php"><h3 class="title">как выбрать утюг отзывы Электрическая соковыжималка красная Bodum BISTRO 11149-294EURO</h3><p>от <span class="price">3340</span> руб.</p></a></div></li>
						<li><img src="photos/395739893470046928b7502ebf2a09eb.jpeg" alt="джем в хлебопечке Электрическая соковыжималка черная Bodum BISTRO 11149-01EURO" title="джем в хлебопечке Электрическая соковыжималка черная Bodum BISTRO 11149-01EURO"><div class="box" page="elektricheskaya-sokovyzhimalka-chernaya-bodum-bistro-euro-3340r"><span class="title">джем в хлебопечке Электрическая соковыжималка черная Bodum BISTRO 11149-01EURO</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li><img src="photos/ac081ce5674939d79667b2759a2f84a8.jpeg" alt="микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый" title="микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый"><div class="box" page="bodum-bistro-euro-toster-belyy-3660r"><span class="title">микроволновая печь работа Bodum BISTRO 10709-913EURO Тостер белый</span><p>от <span class="price">3660</span> руб.</p></div></li>
						<li><img src="photos/f2d6d870289f867bca2e3ea0f8531c8e.jpeg" alt="блендер металлический Электрический чайник  Zauber Z-350" title="блендер металлический Электрический чайник  Zauber Z-350"><div class="box" page="elektricheskiy-chaynik-zauber-z-1600r"><span class="title">блендер металлический Электрический чайник  Zauber Z-350</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li class="large"><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li class="large"><img src="photos/133af075f6993e048350b753f5c2c798.jpeg" alt="десерты в блендере Электрический чайник Atlanta АТН-727" title="десерты в блендере Электрический чайник Atlanta АТН-727"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r-2"><span class="title">десерты в блендере Электрический чайник Atlanta АТН-727</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li class="large"><img src="photos/4aa517f040bb8f7cdf25d41fea297b7f.jpeg" alt="нож для мясорубки kenwood Электрический чайник Atlanta АТН-781" title="нож для мясорубки kenwood Электрический чайник Atlanta АТН-781"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1000r"><span class="title">нож для мясорубки kenwood Электрический чайник Atlanta АТН-781</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/ab7fd4cacdc88b690decc0d20bd53770.jpeg" alt="карандаш для чистки утюга Чайник-термос Atlanta АТН-768" title="карандаш для чистки утюга Чайник-термос Atlanta АТН-768"><div class="box" page="chayniktermos-atlanta-atn-1700r"><span class="title">карандаш для чистки утюга Чайник-термос Atlanta АТН-768</span><p>от <span class="price">1700</span> руб.</p></div></li>
						<li><img src="photos/6a73d6f5ed044b39207ab31ca41595f1.jpeg" alt="утюг braun 18895 Пылесос моющий Thomas Bravo 20" title="утюг braun 18895 Пылесос моющий Thomas Bravo 20"><div class="box" page="pylesos-moyuschiy-thomas-bravo-8050r"><span class="title">утюг braun 18895 Пылесос моющий Thomas Bravo 20</span><p>от <span class="price">8050</span> руб.</p></div></li>
						<li><img src="photos/9fd5ef54211079a33ba5cc9bfbb9bfcf.jpeg" alt="купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter" title="купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-bravo-s-aquafilter-9270r"><span class="title">купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter</span><p>от <span class="price">9270</span> руб.</p></div></li>
						<li><img src="photos/63eadb71b95851c3e7f26e5885bd43ae.jpeg" alt="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832" title="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-6900r"><span class="title">moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832</span><p>от <span class="price">6900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-l-bodum-bistro-euro-2740r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-l-bodum-bistro-euro-2740r.php")) require_once "comments/elektricheskiy-chaynik-l-bodum-bistro-euro-2740r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-l-bodum-bistro-euro-2740r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>