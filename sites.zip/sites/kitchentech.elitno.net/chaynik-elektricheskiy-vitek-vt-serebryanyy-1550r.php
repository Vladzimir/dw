<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r.php","керхер робот пылесос");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>керхер робот пылесос Чайник электрический Vitek VT-1144 серебряный  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="керхер робот пылесос, выбор микроволновой печи, контрольная закупка пылесос, хлебопечка хлеб из гречневой муки, кувшин для кофеварки, хлебопечка борк отзывы, мультиварка акции, куриное филе в пароварке, хлебопечка германия, нож для мясорубки kenwood, микроволновая печь бош, слоеное тесто в аэрогриле, кофеварки домашние, ремонт микроволновых печей самсунг,  мясорубка 6061">
		<meta name="description" content="керхер робот пылесос Чайник электрический Vitek VT-1144 не только обладает всеми необходимыми характе...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/b18048af79224983f1e624ba7e264cff.jpeg" title="керхер робот пылесос Чайник электрический Vitek VT-1144 серебряный"><img src="photos/b18048af79224983f1e624ba7e264cff.jpeg" alt="керхер робот пылесос Чайник электрический Vitek VT-1144 серебряный" title="керхер робот пылесос Чайник электрический Vitek VT-1144 серебряный -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/vspenivatel-melitta-cremio-krasnyy-4155r.php"><img src="photos/0b57a5fa2564b3001e847ebdd45ce976.jpeg" alt="выбор микроволновой печи Вспениватель Melitta Cremio красный" title="выбор микроволновой печи Вспениватель Melitta Cremio красный"></a><h2>Вспениватель Melitta Cremio красный</h2></li>
							<li><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-2740r.php"><img src="photos/b6c05d69ce9bf94410c78acce4c5e9cb.jpeg" alt="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер" title="контрольная закупка пылесос Bodum BISTRO 11151-01EURO Электрический миксер"></a><h2>Bodum BISTRO 11151-01EURO Электрический миксер</h2></li>
							<li><a href="http://kitchentech.elitno.net/indukcionnaya-plita-kitfort-kt-2700r.php"><img src="photos/7ffc20dc8107b2fc1365cfb7486e823a.jpeg" alt="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101" title="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101"></a><h2>Индукционная плита Kitfort KT-101</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>керхер робот пылесос Чайник электрический Vitek VT-1144 серебряный</h1>
						<div class="tb"><p>Цена: от <span class="price">1550</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8404.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический V</b><b>itek</b><b> VT-1144 </b>не только обладает всеми необходимыми характеристиками современных устройств, но еще и оповестит вас музыкальным сигналом, о том, что вода закипела. Корпус выполнен из качественной нержавеющей стали, а шкала уровня жидкости оснащена подсветкой. Также среди достоинств модели можно отметить: защиту от перегрева, автоотключение при закипании, наличие съемного фильтра от накипи и скрытый нагревательный элемент.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 1850-2200Вт </li><li>Нагревательный элемент: скрытый </li><li>Поворачивающийся корпус: 360° </li><li>Объем: 1,5л </li><li>Материал корпуса: нержавеющая сталь </li><li>Фильтр: съемный фильтр от накипи </li><li>Индикатор уровня воды: есть </li><li>Автоотключение при закипании воды: есть </li><li>Защита от перегрева: есть </li><li>Подсветка корпуса: внутренняя подсветка шкалы уровня воды </li><li>Место для хранения шнура: есть </li><li>Музыкальная индикация закипания воды</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> керхер робот пылесос</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d4f76a5fd1a2c3a65c40e2234f6145bc.jpeg" alt="кувшин для кофеварки Соковыжималка Moulinex JU570D3 Juice Machine" title="кувшин для кофеварки Соковыжималка Moulinex JU570D3 Juice Machine"><div class="box" page="sokovyzhimalka-moulinex-jud-juice-machine-3320r"><span class="title">кувшин для кофеварки Соковыжималка Moulinex JU570D3 Juice Machine</span><p>от <span class="price">3320</span> руб.</p></div></li>
						<li><img src="photos/5cd90ccf1383ae054567f8f62fe579ca.jpeg" alt="хлебопечка борк отзывы Тостер Atlanta ATH-237" title="хлебопечка борк отзывы Тостер Atlanta ATH-237"><div class="box" page="toster-atlanta-ath-740r"><span class="title">хлебопечка борк отзывы Тостер Atlanta ATH-237</span><p>от <span class="price">740</span> руб.</p></div></li>
						<li><img src="photos/b11b426009f0167e5ff93f5aa64ca56d.jpeg" alt="мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л" title="мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1650r"><span class="title">мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/c75538a0a02b722bb4d5b9c47eb925e7.jpeg" alt="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л" title="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r"><span class="title">куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л</span><p>от <span class="price">2570</span> руб.</p></div></li>
						<li class="large"><img src="photos/b3fae48615963478f00e0c05f3baa485.jpeg" alt="хлебопечка германия Электрический чайник  Zauber R-380" title="хлебопечка германия Электрический чайник  Zauber R-380"><div class="box" page="elektricheskiy-chaynik-zauber-r-1830r"><span class="title">хлебопечка германия Электрический чайник  Zauber R-380</span><p>от <span class="price">1830</span> руб.</p></div></li>
						<li class="large"><img src="photos/4aa517f040bb8f7cdf25d41fea297b7f.jpeg" alt="нож для мясорубки kenwood Электрический чайник Atlanta АТН-781" title="нож для мясорубки kenwood Электрический чайник Atlanta АТН-781"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1000r"><span class="title">нож для мясорубки kenwood Электрический чайник Atlanta АТН-781</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li class="large"><img src="photos/66926416069d8d65cb760c1b8131e267.jpeg" alt="микроволновая печь бош Электрический чайник Atlanta АТН-785" title="микроволновая печь бош Электрический чайник Atlanta АТН-785"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1420r"><span class="title">микроволновая печь бош Электрический чайник Atlanta АТН-785</span><p>от <span class="price">1420</span> руб.</p></div></li>
						<li><img src="photos/b28d3e929be020189d8c25424817be16.jpeg" alt="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO" title="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2270r"><span class="title">слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li><img src="photos/f08bd4abc7ad4c0cc84da510e6f6c4d3.jpeg" alt="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт." title="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт."><div class="box" page="filtr-dlya-pylesosa-vitek-vt-vt-sht-215r"><span class="title">кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт.</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li><img src="photos/de0ae611994f30f17a2187f2f1b20950.jpeg" alt="ремонт микроволновых печей самсунг Пылесос Dyson all floors DC 24" title="ремонт микроволновых печей самсунг Пылесос Dyson all floors DC 24"><div class="box" page="pylesos-dyson-all-floors-dc-26990r-2"><span class="title">ремонт микроволновых печей самсунг Пылесос Dyson all floors DC 24</span><p>от <span class="price">26990</span> руб.</p></div></li>
						<li><img src="photos/4fbb8e89e08e4c6965da2c5a458072d3.jpeg" alt="кубань 8 вафельница Пылесос Vitek VT-1836 красный" title="кубань 8 вафельница Пылесос Vitek VT-1836 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3600r"><span class="title">кубань 8 вафельница Пылесос Vitek VT-1836 красный</span><p>от <span class="price">3600</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>