<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("kuhonnyy-kombayn-moulinex-fp-6140r.php","мультиварка декс");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("kuhonnyy-kombayn-moulinex-fp-6140r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мультиварка декс Кухонный комбайн Moulinex FP711141  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мультиварка декс, турка для кофе купить, аппараты для педикюра с пылесосом, самсунг пылесос робот, продам мультиварку, magic pot мультиварка, как правильно выбрать пароварку, хлебопечка panasonic 255 купить, блендер в одессе, фильтр для пылесоса thomas twin, кофеварка эспрессо для дома, кофеварка полуавтомат, daewoo микроволновая печь инструкция, покрытие микроволновой печи,  мультиварка кенвуд">
		<meta name="description" content="мультиварка декс С мощным надежным универсальным кухонным комбайном от Moulinex приготовление люб...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/59cc932c7224c4f3a91684264a52c663.jpeg" title="мультиварка декс Кухонный комбайн Moulinex FP711141"><img src="photos/59cc932c7224c4f3a91684264a52c663.jpeg" alt="мультиварка декс Кухонный комбайн Moulinex FP711141" title="мультиварка декс Кухонный комбайн Moulinex FP711141 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-russell-hobbs-desire-art-2990r.php"><img src="photos/8acd8b43677456777a29a4a8d53c0c0b.jpeg" alt="турка для кофе купить Блендер Russell Hobbs Desire, арт. 18510-56" title="турка для кофе купить Блендер Russell Hobbs Desire, арт. 18510-56"></a><h2>Блендер Russell Hobbs Desire, арт. 18510-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/vspenivatel-melitta-cremio-chernyy-4155r.php"><img src="photos/4e6a1db3aa397f67ece5fe8079d3244b.jpeg" alt="аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный" title="аппараты для педикюра с пылесосом Вспениватель Melitta Cremio черный"></a><h2>Вспениватель Melitta Cremio черный</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-2200r.php"><img src="photos/131f031076f016a5b0e85b06b57d0206.jpeg" alt="самсунг пылесос робот Микроволновая печь Vitek VT-1680" title="самсунг пылесос робот Микроволновая печь Vitek VT-1680"></a><h2>Микроволновая печь Vitek VT-1680</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мультиварка декс Кухонный комбайн Moulinex FP711141</h1>
						<div class="tb"><p>Цена: от <span class="price">6140</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_11994.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>С мощным надежным универсальным <b>кухонным комбайном</b> от Moulinex<b> </b>приготовление любых блюд станет настоящим удовольствием, кроме того, вы не только потратите меньше усилий на готовку, но и значительно сэкономите время, проведенное на кухне. Стильный дизайн устройства впишется в любой интерьер. Модель FP711141 обладает мощностью 900 Вт, двумя скоростными режимами (плюс импульсный), вместительной чашей на 3 л, блендером емкостью 1,5 л. Комбайн оснащен шнековой мясорубкой, соковыжималкой для цитрусовых, градуированной шкалой, клавишей Security для удобства разблокировки насадок. В комплекте идут две решетки для фарша: 4,7 мм и 7,5 мм, диски: два двусторонних - для натирания и нарезки, один - для картофеля фри и еще один - для измельчения, металлический нож, крюк для теста, венчик для взбивания, насадка для смешивания и терка-шинковка.</p><p>Комбайн изготовлен из высококачественного пластика, с ножом и решетками из нержавеющей стали, снабжен присосками, которые обеспечивают устойчивость прибора на столе, имеет отсек для хранения шнура. В целях безопасности предусмотрена функция отключения при перегреве. </p><p><b></b></p><p><b>Насадки:</b></p><ul type=disc><li>2 двусторонних диска для натирания и нарезки; <li>Диск для картофеля фри; <li>Диск для измельчения; <li>Металлический нож; <li>Крюк для теста; <li>Металлический венчик; <li>Насадка для смешивания; <li>Терка-шинковка. </li></ul><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 900 Вт; <li>Питание: 220 В; <li>Объем чаши: 3 л; <li>Объем блендера: 1,5 л; <li>Шнековая мясорубка; <li>Цитрусовая соковыжималка; <li>Производительность: 1,5 кг/мин; <li>Количество скоростей: 2; <li>Импульсный режим; <li>2 решетки для фарша: 4,7 мм и 7,5 мм; <li>Материал: пластик; <li>Нож и решетки из нержавеющей стали; <li>Градуированная шкала; <li>Отключение при перегреве; <li>Клавиша Security для разблокировки насадок; <li>Отверстие для ингредиентов; <li>Отсек для сетевого шнура; <li>Присоски для устойчивости на столе; <li>Длина сетевого шнура: 1,25 м; <li>Книга рецептов; <li>Размеры: 33х40х22 см; <li>Вес: 4 кг; <li>Цвет: белый.</li></ul><p><b>Производитель:</b> Moulinex.</p><p><b>Страна:</b> Франция.</p><p><b>Гарантия:</b> 2 года.</p> мультиварка декс</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/35ee696c1c92edfebad75db4602c2861.jpeg" alt="продам мультиварку Миксер Atlanta ATH-283" title="продам мультиварку Миксер Atlanta ATH-283"><div class="box"><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-530r.php"><h3 class="title">продам мультиварку Миксер Atlanta ATH-283</h3><p>от <span class="price">530</span> руб.</p></a></div></li>
						<li><img src="photos/be6b78c2525e9286d015556c4db7013b.jpeg" alt="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO" title="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO"><div class="box" page="elektricheskiy-mikser-krasnyy-bodum-bistro-euro-2740r"><span class="title">magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/966c1a147ae7eedce6463b74d364fbff.jpeg" alt="как правильно выбрать пароварку Пароварка Atlanta АТН-602" title="как правильно выбрать пароварку Пароварка Atlanta АТН-602"><div class="box" page="parovarka-atlanta-atn-1050r"><span class="title">как правильно выбрать пароварку Пароварка Atlanta АТН-602</span><p>от <span class="price">1050</span> руб.</p></div></li>
						<li><img src="photos/0f5208729d1f126a03ea2f6dcc581158.jpeg" alt="хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430" title="хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430"><div class="box" page="hlebopechka-moulinex-ow-7500r"><span class="title">хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430</span><p>от <span class="price">7500</span> руб.</p></div></li>
						<li class="large"><img src="photos/64a1e17046b7c97f3413bb1bcacb4f30.jpeg" alt="блендер в одессе Чайник экспресс Binatone EEJ-1555 White" title="блендер в одессе Чайник экспресс Binatone EEJ-1555 White"><div class="box" page="chaynik-ekspress-binatone-eej-white-2600r"><span class="title">блендер в одессе Чайник экспресс Binatone EEJ-1555 White</span><p>от <span class="price">2600</span> руб.</p></div></li>
						<li class="large"><img src="photos/c737b54864f365f17a12fbd2acc0e1ac.jpeg" alt="фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134" title="фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134"><div class="box" page="chaynik-elektricheskiy-vitek-vt-900r"><span class="title">фильтр для пылесоса thomas twin Чайник электрический Vitek VT-1134</span><p>от <span class="price">900</span> руб.</p></div></li>
						<li class="large"><img src="photos/50b32a99f8069aa25115dc1163e0b555.jpeg" alt="кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л" title="кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1760r"><span class="title">кофеварка эспрессо для дома Чайник электрический Tefal VitesseS BF66234 1,7 л</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li><img src="photos/8964576110671ffcda667fca45b4c191.jpeg" alt="кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л" title="кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1560r"><span class="title">кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л</span><p>от <span class="price">1560</span> руб.</p></div></li>
						<li><img src="photos/0acc9f01a71196d6ab7726b81327e74c.jpeg" alt="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717" title="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-390r"><span class="title">daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/e60d974a9eb12d238a3e8bae6f4ce905.jpeg" alt="покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)" title="покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-670r"><span class="title">покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)</span><p>от <span class="price">670</span> руб.</p></div></li>
						<li><img src="photos/c97072b686d00422f9e5b9490c04caab.jpeg" alt="кофеварка espresso Пылесос Thomas Inox 1545 Sfe" title="кофеварка espresso Пылесос Thomas Inox 1545 Sfe"><div class="box" page="pylesos-thomas-inox-sfe-13350r"><span class="title">кофеварка espresso Пылесос Thomas Inox 1545 Sfe</span><p>от <span class="price">13350</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("kuhonnyy-kombayn-moulinex-fp-6140r.php", 0, -4); if (file_exists("comments/kuhonnyy-kombayn-moulinex-fp-6140r.php")) require_once "comments/kuhonnyy-kombayn-moulinex-fp-6140r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="kuhonnyy-kombayn-moulinex-fp-6140r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>