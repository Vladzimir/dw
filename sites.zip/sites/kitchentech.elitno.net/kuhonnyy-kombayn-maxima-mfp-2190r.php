<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("kuhonnyy-kombayn-maxima-mfp-2190r.php","кольцо для аэрогриля");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("kuhonnyy-kombayn-maxima-mfp-2190r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кольцо для аэрогриля Кухонный комбайн Maxima MFP-0139  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кольцо для аэрогриля, кофемашина philips hd 8745, пароварка магазин, утюг philips 9220, мультиварка sr tmh 10, микроволновая печь тест, купить пылесос зелмер, кофеварка полуавтомат, десерты в блендере, лучший пылесос с аквафильтром, солянка в мультиварке, мини соковыжималка, горошница в мультиварке, блендер braun mx 2050,  слоеное тесто в аэрогриле">
		<meta name="description" content="кольцо для аэрогриля Погружной кухонный комбайн Maxima, мощностью 400 Вт, станет  незаменимым помощни...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3ee610b7cf277344aaeccda38d02c2fc.jpeg" title="кольцо для аэрогриля Кухонный комбайн Maxima MFP-0139"><img src="photos/3ee610b7cf277344aaeccda38d02c2fc.jpeg" alt="кольцо для аэрогриля Кухонный комбайн Maxima MFP-0139" title="кольцо для аэрогриля Кухонный комбайн Maxima MFP-0139 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-ci-silver-76390r.php"><img src="photos/c1f8cc6aba8e400d609d0ece06ae850b.jpeg" alt="кофемашина philips hd 8745 Эспрессо-кофемашина Melitta Caffeo CI Silver (4.0009.98)" title="кофемашина philips hd 8745 Эспрессо-кофемашина Melitta Caffeo CI Silver (4.0009.98)"></a><h2>Эспрессо-кофемашина Melitta Caffeo CI Silver (4.0009.98)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-beloserebristaya-29530r.php"><img src="photos/5b2c06d57a572404f45fc75e65b42e87.jpeg" alt="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая" title="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskaya-sokovyzhimalka-limonnaya-bodum-bistro-euro-3340r.php"><img src="photos/f99ea88369bed621a6594f78c2508e9a.jpeg" alt="утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO" title="утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO"></a><h2>Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кольцо для аэрогриля Кухонный комбайн Maxima MFP-0139</h1>
						<div class="tb"><p>Цена: от <span class="price">2190</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20501.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Погружной кухонный комбайн Maxima, мощностью 400 Вт, станет  незаменимым помощником на кухне любой хозяйки. Материал погружной части  устройства выполнен из металла. В механической системе управления предусмотрено  2 скорости работы и 2 вида терок. Кухонный комбайн поможет Вам в приготовлении  разнообразных блюд.</p><p><br><strong>Характеристики:</strong></p><ul><li>Тип: погружной;</li><li>Мощность: 400 Вт;</li><li>Управление: механическое;</li><li>Число скоростей: 2;</li><li>Измельчитель;</li><li>Мерный стаканчик;</li><li>Мельничка;</li><li>Венчик для взбивания;</li><li>Материал погружной части: металл;</li><li>Отверстие для ингредиентов;</li><li>2 вида терок.</li></ul><p><strong>Производитель:</strong><strong> Maxima (Китай)</strong><br><strong>Изготовитель: Китай</strong><br><strong>Гарантия: 12 месяцев</strong></p> кольцо для аэрогриля</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/b18048af79224983f1e624ba7e264cff.jpeg" alt="мультиварка sr tmh 10 Чайник электрический Vitek VT-1144 серебряный" title="мультиварка sr tmh 10 Чайник электрический Vitek VT-1144 серебряный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-serebryanyy-1550r"><span class="title">мультиварка sr tmh 10 Чайник электрический Vitek VT-1144 серебряный</span><p>от <span class="price">1550</span> руб.</p></div></li>
						<li><img src="photos/cb5b82e2b4fb8916dd96c68408275e51.jpeg" alt="микроволновая печь тест Чайник электрический Vitek VT-1149 красный" title="микроволновая печь тест Чайник электрический Vitek VT-1149 красный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-krasnyy-1650r"><span class="title">микроволновая печь тест Чайник электрический Vitek VT-1149 красный</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/67898b31f2a00b51820f96bc789fed43.jpeg" alt="купить пылесос зелмер Чайник электрический Maxima MК- M281" title="купить пылесос зелмер Чайник электрический Maxima MК- M281"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r"><span class="title">купить пылесос зелмер Чайник электрический Maxima MК- M281</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/8964576110671ffcda667fca45b4c191.jpeg" alt="кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л" title="кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1560r"><span class="title">кофеварка полуавтомат Чайник электрический  Vitesse VS-140 1,8л</span><p>от <span class="price">1560</span> руб.</p></div></li>
						<li class="large"><img src="photos/133af075f6993e048350b753f5c2c798.jpeg" alt="десерты в блендере Электрический чайник Atlanta АТН-727" title="десерты в блендере Электрический чайник Atlanta АТН-727"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r-2"><span class="title">десерты в блендере Электрический чайник Atlanta АТН-727</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li class="large"><img src="photos/d509d0771406a8c20b2506d316fad0aa.jpeg" alt="лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario" title="лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario"><div class="box" page="chaynik-melitta-look-aqua-vario-2838r"><span class="title">лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario</span><p>от <span class="price">2838</span> руб.</p></div></li>
						<li class="large"><img src="photos/39b908a415c11ffadfa5f63c6981b9e7.jpeg" alt="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail" title="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail"><div class="box" page="universalnaya-miniturboschetka-v-upakovke-dyson-mini-turbine-head-ir-cl-retail-2290r"><span class="title">солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail</span><p>от <span class="price">2290</span> руб.</p></div></li>
						<li><img src="photos/8201fb734cec793db96d43f2e27a6cc4.jpeg" alt="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail" title="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail"><div class="box" page="nabor-dlya-doma-dyson-home-cleaning-kit-retail-2490r"><span class="title">мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/6f1dc0aa11d1eda2d816fefb2df4a739.jpeg" alt="горошница в мультиварке Пылесос моющий Thomas Hygiene Plus T2" title="горошница в мультиварке Пылесос моющий Thomas Hygiene Plus T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-plus-t-19460r"><span class="title">горошница в мультиварке Пылесос моющий Thomas Hygiene Plus T2</span><p>от <span class="price">19460</span> руб.</p></div></li>
						<li><img src="photos/508d5d97fb58fc95875b08492316946f.jpeg" alt="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29" title="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29"><div class="box" page="pylesos-dyson-allergy-db-dc-19990r"><span class="title">блендер braun mx 2050 Пылесос Dyson allergy dB DC 29</span><p>от <span class="price">19990</span> руб.</p></div></li>
						<li><img src="photos/39a5505798446240c306b0610cc8e434.jpeg" alt="сколько стоит моющий пылесос Пылесос Vitek VT-1834" title="сколько стоит моющий пылесос Пылесос Vitek VT-1834"><div class="box" page="pylesos-vitek-vt-5890r"><span class="title">сколько стоит моющий пылесос Пылесос Vitek VT-1834</span><p>от <span class="price">5890</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("kuhonnyy-kombayn-maxima-mfp-2190r.php", 0, -4); if (file_exists("comments/kuhonnyy-kombayn-maxima-mfp-2190r.php")) require_once "comments/kuhonnyy-kombayn-maxima-mfp-2190r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="kuhonnyy-kombayn-maxima-mfp-2190r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>