<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-atlanta-ath-990r-2.php","моющий пылесос thomas купить");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-atlanta-ath-990r-2.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>моющий пылесос thomas купить Чайник электрический Atlanta ATH-759  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="моющий пылесос thomas купить, пылесос старый, кофемашина saeco инструкция, профессиональный дозиметр, разборка кофемашины, ремонт пылесосов бош, чайник электрический bork, купить кофемашину bosch, щетка для пылесоса electrolux, дешевая хлебопечка, мультиварка скороварка moulinex, купить рецепты для мультиварки, бытовой утюг, микроволновая печь bork,  кубань 8 вафельница">
		<meta name="description" content="моющий пылесос thomas купить Керамический электрический чайник Atlanta ATH-759 черного цвета с красивым рисун...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/8be60bf8ecb8c08e6df4d6b339b40b58.jpeg" title="моющий пылесос thomas купить Чайник электрический Atlanta ATH-759"><img src="photos/8be60bf8ecb8c08e6df4d6b339b40b58.jpeg" alt="моющий пылесос thomas купить Чайник электрический Atlanta ATH-759" title="моющий пылесос thomas купить Чайник электрический Atlanta ATH-759 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blendermaxima-mhb-760r.php"><img src="photos/29743842b370217cef729ce30e8386c4.jpeg" alt="пылесос старый БлендерMaxima MHB-0629" title="пылесос старый БлендерMaxima MHB-0629"></a><h2>БлендерMaxima MHB-0629</h2></li>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-blender-v-russell-hobbs-allure-art-3490r.php"><img src="photos/8eb90b2c93f90da38a9a78776cb9380e.jpeg" alt="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56" title="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56"></a><h2>Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/schetka-silikonovaya-giza-vitesse-vs-500r.php"><img src="photos/0b78d91a105ad11353549e33ee928e3e.jpeg" alt="профессиональный дозиметр Щетка силиконовая Giza Vitesse VS-1819" title="профессиональный дозиметр Щетка силиконовая Giza Vitesse VS-1819"></a><h2>Щетка силиконовая Giza Vitesse VS-1819</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>моющий пылесос thomas купить Чайник электрический Atlanta ATH-759</h1>
						<div class="tb"><p>Цена: от <span class="price">990</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18123.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Керамический электрический чайник Atlanta ATH-759 черного цвета с красивым рисунком объемом 1 литр, мощностью 1000 Вт с дисковым нагревателем из нержавеющей стали в качестве нагревательного элемента и фильтром от накипи. Абсолютно безопасен: выключается при закипании и не включается при отсутствии воды. </p><p><b>Характеристики:</b></p><ul type=disc><li>Объем: 1 л <li>Мощность: 1200 Вт <li>Нагревательный элемент: закрытая спираль <li>Блокировка включения без воды <li>Автоматическое выключение </li></ul><p><b>Производитель: Китай</b></p> моющий пылесос thomas купить</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/f21bb6b475177e08f0f09714d9a7c1cf.jpeg" alt="разборка кофемашины Микроволновка Zigmund & Shtain BMO 10.342 B" title="разборка кофемашины Микроволновка Zigmund & Shtain BMO 10.342 B"><div class="box" page="mikrovolnovka-zigmund-shtain-bmo-b-14900r"><span class="title">разборка кофемашины Микроволновка Zigmund & Shtain BMO 10.342 B</span><p>от <span class="price">14900</span> руб.</p></div></li>
						<li><img src="photos/5150ac82725ad8b6206019fefda496f4.jpeg" alt="ремонт пылесосов бош A&D NP-20KS Порционные весы" title="ремонт пылесосов бош A&D NP-20KS Порционные весы"><div class="box" page="ad-npks-porcionnye-vesy-7150r"><span class="title">ремонт пылесосов бош A&D NP-20KS Порционные весы</span><p>от <span class="price">7150</span> руб.</p></div></li>
						<li><img src="photos/cba9fd30236faeadb264f6621c9544f6.jpeg" alt="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер" title="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер"><div class="box" page="sokovyzhimalka-maxima-mj-blender-2190r"><span class="title">чайник электрический bork Соковыжималка Maxima MJ-049 + блендер</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/60dff82992355ef436c4e763a78c1f99.jpeg" alt="купить кофемашину bosch Соковыжималка для цитрусовых" title="купить кофемашину bosch Соковыжималка для цитрусовых"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-760r"><span class="title">купить кофемашину bosch Соковыжималка для цитрусовых</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/d0af4bd740dd75cf948a8f00224c2bee.jpeg" alt="щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White" title="щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White"><div class="box" page="chaynik-elektricheskiy-binatone-cej-white-1080r"><span class="title">щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li class="large"><img src="photos/6b196c567e46a72cdbf1317947c6e278.jpeg" alt="дешевая хлебопечка Чайник электрический  Vitesse VS-112, дорожный 0,8л" title="дешевая хлебопечка Чайник электрический  Vitesse VS-112, дорожный 0,8л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r"><span class="title">дешевая хлебопечка Чайник электрический  Vitesse VS-112, дорожный 0,8л</span><p>от <span class="price">970</span> руб.</p></div></li>
						<li class="large"><img src="photos/96ed77acce770bf04afcf29723d61326.jpeg" alt="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas" title="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-2"><span class="title">мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/c4ed1ed9a910d5dd5d3b4d4cba707112.jpeg" alt="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP" title="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP"><div class="box" page="nasadka-dlya-matrasov-v-upakovke-dyson-mattress-tool-assy-retail-np-1090r"><span class="title">купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/100a2bcb8188ff9463a9e3368c849858.jpeg" alt="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit" title="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit"><div class="box" page="nabor-dlya-uborki-v-avtomobile-dyson-car-cleaning-kit-2790r"><span class="title">бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit</span><p>от <span class="price">2790</span> руб.</p></div></li>
						<li><img src="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" alt="микроволновая печь bork Пылесос моющий Thomas Hygiene T2" title="микроволновая печь bork Пылесос моющий Thomas Hygiene T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-t-15900r"><span class="title">микроволновая печь bork Пылесос моющий Thomas Hygiene T2</span><p>от <span class="price">15900</span> руб.</p></div></li>
						<li><img src="photos/9fd5ef54211079a33ba5cc9bfbb9bfcf.jpeg" alt="купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter" title="купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-bravo-s-aquafilter-9270r"><span class="title">купить кофемашину jura Пылесос моющий Thomas Bravo 20 S Aquafilter</span><p>от <span class="price">9270</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-atlanta-ath-990r-2.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-atlanta-ath-990r-2.php")) require_once "comments/chaynik-elektricheskiy-atlanta-ath-990r-2.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-atlanta-ath-990r-2.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>