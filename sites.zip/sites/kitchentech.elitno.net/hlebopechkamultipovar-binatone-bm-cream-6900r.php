<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("hlebopechkamultipovar-binatone-bm-cream-6900r.php","кухонные весы scarlett");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("hlebopechkamultipovar-binatone-bm-cream-6900r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кухонные весы scarlett Хлебопечка-мультиповар Binatone BM-2170 Cream  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кухонные весы scarlett, кофеварка френч пресс, пылесос roomy gold, мясорубка moulinex hv, эльдорадо кофемашины, пылесосы с аквафильтром soteco, спагетти в мультиварке, какой моющий пылесос выбрать, кофемашина krups dolce gusto, кофемашина la cimbali, взбить блендером яйца, бетоносмеситель миксер, стимер для аэрогриля, кубань 8 вафельница,  микроволновая печь vitek">
		<meta name="description" content="кухонные весы scarlett Хлебопечка-мультиповар Binatone BM-2170 Cream представляет собой многофункционал...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/6e1b19f4e2e44aaedf95ea7e61a0919a.jpeg" title="кухонные весы scarlett Хлебопечка-мультиповар Binatone BM-2170 Cream"><img src="photos/6e1b19f4e2e44aaedf95ea7e61a0919a.jpeg" alt="кухонные весы scarlett Хлебопечка-мультиповар Binatone BM-2170 Cream" title="кухонные весы scarlett Хлебопечка-мультиповар Binatone BM-2170 Cream -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-redmond-rfp-5390r.php"><img src="photos/eeb9eab6db603b9616a92fc025537c6c.jpeg" alt="кофеварка френч пресс Кухонный комбайн Redmond  RFP-3903" title="кофеварка френч пресс Кухонный комбайн Redmond  RFP-3903"></a><h2>Кухонный комбайн Redmond  RFP-3903</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-35190r.php"><img src="photos/df4de2da7d663a4198320cc2af72f271.jpeg" alt="пылесос roomy gold Кофемашина Nivona NICR650 CafeRomatica" title="пылесос roomy gold Кофемашина Nivona NICR650 CafeRomatica"></a><h2>Кофемашина Nivona NICR650 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-solo-pure-silverblack-27000r.php"><img src="photos/e049963f26559d8e89e28ab3a3213f10.jpeg" alt="мясорубка moulinex hv Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)" title="мясорубка moulinex hv Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кухонные весы scarlett Хлебопечка-мультиповар Binatone BM-2170 Cream</h1>
						<div class="tb"><p>Цена: от <span class="price">6900</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_6809.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Хлебопечка-мультиповар </b><b>Binatone </b><b>BM-2170 </b><b>Cream</b> представляет собой многофункциональное устройство, которое можно использовать как хлебопечку, пароварку, суповарку, рисоварку, йогуртницу. Достаточно положить ингредиенты в лоток, и мультиповар сам приготовит нужное блюдо. Процесс готовки полностью автоматизирован. Модель оснащена 16-ю программами, большим удобным ЖК дисплеем с голубой подсветкой и панелью управления на русском языке. Незаменимый помощник на кухне, способный заменить множество приборов. Компания Binatone - один из ведущих мировых производителей мелкой и средней бытовой техники, представляющий широкий ассортимент различных товаров для дома и офиса. Продукция фирмы отличается высоким качеством, оригинальным дизайном и интересными цветовыми решениями.</p><p><b>Комплектация:</b></p><ul type=disc><li>Мерный стаканчик; <li>Мерная ложка; <li>Лопаточка для перемешивания; <li>Половник; <li>Две формы с антипригарным покрытием, удобные для мытья в посудомоечной машине; <li>Кулинарная книга рецептов.</li></ul><p><b></b></p><p><b>Особенности:</b></p><ul type=disc><li>Материал корпуса: пластик, не нагревающийся; <li>Имеется смотровое окно; <li>Количество программ выпечки: 16, из них 10 программ для разных видов хлеба и теста; <li>Сигнал для своевременной подачи в тесто дополнительных ингредиентов; <li>Автоматическое приготовление первых и вторых горячих блюд, десертов: супов, каш, тушеных овощей, плова, йогурта, джема, выпечка хлеба; <li>Возможность приготовления варенья; <li>Режим ускоренной выпечки; <li>Замес теста; <li>2 формы с антипригарным покрытием: одна для выпечки хлеба и приготовления йогурта и джема; другая - для приготовления горячих блюд; <li>Форма выпечки: буханка; <li>Выбор цвета корочки; <li>Регулировка веса выпечки; <li>Регулировка температуры приготовления (низкая, средняя, высокая); <li>Цвет: кремовый.</li></ul><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 1260 Вт; <li>Отложенный старт: 12 часов; <li>2 возможных веса выпечки: 750 и 900 г; <li>Поддержание температуры: до 1 часа; <li>Большой ЖК-дисплей с голубой подсветкой; <li>Запас памяти при сбое электропитания: 10 мин; <li>Вес: 7,4 кг.</li></ul><p><b>Производитель: </b>Binatone.</p> кухонные весы scarlett</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="эльдорадо кофемашины Микроволновая печь Vitek VT-1684" title="эльдорадо кофемашины Микроволновая печь Vitek VT-1684"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3870r"><span class="title">эльдорадо кофемашины Микроволновая печь Vitek VT-1684</span><p>от <span class="price">3870</span> руб.</p></div></li>
						<li><img src="photos/78e004a504b51dca5b370513a73854ac.jpeg" alt="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373" title="пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373"><div class="box" page="myasorubka-atlanta-ath-2150r"><span class="title">пылесосы с аквафильтром soteco Мясорубка  Atlanta ATH-373</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/b4972945a0247403022f6df03f16440c.jpeg" alt="спагетти в мультиварке Пароварка-блендер Philips Avent 85300" title="спагетти в мультиварке Пароварка-блендер Philips Avent 85300"><div class="box" page="parovarkablender-philips-avent-5600r"><span class="title">спагетти в мультиварке Пароварка-блендер Philips Avent 85300</span><p>от <span class="price">5600</span> руб.</p></div></li>
						<li><img src="photos/d2b0cc36c62095fdc525b7665e50506c.jpeg" alt="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321" title="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321"><div class="box" page="sokovyzhimalka-atlanta-ath-1010r"><span class="title">какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/10045e221774030a9f06ef65dc2f63de.jpeg" alt="кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024" title="кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024"><div class="box" page="frityurnica-tefal-minute-snack-ff-2220r"><span class="title">кофемашина krups dolce gusto Фритюрница Tefal Minute snack FF1024</span><p>от <span class="price">2220</span> руб.</p></div></li>
						<li class="large"><img src="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" alt="кофемашина la cimbali Электрический чайник Atlanta АТН-788" title="кофемашина la cimbali Электрический чайник Atlanta АТН-788"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1350r"><span class="title">кофемашина la cimbali Электрический чайник Atlanta АТН-788</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li class="large"><img src="photos/a42c720a2044c4a70ca880342e1aa3f1.jpeg" alt="взбить блендером яйца Чайник дисковый керамический 1,7л, розовые цветы Zauber ECO-350" title="взбить блендером яйца Чайник дисковый керамический 1,7л, розовые цветы Zauber ECO-350"><div class="box" page="chaynik-diskovyy-keramicheskiy-l-rozovye-cvety-zauber-eco-1750r"><span class="title">взбить блендером яйца Чайник дисковый керамический 1,7л, розовые цветы Zauber ECO-350</span><p>от <span class="price">1750</span> руб.</p></div></li>
						<li><img src="photos/569a7a448800e6c331839b4f1803d826.jpeg" alt="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502" title="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502"><div class="box" page="moyuschiy-koncentrat-thomas-protex-l-520r"><span class="title">бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/127daa75b6d910b9f123f08316795848.png" alt="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37" title="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37"><div class="box" page="pylesos-dyson-allergy-musclehead-dc-24590r"><span class="title">стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37</span><p>от <span class="price">24590</span> руб.</p></div></li>
						<li><img src="photos/4fbb8e89e08e4c6965da2c5a458072d3.jpeg" alt="кубань 8 вафельница Пылесос Vitek VT-1836 красный" title="кубань 8 вафельница Пылесос Vitek VT-1836 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3600r"><span class="title">кубань 8 вафельница Пылесос Vitek VT-1836 красный</span><p>от <span class="price">3600</span> руб.</p></div></li>
						<li><img src="photos/28ebbb0322a7eac61313d0d41391d394.jpeg" alt="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий" title="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-siniy-6900r"><span class="title">пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий</span><p>от <span class="price">6900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("hlebopechkamultipovar-binatone-bm-cream-6900r.php", 0, -4); if (file_exists("comments/hlebopechkamultipovar-binatone-bm-cream-6900r.php")) require_once "comments/hlebopechkamultipovar-binatone-bm-cream-6900r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="hlebopechkamultipovar-binatone-bm-cream-6900r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>