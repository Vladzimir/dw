<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektroplitka-maxima-mes-550r.php","кофемашина saeco hd 8747");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektroplitka-maxima-mes-550r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофемашина saeco hd 8747 Электроплитка Maxima MES-0152-1  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофемашина saeco hd 8747, сервисный центр по ремонту пылесосов, рецепт курицы в мультиварке, binatone хлебопечка отзывы, quigg хлебопечка, хлебопечка мистери, десерты в блендере, сравнение блендеров, пароварка газовая купить, кофеварка дольче густо отзывы, работа парогенератора, сколько стоит моющий пылесос, сколько стоит моющий пылесос, moulinex mk7003 мультиварка,  индукционная керамическая плита">
		<meta name="description" content="кофемашина saeco hd 8747 Электроплитка Maxima, мощностью 1000 Вт, отличное решение для дома или дачи.  Ко...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/99f24579a4151d885006823a70346b26.jpeg" title="кофемашина saeco hd 8747 Электроплитка Maxima MES-0152-1"><img src="photos/99f24579a4151d885006823a70346b26.jpeg" alt="кофемашина saeco hd 8747 Электроплитка Maxima MES-0152-1" title="кофемашина saeco hd 8747 Электроплитка Maxima MES-0152-1 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-vitek-vt-serebryanyy-1950r.php"><img src="photos/ca60273e08388d5c0131f65b9bd68f09.jpeg" alt="сервисный центр по ремонту пылесосов Блендер Vitek VT-1456 серебряный" title="сервисный центр по ремонту пылесосов Блендер Vitek VT-1456 серебряный"></a><h2>Блендер Vitek VT-1456 серебряный</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-750r.php"><img src="photos/4a8644a2c29f22e2d9c92389f96ff2ab.jpeg" alt="рецепт курицы в мультиварке Кухонный комбайн ATH-350" title="рецепт курицы в мультиварке Кухонный комбайн ATH-350"></a><h2>Кухонный комбайн ATH-350</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-39590r.php"><img src="photos/93a66ef135566c3ae659c72709d3515e.jpeg" alt="binatone хлебопечка отзывы Кофемашина Nivona NICR770 CafeRomatica" title="binatone хлебопечка отзывы Кофемашина Nivona NICR770 CafeRomatica"></a><h2>Кофемашина Nivona NICR770 CafeRomatica</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофемашина saeco hd 8747 Электроплитка Maxima MES-0152-1</h1>
						<div class="tb"><p>Цена: от <span class="price">550</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20648.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электроплитка Maxima, мощностью 1000 Вт, отличное решение для дома или дачи.  Корпус выполнен из прочного металла, а спиральный нагревательный элемент  выполнен из высококачественной стали. Для простоты эксплуатации электроплитка  покрыта прочным легкоочищающимся термостойким эмалевым покрытием. В целях безопасности  предусмотрена защита от перегрева.</p><p><br><strong>Характеристики:</strong></p><ul><li>Цвет: серый/черный;<br></li><li>Тип плиты: электрическая;</li><li>Количество конфорок: 1;</li><li>Цвет: серебристый;</li><li>Мощность 1000 Вт;</li><li>Диаметр конфорки: 145 мм;</li><li>Металлический корпус;</li><li>Плавная регулировка температуры;</li><li>Светодиодная индикация работы;</li><li>Спиральный нагревательный элемент из  высококачественной стали;</li><li>Прочное легкоочищаемое термостойкое эмалевое  покрытие;</li><li>Защита от перегрева.</li></ul><p><strong>Производитель: </strong><strong>Maxima (Китай)</strong><br><strong>Изготовитель: Китай</strong><br><strong>Гарантия: 12 месяцев</strong></p> кофемашина saeco hd 8747</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/ba4426ec9ff105596978c39d5f7ff4de.jpeg" alt="quigg хлебопечка Соковыжималка для цитрусовых 304-CP" title="quigg хлебопечка Соковыжималка для цитрусовых 304-CP"><div class="box"><a href="http://kitchentech.elitno.net/sokovyzhimalka-dlya-citrusovyh-cp-1300r.php"><h3 class="title">quigg хлебопечка Соковыжималка для цитрусовых 304-CP</h3><p>от <span class="price">1300</span> руб.</p></a></div></li>
						<li><img src="photos/aa004256b858fb51c2e43e9faff2b9a8.jpeg" alt="хлебопечка мистери Чайник электрический Maxima MК-113" title="хлебопечка мистери Чайник электрический Maxima MК-113"><div class="box" page="chaynik-elektricheskiy-maxima-mk-760r-3"><span class="title">хлебопечка мистери Чайник электрический Maxima MК-113</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/133af075f6993e048350b753f5c2c798.jpeg" alt="десерты в блендере Электрический чайник Atlanta АТН-727" title="десерты в блендере Электрический чайник Atlanta АТН-727"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r-2"><span class="title">десерты в блендере Электрический чайник Atlanta АТН-727</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li><img src="photos/41efedb38089aeb46a210ce7ff30eedc.jpeg" alt="сравнение блендеров Детектор жучков BugHunter Professional BH-01" title="сравнение блендеров Детектор жучков BugHunter Professional BH-01"><div class="box" page="detektor-zhuchkov-bughunter-professional-bh-7990r"><span class="title">сравнение блендеров Детектор жучков BugHunter Professional BH-01</span><p>от <span class="price">7990</span> руб.</p></div></li>
						<li class="large"><img src="photos/e754a7b0b0a20443433494bbd5f5ba8d.jpeg" alt="пароварка газовая купить Пылесборник Vitek VT-1851 5шт." title="пароварка газовая купить Пылесборник Vitek VT-1851 5шт."><div class="box" page="pylesbornik-vitek-vt-sht-190r"><span class="title">пароварка газовая купить Пылесборник Vitek VT-1851 5шт.</span><p>от <span class="price">190</span> руб.</p></div></li>
						<li class="large"><img src="photos/d360b8a0c7da5c2048584c84686650a7.jpeg" alt="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)" title="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-55r"><span class="title">кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)</span><p>от <span class="price">55</span> руб.</p></div></li>
						<li class="large"><img src="photos/1075d3353fd91819c5405594beb1237b.jpeg" alt="работа парогенератора Пылесос Dyson motorhead DC 23" title="работа парогенератора Пылесос Dyson motorhead DC 23"><div class="box" page="pylesos-dyson-motorhead-dc-36990r"><span class="title">работа парогенератора Пылесос Dyson motorhead DC 23</span><p>от <span class="price">36990</span> руб.</p></div></li>
						<li><img src="photos/39a5505798446240c306b0610cc8e434.jpeg" alt="сколько стоит моющий пылесос Пылесос Vitek VT-1834" title="сколько стоит моющий пылесос Пылесос Vitek VT-1834"><div class="box" page="pylesos-vitek-vt-5890r"><span class="title">сколько стоит моющий пылесос Пылесос Vitek VT-1834</span><p>от <span class="price">5890</span> руб.</p></div></li>
						<li><img src="photos/03817b6f2ca60ce9b5c33914a6a1ea52.jpeg" alt="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter" title="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter"><div class="box" page="pylesos-thomas-genius-aquafilter-9480r"><span class="title">сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter</span><p>от <span class="price">9480</span> руб.</p></div></li>
						<li><img src="photos/63eadb71b95851c3e7f26e5885bd43ae.jpeg" alt="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832" title="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-6900r"><span class="title">moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832</span><p>от <span class="price">6900</span> руб.</p></div></li>
						<li><img src="photos/d7f319eafa0a03def3b072699daeccdd.jpeg" alt="утюг в туле Утюг Vitek VT-1235" title="утюг в туле Утюг Vitek VT-1235"><div class="box" page="utyug-vitek-vt-970r"><span class="title">утюг в туле Утюг Vitek VT-1235</span><p>от <span class="price">970</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektroplitka-maxima-mes-550r.php", 0, -4); if (file_exists("comments/elektroplitka-maxima-mes-550r.php")) require_once "comments/elektroplitka-maxima-mes-550r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektroplitka-maxima-mes-550r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>