<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-binatone-si-blue-1600r.php","мясорубка elenberg");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-binatone-si-blue-1600r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мясорубка elenberg Утюг Binatone SI-4040 Blue  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мясорубка elenberg, экспресс кофеварка, преимущества мультиварки, тыква в мультиварке, пароварка магазин, рецепт пиццы в хлебопечке, мотор пылесоса самсунг, гречневая каша в мультиварке, утюг philips 4420, лампа для аэрогриля, купить кофемашину bosch, пылесос томас твин т1, блендер philips hr1659, аэрогриль pag 1205d,  какой лучше парогенератор">
		<meta name="description" content="мясорубка elenberg Утюг паровой Binatone SI-4040 Blue оснащен двойной керамической антипригарной по...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/b5afd7c51355e06ff913b79a852afc55.jpeg" title="мясорубка elenberg Утюг Binatone SI-4040 Blue"><img src="photos/b5afd7c51355e06ff913b79a852afc55.jpeg" alt="мясорубка elenberg Утюг Binatone SI-4040 Blue" title="мясорубка elenberg Утюг Binatone SI-4040 Blue -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/miniblender-elektricheskiy-philips-avent-s-naborom-dlya-prigotovleniya-prikorma-2630r.php"><img src="photos/e108698677b9a90b7d512a1822cd82a7.jpeg" alt="экспресс кофеварка Миниблендер электрический Philips Avent с набором для приготовления прикорма 85210" title="экспресс кофеварка Миниблендер электрический Philips Avent с набором для приготовления прикорма 85210"></a><h2>Миниблендер электрический Philips Avent с набором для приготовления прикорма 85210</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-tefal-blde-2660r.php"><img src="photos/a169e670a3a2eab3dd68bb002270cf0f.jpeg" alt="преимущества мультиварки Блендер Tefal BL522D3E" title="преимущества мультиварки Блендер Tefal BL522D3E"></a><h2>Блендер Tefal BL522D3E</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-1290r.php"><img src="photos/6dd18dbc3abd740bf749993f0923000d.jpeg" alt="тыква в мультиварке Блендер Maxima MHB-0329" title="тыква в мультиварке Блендер Maxima MHB-0329"></a><h2>Блендер Maxima MHB-0329</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мясорубка elenberg Утюг Binatone SI-4040 Blue</h1>
						<div class="tb"><p>Цена: от <span class="price">1600</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_6825.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Утюг</b><b> паровой</b><b> Binatone SI-4040 Blue </b>оснащен двойной керамической антипригарной подошвой Carelux, вращающимся шнуром, удобной прорезиненной ручкой. Модель способна работать в различных температурных режимах, возможна сухая глажка, турбо пар. Предусмотрено защитное автоотключение, функция защиты от накипи, самоочистка. Компания Binatone - один из ведущих мировых производителей мелкой и средней бытовой техники, представляющий широкий ассортимент различных товаров для дома и офиса. Продукция фирмы отличается высоким качеством, оригинальным дизайном и интересными цветовыми решениями.</p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 2400 Вт; <li>Двойная керамическая подошва Carelux; <li>Различные режимы парообразования; <li>Защитное автоотключение; <li>Противокапельная система; <li>Функция защиты от накипи; <li>Мощный вертикальный пар; <li>Турбо пар; <li>Спрей; <li>Различные температурные режимы; <li>Возможность сухой глажки; <li>Функция самоочистки; <li>Вращающийся шнур; <li>Мерный стаканчик в комплекте; <li>Цвет: голубой; <li>Вес: 1,65 кг.</li></ul><p><b>Производитель: </b>Binatone.</p> мясорубка elenberg</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5b2c06d57a572404f45fc75e65b42e87.jpeg" alt="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая" title="пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-lattea-beloserebristaya-29530r"><span class="title">пароварка магазин Автоматическая кофемашина Melitta CAFFEO Lattea, бело-серебристая</span><p>от <span class="price">29530</span> руб.</p></div></li>
						<li><img src="photos/7182cc256e7e3343e3aec4d550f1f314.jpeg" alt="рецепт пиццы в хлебопечке Электрическая кофемолка Bodum BISTRO 10903-913EURO белая" title="рецепт пиццы в хлебопечке Электрическая кофемолка Bodum BISTRO 10903-913EURO белая"><div class="box" page="elektricheskaya-kofemolka-bodum-bistro-euro-belaya-5730r"><span class="title">рецепт пиццы в хлебопечке Электрическая кофемолка Bodum BISTRO 10903-913EURO белая</span><p>от <span class="price">5730</span> руб.</p></div></li>
						<li><img src="photos/99f24579a4151d885006823a70346b26.jpeg" alt="мотор пылесоса самсунг Электроплитка Maxima MES-0152-1" title="мотор пылесоса самсунг Электроплитка Maxima MES-0152-1"><div class="box" page="elektroplitka-maxima-mes-550r"><span class="title">мотор пылесоса самсунг Электроплитка Maxima MES-0152-1</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li><img src="photos/8472253b416100a0ed111bb9484a2b5a.jpeg" alt="гречневая каша в мультиварке Мороженица Montiss KIM5405M 1,1 л" title="гречневая каша в мультиварке Мороженица Montiss KIM5405M 1,1 л"><div class="box" page="morozhenica-montiss-kimm-l-1900r"><span class="title">гречневая каша в мультиварке Мороженица Montiss KIM5405M 1,1 л</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/8e06126566eae5ed349414b3b9cfd8ea.jpeg" alt="утюг philips 4420 Мультиварка Maruchi RB-FC46" title="утюг philips 4420 Мультиварка Maruchi RB-FC46"><div class="box" page="multivarka-maruchi-rbfc-2500r"><span class="title">утюг philips 4420 Мультиварка Maruchi RB-FC46</span><p>от <span class="price">2500</span> руб.</p></div></li>
						<li class="large"><img src="photos/c2ec0f6a659b8874d2e6e8a30149501a.jpeg" alt="лампа для аэрогриля Мультиварка Maruchi  RW-FZ45F" title="лампа для аэрогриля Мультиварка Maruchi  RW-FZ45F"><div class="box" page="multivarka-maruchi-rwfzf-2700r"><span class="title">лампа для аэрогриля Мультиварка Maruchi  RW-FZ45F</span><p>от <span class="price">2700</span> руб.</p></div></li>
						<li class="large"><img src="photos/60dff82992355ef436c4e763a78c1f99.jpeg" alt="купить кофемашину bosch Соковыжималка для цитрусовых" title="купить кофемашину bosch Соковыжималка для цитрусовых"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-760r"><span class="title">купить кофемашину bosch Соковыжималка для цитрусовых</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/58caa49e2e5c4bf06cfbf9dcdde29448.jpeg" alt="пылесос томас твин т1 Чайник электрический Vitek VT-1142" title="пылесос томас твин т1 Чайник электрический Vitek VT-1142"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1950r"><span class="title">пылесос томас твин т1 Чайник электрический Vitek VT-1142</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/eb489286225dbbc8037e4654ee2b1544.jpeg" alt="блендер philips hr1659 Чайник электрический Redmond  RK-M114" title="блендер philips hr1659 Чайник электрический Redmond  RK-M114"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2990r"><span class="title">блендер philips hr1659 Чайник электрический Redmond  RK-M114</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/823ffa497493bf85b62e76ddeebc1296.jpeg" alt="аэрогриль pag 1205d Чайник электрический Redmond  RK-М117 white" title="аэрогриль pag 1205d Чайник электрический Redmond  RK-М117 white"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-white-1190r"><span class="title">аэрогриль pag 1205d Чайник электрический Redmond  RK-М117 white</span><p>от <span class="price">1190</span> руб.</p></div></li>
						<li><img src="photos/0acc9f01a71196d6ab7726b81327e74c.jpeg" alt="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717" title="daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-390r"><span class="title">daewoo микроволновая печь инструкция Электрический чайник Atlanta АТН-717</span><p>от <span class="price">390</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-binatone-si-blue-1600r.php", 0, -4); if (file_exists("comments/utyug-binatone-si-blue-1600r.php")) require_once "comments/utyug-binatone-si-blue-1600r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-binatone-si-blue-1600r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>