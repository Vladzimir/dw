<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("bumazhnye-filtrymeshki-dlya-thomas-1150r.php","нитратомер купить");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("bumazhnye-filtrymeshki-dlya-thomas-1150r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>нитратомер купить Бумажные фильтры-мешки 450 (787-114) для Thomas  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="нитратомер купить, хлебопечка ру рецепты, цилиндрические пылесосы, рецепты для хлебопечки с фото, картофель во фритюрнице, эльдорадо кофемашины, борщ в мультиварке панасоник, приготовление майонеза в блендере, ножки в аэрогриле, мультиварка панасоник sr tmh18, пылесос bork v500, тостер philips hd, мультиварка киев купить, пылесос с электрощеткой,  микроволновая печь vitek">
		<meta name="description" content="нитратомер купить Бумажные фильтры-мешки выпускаются в упаковке из пяти штук. Они отличаются высок...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/ebeb61ea1ddcbebc4d0a7ed9a625842f.jpeg" title="нитратомер купить Бумажные фильтры-мешки 450 (787-114) для Thomas"><img src="photos/ebeb61ea1ddcbebc4d0a7ed9a625842f.jpeg" alt="нитратомер купить Бумажные фильтры-мешки 450 (787-114) для Thomas" title="нитратомер купить Бумажные фильтры-мешки 450 (787-114) для Thomas -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/oksiochistitel-ot-nakipi-swirl-hg-90r.php"><img src="photos/b1940086e49964580ca58fbacc9f1c79.jpeg" alt="хлебопечка ру рецепты Окси-очиститель от накипи Swirl, 2х15г" title="хлебопечка ру рецепты Окси-очиститель от накипи Swirl, 2х15г"></a><h2>Окси-очиститель от накипи Swirl, 2х15г</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2190r.php"><img src="photos/1546b6eb4b08215189976c86afe6dd84.jpeg" alt="цилиндрические пылесосы Блендер Redmond RHB-2905" title="цилиндрические пылесосы Блендер Redmond RHB-2905"></a><h2>Блендер Redmond RHB-2905</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lounge-black-45500r.php"><img src="photos/f5887b3a092904b4c854c36d9035df19.jpeg" alt="рецепты для хлебопечки с фото Эспрессо-кофемашина Melitta Caffeo Lounge Black (4.0009.87)" title="рецепты для хлебопечки с фото Эспрессо-кофемашина Melitta Caffeo Lounge Black (4.0009.87)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lounge Black (4.0009.87)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>нитратомер купить Бумажные фильтры-мешки 450 (787-114) для Thomas</h1>
						<div class="tb"><p>Цена: от <span class="price">1150</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14813.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Бумажные фильтры-мешки выпускаются в упаковке из пяти штук. Они отличаются высокой прочностью, совместимы с моделями пылесосов фирмы Thomas: 1243/1250S/1445 S/1445 SFE.</p><p><b>Характеристики:</b></p><ul type=disc><li>Количество: 5 шт; </li><li>Материал: бумага.</li></ul><p><b>Подходят к моделям пылесосов: </b></p><ul type=disc><li>Thomas 1243/1250S/1445 S/1445 SFE</li></ul><p><b>Производитель:</b> Thomas.</p> нитратомер купить</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d1b139f63086ad817c04622c294f1224.jpeg" alt="картофель во фритюрнице Кофеварка  ATH-278" title="картофель во фритюрнице Кофеварка  ATH-278"><div class="box" page="kofevarka-ath-560r"><span class="title">картофель во фритюрнице Кофеварка  ATH-278</span><p>от <span class="price">560</span> руб.</p></div></li>
						<li><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="эльдорадо кофемашины Микроволновая печь Vitek VT-1684" title="эльдорадо кофемашины Микроволновая печь Vitek VT-1684"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3870r"><span class="title">эльдорадо кофемашины Микроволновая печь Vitek VT-1684</span><p>от <span class="price">3870</span> руб.</p></div></li>
						<li><img src="photos/5254af3bd6ab9ae98e8b312cfa811acd.jpeg" alt="борщ в мультиварке панасоник Миксер Moulinex HM5500 Easy Max" title="борщ в мультиварке панасоник Миксер Moulinex HM5500 Easy Max"><div class="box" page="mikser-moulinex-hm-easy-max-2050r"><span class="title">борщ в мультиварке панасоник Миксер Moulinex HM5500 Easy Max</span><p>от <span class="price">2050</span> руб.</p></div></li>
						<li><img src="photos/4aba59e656a62396ee01dc9ed0a83fa8.jpeg" alt="приготовление майонеза в блендере Соковыжималка TURBO" title="приготовление майонеза в блендере Соковыжималка TURBO"><div class="box" page="sokovyzhimalka-turbo-7790r"><span class="title">приготовление майонеза в блендере Соковыжималка TURBO</span><p>от <span class="price">7790</span> руб.</p></div></li>
						<li class="large"><img src="photos/3efeed2a40b596512ea138d7f6d2f182.jpeg" alt="ножки в аэрогриле Термопот Binatone TP-4055 White" title="ножки в аэрогриле Термопот Binatone TP-4055 White"><div class="box" page="termopot-binatone-tp-white-1990r"><span class="title">ножки в аэрогриле Термопот Binatone TP-4055 White</span><p>от <span class="price">1990</span> руб.</p></div></li>
						<li class="large"><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/aad075f22e1967e01f21286f7d5da33a.jpeg" alt="пылесос bork v500 Чайник Vitek VT-1161 с керамическим корпусом" title="пылесос bork v500 Чайник Vitek VT-1161 с керамическим корпусом"><div class="box" page="chaynik-vitek-vt-s-keramicheskim-korpusom-3450r"><span class="title">пылесос bork v500 Чайник Vitek VT-1161 с керамическим корпусом</span><p>от <span class="price">3450</span> руб.</p></div></li>
						<li><img src="photos/0e0d48622ca21267b7347abd2a6edbfa.jpeg" alt="тостер philips hd Redmond RK-M120D Чайник электрический" title="тостер philips hd Redmond RK-M120D Чайник электрический"><div class="box" page="redmond-rkmd-chaynik-elektricheskiy-4950r"><span class="title">тостер philips hd Redmond RK-M120D Чайник электрический</span><p>от <span class="price">4950</span> руб.</p></div></li>
						<li><img src="photos/1b3cfce3fc4c2602ab4206bda1961e7d.jpeg" alt="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный" title="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belolazurnyy-920r"><span class="title">мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/b5afd7c51355e06ff913b79a852afc55.jpeg" alt="пылесос с электрощеткой Утюг Binatone SI-4040 Blue" title="пылесос с электрощеткой Утюг Binatone SI-4040 Blue"><div class="box" page="utyug-binatone-si-blue-1600r"><span class="title">пылесос с электрощеткой Утюг Binatone SI-4040 Blue</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/ee03f1721014fcaa8f40d146634cc194.jpeg" alt="мясорубка с овощерезкой Утюг Vitek VT-1210" title="мясорубка с овощерезкой Утюг Vitek VT-1210"><div class="box" page="utyug-vitek-vt-850r"><span class="title">мясорубка с овощерезкой Утюг Vitek VT-1210</span><p>от <span class="price">850</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("bumazhnye-filtrymeshki-dlya-thomas-1150r.php", 0, -4); if (file_exists("comments/bumazhnye-filtrymeshki-dlya-thomas-1150r.php")) require_once "comments/bumazhnye-filtrymeshki-dlya-thomas-1150r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="bumazhnye-filtrymeshki-dlya-thomas-1150r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>