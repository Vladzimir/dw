<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("utyug-atlanta-ath-1150r.php","треска в мультиварке");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("utyug-atlanta-ath-1150r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>треска в мультиварке Утюг Atlanta ATH-494  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="треска в мультиварке, пылесос thomas genius s2, пылесос прессующий, хлебопечка хлеб из гречневой муки, вафельница орешек 4, блендер в одессе, электрические чайники скарлет, как пользоваться мультиваркой, кофемашины оптом, пароварка tefal 7001, аэрогриль рецепты картофель, panasonic блендер, хлебопечка советы, кофеварка дольче густо отзывы,  горошница в мультиварке">
		<meta name="description" content="треска в мультиварке Утюг Atlanta ATH-494 с пароувлажнителем мощностью 2000 Вт – мощный стильный приб...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3ef4b6d6e70d5b5e3028d838a7d2a793.jpeg" title="треска в мультиварке Утюг Atlanta ATH-494"><img src="photos/3ef4b6d6e70d5b5e3028d838a7d2a793.jpeg" alt="треска в мультиварке Утюг Atlanta ATH-494" title="треска в мультиварке Утюг Atlanta ATH-494 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2180r.php"><img src="photos/a1f8cd769afd06226b32e6fb44474c86.jpeg" alt="пылесос thomas genius s2 Блендер Redmond RHB-2908" title="пылесос thomas genius s2 Блендер Redmond RHB-2908"></a><h2>Блендер Redmond RHB-2908</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-maxima-mfp-2190r.php"><img src="photos/3ee610b7cf277344aaeccda38d02c2fc.jpeg" alt="пылесос прессующий Кухонный комбайн Maxima MFP-0139" title="пылесос прессующий Кухонный комбайн Maxima MFP-0139"></a><h2>Кухонный комбайн Maxima MFP-0139</h2></li>
							<li><a href="http://kitchentech.elitno.net/indukcionnaya-plita-kitfort-kt-2700r.php"><img src="photos/7ffc20dc8107b2fc1365cfb7486e823a.jpeg" alt="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101" title="хлебопечка хлеб из гречневой муки Индукционная плита Kitfort KT-101"></a><h2>Индукционная плита Kitfort KT-101</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>треска в мультиварке Утюг Atlanta ATH-494</h1>
						<div class="tb"><p>Цена: от <span class="price">1150</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19760.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Утюг Atlanta ATH-494 с пароувлажнителем мощностью 2000 Вт – мощный стильный прибор черно-голубого цвета для глажки, с подошвой с керамическим напылением. Абсолютно безопасен, т. к. имеет функцию автоматического отключения. Также есть функция самоочистки. Кроме того, он имеет функцию парового удара. Иногда для проглаживания сильно пересушенных или толстых тканей не хватает даже максимальной модности постоянного пара. Специально для таких случаев в этом утюге есть паровой удар. При нажатии на кнопку происходит мощная подача пара, находящегося под высоким давлением. Сильный удар горячего пара размягчает волокна и быстро разглаживает даже глубокие складки. А подача вертикального пара позволяет гладить пиджаки, пальто и другие вещи прямо на вешалке или манекене.</p><p>Характеристики:</p><ul type=disc><li>Высокая мощность <li>Подошва с керамическим напылением <li>Автоматическое отключение <li>Защита от перегрева <li>Самоочистка  <li>Вертикальная подача пара <li>Функция увлажнения <li>Противокапельный механизм <li>Ручка с противоскользящим покрытием <li>Изделие сертифицировано Госстандартом РФ <li>Соответствует европейским нормам безопасности <li>Потребляемая мощность 2000 Вт  <li>230 В, 50 Гц <li>13 x 12.4 x 17.8 см </li></ul><p> </p><p><strong>Производитель: США</strong></p> треска в мультиварке</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d7869500a03daf3749520ba97157adc1.jpeg" alt="вафельница орешек 4 Хлебопечка Moulinex OW310130 Uno" title="вафельница орешек 4 Хлебопечка Moulinex OW310130 Uno"><div class="box" page="hlebopechka-moulinex-ow-uno-4990r"><span class="title">вафельница орешек 4 Хлебопечка Moulinex OW310130 Uno</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/64a1e17046b7c97f3413bb1bcacb4f30.jpeg" alt="блендер в одессе Чайник экспресс Binatone EEJ-1555 White" title="блендер в одессе Чайник экспресс Binatone EEJ-1555 White"><div class="box" page="chaynik-ekspress-binatone-eej-white-2600r"><span class="title">блендер в одессе Чайник экспресс Binatone EEJ-1555 White</span><p>от <span class="price">2600</span> руб.</p></div></li>
						<li><img src="photos/c48020be535a5770584db54e47af400d.jpeg" alt="электрические чайники скарлет Чайник электрический Vitek VT-1115 желтый" title="электрические чайники скарлет Чайник электрический Vitek VT-1115 желтый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-zheltyy-1090r"><span class="title">электрические чайники скарлет Чайник электрический Vitek VT-1115 желтый</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/1e85a6f32a0f78265e06897930cad48c.jpeg" alt="как пользоваться мультиваркой Электрический чайник Atlanta АТН-660" title="как пользоваться мультиваркой Электрический чайник Atlanta АТН-660"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-650r"><span class="title">как пользоваться мультиваркой Электрический чайник Atlanta АТН-660</span><p>от <span class="price">650</span> руб.</p></div></li>
						<li class="large"><img src="photos/78965fa03e391297ff5141e1ed5d2961.jpeg" alt="кофемашины оптом Электрический чайник Atlanta АТН-721" title="кофемашины оптом Электрический чайник Atlanta АТН-721"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r"><span class="title">кофемашины оптом Электрический чайник Atlanta АТН-721</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li class="large"><img src="photos/7c67b6491c0da9489fd3f2ddee3c01b1.jpeg" alt="пароварка tefal 7001 Паровая гладильная система Sofia Lux" title="пароварка tefal 7001 Паровая гладильная система Sofia Lux"><div class="box" page="parovaya-gladilnaya-sistema-sofia-lux-69000r"><span class="title">пароварка tefal 7001 Паровая гладильная система Sofia Lux</span><p>от <span class="price">69000</span> руб.</p></div></li>
						<li class="large"><img src="photos/7bfc4f4031d68720fdce5209cf8c8c0d.jpeg" alt="аэрогриль рецепты картофель Мини-весы Tanita 1479V" title="аэрогриль рецепты картофель Мини-весы Tanita 1479V"><div class="box" page="minivesy-tanita-v-3000r"><span class="title">аэрогриль рецепты картофель Мини-весы Tanita 1479V</span><p>от <span class="price">3000</span> руб.</p></div></li>
						<li><img src="photos/a72d69a17b01ae0c39e3992b04fd72d5.jpeg" alt="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)" title="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-750r"><span class="title">panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)</span><p>от <span class="price">750</span> руб.</p></div></li>
						<li><img src="photos/cc9208f636d59db8c6c0a8ac95064dc7.jpeg" alt="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0" title="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0"><div class="box" page="shlang-podachi-vody-c-filtrom-karcher-1750r"><span class="title">хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0</span><p>от <span class="price">1750</span> руб.</p></div></li>
						<li><img src="photos/d360b8a0c7da5c2048584c84686650a7.jpeg" alt="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)" title="кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-55r"><span class="title">кофеварка дольче густо отзывы Фильтры для пылесоса Vitek VT-1868 (VT-1838)</span><p>от <span class="price">55</span> руб.</p></div></li>
						<li><img src="photos/bf71bbc1609948054c42cfa52f5f228d.jpeg" alt="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas" title="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r"><span class="title">лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("utyug-atlanta-ath-1150r.php", 0, -4); if (file_exists("comments/utyug-atlanta-ath-1150r.php")) require_once "comments/utyug-atlanta-ath-1150r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="utyug-atlanta-ath-1150r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>