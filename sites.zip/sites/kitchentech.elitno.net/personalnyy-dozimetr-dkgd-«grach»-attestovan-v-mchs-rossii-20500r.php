<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r.php","пылесос купить недорого");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос купить недорого Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос купить недорого, хлебопечка bifinett инструкция, аэрогриль hotter инструкция, пароварка scarlett is 550, zelmer мясорубка отзывы, стоимость миксера, рецепт индейки в мультиварке, купить утюг для волос, капельная кофеварка инструкция, гречневая каша в мультиварке, ребра в аэрогриле, покупка пылесоса, как варить гречку в пароварке, panasonic блендер,  ржаная мука для хлебопечки">
		<meta name="description" content="пылесос купить недорого Персональный высокочувствительный дозиметр ДКГ-03Д «Грач» представляет собой удо...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d221c08cbc7532258ec107ff315e3516.jpeg" title="пылесос купить недорого Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)"><img src="photos/d221c08cbc7532258ec107ff315e3516.jpeg" alt="пылесос купить недорого Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)" title="пылесос купить недорого Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России) -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/minipechkaduhovka-atlanta-atn-2200r.php"><img src="photos/c6ad3fad9605570f18884e29f3616e94.jpeg" alt="хлебопечка bifinett инструкция Минипечка-духовка Atlanta АТН-1401" title="хлебопечка bifinett инструкция Минипечка-духовка Atlanta АТН-1401"></a><h2>Минипечка-духовка Atlanta АТН-1401</h2></li>
							<li><a href="http://kitchentech.elitno.net/minipechkaduhovka-atlanta-atn-2860r.php"><img src="photos/99e42fd1d4a11c6642a9386db8a9c8d1.jpeg" alt="аэрогриль hotter инструкция Минипечка-духовка Atlanta АТН-1402" title="аэрогриль hotter инструкция Минипечка-духовка Atlanta АТН-1402"></a><h2>Минипечка-духовка Atlanta АТН-1402</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-870r.php"><img src="photos/08c15d1f7a465f949f829449dc3e88eb.jpeg" alt="пароварка scarlett is 550 Блендер Maxima MHB-0429" title="пароварка scarlett is 550 Блендер Maxima MHB-0429"></a><h2>Блендер Maxima MHB-0429</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос купить недорого Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)</h1>
						<div class="tb"><p>Цена: от <span class="price">20500</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_12849.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Персональный высокочувствительный дозиметр ДКГ-03Д «Грач» представляет собой удобный компактный прибор, который применяется как штатными, так и нештатными аварийно-спасательными формированиями единой государственной системы по предупреждению и ликвидации чрезвычайных ситуаций. Аппарат вошел в нормы оснащения в соответствии с приказом МЧС России «Об утверждении Порядка создания нештатных аварийно-спасательных формирований» (№ 999 от 23 декабря 2005 года).</p><p>Дозиметр удобен для проведения радиационных обследований, он отличается удачным алгоритмом измерения, высокой чувствительностью, а также довольно приемлемой ценой. С момента начала измерения, результаты и погрешность непрерывно индицируются и постоянно уточняются, также при достижении необходимой погрешности процесс можно прервать. Дозиметр выполнен в пластиковом корпусе, оснащен экраном с подсветкой, звуковой сигнализацией с пропорциональной мощности дозы частотой, предусматривает возможность подключения головного телефона. Прибор питается от двух батарей АА по 1,5В, непрерывной работы которых хватает не менее, чем на 200 часов.</p><p><b>Технические характеристики:</b></p><ul type=disc><li>Детектор: газоразрядный счетчик (по чувствительности эквивалентен 3 шт. СБМ-20); </li><li>Диапазон измерения мощности дозы Н*(10): 0,1 мкЗв/ч - 1,0 мЗв/ч; </li><li>Диапазон измерения дозы Н*(10): 1,0 мкЗв - 100 Зв; </li><li>Диапазон энергий гамма-излучения: 0,05 - 3,0 МэВ; </li><li>Пределы допускаемой основной относительной погрешности измерения: ±[15+2,5/Н *(10)]%, где Н*(10) - измеренное значение, мкЗв/ч(мкЗв); </li><li>Чувствительность: 20000 имп/мкЗв; </li><li>Энергетическая зависимость чувствительности (относительно эффективной энергии 0,662 кэВ): не более 25%; </li><li>Вывод информации: цифровая индикация с подсветом экрана, звуковая сигнализация (возможно подключение головного телефона); </li><li>Время выхода на рабочий режим: 2 сек; </li><li>Диапазон рабочих температур: -20 - +50 °C; </li><li>Влажность: до 90% при +25 °C; </li><li>Конструктивное исполнение: корпус из пластмассы; </li><li>Питание: 2 элемента по 1,5В типа АА; </li><li>Время непрерывной работы с одним комплектом батарей, не менее: 200 часов; </li><li>Габаритные размеры: 111х28х73 мм; </li><li>Вес, не более: 0,18 кг.</li></ul><p><b>Страна:</b> Россия.</p> пылесос купить недорого</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/ac0d13475c79f9c87e6f514f3140de60.jpeg" alt="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56" title="zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56"><div class="box" page="blender-russell-hobbs-allure-art-5490r"><span class="title">zelmer мясорубка отзывы Блендер Russell Hobbs Allure, арт. 18276-56</span><p>от <span class="price">5490</span> руб.</p></div></li>
						<li><img src="photos/696246935af3c686fbf13206e4f5dbc0.jpeg" alt="стоимость миксера Кофемолка Nivona NICG120 CafeGrano" title="стоимость миксера Кофемолка Nivona NICG120 CafeGrano"><div class="box" page="kofemolka-nivona-nicg-cafegrano-4490r"><span class="title">стоимость миксера Кофемолка Nivona NICG120 CafeGrano</span><p>от <span class="price">4490</span> руб.</p></div></li>
						<li><img src="photos/1c87b1da99c709915f1f2bf9d89b2035.jpeg" alt="рецепт индейки в мультиварке Zauber Кофемолка  X-470" title="рецепт индейки в мультиварке Zauber Кофемолка  X-470"><div class="box" page="zauber-kofemolka-x-850r"><span class="title">рецепт индейки в мультиварке Zauber Кофемолка  X-470</span><p>от <span class="price">850</span> руб.</p></div></li>
						<li><img src="photos/3bdb5a7ebf59a397ed1b6263ffa77483.jpeg" alt="купить утюг для волос Кофемолка Vitesse VS-271" title="купить утюг для волос Кофемолка Vitesse VS-271"><div class="box" page="kofemolka-vitesse-vs-1100r"><span class="title">купить утюг для волос Кофемолка Vitesse VS-271</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li class="large"><img src="photos/59cc932c7224c4f3a91684264a52c663.jpeg" alt="капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141" title="капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141"><div class="box" page="kuhonnyy-kombayn-moulinex-fp-6140r"><span class="title">капельная кофеварка инструкция Кухонный комбайн Moulinex FP711141</span><p>от <span class="price">6140</span> руб.</p></div></li>
						<li class="large"><img src="photos/8472253b416100a0ed111bb9484a2b5a.jpeg" alt="гречневая каша в мультиварке Мороженица Montiss KIM5405M 1,1 л" title="гречневая каша в мультиварке Мороженица Montiss KIM5405M 1,1 л"><div class="box" page="morozhenica-montiss-kimm-l-1900r"><span class="title">гречневая каша в мультиварке Мороженица Montiss KIM5405M 1,1 л</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/1a5872ce4a924d71272e9d8aacab1a34.jpeg" alt="ребра в аэрогриле Чайник электрический Maxima MК-103" title="ребра в аэрогриле Чайник электрический Maxima MК-103"><div class="box" page="chaynik-elektricheskiy-maxima-mk-760r"><span class="title">ребра в аэрогриле Чайник электрический Maxima MК-103</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/a6fb3c6ce325a3d2e51b29fc0035a27d.jpeg" alt="покупка пылесоса Чайник электрический Redmond RK-M107" title="покупка пылесоса Чайник электрический Redmond RK-M107"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1790r"><span class="title">покупка пылесоса Чайник электрический Redmond RK-M107</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li><img src="photos/c8d95936ceb77257c40da032828b68b2.jpeg" alt="как варить гречку в пароварке Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1" title="как варить гречку в пароварке Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1"><div class="box" page="batareyka-gp-batteries-super-alkaline-lf-abc-100r"><span class="title">как варить гречку в пароварке Батарейка GP Batteries Super alkaline 6LF22 1604A-BC1</span><p>от <span class="price">100</span> руб.</p></div></li>
						<li><img src="photos/a72d69a17b01ae0c39e3992b04fd72d5.jpeg" alt="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)" title="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-750r"><span class="title">panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)</span><p>от <span class="price">750</span> руб.</p></div></li>
						<li><img src="photos/96ed77acce770bf04afcf29723d61326.jpeg" alt="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas" title="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-2"><span class="title">мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r.php", 0, -4); if (file_exists("comments/personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r.php")) require_once "comments/personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>