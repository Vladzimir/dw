<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-binatone-mej-mat-metal-1500r.php","moulinex mk700130 мультиварка");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-binatone-mej-mat-metal-1500r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>moulinex mk700130 мультиварка Чайник электрический Binatone MEJ-1780 Mat Metal  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="moulinex mk700130 мультиварка, картофель микроволновая печь, продам мультиварку, мультиварка multihotter отзывы, насадки для мясорубки zelmer, кухня микроволновой печи, блендер philips hr 1617, ребра в аэрогриле, шампунь для пылесоса, блендер philips hr 2860, блюда с помощью блендера, мультиварка panasonic магазин, кубань 8 вафельница, микроволновые печи в москве,  работа аэрогриля">
		<meta name="description" content="moulinex mk700130 мультиварка Чайник электрический Binatone MEJ-1780 Mat Metal легко впишется в любой интерьер...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/16c51a83d3b90dc92106b51b933b769e.jpeg" title="moulinex mk700130 мультиварка Чайник электрический Binatone MEJ-1780 Mat Metal"><img src="photos/16c51a83d3b90dc92106b51b933b769e.jpeg" alt="moulinex mk700130 мультиварка Чайник электрический Binatone MEJ-1780 Mat Metal" title="moulinex mk700130 мультиварка Чайник электрический Binatone MEJ-1780 Mat Metal -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofemolka-vitesse-vs-1980r.php"><img src="photos/127a383548663b9c155664559c9c2000.jpeg" alt="картофель микроволновая печь Кофемолка Vitesse VS-272" title="картофель микроволновая печь Кофемолка Vitesse VS-272"></a><h2>Кофемолка Vitesse VS-272</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-530r.php"><img src="photos/35ee696c1c92edfebad75db4602c2861.jpeg" alt="продам мультиварку Миксер Atlanta ATH-283" title="продам мультиварку Миксер Atlanta ATH-283"></a><h2>Миксер Atlanta ATH-283</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-redmond-rstm-3990r.php"><img src="photos/5463e59bde9d8697c1104a5ca7198687.jpeg" alt="мультиварка multihotter отзывы Пароварка Redmond RST-M1101" title="мультиварка multihotter отзывы Пароварка Redmond RST-M1101"></a><h2>Пароварка Redmond RST-M1101</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>moulinex mk700130 мультиварка Чайник электрический Binatone MEJ-1780 Mat Metal</h1>
						<div class="tb"><p>Цена: от <span class="price">1500</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_6822.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический </b><b>Binatone </b><b>MEJ-1780 </b><b>Mat </b><b>Metal </b>легко впишется в любой интерьер, благодаря стильному дизайну. Кроме того, он сделает наш быт проще и приятнее. Мощность чайника составляет 2200 Вт, вместимость стандартная: 1,7 л, материал корпуса – матовая нержавеющая сталь. Модель снабжена закрытым нагревательным элементом, индикатором уровня воды, съемным фильтром для удобства чистки, продуманной подставкой с возможностью поворота на ней чайника на 360є и местом для хранения шнура. Предусмотрены функции автоотключения при закипании, отключения при снятии с подставки, блокировки включения без воды. Компания Binatone - один из ведущих мировых производителей мелкой и средней бытовой техники, представляющий широкий ассортимент различных товаров для дома и офиса. Продукция фирмы отличается высоким качеством, оригинальным дизайном и интересными цветовыми решениями.</p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 2200 Вт; <li>Вместимость: 1,7 л; <li>Корпус из матовой нержавеющей стали; <li>Возможность поворота на подставке на 360є; <li>Закрытый нагревательный элемент из нержавеющей стали; <li>Съемный фильтр для удобства чистки; <li>Защита от работы без воды; <li>Шкала уровня воды; <li>Откидная крышка с защелкой; <li>Автоотключение при закипании; <li>Подставка с местом для хранения шнура; <li>Световой индикатор работы; <li>Цвет: матовый металл; <li>Вес: 1,44 кг.</li></ul><p><b>Производитель: </b>Binatone.</p> moulinex mk700130 мультиварка</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7476c2912d4d9c99682e7b20dcc24385.jpeg" alt="насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192" title="насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192"><div class="box" page="elektroplita-indukcionnaya-atlanta-ath-1900r"><span class="title">насадки для мясорубки zelmer Электроплита индукционная Atlanta ATH-192</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li><img src="photos/d13e770b0f20ea7295762dcccfd88ddd.jpeg" alt="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда" title="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда"><div class="box" page="elektroplitka-indukcionnaya-maxima-mic-posuda-1790r"><span class="title">кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li><img src="photos/c4c3375bd5e900bb92cb2c5b9021e247.jpeg" alt="блендер philips hr 1617 Термопот  Redmond RTP-M801" title="блендер philips hr 1617 Термопот  Redmond RTP-M801"><div class="box" page="termopot-redmond-rtpm-3290r"><span class="title">блендер philips hr 1617 Термопот  Redmond RTP-M801</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li><img src="photos/1a5872ce4a924d71272e9d8aacab1a34.jpeg" alt="ребра в аэрогриле Чайник электрический Maxima MК-103" title="ребра в аэрогриле Чайник электрический Maxima MК-103"><div class="box" page="chaynik-elektricheskiy-maxima-mk-760r"><span class="title">ребра в аэрогриле Чайник электрический Maxima MК-103</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/52100c33edc3ca0743ca02e24c7f8dba.jpeg" alt="шампунь для пылесоса Электрический чайник Atlanta АТН-720" title="шампунь для пылесоса Электрический чайник Atlanta АТН-720"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-550r"><span class="title">шампунь для пылесоса Электрический чайник Atlanta АТН-720</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li class="large"><img src="photos/16e3783a13e306fc3fd90925cbbcc384.jpeg" alt="блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO" title="блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO"><div class="box" page="elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r"><span class="title">блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li class="large"><img src="photos/b8e20b7d51cc5f25b0392815fadedf6e.jpeg" alt="блюда с помощью блендера Турбощетка Redmond  RTB-4801" title="блюда с помощью блендера Турбощетка Redmond  RTB-4801"><div class="box" page="turboschetka-redmond-rtb-920r"><span class="title">блюда с помощью блендера Турбощетка Redmond  RTB-4801</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/787fcfe3b6052ac0b67b5602b473ad73.jpeg" alt="мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter" title="мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-t-aquafilter-18180r"><span class="title">мультиварка panasonic магазин Пылесос моющий Thomas Twin T2 Aquafilter</span><p>от <span class="price">18180</span> руб.</p></div></li>
						<li><img src="photos/4fbb8e89e08e4c6965da2c5a458072d3.jpeg" alt="кубань 8 вафельница Пылесос Vitek VT-1836 красный" title="кубань 8 вафельница Пылесос Vitek VT-1836 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3600r"><span class="title">кубань 8 вафельница Пылесос Vitek VT-1836 красный</span><p>от <span class="price">3600</span> руб.</p></div></li>
						<li><img src="photos/11c7c6ddf93edcdf0c5e620d5363815f.jpeg" alt="микроволновые печи в москве Пылесос Vitek VT-1844" title="микроволновые печи в москве Пылесос Vitek VT-1844"><div class="box" page="pylesos-vitek-vt-3250r"><span class="title">микроволновые печи в москве Пылесос Vitek VT-1844</span><p>от <span class="price">3250</span> руб.</p></div></li>
						<li><img src="photos/4c318bd3b290409dcd94808ff157a415.jpeg" alt="печенье через мясорубку рецепт Утюг паровой Tefal Ultimate Autoclean FV9450E2" title="печенье через мясорубку рецепт Утюг паровой Tefal Ultimate Autoclean FV9450E2"><div class="box" page="utyug-parovoy-tefal-ultimate-autoclean-fve-3950r"><span class="title">печенье через мясорубку рецепт Утюг паровой Tefal Ultimate Autoclean FV9450E2</span><p>от <span class="price">3950</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-binatone-mej-mat-metal-1500r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-binatone-mej-mat-metal-1500r.php")) require_once "comments/chaynik-elektricheskiy-binatone-mej-mat-metal-1500r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-binatone-mej-mat-metal-1500r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>