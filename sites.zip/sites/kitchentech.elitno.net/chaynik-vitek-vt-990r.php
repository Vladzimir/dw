<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-vitek-vt-990r.php","микроволновая печь hyundai");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-vitek-vt-990r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>микроволновая печь hyundai Чайник Vitek VT-1163  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="микроволновая печь hyundai, пароварка scarlett is 550, отважный тостер скачать, запчасти пылесос томас, мясорубка binatone, сравнить пароварки, слоеное тесто в аэрогриле, измельчитель сучьев, кофемашина rowenta, ребра в аэрогриле, аэрогриль hotter 1037, баклажаны в пароварке, как выбрать кофеварку, пылесос triathlon,  держатель для пылесоса">
		<meta name="description" content="микроволновая печь hyundai Чайник Vitek,  мощностью до 2200 Вт, позволит вскипятить воду (до 1,7 литра) в с...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/e766dc7a6c0cf1b164fee2cb011a81f8.jpeg" title="микроволновая печь hyundai Чайник Vitek VT-1163"><img src="photos/e766dc7a6c0cf1b164fee2cb011a81f8.jpeg" alt="микроволновая печь hyundai Чайник Vitek VT-1163" title="микроволновая печь hyundai Чайник Vitek VT-1163 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-870r.php"><img src="photos/08c15d1f7a465f949f829449dc3e88eb.jpeg" alt="пароварка scarlett is 550 Блендер Maxima MHB-0429" title="пароварка scarlett is 550 Блендер Maxima MHB-0429"></a><h2>Блендер Maxima MHB-0429</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-4150r.php"><img src="photos/09368438bc3c0f6d8d6445abd5f08674.jpeg" alt="отважный тостер скачать Микроволновая печь Vitek VT-1693" title="отважный тостер скачать Микроволновая печь Vitek VT-1693"></a><h2>Микроволновая печь Vitek VT-1693</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-s-grilem-moulinex-mw-parovarka-l-serebro-6110r.php"><img src="photos/a9b561236bfa7747af43043cb7d43b52.jpeg" alt="запчасти пылесос томас Микроволновая печь с грилем Moulinex MW531030 пароварка, 23 л, серебро" title="запчасти пылесос томас Микроволновая печь с грилем Moulinex MW531030 пароварка, 23 л, серебро"></a><h2>Микроволновая печь с грилем Moulinex MW531030 пароварка, 23 л, серебро</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>микроволновая печь hyundai Чайник Vitek VT-1163</h1>
						<div class="tb"><p>Цена: от <span class="price">990</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_21047.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Чайник Vitek,  мощностью до 2200 Вт, позволит вскипятить воду (до 1,7 литра) в считанные  минуты. Корпус выполнен из термостойкого пластика, нагревательный элемент  скрытый, что обеспечивает безопасность использования и исключение вероятности  ожога. Для удобства эксплуатации предусмотрена шкала уровня воды, световой  индикатор работы и поворачивающийся на 360 градусов корпус. Крышка открывается  одним нажатием кнопки.  В чайнике Vitek предусмотрено отдельное  место для хранения шнура. При закипании воды чайник автоматически отключается.</p><p><strong>Характеристики:</strong></p><ul><li>Мощность: 1850-2200Вт;</li><li>Максимальный объем: 1,7 л;</li><li>Корпус из термостойкого пластика;</li><li>Поворачивающийся на 360° корпус;</li><li>Открытие крышки нажатием на кнопку;</li><li>Скрытый нагревательный элемент;</li><li>Съемный фильтр;</li><li>Шкала уровня воды;</li><li>Световой индикатор работы;</li><li>Авто-отключение при  закипании воды;</li><li>Защита от включения без воды;</li><li>Место для хранения шнура;</li><li>Электропитание: 220-240 В, ~ 50 Гц.</li></ul><p><strong>Производитель:</strong><strong>Vitek (Россия)</strong></p> микроволновая печь hyundai</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/cf93342053e92b125e6f4adca7e47bbe.jpeg" alt="мясорубка binatone Пароварка Tefal Simply Invents VC1017" title="мясорубка binatone Пароварка Tefal Simply Invents VC1017"><div class="box"><a href="http://kitchentech.elitno.net/parovarka-tefal-simply-invents-vc-3990r.php"><h3 class="title">мясорубка binatone Пароварка Tefal Simply Invents VC1017</h3><p>от <span class="price">3990</span> руб.</p></a></div></li>
						<li><img src="photos/a5a944903050174bbca074a40d4e65fa.jpeg" alt="сравнить пароварки Соковыжималка Atlanta ATH-325" title="сравнить пароварки Соковыжималка Atlanta ATH-325"><div class="box" page="sokovyzhimalka-atlanta-ath-520r"><span class="title">сравнить пароварки Соковыжималка Atlanta ATH-325</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/f1de3ed8b30a0103d37ce7f82bba78f6.jpeg" alt="слоеное тесто в аэрогриле Тостер Russell Hobbs Mono, арт. 18535-56" title="слоеное тесто в аэрогриле Тостер Russell Hobbs Mono, арт. 18535-56"><div class="box" page="toster-russell-hobbs-mono-art-1690r"><span class="title">слоеное тесто в аэрогриле Тостер Russell Hobbs Mono, арт. 18535-56</span><p>от <span class="price">1690</span> руб.</p></div></li>
						<li><img src="photos/7b0ef0b12e5f66ec7582c9396725bc92.jpeg" alt="измельчитель сучьев Чайник электрический Vitek VT-1120" title="измельчитель сучьев Чайник электрический Vitek VT-1120"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1150r"><span class="title">измельчитель сучьев Чайник электрический Vitek VT-1120</span><p>от <span class="price">1150</span> руб.</p></div></li>
						<li class="large"><img src="photos/65ddf318df091ecf01e6a4b331f1492d.jpeg" alt="кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л" title="кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1950r"><span class="title">кофемашина rowenta Чайник электрический Tefal VitesseS BF663440 1,7 л</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li class="large"><img src="photos/1a5872ce4a924d71272e9d8aacab1a34.jpeg" alt="ребра в аэрогриле Чайник электрический Maxima MК-103" title="ребра в аэрогриле Чайник электрический Maxima MК-103"><div class="box" page="chaynik-elektricheskiy-maxima-mk-760r"><span class="title">ребра в аэрогриле Чайник электрический Maxima MК-103</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/e9322568d654cf02152dc451f13376f9.jpeg" alt="аэрогриль hotter 1037 Чайник электрический  Vitesse VS-113 1,5л красный" title="аэрогриль hotter 1037 Чайник электрический  Vitesse VS-113 1,5л красный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-krasnyy-1950r"><span class="title">аэрогриль hotter 1037 Чайник электрический  Vitesse VS-113 1,5л красный</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li><img src="photos/916a75c3d4cbc8ec64d3ba505b733ba5.jpeg" alt="баклажаны в пароварке Воздушный фильтр Redmond  HEPA-фильтр RV-312" title="баклажаны в пароварке Воздушный фильтр Redmond  HEPA-фильтр RV-312"><div class="box" page="vozdushnyy-filtr-redmond-hepafiltr-rv-390r"><span class="title">баклажаны в пароварке Воздушный фильтр Redmond  HEPA-фильтр RV-312</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/022434340143cfbbf0a87e93fd1fc9c0.jpeg" alt="как выбрать кофеварку Щетка для собак Dyson Groom Retail" title="как выбрать кофеварку Щетка для собак Dyson Groom Retail"><div class="box" page="schetka-dlya-sobak-dyson-groom-retail-1690r"><span class="title">как выбрать кофеварку Щетка для собак Dyson Groom Retail</span><p>от <span class="price">1690</span> руб.</p></div></li>
						<li><img src="photos/ec7faf951c2854afe4a3aed647e65436.jpeg" alt="пылесос triathlon Пылесос Dyson origin extra DC 37" title="пылесос triathlon Пылесос Dyson origin extra DC 37"><div class="box" page="pylesos-dyson-origin-extra-dc-22990r"><span class="title">пылесос triathlon Пылесос Dyson origin extra DC 37</span><p>от <span class="price">22990</span> руб.</p></div></li>
						<li><img src="photos/dcfd8cc55439cd877d074c0e060c75d4.jpeg" alt="качество пылесосов Пылесос Vitek VT-1809 красный" title="качество пылесосов Пылесос Vitek VT-1809 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2600r"><span class="title">качество пылесосов Пылесос Vitek VT-1809 красный</span><p>от <span class="price">2600</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-vitek-vt-990r.php", 0, -4); if (file_exists("comments/chaynik-vitek-vt-990r.php")) require_once "comments/chaynik-vitek-vt-990r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-vitek-vt-990r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>