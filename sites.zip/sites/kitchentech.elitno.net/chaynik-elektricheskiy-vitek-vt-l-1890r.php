<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-l-1890r.php","хлебопечка sd 2500");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-l-1890r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>хлебопечка sd 2500 Чайник электрический Vitek VT-1112 1,7 л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="хлебопечка sd 2500, тесто для мантов в хлебопечке, мультиварка паларис, мини пылесос божья коровка, что приготовить в мультиварке, смазочный утюг, хлебопечки панасоник инструкция, венчики для миксера, как использовать пароварку, кофеварки домашние, лучшие рецепты для мультиварки, блюда с помощью блендера, купить рецепты для мультиварки, аэрогриль lentel d101b,  соковыжималка juice">
		<meta name="description" content="хлебопечка sd 2500 Электрический чайник Vitek VT-1112 дополнит собой интерьер любой кухни, благодар...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/0fb0d4eda0d01d4692f2fbd689f6f46f.jpeg" title="хлебопечка sd 2500 Чайник электрический Vitek VT-1112 1,7 л"><img src="photos/0fb0d4eda0d01d4692f2fbd689f6f46f.jpeg" alt="хлебопечка sd 2500 Чайник электрический Vitek VT-1112 1,7 л" title="хлебопечка sd 2500 Чайник электрический Vitek VT-1112 1,7 л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-serebristaya-26999r.php"><img src="photos/26f6130b768cf990fa9fa11bd1f16cb3.jpeg" alt="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая" title="тесто для мантов в хлебопечке Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Solo&milk, серебристая</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-bistro-erp-serebristaya-36999r.php"><img src="photos/9fea21248e7566db156b2a08dbe43d4c.jpeg" alt="мультиварка паларис Автоматическая кофемашина Melitta Caffeo Bistro ERP, серебристая" title="мультиварка паларис Автоматическая кофемашина Melitta Caffeo Bistro ERP, серебристая"></a><h2>Автоматическая кофемашина Melitta Caffeo Bistro ERP, серебристая</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-tefal-le-hachoir-me-5880r.php"><img src="photos/a719c7f9b9161eaae5e6d50552aa1d04.jpeg" alt="мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011" title="мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011"></a><h2>Мясорубка электрическая Tefal Le Hachoir ME7011</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>хлебопечка sd 2500 Чайник электрический Vitek VT-1112 1,7 л</h1>
						<div class="tb"><p>Цена: от <span class="price">1890</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_11299.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Электрический чайник Vitek VT-1112 </b>дополнит собой интерьер любой кухни, благодаря стильному современному дизайну. Кроме того, он сделает ваш быт проще и комфортнее. Чайник выполнен в корпусе из прозрачного стекла и черного пластика, рассчитан на стандартный объем 1,7 л. Модель обладает мощностью 2200 Вт, имеет скрытый нагревательный элемент, оснащена фильтром, шкалой уровня воды, специальным отсеком для удобного хранения шнура. Прибор также снабжен индикатором включения и блокировкой работы без воды.</p><p><b>Характеристики:</b></p><ul type=\disc\><li>Мощность: 2200 Вт; </li><li>Объем: 1,7 л; </li><li>Тип нагревательного элемента: закрытая спираль (центральный контакт); </li><li>Материал корпуса: пластик/стекло; </li><li>Блокировка крышки, блокировка включения без воды; </li><li>Фильтр; </li><li>Индикатор уровня воды; </li><li>Индикация включения; </li><li>Отсек для шнура.</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна:</b> Россия.</p> хлебопечка sd 2500</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/bd86985191b900e717a6f18b17266152.jpeg" alt="что приготовить в мультиварке Пароварка Binatone FS-404 White Green" title="что приготовить в мультиварке Пароварка Binatone FS-404 White Green"><div class="box"><a href="http://kitchentech.elitno.net/parovarka-binatone-fs-white-green-1895r.php"><h3 class="title">что приготовить в мультиварке Пароварка Binatone FS-404 White Green</h3><p>от <span class="price">1895</span> руб.</p></a></div></li>
						<li><img src="photos/53d96832eb34bb57a7f20e415ffd59f8.jpeg" alt="смазочный утюг Тостер Russell Hobbs Cottage, арт. 18260-57" title="смазочный утюг Тостер Russell Hobbs Cottage, арт. 18260-57"><div class="box" page="toster-russell-hobbs-cottage-art-2690r"><span class="title">смазочный утюг Тостер Russell Hobbs Cottage, арт. 18260-57</span><p>от <span class="price">2690</span> руб.</p></div></li>
						<li><img src="photos/0a3cf9abc3fc820de574913fb2ebcdd1.jpeg" alt="хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка" title="хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка"><div class="box" page="vitesse-vs-hlebopechka-5200r"><span class="title">хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка</span><p>от <span class="price">5200</span> руб.</p></div></li>
						<li><img src="photos/8be60bf8ecb8c08e6df4d6b339b40b58.jpeg" alt="венчики для миксера Чайник электрический Atlanta ATH-759" title="венчики для миксера Чайник электрический Atlanta ATH-759"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-990r-2"><span class="title">венчики для миксера Чайник электрический Atlanta ATH-759</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/2604c204c493f1487a5255f83dc099af.jpeg" alt="как использовать пароварку Зарядное устройство GP Batteries PB350GS210-UE4" title="как использовать пароварку Зарядное устройство GP Batteries PB350GS210-UE4"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-1025r"><span class="title">как использовать пароварку Зарядное устройство GP Batteries PB350GS210-UE4</span><p>от <span class="price">1025</span> руб.</p></div></li>
						<li class="large"><img src="photos/f08bd4abc7ad4c0cc84da510e6f6c4d3.jpeg" alt="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт." title="кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт."><div class="box" page="filtr-dlya-pylesosa-vitek-vt-vt-sht-215r"><span class="title">кофеварки домашние Фильтр для пылесоса Vitek VT-1858 (VT-1847) 1 шт.</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li class="large"><img src="photos/bf71bbc1609948054c42cfa52f5f228d.jpeg" alt="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas" title="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r"><span class="title">лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/b8e20b7d51cc5f25b0392815fadedf6e.jpeg" alt="блюда с помощью блендера Турбощетка Redmond  RTB-4801" title="блюда с помощью блендера Турбощетка Redmond  RTB-4801"><div class="box" page="turboschetka-redmond-rtb-920r"><span class="title">блюда с помощью блендера Турбощетка Redmond  RTB-4801</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li><img src="photos/c4ed1ed9a910d5dd5d3b4d4cba707112.jpeg" alt="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP" title="купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP"><div class="box" page="nasadka-dlya-matrasov-v-upakovke-dyson-mattress-tool-assy-retail-np-1090r"><span class="title">купить рецепты для мультиварки Насадка для матрасов в упаковке Dyson Mattress Tool Assy Retail NP</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
						<li><img src="photos/a5307e77bbd77d05fd1bf891a3eeb5d0.jpeg" alt="хлебопечки в новосибирске Пылесос Vitek VT-1845 красный" title="хлебопечки в новосибирске Пылесос Vitek VT-1845 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-4590r"><span class="title">хлебопечки в новосибирске Пылесос Vitek VT-1845 красный</span><p>от <span class="price">4590</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-l-1890r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-l-1890r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-l-1890r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-l-1890r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>