<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r.php","мультиварка филипс");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мультиварка филипс Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мультиварка филипс, мультиварки киев, джем в хлебопечке рецепт, что можно делать блендером, что приготовить в мультиварке, капсульные кофемашины bosch, хлебопечка мулинекс 3101, пылесос для сухой чистки, хлебопечка германия, измерение электромагнитного излучения, семга в мультиварке, лучшие рецепты для мультиварки, кофемашина philips hd 8745, фильтры для моющего пылесоса,  слоеное тесто в аэрогриле">
		<meta name="description" content="мультиварка филипс В комплект входит зарядное устройство и два NiMH аккумулятора типа АА. Время зар...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/56eef2b8f5929fc5948323a8a5a2e051.jpeg" title="мультиварка филипс Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)"><img src="photos/56eef2b8f5929fc5948323a8a5a2e051.jpeg" alt="мультиварка филипс Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)" title="мультиварка филипс Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH) -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-ci-black-76390r.php"><img src="photos/4c9f6fc7185095b9ee0e389df903b9c9.jpeg" alt="мультиварки киев Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)" title="мультиварки киев Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)"></a><h2>Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-wb-630r.php"><img src="photos/8dac9aeadde6a6d95b71abb890265199.jpeg" alt="джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB" title="джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB"></a><h2>Миксер Atlanta ATH-263 WB</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-binatone-mgr-white-3700r.php"><img src="photos/060f95312423ba3e968eaf23618bd36d.jpeg" alt="что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White" title="что можно делать блендером Мясорубка электрическая Binatone MGR-3040 White"></a><h2>Мясорубка электрическая Binatone MGR-3040 White</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мультиварка филипс Зарядное устройство GP Batteries PB25-BС2 + (2х270AAH)</h1>
						<div class="tb"><p>Цена: от <span class="price">1220</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16538.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>В комплект входит зарядное устройство и два NiMH аккумулятора типа АА. Время зарядки составляет всего 5 часов. На устройстве расположено два слота для элементов питания класса АА и ААА, а также световой индикатор. Оптимальное сочетание цены и качества.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: Аккумулятор + зарядное устройство <li>Тип аккумулятора: NiMH <li>Емкость: 1000 мAч <li>Напряжение: 1,2 В <li>Количество в комплекте: 2 <li>Тип заряжаемых аккумуляторов: NiMH <li>Заряжает AA: Да <li>Заряжает AAA: Да <li>Время заряда: 5 ч <li>Количество слотов: 2 <li>Количество каналов: 2 <li>Размеры (ШхГхВ): 4,8х10,7х3,6 см </li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p><p><b>Гарантия: </b>6 месяцев.</p> мультиварка филипс</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/bd86985191b900e717a6f18b17266152.jpeg" alt="что приготовить в мультиварке Пароварка Binatone FS-404 White Green" title="что приготовить в мультиварке Пароварка Binatone FS-404 White Green"><div class="box"><a href="http://kitchentech.elitno.net/parovarka-binatone-fs-white-green-1895r.php"><h3 class="title">что приготовить в мультиварке Пароварка Binatone FS-404 White Green</h3><p>от <span class="price">1895</span> руб.</p></a></div></li>
						<li><img src="photos/151cdbb0e55d78748fdd51a7bbe40bf0.jpeg" alt="капсульные кофемашины bosch Соковыжималка Atlanta ATH-329" title="капсульные кофемашины bosch Соковыжималка Atlanta ATH-329"><div class="box" page="sokovyzhimalka-atlanta-ath-2990r"><span class="title">капсульные кофемашины bosch Соковыжималка Atlanta ATH-329</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/7903c21b4883d9e9c99d0a478392fee7.jpeg" alt="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906" title="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906"><div class="box" page="sokovyzhimalka-redmond-rjm-4990r"><span class="title">хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/92677a851872ec83258943db2c5f8e10.jpeg" alt="пылесос для сухой чистки Чайник электрический Tefal Reminisce KI2016 1,7 л" title="пылесос для сухой чистки Чайник электрический Tefal Reminisce KI2016 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2"><span class="title">пылесос для сухой чистки Чайник электрический Tefal Reminisce KI2016 1,7 л</span><p>от <span class="price">2370</span> руб.</p></div></li>
						<li class="large"><img src="photos/b3fae48615963478f00e0c05f3baa485.jpeg" alt="хлебопечка германия Электрический чайник  Zauber R-380" title="хлебопечка германия Электрический чайник  Zauber R-380"><div class="box" page="elektricheskiy-chaynik-zauber-r-1830r"><span class="title">хлебопечка германия Электрический чайник  Zauber R-380</span><p>от <span class="price">1830</span> руб.</p></div></li>
						<li class="large"><img src="photos/663e4c317fe5187d7f962aa4403e4d2c.jpeg" alt="измерение электромагнитного излучения Электрический чайник Zauber Z-370" title="измерение электромагнитного излучения Электрический чайник Zauber Z-370"><div class="box" page="elektricheskiy-chaynik-zauber-z-1900r"><span class="title">измерение электромагнитного излучения Электрический чайник Zauber Z-370</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/eae88ed8d5eeac95cd1245092b541388.jpeg" alt="семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas" title="семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-3"><span class="title">семга в мультиварке Бумажные фильтры-мешки 350 (787-104) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/bf71bbc1609948054c42cfa52f5f228d.jpeg" alt="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas" title="лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas"><div class="box" page="nabor-meshkovpylesbornikov-dlya-thomas-1100r"><span class="title">лучшие рецепты для мультиварки Набор мешков-пылесборников 50 (790-012) для Thomas</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/daa26c20552b4c54039ad44aa7ab957b.jpeg" alt="кофемашина philips hd 8745 Пылесос Thomas Inox 1530" title="кофемашина philips hd 8745 Пылесос Thomas Inox 1530"><div class="box" page="pylesos-thomas-inox-6310r"><span class="title">кофемашина philips hd 8745 Пылесос Thomas Inox 1530</span><p>от <span class="price">6310</span> руб.</p></div></li>
						<li><img src="photos/a24b7e04e12ea5cc75354fc2b5ebd18d.jpeg" alt="фильтры для моющего пылесоса Пылесос Vitek VT-1809 черный" title="фильтры для моющего пылесоса Пылесос Vitek VT-1809 черный"><div class="box" page="pylesos-vitek-vt-chernyy-2600r"><span class="title">фильтры для моющего пылесоса Пылесос Vitek VT-1809 черный</span><p>от <span class="price">2600</span> руб.</p></div></li>
						<li><img src="photos/2fefc92a511ec2a4cec4d67efd9d8253.jpeg" alt="аэрогриль vitesse vs 408 Пылесос Thomas Genius S1 Eco Aquafilter" title="аэрогриль vitesse vs 408 Пылесос Thomas Genius S1 Eco Aquafilter"><div class="box" page="pylesos-thomas-genius-s-eco-aquafilter-9660r"><span class="title">аэрогриль vitesse vs 408 Пылесос Thomas Genius S1 Eco Aquafilter</span><p>от <span class="price">9660</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r.php", 0, -4); if (file_exists("comments/zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r.php")) require_once "comments/zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="zaryadnoe-ustroystvo-gp-batteries-pbbs-haah-1220r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>