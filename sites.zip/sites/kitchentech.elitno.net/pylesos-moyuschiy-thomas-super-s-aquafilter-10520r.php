<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-moyuschiy-thomas-super-s-aquafilter-10520r.php","кофеварка philips hd8325");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-moyuschiy-thomas-super-s-aquafilter-10520r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кофеварка philips hd8325 Пылесос моющий Thomas Super 30 S Aquafilter  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кофеварка philips hd8325, кофемашина saeco инструкция, кофемолка moulinex, хлебопечка redmond rbm 1902, эльдорадо кофемашины, куриные грудки в мультиварке, ремонт мясорубок мулинекс, купить вертикальный утюг, бумажные мешки для пылесоса, микроволновая печь бош, мультиварка купить в минске, хлебопечка кефир, пылесос филипс 9174, аэрогриль lentel d101b,  чайник или термопот">
		<meta name="description" content="кофеварка philips hd8325 Моющий пылесос Thomas обеспечит не только превосходную сухую уборку, но и удалит...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/20a6a481b9a3a072fa1293146dcb1ec9.jpeg" title="кофеварка philips hd8325 Пылесос моющий Thomas Super 30 S Aquafilter"><img src="photos/20a6a481b9a3a072fa1293146dcb1ec9.jpeg" alt="кофеварка philips hd8325 Пылесос моющий Thomas Super 30 S Aquafilter" title="кофеварка philips hd8325 Пылесос моющий Thomas Super 30 S Aquafilter -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-blender-v-russell-hobbs-allure-art-3490r.php"><img src="photos/8eb90b2c93f90da38a9a78776cb9380e.jpeg" alt="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56" title="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56"></a><h2>Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-3290r.php"><img src="photos/77a7b9eee8f1b767f7912a55eb9e902b.jpeg" alt="кофемолка moulinex Блендер Redmond RHB-2904" title="кофемолка moulinex Блендер Redmond RHB-2904"></a><h2>Блендер Redmond RHB-2904</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-ath-730r.php"><img src="photos/d8bd47322f35143f577f4b450e121a71.jpeg" alt="хлебопечка redmond rbm 1902 Кухонный комбайн  ATH-353" title="хлебопечка redmond rbm 1902 Кухонный комбайн  ATH-353"></a><h2>Кухонный комбайн  ATH-353</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кофеварка philips hd8325 Пылесос моющий Thomas Super 30 S Aquafilter</h1>
						<div class="tb"><p>Цена: от <span class="price">10520</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14655.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий пылесос Thomas обеспечит не только превосходную сухую уборку, но и удалит даже сильно въевшиеся загрязнения с ковров или мягкой мебели. Также прибор отлично вымоет линолеум и кафельную плитку. В процессе сухой уборки пыль скапливается в бумажном мешке вместимостью 30 л, что позволит Вам не часто производить замену пылесборника. Потрясающее качество влажной уборки с пылесосом обеспечивается за счет особой системы фильтрации, в основе которой лежит циклонный водяной фильтр. Функция распыления и всасывания жидкости позволит легко справиться с любыми загрязнениями. Модель обладает мощностью 1400 Вт.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: обычный; </li><li>Уборка: сухая/влажная; </li><li>Потребляемая мощность: 1400 Вт; </li><li>Мощность всасывания: 200 Вт; </li><li>Пылесборник аквафильтр, емкостью 2 л; </li><li>Объем воды: 13 л; </li><li>Объем резервуара для сухой и влажной уборки: 30 л; </li><li>Управление: механическое; </li><li>Эргономичная ручка; </li><li>Фиксатор кабеля; </li><li>Автосматывание сетевого шнура; </li><li>Вертикальная парковка трубы всасывания на корпусе пылесоса; </li><li>Циклонный водяной фильтр; </li><li>Специальный нагнетательный насос с давлением - 4 бар; </li><li>Размеры (ШхВхГ): 61x38,5x38,5 см; </li><li>Вес: 10,3 кг; </li><li>Цвет синий.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> кофеварка philips hd8325</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5e475c33aea662be8e01a1f2443fb6c0.jpeg" alt="эльдорадо кофемашины Микроволновая печь Vitek VT-1684" title="эльдорадо кофемашины Микроволновая печь Vitek VT-1684"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3870r"><span class="title">эльдорадо кофемашины Микроволновая печь Vitek VT-1684</span><p>от <span class="price">3870</span> руб.</p></div></li>
						<li><img src="photos/47aa32b114cfa34725d4752f07527890.jpeg" alt="куриные грудки в мультиварке Мультиварка Redmond RMC-M4502" title="куриные грудки в мультиварке Мультиварка Redmond RMC-M4502"><div class="box" page="multivarka-redmond-rmcm-4990r"><span class="title">куриные грудки в мультиварке Мультиварка Redmond RMC-M4502</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/dc407a1e2a485cfa91965baf93f3d5ba.jpeg" alt="ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051" title="ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051"><div class="box" page="myasorubka-elektricheskaya-moulinex-me-3820r"><span class="title">ремонт мясорубок мулинекс Мясорубка электрическая Moulinex ME6051</span><p>от <span class="price">3820</span> руб.</p></div></li>
						<li><img src="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" alt="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56" title="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56"><div class="box" page="toster-russell-hobbs-jungle-green-art-1890r"><span class="title">купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li class="large"><img src="photos/977fa3b86531dce2d95f99f061a78e23.jpeg" alt="бумажные мешки для пылесоса Чайник электрический  Vitesse VS-133 1,7л" title="бумажные мешки для пылесоса Чайник электрический  Vitesse VS-133 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1550r"><span class="title">бумажные мешки для пылесоса Чайник электрический  Vitesse VS-133 1,7л</span><p>от <span class="price">1550</span> руб.</p></div></li>
						<li class="large"><img src="photos/66926416069d8d65cb760c1b8131e267.jpeg" alt="микроволновая печь бош Электрический чайник Atlanta АТН-785" title="микроволновая печь бош Электрический чайник Atlanta АТН-785"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1420r"><span class="title">микроволновая печь бош Электрический чайник Atlanta АТН-785</span><p>от <span class="price">1420</span> руб.</p></div></li>
						<li class="large"><img src="photos/5ad08e9c72a81deadb5d71650c46c50a.jpeg" alt="мультиварка купить в минске Парогенератор Maxima MSC-2001 фиолетовый" title="мультиварка купить в минске Парогенератор Maxima MSC-2001 фиолетовый"><div class="box" page="parogenerator-maxima-msc-fioletovyy-1650r"><span class="title">мультиварка купить в минске Парогенератор Maxima MSC-2001 фиолетовый</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/54b10604c01ad075cc189094150a1393.jpeg" alt="хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP" title="хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP"><div class="box" page="schetka-s-myagkoy-schetinoy-v-upakovke-dyson-soft-dusting-brush-assy-retail-np-1390r"><span class="title">хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP</span><p>от <span class="price">1390</span> руб.</p></div></li>
						<li><img src="photos/292e6011285b984f12ba49506a158a8f.jpeg" alt="пылесос филипс 9174 Пылесос Redmond RV-309" title="пылесос филипс 9174 Пылесос Redmond RV-309"><div class="box" page="pylesos-redmond-rv-5490r"><span class="title">пылесос филипс 9174 Пылесос Redmond RV-309</span><p>от <span class="price">5490</span> руб.</p></div></li>
						<li><img src="photos/265e30ba27b80acc7dc11e5947b9e36a.jpeg" alt="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный" title="аэрогриль lentel d101b Пылесос Vitek VT-1813 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2450r"><span class="title">аэрогриль lentel d101b Пылесос Vitek VT-1813 красный</span><p>от <span class="price">2450</span> руб.</p></div></li>
						<li><img src="photos/28ebbb0322a7eac61313d0d41391d394.jpeg" alt="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий" title="пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-siniy-6900r"><span class="title">пылесос компрессор отзывы Пылесос с аквафильтром Vitek VT-1832 синий</span><p>от <span class="price">6900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-moyuschiy-thomas-super-s-aquafilter-10520r.php", 0, -4); if (file_exists("comments/pylesos-moyuschiy-thomas-super-s-aquafilter-10520r.php")) require_once "comments/pylesos-moyuschiy-thomas-super-s-aquafilter-10520r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-moyuschiy-thomas-super-s-aquafilter-10520r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>