<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-chernyy-2150r.php","соковыжималка hr 1861");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-chernyy-2150r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>соковыжималка hr 1861 Чайник электрический Vitek VT-1101 черный  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="соковыжималка hr 1861, bierhof кухонный комбайн, микроволновая печь польза, маленькие мультиварки, пылесосы с аквафильтром soteco, хлебопечки панасоник инструкция, как разобрать утюг, кофемашина bosch 5201, слоеное тесто в аэрогриле, сколько стоит фритюрница, измельчитель kenwood, утюг для волос профессиональный, mini пылесос, kress пылесос,  работа аэрогриля">
		<meta name="description" content="соковыжималка hr 1861 Чайник электрический Vitek VT-1101 из высококачественного термостойкого стекла “...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/f12c67c091dc7674e75925e27c6ee910.jpeg" title="соковыжималка hr 1861 Чайник электрический Vitek VT-1101 черный"><img src="photos/f12c67c091dc7674e75925e27c6ee910.jpeg" alt="соковыжималка hr 1861 Чайник электрический Vitek VT-1101 черный" title="соковыжималка hr 1861 Чайник электрический Vitek VT-1101 черный -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-73690r.php"><img src="photos/502f3c027327d4b33adc28c2b2f5d085.jpeg" alt="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica" title="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica"></a><h2>Кофемашина Nivona NICR850 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-krasnaya-29530r.php"><img src="photos/39e04c91cf56d7c949379d4f2e2d6076.jpeg" alt="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная" title="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, красная</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-4990r.php"><img src="photos/ab8e324f37683fb482e2239bd528b88e.jpeg" alt="маленькие мультиварки Мясорубка Redmond RMG-1203" title="маленькие мультиварки Мясорубка Redmond RMG-1203"></a><h2>Мясорубка Redmond RMG-1203</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>соковыжималка hr 1861 Чайник электрический Vitek VT-1101 черный</h1>
						<div class="tb"><p>Цена: от <span class="price">2150</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8349.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Чайник электрический V</b><b>itek</b><b> VT-1101</b> из высококачественного термостойкого стекла “Schott” прекрасно впишется в интерьер любой кухни. Среди достоинств модели можно отметить: съемный фильтр от накипи, автоотключение при закипании воды, защиту от перегрева и блокировку включения при отсутствии жидкости в резервуаре. Устройство стоит на дисковой подставке и может поворачиваться на 360°.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 2000Вт (максимальная) </li><li>Нагревательный элемент: скрытый </li><li>Поворачивающийся корпус: 360° </li><li>Объем: 1,7л </li><li>Материал корпуса: высококачественное термостойкое стекло “Schott” </li><li>Фильтр: съемный фильтр от накипи </li><li>Индикатор уровня воды: легко определяемый уровень воды через прозрачную колбу </li><li>Автоотключение при закипании воды: есть </li><li>Защита от перегрева и блокировка включения при отсутствии воды </li><li>Место для хранения шнура: есть </li><li>Удобная откидывающаяся крышка</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> соковыжималка hr 1861</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/03d6a39216ccd97c8a662a35f965b076.jpeg" alt="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611" title="пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611"><div class="box" page="sokovyzhimalka-vitek-vt-600r"><span class="title">пылесосы с аквафильтром soteco Соковыжималка VITEK VT-1611</span><p>от <span class="price">600</span> руб.</p></div></li>
						<li><img src="photos/0a3cf9abc3fc820de574913fb2ebcdd1.jpeg" alt="хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка" title="хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка"><div class="box" page="vitesse-vs-hlebopechka-5200r"><span class="title">хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка</span><p>от <span class="price">5200</span> руб.</p></div></li>
						<li><img src="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" alt="как разобрать утюг Чайник электрический Maxima MК- M211" title="как разобрать утюг Чайник электрический Maxima MК- M211"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-1090r"><span class="title">как разобрать утюг Чайник электрический Maxima MК- M211</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/ad9a939cae5c8a1c68f17220dbb422a8.jpeg" alt="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый" title="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belyy-1080r"><span class="title">кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li class="large"><img src="photos/b28d3e929be020189d8c25424817be16.jpeg" alt="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO" title="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2270r"><span class="title">слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li class="large"><img src="photos/49901359ef2b43e118be22a24f1caa05.jpeg" alt="сколько стоит фритюрница Minamoto R6 (AA)" title="сколько стоит фритюрница Minamoto R6 (AA)"><div class="box" page="minamoto-r-aa-3r"><span class="title">сколько стоит фритюрница Minamoto R6 (AA)</span><p>от <span class="price">3</span> руб.</p></div></li>
						<li class="large"><img src="photos/d221c08cbc7532258ec107ff315e3516.jpeg" alt="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)" title="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)"><div class="box" page="personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r"><span class="title">измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)</span><p>от <span class="price">20500</span> руб.</p></div></li>
						<li><img src="photos/ae6aa53dcc9eb32133541922b9ec3b16.jpeg" alt="утюг для волос профессиональный Мини весы Tanita 1579" title="утюг для волос профессиональный Мини весы Tanita 1579"><div class="box" page="mini-vesy-tanita-3900r"><span class="title">утюг для волос профессиональный Мини весы Tanita 1579</span><p>от <span class="price">3900</span> руб.</p></div></li>
						<li><img src="photos/28da988d46134dfe1236e7598e0579cc.jpeg" alt="mini пылесос Турбощетка Redmond  RV-308" title="mini пылесос Турбощетка Redmond  RV-308"><div class="box" page="turboschetka-redmond-rv-390r"><span class="title">mini пылесос Турбощетка Redmond  RV-308</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/cfc3673046a371ff9baffb342aa8e52b.jpeg" alt="kress пылесос Пылесос моющий Thomas Twin Aquafilter" title="kress пылесос Пылесос моющий Thomas Twin Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquafilter-11550r"><span class="title">kress пылесос Пылесос моющий Thomas Twin Aquafilter</span><p>от <span class="price">11550</span> руб.</p></div></li>
						<li><img src="photos/ee03f1721014fcaa8f40d146634cc194.jpeg" alt="мясорубка с овощерезкой Утюг Vitek VT-1210" title="мясорубка с овощерезкой Утюг Vitek VT-1210"><div class="box" page="utyug-vitek-vt-850r"><span class="title">мясорубка с овощерезкой Утюг Vitek VT-1210</span><p>от <span class="price">850</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-chernyy-2150r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-chernyy-2150r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-chernyy-2150r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-chernyy-2150r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>