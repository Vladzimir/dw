<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("kofemolka-maxima-mcg-550r.php","аэрогриль hotter tiger");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("kofemolka-maxima-mcg-550r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>аэрогриль hotter tiger Кофемолка Maxima MCG-1602  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="аэрогриль hotter tiger, пылесос thomas genius s2, bierhof кухонный комбайн, аэрогриль воронеж, magic pot мультиварка, самый дорогой пылесос, пакеты для пылесоса, мультиварка redmond 4504, электрические чайники скарлет, устройство блендера, продажа мультиварок, как выбрать кофеварку, мясорубка kenwood mg510, микроволновые печи в москве,  кофемашины verobar">
		<meta name="description" content="аэрогриль hotter tiger Кофемолка Maxima,  мощностью 100 Вт, позволит перемолоть до 300 мл зернового коф...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/ccf51377f0419f271513b485782fac2b.jpeg" title="аэрогриль hotter tiger Кофемолка Maxima MCG-1602"><img src="photos/ccf51377f0419f271513b485782fac2b.jpeg" alt="аэрогриль hotter tiger Кофемолка Maxima MCG-1602" title="аэрогриль hotter tiger Кофемолка Maxima MCG-1602 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2180r.php"><img src="photos/a1f8cd769afd06226b32e6fb44474c86.jpeg" alt="пылесос thomas genius s2 Блендер Redmond RHB-2908" title="пылесос thomas genius s2 Блендер Redmond RHB-2908"></a><h2>Блендер Redmond RHB-2908</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-73690r.php"><img src="photos/502f3c027327d4b33adc28c2b2f5d085.jpeg" alt="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica" title="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica"></a><h2>Кофемашина Nivona NICR850 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/zauber-kofemolka-x-1250r.php"><img src="photos/13e215c432e654a40129e4a1cdc305f1.jpeg" alt="аэрогриль воронеж Zauber Кофемолка  X-480" title="аэрогриль воронеж Zauber Кофемолка  X-480"></a><h2>Zauber Кофемолка  X-480</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>аэрогриль hotter tiger Кофемолка Maxima MCG-1602</h1>
						<div class="tb"><p>Цена: от <span class="price">550</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20627.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Кофемолка Maxima,  мощностью 100 Вт, позволит перемолоть до 300 мл зернового кофе. Для помола  используется ротационный нож. Лезвие и чаша выполнены из нержавеющей стали, что  обеспечивает долговечность устройства. В конструкции предусмотрен дозатор.  Безопасность эксплуатации обеспечивает функция автоматической блокировки  включения при снятой крышке.</p><p><strong>Характеристики:</strong></p><ul><li>Цвет: черный / белый;<br></li><li>Система помола: ротационный нож;</li><li>Мощность: 100 Вт;</li><li>Вместимость: 300 г;</li><li>Импульсный режим;</li><li>Конструкция: дозатор;</li><li>Блокировка включения при снятой крышке;</li><li>Размеры: 10.5х17.2х10.5;</li><li>Вес: 0.208 кг;</li><li>Цвета: черный, белый.</li></ul><p><strong>Производитель: </strong><strong>Maxima (Китай)</strong><br><strong>Изготовитель: Китай</strong><br><strong>Гарантия: 12 месяцев</strong></p> аэрогриль hotter tiger</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/be6b78c2525e9286d015556c4db7013b.jpeg" alt="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO" title="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO"><div class="box"><a href="http://kitchentech.elitno.net/elektricheskiy-mikser-krasnyy-bodum-bistro-euro-2740r.php"><h3 class="title">magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO</h3><p>от <span class="price">2740</span> руб.</p></a></div></li>
						<li><img src="photos/8b7adfef9e224f5e6ff3fcdd084f6869.jpeg" alt="самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook" title="самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook"><div class="box" page="multivarka-moulinex-ce-minute-cook-5850r"><span class="title">самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook</span><p>от <span class="price">5850</span> руб.</p></div></li>
						<li><img src="photos/2cdb40f493d1b8360833641d1048d5de.jpeg" alt="пакеты для пылесоса Мясорубка Braun G1300 MN WH" title="пакеты для пылесоса Мясорубка Braun G1300 MN WH"><div class="box" page="myasorubka-braun-g-mn-wh-4980r"><span class="title">пакеты для пылесоса Мясорубка Braun G1300 MN WH</span><p>от <span class="price">4980</span> руб.</p></div></li>
						<li><img src="photos/696c3eff6d4752e21e651f3d4b34c0a7.jpeg" alt="мультиварка redmond 4504 Мясорубка Redmond RMG-1204" title="мультиварка redmond 4504 Мясорубка Redmond RMG-1204"><div class="box" page="myasorubka-redmond-rmg-3290r"><span class="title">мультиварка redmond 4504 Мясорубка Redmond RMG-1204</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li class="large"><img src="photos/c48020be535a5770584db54e47af400d.jpeg" alt="электрические чайники скарлет Чайник электрический Vitek VT-1115 желтый" title="электрические чайники скарлет Чайник электрический Vitek VT-1115 желтый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-zheltyy-1090r"><span class="title">электрические чайники скарлет Чайник электрический Vitek VT-1115 желтый</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li class="large"><img src="photos/0c8f8180d11bb1b314126b1e547c3319.jpeg" alt="устройство блендера Чайник электрический  Vitesse VS-131 1,7 л" title="устройство блендера Чайник электрический  Vitesse VS-131 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1220r"><span class="title">устройство блендера Чайник электрический  Vitesse VS-131 1,7 л</span><p>от <span class="price">1220</span> руб.</p></div></li>
						<li class="large"><img src="photos/08f854ed7155a317d7f9ee53182183f6.jpeg" alt="продажа мультиварок Парогенератор Lelit PS21" title="продажа мультиварок Парогенератор Lelit PS21"><div class="box" page="parogenerator-lelit-ps-12650r-2"><span class="title">продажа мультиварок Парогенератор Lelit PS21</span><p>от <span class="price">12650</span> руб.</p></div></li>
						<li><img src="photos/022434340143cfbbf0a87e93fd1fc9c0.jpeg" alt="как выбрать кофеварку Щетка для собак Dyson Groom Retail" title="как выбрать кофеварку Щетка для собак Dyson Groom Retail"><div class="box" page="schetka-dlya-sobak-dyson-groom-retail-1690r"><span class="title">как выбрать кофеварку Щетка для собак Dyson Groom Retail</span><p>от <span class="price">1690</span> руб.</p></div></li>
						<li><img src="photos/ebd6fc853a788b316468033f41ae3864.jpeg" alt="мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22" title="мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22"><div class="box" page="pylesos-dyson-motorhead-dc-34990r"><span class="title">мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22</span><p>от <span class="price">34990</span> руб.</p></div></li>
						<li><img src="photos/11c7c6ddf93edcdf0c5e620d5363815f.jpeg" alt="микроволновые печи в москве Пылесос Vitek VT-1844" title="микроволновые печи в москве Пылесос Vitek VT-1844"><div class="box" page="pylesos-vitek-vt-3250r"><span class="title">микроволновые печи в москве Пылесос Vitek VT-1844</span><p>от <span class="price">3250</span> руб.</p></div></li>
						<li><img src="photos/64dc96f26f782ba3e39f0fd329fa03d0.jpeg" alt="видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C" title="видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C"><div class="box" page="pylesos-thomas-power-pack-c-4740r"><span class="title">видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C</span><p>от <span class="price">4740</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("kofemolka-maxima-mcg-550r.php", 0, -4); if (file_exists("comments/kofemolka-maxima-mcg-550r.php")) require_once "comments/kofemolka-maxima-mcg-550r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="kofemolka-maxima-mcg-550r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>