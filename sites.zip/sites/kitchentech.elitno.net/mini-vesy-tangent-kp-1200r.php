<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("mini-vesy-tangent-kp-1200r.php","микроволновая печь scarlett");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("mini-vesy-tangent-kp-1200r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>микроволновая печь scarlett Мини весы Tangent KP-103  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="микроволновая печь scarlett, приготовление теста в хлебопечке, грудка в пароварке, кофемолка bosch, выпечка в хлебопечке мулинекс, рецепты для мультиварки viconte, делонги кофемашина примадонна, пылесос автомобильный купить, батон в хлебопечке, рейтинг пылесосов 2011, кофеварка ровента инструкция, солянка в мультиварке, мини соковыжималка, микроволновая печь bork,  мясорубка для столовой">
		<meta name="description" content="микроволновая печь scarlett Небольшие размеры весов скрывают под собой многофункциональное устройство для вз...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/ab56fe42ec3af82144d9f5eb1f80eb4c.jpeg" title="микроволновая печь scarlett Мини весы Tangent KP-103"><img src="photos/ab56fe42ec3af82144d9f5eb1f80eb4c.jpeg" alt="микроволновая печь scarlett Мини весы Tangent KP-103" title="микроволновая печь scarlett Мини весы Tangent KP-103 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-ci-chernaya-65999r.php"><img src="photos/46d0cfd29014c8ec4bfb9c09c292bb23.jpeg" alt="приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная" title="приготовление теста в хлебопечке Автоматическая кофемашина Melitta CAFFEO CI, черная"></a><h2>Автоматическая кофемашина Melitta CAFFEO CI, черная</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemolka-ath-600r.php"><img src="photos/0e305c07a6dd83a006dadb83e537663e.jpeg" alt="грудка в пароварке Кофемолка  ATH-272" title="грудка в пароварке Кофемолка  ATH-272"></a><h2>Кофемолка  ATH-272</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-s-konvekciey-moulinex-mw-hlebopechka-l-serebro-12050r.php"><img src="photos/5ac0b374c54627e297ebdd1a47a1cc62.jpeg" alt="кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро" title="кофемолка bosch Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро"></a><h2>Микроволновая печь с конвекцией Moulinex MW700131 хлебопечка, 28 л, серебро</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>микроволновая печь scarlett Мини весы Tangent KP-103</h1>
						<div class="tb"><p>Цена: от <span class="price">1200</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_210.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Небольшие размеры весов скрывают под собой многофункциональное устройство для взвешивания в первую очередь продуктов. Среди доступных опций <strong>мини весов Tangent KP-103</strong> - расчет хлебных единиц, углеводов, доз инсулина и лекарственных средств для диабетика. Эти функции необходимы, дабы обезопасить пользователя от возможной передозировки сильнодействующих веществ в порошкообразной форме. ЖК-дипслей, функция вычета тары, а также режим калибровки выступают дополнительными преимуществами <strong>модели Tangent KP-103.</strong></p><p><strong>Особенности: </strong></p><ul type=disc><li>Контрастный ЖК-дисплей <li>Функция автоотключения (через 10 мин) <li>Функция тарирования (вычет тары) <li>Режим калибровки <li>Единицы измерения: граммы, oz, ozt, dwt <li>Индикация перегрузки <li>Индикация разряда батареи <li>Верхняя крышка предохраняет механизм весов </li></ul><p><b>Технические характеристики:</b></p><ul type=disc><li>Размер платформы: 75 х 55 мм <li>Размер экрана: 30 х 15 мм <li>Цена деления: 0,1 г <li>Предел взвешивания: 120 г <li>Питание: 1 батарейка CR2032 <li>Габаритные размеры: 115 х 90 х 20 мм <li>Вес: 100,3 г</li></ul><p><strong>В комплект входит:</strong> основное устройство, батарейка, чехол, инструкция.</p><p><strong>Производитель: </strong>Tanita (Япония) </p><p><strong>Гарантия: </strong>1 год </p> микроволновая печь scarlett</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/78465bcfeecb4716f9891b6cf30f9b2b.jpeg" alt="выпечка в хлебопечке мулинекс Миксер Atlanta ATH-290" title="выпечка в хлебопечке мулинекс Миксер Atlanta ATH-290"><div class="box"><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-670r.php"><h3 class="title">выпечка в хлебопечке мулинекс Миксер Atlanta ATH-290</h3><p>от <span class="price">670</span> руб.</p></a></div></li>
						<li><img src="photos/602afbefdc154f32c668e628ed57301c.jpeg" alt="рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903" title="рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903"><div class="box" page="sokovyzhimalka-maxima-mjm-1850r"><span class="title">рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li><img src="photos/46a5120709bf99f581bc7ea7569bd649.png" alt="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902" title="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902"><div class="box" page="hlebopech-redmond-rbmm-3990r"><span class="title">делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li><img src="photos/b2f5222e6fab12eeb526363895bfe319.jpeg" alt="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л" title="пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-950r"><span class="title">пылесос автомобильный купить Чайник электрический  Vitesse VS-138 1,7л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/1e8cb522c5d55835b46dcc4fc497881b.jpeg" alt="батон в хлебопечке Чайник-термос  Atlanta АТН-765" title="батон в хлебопечке Чайник-термос  Atlanta АТН-765"><div class="box" page="chayniktermos-atlanta-atn-1380r"><span class="title">батон в хлебопечке Чайник-термос  Atlanta АТН-765</span><p>от <span class="price">1380</span> руб.</p></div></li>
						<li class="large"><img src="photos/ea47296a93804ab77bc9f5e5af614a8b.jpeg" alt="рейтинг пылесосов 2011 Батарейка GP Batteries Super alkaline LR14 14A-BC2" title="рейтинг пылесосов 2011 Батарейка GP Batteries Super alkaline LR14 14A-BC2"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-130r"><span class="title">рейтинг пылесосов 2011 Батарейка GP Batteries Super alkaline LR14 14A-BC2</span><p>от <span class="price">130</span> руб.</p></div></li>
						<li class="large"><img src="photos/b30a9264a94da2d2b2a0829021bb7fab.jpeg" alt="кофеварка ровента инструкция Экотестер СоЭкс (2 в 1: дозиметр радиации и нитрат тестер)" title="кофеварка ровента инструкция Экотестер СоЭкс (2 в 1: дозиметр радиации и нитрат тестер)"><div class="box" page="ekotester-soeks-v-dozimetr-radiacii-i-nitrat-tester-8600r"><span class="title">кофеварка ровента инструкция Экотестер СоЭкс (2 в 1: дозиметр радиации и нитрат тестер)</span><p>от <span class="price">8600</span> руб.</p></div></li>
						<li><img src="photos/39b908a415c11ffadfa5f63c6981b9e7.jpeg" alt="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail" title="солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail"><div class="box" page="universalnaya-miniturboschetka-v-upakovke-dyson-mini-turbine-head-ir-cl-retail-2290r"><span class="title">солянка в мультиварке Универсальная минитурбощетка в упаковке Dyson Mini Turbine Head Ir Cl Retail</span><p>от <span class="price">2290</span> руб.</p></div></li>
						<li><img src="photos/8201fb734cec793db96d43f2e27a6cc4.jpeg" alt="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail" title="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail"><div class="box" page="nabor-dlya-doma-dyson-home-cleaning-kit-retail-2490r"><span class="title">мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" alt="микроволновая печь bork Пылесос моющий Thomas Hygiene T2" title="микроволновая печь bork Пылесос моющий Thomas Hygiene T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-t-15900r"><span class="title">микроволновая печь bork Пылесос моющий Thomas Hygiene T2</span><p>от <span class="price">15900</span> руб.</p></div></li>
						<li><img src="photos/508d5d97fb58fc95875b08492316946f.jpeg" alt="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29" title="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29"><div class="box" page="pylesos-dyson-allergy-db-dc-19990r"><span class="title">блендер braun mx 2050 Пылесос Dyson allergy dB DC 29</span><p>от <span class="price">19990</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("mini-vesy-tangent-kp-1200r.php", 0, -4); if (file_exists("comments/mini-vesy-tangent-kp-1200r.php")) require_once "comments/mini-vesy-tangent-kp-1200r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="mini-vesy-tangent-kp-1200r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>