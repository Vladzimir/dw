<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-moyuschiy-thomas-hygiene-t-15900r.php","каша в аэрогриле");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-moyuschiy-thomas-hygiene-t-15900r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>каша в аэрогриле Пылесос моющий Thomas Hygiene T2  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="каша в аэрогриле, блендер philips hr1615, вафельница киев, пылесос с водяным фильтром samsung, какой моющий пылесос выбрать, блендер philips hr 1617, дозиметр рентгеновского излучения, хлебопечка panasonic 255 купить, пылесос thomas s1, мультиварка киев купить, электронная мясорубка, утюг tefal с парогенератором, курица с грибами в мультиварке, соковыжималка сатурн,  мясорубка moulinex hv8 me625">
		<meta name="description" content="каша в аэрогриле Моющий пылесос Thomas предназначен для сухой или влажной уборки. Он обладает выс...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" title="каша в аэрогриле Пылесос моющий Thomas Hygiene T2"><img src="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" alt="каша в аэрогриле Пылесос моющий Thomas Hygiene T2" title="каша в аэрогриле Пылесос моющий Thomas Hygiene T2 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-cc-4920r.php"><img src="photos/0c50b7e39e50ca19abd7fa5476ddc943.jpeg" alt="блендер philips hr1615 Блендер Braun MR-730 CC" title="блендер philips hr1615 Блендер Braun MR-730 CC"></a><h2>Блендер Braun MR-730 CC</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-63790r.php"><img src="photos/7bf6714fb23984d0a15fec9274d53078.jpeg" alt="вафельница киев Кофемашина Nivona NICR830 CafeRomatica" title="вафельница киев Кофемашина Nivona NICR830 CafeRomatica"></a><h2>Кофемашина Nivona NICR830 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/multivarka-elektricheskaya-atlanta-atn-3490r.php"><img src="photos/50ba0f1ba21fa51f038f164ecd16fe2c.jpeg" alt="пылесос с водяным фильтром samsung Мультиварка электрическая ATLANTA АТН-592" title="пылесос с водяным фильтром samsung Мультиварка электрическая ATLANTA АТН-592"></a><h2>Мультиварка электрическая ATLANTA АТН-592</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>каша в аэрогриле Пылесос моющий Thomas Hygiene T2</h1>
						<div class="tb"><p>Цена: от <span class="price">15900</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14622.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий пылесос Thomas предназначен для сухой или влажной уборки. Он обладает высокой мощностью - 1600 Вт, оборудован фильтром тонкой очистки, снабжен ножным переключателем, расположенным на корпусе. Шнур устройства сматывается автоматически, труба всасывания вертикально паркуется на корпусе, предусмотрено наличие бампера для защиты мебели от возможных повреждений. </p><p>Модель комплектуется распыляющими насадками для ковровых и твердых покрытий (со встроенным адаптером) и для влажной уборки мягкой мебели, специальной насадкой для сухой уборки с адаптером для паркета, насадкой для очистки мягкой мебели с нитеподъемником, кисточкой для мебели, насадкой для прочистки сифонов, щелевой насадкой. Кроме того, в комплекте идут три салфетки из микроволокна и сумка для удобного хранения принадлежностей пылесоса.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: обычный; <li>Уборка: сухая / влажная; <li>Потребляемая мощность: 1600 Вт; <li>Пылесборник: аквафильтр; <li>Фильтр тонкой очистки: есть; <li>Источник питания: сеть; <li>Длина сетевого шнура: 8 м; <li>Автосматывание сетевого шнура; <li>Ножной переключатель вкл./выкл. на корпусе; <li>Вертикальная парковка трубы всасывания на корпусе пылесоса; <li>Вес: 9,2 кг; <li>Емкость резервуара моющего средства 2,4 л; <li>Давление насоса: 4 бар; <li>Бампер для защиты мебели; <li>Сумка для хранения принадлежностей; <li>3 салфетки из микроволокна для твердых полов и мытья окон; <li>Труба всасывания: телескопическая.</li></ul><p><b></b></p><p><b>Дополнительные насадки в комплекте: </b></p><ul type=disc><li>Распыляющая со встроенным адаптером для ковровых и твердых поверхностей; <li>Распыляющая для влажной уборки мягкой мебели; <li>Для сухой уборки с адаптером для паркета; <li>Для очистки мягкой мебели с нитеподъемником; <li>Кисточка для мебели; <li>Щелевая; <li>Для прочистки сифонов.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> каша в аэрогриле</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d2b0cc36c62095fdc525b7665e50506c.jpeg" alt="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321" title="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321"><div class="box" page="sokovyzhimalka-atlanta-ath-1010r"><span class="title">какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li><img src="photos/c4c3375bd5e900bb92cb2c5b9021e247.jpeg" alt="блендер philips hr 1617 Термопот  Redmond RTP-M801" title="блендер philips hr 1617 Термопот  Redmond RTP-M801"><div class="box" page="termopot-redmond-rtpm-3290r"><span class="title">блендер philips hr 1617 Термопот  Redmond RTP-M801</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li><img src="photos/316a6aef2ce50d76bdf9280d8e11dad1.jpeg" alt="дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230" title="дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230"><div class="box" page="hlebopechka-moulinex-ow-4790r"><span class="title">дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230</span><p>от <span class="price">4790</span> руб.</p></div></li>
						<li><img src="photos/0f5208729d1f126a03ea2f6dcc581158.jpeg" alt="хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430" title="хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430"><div class="box" page="hlebopechka-moulinex-ow-7500r"><span class="title">хлебопечка panasonic 255 купить Хлебопечка Moulinex OW502430</span><p>от <span class="price">7500</span> руб.</p></div></li>
						<li class="large"><img src="photos/c73e008984140d52a15fd324bddeb59f.jpeg" alt="пылесос thomas s1 Чайник электрический Vitek VT-1141" title="пылесос thomas s1 Чайник электрический Vitek VT-1141"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1350r-2"><span class="title">пылесос thomas s1 Чайник электрический Vitek VT-1141</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li class="large"><img src="photos/1b3cfce3fc4c2602ab4206bda1961e7d.jpeg" alt="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный" title="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belolazurnyy-920r"><span class="title">мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li class="large"><img src="photos/f056d129bd10f6cbcdccf3b119b91dc8.jpeg" alt="электронная мясорубка Чайник электрический  Vitesse VS-143 стеклянный 1,7л" title="электронная мясорубка Чайник электрический  Vitesse VS-143 стеклянный 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r"><span class="title">электронная мясорубка Чайник электрический  Vitesse VS-143 стеклянный 1,7л</span><p>от <span class="price">2280</span> руб.</p></div></li>
						<li><img src="photos/7f879f1e565356e4de3c725635f57ee6.jpeg" alt="утюг tefal с парогенератором Зарядное устройство GP Batteries PB360GS-UE1" title="утюг tefal с парогенератором Зарядное устройство GP Batteries PB360GS-UE1"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-270r"><span class="title">утюг tefal с парогенератором Зарядное устройство GP Batteries PB360GS-UE1</span><p>от <span class="price">270</span> руб.</p></div></li>
						<li><img src="photos/d5bfaa3b5f694911004b112b3792a6d5.jpeg" alt="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130" title="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130"><div class="box" page="komplekt-filtrovmeshkov-karcher-480r"><span class="title">курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li><img src="photos/c760072d30fa7e68aaaf26403c36f72a.jpeg" alt="соковыжималка сатурн Пылесос Thomas Genius S2 Aquafilter" title="соковыжималка сатурн Пылесос Thomas Genius S2 Aquafilter"><div class="box" page="pylesos-thomas-genius-s-aquafilter-10840r"><span class="title">соковыжималка сатурн Пылесос Thomas Genius S2 Aquafilter</span><p>от <span class="price">10840</span> руб.</p></div></li>
						<li><img src="photos/dad55c3e820faa7adb3396e1681091d7.jpeg" alt="рецепты для миксера Утюг Vitek VT-1255" title="рецепты для миксера Утюг Vitek VT-1255"><div class="box" page="utyug-vitek-vt-1350r"><span class="title">рецепты для миксера Утюг Vitek VT-1255</span><p>от <span class="price">1350</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-moyuschiy-thomas-hygiene-t-15900r.php", 0, -4); if (file_exists("comments/pylesos-moyuschiy-thomas-hygiene-t-15900r.php")) require_once "comments/pylesos-moyuschiy-thomas-hygiene-t-15900r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-moyuschiy-thomas-hygiene-t-15900r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>