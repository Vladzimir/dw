<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-maxima-mjm-1850r.php","ратеп мясорубка");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-maxima-mjm-1850r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>ратеп мясорубка Соковыжималка Maxima MJ-M903  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="ратеп мясорубка, кофеварка philips отзывы, кофеварка френч пресс, пылесос roomy gold, соковыжималка profi cook, мультиварка в новосибирске, мясорубки в санкт петербурге, блендер в одессе, мультиварка панасоник sr tmh18, соковыжималка philips 1866, кофемашина la cimbali, пароварка tefal vc 1016, мультиварка скороварка moulinex, кофемашина saeco xsmall,  соковыжималка россошанка">
		<meta name="description" content="ратеп мясорубка Соковыжималка Maxima, мощностью 700 Вт, позволит приготовить натуральный сок,  к...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/602afbefdc154f32c668e628ed57301c.jpeg" title="ратеп мясорубка Соковыжималка Maxima MJ-M903"><img src="photos/602afbefdc154f32c668e628ed57301c.jpeg" alt="ратеп мясорубка Соковыжималка Maxima MJ-M903" title="ратеп мясорубка Соковыжималка Maxima MJ-M903 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-pogruzhnoy-moulinex-ddd-3050r.php"><img src="photos/88431db04944e702f33c054454f31139.jpeg" alt="кофеварка philips отзывы Блендер погружной Moulinex DD407D72" title="кофеварка philips отзывы Блендер погружной Moulinex DD407D72"></a><h2>Блендер погружной Moulinex DD407D72</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-redmond-rfp-5390r.php"><img src="photos/eeb9eab6db603b9616a92fc025537c6c.jpeg" alt="кофеварка френч пресс Кухонный комбайн Redmond  RFP-3903" title="кофеварка френч пресс Кухонный комбайн Redmond  RFP-3903"></a><h2>Кухонный комбайн Redmond  RFP-3903</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-35190r.php"><img src="photos/df4de2da7d663a4198320cc2af72f271.jpeg" alt="пылесос roomy gold Кофемашина Nivona NICR650 CafeRomatica" title="пылесос roomy gold Кофемашина Nivona NICR650 CafeRomatica"></a><h2>Кофемашина Nivona NICR650 CafeRomatica</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>ратеп мясорубка Соковыжималка Maxima MJ-M903</h1>
						<div class="tb"><p>Цена: от <span class="price">1850</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20603.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Соковыжималка Maxima, мощностью 700 Вт, позволит приготовить натуральный сок,  как из мягких, так и  из твердых  продуктов. Функция защиты от протекания и прозрачная защитная крышка сохранят  чистоту на Вашей кухне. Сетчатый фильтр с микроотверстиями, выполнен из нержавеющей  стали, для повышения долговечности. Функция автоматического выброса мякоти  облегчит эксплуатацию устройства (резервуар для мякоти 1.6 л). Горловина  соковыжималки круглая (75 мм). Максимальное число оборотов 20 000 в минуту  (2 скорости работы). В целях безопасности предусмотрена защита от случайного  включения.</p><p><br><strong>Характеристики:</strong></p><ul><li>Тип: универсальная;</li><li>Мощность: 700 Вт;</li><li>Автоматический выброс мякоти;</li><li>Объем резервуара для мякоти: 1.6 л;</li><li>Защита от случайного включения;</li><li>Количество скоростей: 2;</li><li>Максимальная скорость вращения: 20 000  об/мин;</li><li>Импульсный режим;</li><li>Система прямой подачи сока;</li><li>Система «капля-стоп»;</li><li>Размеры: 22х34х39.5 см;</li></ul><p><strong>Производитель:</strong><strong> Maxima (Китай)</strong><br><strong>Изготовитель: Китай</strong><br><strong>Гарантия: 12 месяцев</strong></p> ратеп мясорубка</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/b3484386aa5de93840c27e2c8187adfa.jpeg" alt="соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293" title="соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293"><div class="box" page="mylopoglotitel-nepriyatnyh-zapahov-vitesse-vs-530r"><span class="title">соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293</span><p>от <span class="price">530</span> руб.</p></div></li>
						<li><img src="photos/5a5674539caee9c3fc9dbe29847298d4.jpeg" alt="мультиварка в новосибирске Мясорубка электрическая Vitek VT-1671 белая" title="мультиварка в новосибирске Мясорубка электрическая Vitek VT-1671 белая"><div class="box" page="myasorubka-elektricheskaya-vitek-vt-belaya-3300r"><span class="title">мультиварка в новосибирске Мясорубка электрическая Vitek VT-1671 белая</span><p>от <span class="price">3300</span> руб.</p></div></li>
						<li><img src="photos/54c54bed2f103aac514687168a05cb1f.jpeg" alt="мясорубки в санкт петербурге Тостер Russell Hobbs Cottage Floral, арт. 18513-56" title="мясорубки в санкт петербурге Тостер Russell Hobbs Cottage Floral, арт. 18513-56"><div class="box" page="toster-russell-hobbs-cottage-floral-art-2790r"><span class="title">мясорубки в санкт петербурге Тостер Russell Hobbs Cottage Floral, арт. 18513-56</span><p>от <span class="price">2790</span> руб.</p></div></li>
						<li><img src="photos/64a1e17046b7c97f3413bb1bcacb4f30.jpeg" alt="блендер в одессе Чайник экспресс Binatone EEJ-1555 White" title="блендер в одессе Чайник экспресс Binatone EEJ-1555 White"><div class="box" page="chaynik-ekspress-binatone-eej-white-2600r"><span class="title">блендер в одессе Чайник экспресс Binatone EEJ-1555 White</span><p>от <span class="price">2600</span> руб.</p></div></li>
						<li class="large"><img src="photos/85911164b0086dda5108661c861dc16a.jpeg" alt="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л" title="мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л"><div class="box" page="chaynik-elektricheskiy-tefal-delfina-be-l-950r"><span class="title">мультиварка панасоник sr tmh18 Чайник электрический Tefal Delfina BE531040 1,5 л</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/ba65472be620113b82aa055e0f7c89a6.jpeg" alt="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный" title="соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-krasnyy-1510r"><span class="title">соковыжималка philips 1866 Чайник электрический  Vitesse VS-135 1,7л красный</span><p>от <span class="price">1510</span> руб.</p></div></li>
						<li class="large"><img src="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" alt="кофемашина la cimbali Электрический чайник Atlanta АТН-788" title="кофемашина la cimbali Электрический чайник Atlanta АТН-788"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1350r"><span class="title">кофемашина la cimbali Электрический чайник Atlanta АТН-788</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li><img src="photos/59caa0f57be012636d82040c68bfc641.jpeg" alt="пароварка tefal vc 1016 Батарейка GP Batteries Super alkaline LR6 15A-BC2" title="пароварка tefal vc 1016 Батарейка GP Batteries Super alkaline LR6 15A-BC2"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-45r"><span class="title">пароварка tefal vc 1016 Батарейка GP Batteries Super alkaline LR6 15A-BC2</span><p>от <span class="price">45</span> руб.</p></div></li>
						<li><img src="photos/96ed77acce770bf04afcf29723d61326.jpeg" alt="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas" title="мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas"><div class="box" page="bumazhnye-filtrymeshki-dlya-thomas-1000r-2"><span class="title">мультиварка скороварка moulinex Бумажные фильтры-мешки 300 (787-102) для Thomas</span><p>от <span class="price">1000</span> руб.</p></div></li>
						<li><img src="photos/20a6a481b9a3a072fa1293146dcb1ec9.jpeg" alt="кофемашина saeco xsmall Пылесос моющий Thomas Super 30 S Aquafilter" title="кофемашина saeco xsmall Пылесос моющий Thomas Super 30 S Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-super-s-aquafilter-10520r"><span class="title">кофемашина saeco xsmall Пылесос моющий Thomas Super 30 S Aquafilter</span><p>от <span class="price">10520</span> руб.</p></div></li>
						<li><img src="photos/b5afd7c51355e06ff913b79a852afc55.jpeg" alt="пылесос с электрощеткой Утюг Binatone SI-4040 Blue" title="пылесос с электрощеткой Утюг Binatone SI-4040 Blue"><div class="box" page="utyug-binatone-si-blue-1600r"><span class="title">пылесос с электрощеткой Утюг Binatone SI-4040 Blue</span><p>от <span class="price">1600</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-maxima-mjm-1850r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-maxima-mjm-1850r.php")) require_once "comments/sokovyzhimalka-maxima-mjm-1850r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-maxima-mjm-1850r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>