<div class="footer">
				<ul class="sn">
					<li><a href="http://www.twitter.com"><img src="images/twitter.png" alt="twitter"></a></li>
					<li><a href="http://www.facebook.com"><img src="images/facebook.png" alt="facebook"></a></li>
				</ul>
				<a href="index.php"><img class="logo" src="images/footer-logo.png" alt="logo"></a>
				<script type="text/javascript">document.write("<a href='http://www.liveinternet.ru/click' "+"target=_blank><img class='li' src='//counter.yadro.ru/hit?t40.6;r"+escape(document.referrer)+((typeof(screen)=="undefined")?"":";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+";"+Math.random()+"' alt='' title='LiveInternet' "+"border='0' width='31' height='31'><\/a>")</script>
				<ul class="nav">
					<li><a href="contact.php">Контакты</a></li>
					<li><a href="privacy.php">Политика конфидециальности</a></li>
					<li><a href="terms.php">Условия использования сайтом</a></li>
				</ul>
			</div>