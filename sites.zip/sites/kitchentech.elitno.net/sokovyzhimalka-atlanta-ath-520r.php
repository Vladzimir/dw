<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-atlanta-ath-520r.php","утюг braun 18895");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-atlanta-ath-520r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>утюг braun 18895 Соковыжималка Atlanta ATH-325  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="утюг braun 18895, джем в хлебопечке рецепт, где купить пароварку, мультиварка ярославль, пылесос lg с контейнером, запчасти для пылесоса lg, мультиварка куку 1054, хлебопечка германия, запчасти для блендера braun, panasonic блендер, kress пылесос, уха в мультиварке, стимер для аэрогриля, бездрожжевой хлеб в хлебопечке,  робот пылесос deebot">
		<meta name="description" content="утюг braun 18895 Соковыжималка Atlanta ATH-325 черного цвета мощностью 450 Вт – простой и доступн...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/a5a944903050174bbca074a40d4e65fa.jpeg" title="утюг braun 18895 Соковыжималка Atlanta ATH-325"><img src="photos/a5a944903050174bbca074a40d4e65fa.jpeg" alt="утюг braun 18895 Соковыжималка Atlanta ATH-325" title="утюг braun 18895 Соковыжималка Atlanta ATH-325 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/mikser-atlanta-ath-wb-630r.php"><img src="photos/8dac9aeadde6a6d95b71abb890265199.jpeg" alt="джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB" title="джем в хлебопечке рецепт Миксер Atlanta ATH-263 WB"></a><h2>Миксер Atlanta ATH-263 WB</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-tefal-le-hachoir-me-5100r.php"><img src="photos/1a39977506779af8e80d3d2045a86d6b.jpeg" alt="где купить пароварку Мясорубка электрическая Tefal Le Hachoir ME7001" title="где купить пароварку Мясорубка электрическая Tefal Le Hachoir ME7001"></a><h2>Мясорубка электрическая Tefal Le Hachoir ME7001</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-tefal-vitacuisine-compact-vc-3530r.php"><img src="photos/9b1d673d9b457ad6c9a587ce93c1d42a.jpeg" alt="мультиварка ярославль Пароварка Tefal VitaCuisine Compact VC4003" title="мультиварка ярославль Пароварка Tefal VitaCuisine Compact VC4003"></a><h2>Пароварка Tefal VitaCuisine Compact VC4003</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>утюг braun 18895 Соковыжималка Atlanta ATH-325</h1>
						<div class="tb"><p>Цена: от <span class="price">520</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19672.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Соковыжималка Atlanta ATH-325 черного цвета мощностью 450 Вт – простой и доступный прибор в стильном и современном дизайне для приготовления сока в домашних условиях. Если вас не устраивают соки в магазине и вы хотите быть уверенными в качестве и полезности того что пьете, то используйте эту электрическую соковыжималку. Она очень проста и удобна в использовании, очистке и хранении. Она предназначена, для приготовления сока не только из цитрусовых, но также из любых фруктов и ягод. Ее габариты, внешний вид и вес позволят идеально вписаться в интерьер любой кухни. Она станет вашим незаменимым другом. Ее корпус выполнен из высокопрочного пластика. Предусмотрены две скорости работы. Оснащена тихо работающим мощным мотором.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Эргономичный дизайн <li>Две скорости плюс импульсная активация  <li>Мощный мотор <li>Прозрачный контейнер для сбора сока <li>Разборная конструкция удобная для чистки <li>Мощность 450 Вт <li>220-240 В, 50-60 Гц <li>Объем 1 литр <li>Автоматическое вращение в двух направлениях <li>Регулировка мякоти в соке <li>Специальный отсек для намотки шнура <li>Пониженный уровень шума </li></ul><p><strong>Производитель: США</strong></p> утюг braun 18895</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d78a5eb7926a57e3a6daeb54a8fc1659.jpeg" alt="пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine" title="пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine"><div class="box" page="sokovyzhimalka-moulinex-juae-juice-machine-4300r"><span class="title">пылесос lg с контейнером Соковыжималка Moulinex JU599A3E Juice Machine</span><p>от <span class="price">4300</span> руб.</p></div></li>
						<li><img src="photos/57a9dd1cf47f278e2b8c998d7aabc0c5.jpeg" alt="запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный" title="запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный"><div class="box" page="bodum-bistro-euro-toster-krasnyy-3660r"><span class="title">запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный</span><p>от <span class="price">3660</span> руб.</p></div></li>
						<li><img src="photos/f12c67c091dc7674e75925e27c6ee910.jpeg" alt="мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный" title="мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-chernyy-2150r"><span class="title">мультиварка куку 1054 Чайник электрический Vitek VT-1101 черный</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/b3fae48615963478f00e0c05f3baa485.jpeg" alt="хлебопечка германия Электрический чайник  Zauber R-380" title="хлебопечка германия Электрический чайник  Zauber R-380"><div class="box" page="elektricheskiy-chaynik-zauber-r-1830r"><span class="title">хлебопечка германия Электрический чайник  Zauber R-380</span><p>от <span class="price">1830</span> руб.</p></div></li>
						<li class="large"><img src="photos/e766dc7a6c0cf1b164fee2cb011a81f8.jpeg" alt="запчасти для блендера braun Чайник Vitek VT-1163" title="запчасти для блендера braun Чайник Vitek VT-1163"><div class="box" page="chaynik-vitek-vt-990r"><span class="title">запчасти для блендера braun Чайник Vitek VT-1163</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/a72d69a17b01ae0c39e3992b04fd72d5.jpeg" alt="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)" title="panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-750r"><span class="title">panasonic блендер Сопло для пенной чистки Karcher (упаковка 0,6 л)</span><p>от <span class="price">750</span> руб.</p></div></li>
						<li class="large"><img src="photos/cfc3673046a371ff9baffb342aa8e52b.jpeg" alt="kress пылесос Пылесос моющий Thomas Twin Aquafilter" title="kress пылесос Пылесос моющий Thomas Twin Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquafilter-11550r"><span class="title">kress пылесос Пылесос моющий Thomas Twin Aquafilter</span><p>от <span class="price">11550</span> руб.</p></div></li>
						<li><img src="photos/bf1db2ec9a55f45d9ef32e836546d600.jpeg" alt="уха в мультиварке Пылесос моющий Thomas Super 30 S" title="уха в мультиварке Пылесос моющий Thomas Super 30 S"><div class="box" page="pylesos-moyuschiy-thomas-super-s-9020r"><span class="title">уха в мультиварке Пылесос моющий Thomas Super 30 S</span><p>от <span class="price">9020</span> руб.</p></div></li>
						<li><img src="photos/127daa75b6d910b9f123f08316795848.png" alt="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37" title="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37"><div class="box" page="pylesos-dyson-allergy-musclehead-dc-24590r"><span class="title">стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37</span><p>от <span class="price">24590</span> руб.</p></div></li>
						<li><img src="photos/e0fdfa431cfe6b47b04ad11ff4f6a218.jpeg" alt="бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805" title="бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805"><div class="box" page="pylesos-vitek-vt-1870r"><span class="title">бездрожжевой хлеб в хлебопечке Пылесос Vitek VT-1805</span><p>от <span class="price">1870</span> руб.</p></div></li>
						<li><img src="photos/a5307e77bbd77d05fd1bf891a3eeb5d0.jpeg" alt="хлебопечки в новосибирске Пылесос Vitek VT-1845 красный" title="хлебопечки в новосибирске Пылесос Vitek VT-1845 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-4590r"><span class="title">хлебопечки в новосибирске Пылесос Vitek VT-1845 красный</span><p>от <span class="price">4590</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-atlanta-ath-520r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-atlanta-ath-520r.php")) require_once "comments/sokovyzhimalka-atlanta-ath-520r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-atlanta-ath-520r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>