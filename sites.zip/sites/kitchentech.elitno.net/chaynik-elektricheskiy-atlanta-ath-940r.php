<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-atlanta-ath-940r.php","аэрогриль hotter 1087 tiger");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-atlanta-ath-940r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>аэрогриль hotter 1087 tiger Чайник электрический Atlanta ATH-758  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="аэрогриль hotter 1087 tiger, сервисный центр пылесосов, пылесос для ногтей, микроволновая печь польза, утюг какой фирмы лучше, видео мясорубки мулинекс, щетка для пылесоса electrolux, купить вертикальный утюг, принцип микроволновой печи, дженни шаптер хлебопечка скачать, сколько стоит фритюрница, сравнение блендеров, мультиварка скороварка land life, курица с грибами в мультиварке,  мясорубка для столовой">
		<meta name="description" content="аэрогриль hotter 1087 tiger Керамический электрический чайник Atlanta ATH-758 с синим цветком на белом фоне ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/5a34cc2772e0feae9df6932b7f043259.jpeg" title="аэрогриль hotter 1087 tiger Чайник электрический Atlanta ATH-758"><img src="photos/5a34cc2772e0feae9df6932b7f043259.jpeg" alt="аэрогриль hotter 1087 tiger Чайник электрический Atlanta ATH-758" title="аэрогриль hotter 1087 tiger Чайник электрический Atlanta ATH-758 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-atlanta-atn-550r.php"><img src="photos/7911abad6905c53ed2ad855d9cc4e2e1.jpeg" alt="сервисный центр пылесосов Блендер Atlanta АТН-338" title="сервисный центр пылесосов Блендер Atlanta АТН-338"></a><h2>Блендер Atlanta АТН-338</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lounge-white-45500r.php"><img src="photos/45055ec55f153a8a82f9cf1191933a0c.jpeg" alt="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)" title="пылесос для ногтей Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lounge White (4.0008.67)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-krasnaya-29530r.php"><img src="photos/39e04c91cf56d7c949379d4f2e2d6076.jpeg" alt="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная" title="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, красная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>аэрогриль hotter 1087 tiger Чайник электрический Atlanta ATH-758</h1>
						<div class="tb"><p>Цена: от <span class="price">940</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18122.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Керамический электрический чайник Atlanta ATH-758 с синим цветком на белом фоне объемом 1 литр, мощностью 1000 Вт с дисковым нагревателем из нержавеющей стали в качестве нагревательного элемента и фильтром от накипи. Абсолютно безопасен: выключается при закипании и не включается при отсутствии воды. </p><p><b>Характеристики:</b></p><ul type=disc><li>Объем: 1 л <li>Мощность: 1200 Вт <li>Нагревательный элемент: закрытая спираль <li>Блокировка включения без воды <li>Автоматическое выключение </li></ul><p><b>Производитель: Китай</b></p> аэрогриль hotter 1087 tiger</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/ff295724863185ff22e2c85236f25515.jpeg" alt="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый" title="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый"><div class="box"><a href="http://kitchentech.elitno.net/bodum-bistro-euro-elektricheskiy-mikser-zelenyy-2740r.php"><h3 class="title">утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый</h3><p>от <span class="price">2740</span> руб.</p></a></div></li>
						<li><img src="photos/4e7490247492c7ab40236e7400fed0df.jpeg" alt="видео мясорубки мулинекс Мультиварка Redmond RMC-M4503" title="видео мясорубки мулинекс Мультиварка Redmond RMC-M4503"><div class="box" page="multivarka-redmond-rmcm-2990r"><span class="title">видео мясорубки мулинекс Мультиварка Redmond RMC-M4503</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/74bbce31ddb28c5063f247363080794a.jpeg" alt="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502" title="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502"><div class="box" page="chasha-dlya-multivarki-redmond-iprmcm-990r"><span class="title">щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" alt="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56" title="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56"><div class="box" page="toster-russell-hobbs-jungle-green-art-1890r"><span class="title">купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li class="large"><img src="photos/3db103a42b99a0a770887670f28f5ba2.jpeg" alt="принцип микроволновой печи Чайник электрический Moulinex BY5101 1,5 л" title="принцип микроволновой печи Чайник электрический Moulinex BY5101 1,5 л"><div class="box" page="chaynik-elektricheskiy-moulinex-by-l-1950r"><span class="title">принцип микроволновой печи Чайник электрический Moulinex BY5101 1,5 л</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li class="large"><img src="photos/78655cc6df39885b41a8efad804df716.jpeg" alt="дженни шаптер хлебопечка скачать Чайник электрический Redmond RK-M113" title="дженни шаптер хлебопечка скачать Чайник электрический Redmond RK-M113"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2290r"><span class="title">дженни шаптер хлебопечка скачать Чайник электрический Redmond RK-M113</span><p>от <span class="price">2290</span> руб.</p></div></li>
						<li class="large"><img src="photos/49901359ef2b43e118be22a24f1caa05.jpeg" alt="сколько стоит фритюрница Minamoto R6 (AA)" title="сколько стоит фритюрница Minamoto R6 (AA)"><div class="box" page="minamoto-r-aa-3r"><span class="title">сколько стоит фритюрница Minamoto R6 (AA)</span><p>от <span class="price">3</span> руб.</p></div></li>
						<li><img src="photos/41efedb38089aeb46a210ce7ff30eedc.jpeg" alt="сравнение блендеров Детектор жучков BugHunter Professional BH-01" title="сравнение блендеров Детектор жучков BugHunter Professional BH-01"><div class="box" page="detektor-zhuchkov-bughunter-professional-bh-7990r"><span class="title">сравнение блендеров Детектор жучков BugHunter Professional BH-01</span><p>от <span class="price">7990</span> руб.</p></div></li>
						<li><img src="photos/351be0717cadb3b074e20c4a4dccbf50.jpeg" alt="мультиварка скороварка land life Мини весы Momert 6000" title="мультиварка скороварка land life Мини весы Momert 6000"><div class="box" page="mini-vesy-momert-1600r"><span class="title">мультиварка скороварка land life Мини весы Momert 6000</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/d5bfaa3b5f694911004b112b3792a6d5.jpeg" alt="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130" title="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130"><div class="box" page="komplekt-filtrovmeshkov-karcher-480r"><span class="title">курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li><img src="photos/103d1dd79396034a787226c582b363d1.jpeg" alt="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter" title="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter"><div class="box" page="pylesos-thomas-power-edition-aquafilter-6220r"><span class="title">ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter</span><p>от <span class="price">6220</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-atlanta-ath-940r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-atlanta-ath-940r.php")) require_once "comments/chaynik-elektricheskiy-atlanta-ath-940r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-atlanta-ath-940r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>