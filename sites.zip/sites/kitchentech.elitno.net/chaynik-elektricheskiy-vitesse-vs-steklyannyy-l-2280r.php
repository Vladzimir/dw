<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r.php","утюг для сварки полипропиленовых труб");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>утюг для сварки полипропиленовых труб Чайник электрический  Vitesse VS-143 стеклянный 1,7л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="утюг для сварки полипропиленовых труб, чем отличаются кофеварки, соковыжималки выбор, картофель во фритюрнице, курица во фритюрнице, щетка для пылесоса electrolux, кофемашина jura impressa c5, пылесос thomas отзывы, kenwood пароварка, дозиметр радиоактивности, бездрожжевой хлеб в хлебопечке, блендер рецепты видео, утюг в туле, панасоник соковыжималка,  микроволновая печь дешево">
		<meta name="description" content="утюг для сварки полипропиленовых труб Электрический чайник Vitesse VS-143 в стеклянном корпусе  вскипятит 1,7 литра во...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/f056d129bd10f6cbcdccf3b119b91dc8.jpeg" title="утюг для сварки полипропиленовых труб Чайник электрический  Vitesse VS-143 стеклянный 1,7л"><img src="photos/f056d129bd10f6cbcdccf3b119b91dc8.jpeg" alt="утюг для сварки полипропиленовых труб Чайник электрический  Vitesse VS-143 стеклянный 1,7л" title="утюг для сварки полипропиленовых труб Чайник электрический  Vitesse VS-143 стеклянный 1,7л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-red-35700r.php"><img src="photos/0c7c7a9daf3721e5976f772ebe4ae9e2.jpeg" alt="чем отличаются кофеварки Эспрессо-кофемашина Melitta Caffeo Lattea Red (4.0009.92)" title="чем отличаются кофеварки Эспрессо-кофемашина Melitta Caffeo Lattea Red (4.0009.92)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Red (4.0009.92)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-solomilk-chernaya-26999r.php"><img src="photos/3c4c438093f284e24176255dd4b7658c.jpeg" alt="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная" title="соковыжималки выбор Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная"></a><h2>Автоматическая кофемашина Melitta CAFFEO Solo&milk, черная</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofevarka-ath-560r.php"><img src="photos/d1b139f63086ad817c04622c294f1224.jpeg" alt="картофель во фритюрнице Кофеварка  ATH-278" title="картофель во фритюрнице Кофеварка  ATH-278"></a><h2>Кофеварка  ATH-278</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>утюг для сварки полипропиленовых труб Чайник электрический  Vitesse VS-143 стеклянный 1,7л</h1>
						<div class="tb"><p>Цена: от <span class="price">2280</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19647.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Vitesse VS-143 в стеклянном корпусе  вскипятит 1,7 литра воды буквально за минуту.<br>Дополнительными плюсами являются автоматическая блокировка  включения без воды, специальный фильтр защиты от накипи и отсек для хранения  шнура.</p><p>Характеристики:</p><ul type=\disc\><li>Объем:  1.7 л;</li><li>Мощность:   2200 Вт;</li><li>Тип  нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал  корпуса: металл/стекло;</li><li>Блокировка  включения без воды;</li><li>Индикатор  уровня воды;</li><li>Индикация   включения;</li><li>Отсек  для шнура.</li><li></li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong></p> утюг для сварки полипропиленовых труб</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d3bcfc3d08cc302406de89eb814d0d80.jpeg" alt="курица во фритюрнице Кухонный комбайн Vitek VT-1622" title="курица во фритюрнице Кухонный комбайн Vitek VT-1622"><div class="box"><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-vitek-vt-2750r.php"><h3 class="title">курица во фритюрнице Кухонный комбайн Vitek VT-1622</h3><p>от <span class="price">2750</span> руб.</p></a></div></li>
						<li><img src="photos/d0af4bd740dd75cf948a8f00224c2bee.jpeg" alt="щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White" title="щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White"><div class="box" page="chaynik-elektricheskiy-binatone-cej-white-1080r"><span class="title">щетка для пылесоса electrolux Чайник электрический Binatone CEJ-1777 White</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li><img src="photos/35bc2a6ec9e7fd46ce73f8c296c53df9.jpeg" alt="кофемашина jura impressa c5 Чайник электрический Vitek VT-1102 черный" title="кофемашина jura impressa c5 Чайник электрический Vitek VT-1102 черный"><div class="box" page="chaynik-elektricheskiy-vitek-vt-chernyy-2000r"><span class="title">кофемашина jura impressa c5 Чайник электрический Vitek VT-1102 черный</span><p>от <span class="price">2000</span> руб.</p></div></li>
						<li><img src="photos/8e4c77fcf3cd711bd8454688ff0f7bc7.jpeg" alt="пылесос thomas отзывы Чайник электрический Vitek VT-1159" title="пылесос thomas отзывы Чайник электрический Vitek VT-1159"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1900r"><span class="title">пылесос thomas отзывы Чайник электрический Vitek VT-1159</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/97ad6f71f59b7db73d8fda12c75e94a2.jpeg" alt="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2" title="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-680r"><span class="title">kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2</span><p>от <span class="price">680</span> руб.</p></div></li>
						<li class="large"><img src="photos/c0a2e2be0cab06fcd64d43478c95622c.jpeg" alt="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter" title="дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-tt-aquafilter-14900r"><span class="title">дозиметр радиоактивности Пылесос моющий Thomas Twin TT Aquafilter</span><p>от <span class="price">14900</span> руб.</p></div></li>
						<li class="large"><img src="photos/7660e64f2f5c029aab5d6fad25c29084.jpeg" alt="бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843" title="бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843"><div class="box" page="pylesos-vitek-3990r"><span class="title">бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li><img src="photos/7e736b7b32dea00ff19d5eefa59427b8.jpeg" alt="блендер рецепты видео Пылесос Thomas Power Pack 1620" title="блендер рецепты видео Пылесос Thomas Power Pack 1620"><div class="box" page="pylesos-thomas-power-pack-4300r"><span class="title">блендер рецепты видео Пылесос Thomas Power Pack 1620</span><p>от <span class="price">4300</span> руб.</p></div></li>
						<li><img src="photos/d7f319eafa0a03def3b072699daeccdd.jpeg" alt="утюг в туле Утюг Vitek VT-1235" title="утюг в туле Утюг Vitek VT-1235"><div class="box" page="utyug-vitek-vt-970r"><span class="title">утюг в туле Утюг Vitek VT-1235</span><p>от <span class="price">970</span> руб.</p></div></li>
						<li><img src="photos/ab56eb3e56d0f0d6cbcdc267b86f71a7.jpeg" alt="панасоник соковыжималка Утюг паровой Tefal Aquaspeed Ultracord FV5257" title="панасоник соковыжималка Утюг паровой Tefal Aquaspeed Ultracord FV5257"><div class="box" page="utyug-parovoy-tefal-aquaspeed-ultracord-fv-2800r"><span class="title">панасоник соковыжималка Утюг паровой Tefal Aquaspeed Ultracord FV5257</span><p>от <span class="price">2800</span> руб.</p></div></li>
						<li><img src="photos/320f64ebbe69f1db4756b8e715b23297.jpeg" alt="самые популярные пылесосы Утюг Atlanta ATH-422" title="самые популярные пылесосы Утюг Atlanta ATH-422"><div class="box" page="utyug-atlanta-ath-590r"><span class="title">самые популярные пылесосы Утюг Atlanta ATH-422</span><p>от <span class="price">590</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-steklyannyy-l-2280r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>