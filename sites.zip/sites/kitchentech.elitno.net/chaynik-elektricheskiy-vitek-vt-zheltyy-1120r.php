<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-zheltyy-1120r.php","приключения тостера");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-zheltyy-1120r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>приключения тостера Чайник электрический Vitek VT-1139 желтый  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="приключения тостера, язык в аэрогриле, аэрогриль pag 1205d, парогенератор пээ, отважный тостер скачать, рецепт пельменей в хлебопечке, сепараторный пылесос, кофеварка нескафе дольче густо, купить кофемашину bosch, блендер braun mr 530 ca, купить пылесос зелмер, купить блендер braun mr 6550, какие лучше микроволновые печи, мясорубка помощница отзывы,  пылесос компрессор отзывы">
		<meta name="description" content="приключения тостера Превосходный электрический чайник Vitek VT-1139 в стильном пластиком корпусе пре...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/fd3d354d6633b81b504bbc499f3c5989.jpeg" title="приключения тостера Чайник электрический Vitek VT-1139 желтый"><img src="photos/fd3d354d6633b81b504bbc499f3c5989.jpeg" alt="приключения тостера Чайник электрический Vitek VT-1139 желтый" title="приключения тостера Чайник электрический Vitek VT-1139 желтый -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-solo-pure-white-28530r.php"><img src="photos/eb4618ce7491ec77cbaa3b4b7dd675cb.jpeg" alt="язык в аэрогриле Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)" title="язык в аэрогриле Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-lattea-fioletovaya-29530r.php"><img src="photos/d992bf4d2cd488df4b63963039c83898.jpeg" alt="аэрогриль pag 1205d Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая" title="аэрогриль pag 1205d Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая"></a><h2>Автоматическая кофемашина Melitta CAFFEO Lattea, фиолетовая</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-tefal-storeinn-do-3370r.php"><img src="photos/01c2ca770a8a823b21cf869aea4ab4ac.jpeg" alt="парогенератор пээ Кухонный комбайн Tefal Storeinn DO2081" title="парогенератор пээ Кухонный комбайн Tefal Storeinn DO2081"></a><h2>Кухонный комбайн Tefal Storeinn DO2081</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>приключения тостера Чайник электрический Vitek VT-1139 желтый</h1>
						<div class="tb"><p>Цена: от <span class="price">1120</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8398.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Превосходный электрический чайник <b>V</b><b>itek</b><b> VT-1139 </b>в стильном пластиком корпусе прекрасно дополнит интерьер вашей кухни. Скрытый нагревательный элемент находится в дисковой подставке, таким образом, что само устройство может вращаться на 360°. Среди особенностей модели можно отметить: наличие съемного фильтра от накипи, систему автоотключения при закипании воды и защиту от перегрева. Объем резервуара 1,7л.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 2000-2400Вт </li><li>Нагревательный элемент: скрытый </li><li>Поворачивающийся корпус: 360° </li><li>Объем: 1,7л </li><li>Материал корпуса: пластик </li><li>Фильтр: съемный фильтр от накипи </li><li>Двухсторонняя шкала уровня воды </li><li>Автоотключение при закипании воды: есть </li><li>Защита от перегрева: есть </li><li>Световой индикатор работы: есть </li><li>Место для хранения шнура: есть</li></ul><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> приключения тостера</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/09368438bc3c0f6d8d6445abd5f08674.jpeg" alt="отважный тостер скачать Микроволновая печь Vitek VT-1693" title="отважный тостер скачать Микроволновая печь Vitek VT-1693"><div class="box" page="mikrovolnovaya-pech-vitek-vt-4150r"><span class="title">отважный тостер скачать Микроволновая печь Vitek VT-1693</span><p>от <span class="price">4150</span> руб.</p></div></li>
						<li><img src="photos/d325e4ff8de4614af80db126de07173a.jpeg" alt="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8" title="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8"><div class="box" page="myasorubka-redmond-rmg-6690r"><span class="title">рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8</span><p>от <span class="price">6690</span> руб.</p></div></li>
						<li><img src="photos/df340437daa709a0dfc3dc87ab1880bc.jpeg" alt="сепараторный пылесос Индукционная плита Kitfort KT-102" title="сепараторный пылесос Индукционная плита Kitfort KT-102"><div class="box" page="indukcionnaya-plita-kitfort-kt-3000r"><span class="title">сепараторный пылесос Индукционная плита Kitfort KT-102</span><p>от <span class="price">3000</span> руб.</p></div></li>
						<li><img src="photos/5ddb7c0074c19c7852a8997f3b296d03.jpeg" alt="кофеварка нескафе дольче густо Порционные весы NP-5001S" title="кофеварка нескафе дольче густо Порционные весы NP-5001S"><div class="box" page="porcionnye-vesy-nps-5260r"><span class="title">кофеварка нескафе дольче густо Порционные весы NP-5001S</span><p>от <span class="price">5260</span> руб.</p></div></li>
						<li class="large"><img src="photos/60dff82992355ef436c4e763a78c1f99.jpeg" alt="купить кофемашину bosch Соковыжималка для цитрусовых" title="купить кофемашину bosch Соковыжималка для цитрусовых"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-760r"><span class="title">купить кофемашину bosch Соковыжималка для цитрусовых</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/aca42b878e4277b1730672f4f845a597.jpeg" alt="блендер braun mr 530 ca Чайник электрический Binatone NK-7700 Black" title="блендер braun mr 530 ca Чайник электрический Binatone NK-7700 Black"><div class="box" page="chaynik-elektricheskiy-binatone-nk-black-1200r"><span class="title">блендер braun mr 530 ca Чайник электрический Binatone NK-7700 Black</span><p>от <span class="price">1200</span> руб.</p></div></li>
						<li class="large"><img src="photos/67898b31f2a00b51820f96bc789fed43.jpeg" alt="купить пылесос зелмер Чайник электрический Maxima MК- M281" title="купить пылесос зелмер Чайник электрический Maxima MК- M281"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r"><span class="title">купить пылесос зелмер Чайник электрический Maxima MК- M281</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/df7a2601f4d7471689f34a2d1cbcf14f.jpeg" alt="купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO" title="купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2740r"><span class="title">купить блендер braun mr 6550 Электрический чайник 1,5л зеленый Bodum BISTRO 11138-565EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/27a529eb06db7d79aab6d5d214852413.jpeg" alt="какие лучше микроволновые печи Minamoto R03 (AAA)" title="какие лучше микроволновые печи Minamoto R03 (AAA)"><div class="box" page="minamoto-r-aaa-4r"><span class="title">какие лучше микроволновые печи Minamoto R03 (AAA)</span><p>от <span class="price">4</span> руб.</p></div></li>
						<li><img src="photos/457d4b7f3e82f96ca3e9bfa507402a8c.jpeg" alt="мясорубка помощница отзывы Фильтры для пылесоса Vitek VT-1859 (VT-1829)" title="мясорубка помощница отзывы Фильтры для пылесоса Vitek VT-1859 (VT-1829)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-215r"><span class="title">мясорубка помощница отзывы Фильтры для пылесоса Vitek VT-1859 (VT-1829)</span><p>от <span class="price">215</span> руб.</p></div></li>
						<li><img src="photos/54b10604c01ad075cc189094150a1393.jpeg" alt="хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP" title="хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP"><div class="box" page="schetka-s-myagkoy-schetinoy-v-upakovke-dyson-soft-dusting-brush-assy-retail-np-1390r"><span class="title">хлебопечка кефир Щетка с мягкой щетиной в упаковке Dyson Soft Dusting Brush Assy Retail NP</span><p>от <span class="price">1390</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-zheltyy-1120r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-zheltyy-1120r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-zheltyy-1120r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-zheltyy-1120r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>