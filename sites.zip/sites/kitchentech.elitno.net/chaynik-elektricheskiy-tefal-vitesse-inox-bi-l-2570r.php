<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r.php","соковыжималка садовая 302");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>соковыжималка садовая 302 Чайник электрический Tefal Vitesse Inox BI7625 1,7 л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="соковыжималка садовая 302, микроволновые печи gorenje, пылесос sc 4760h33, пылесос samsung vc 5853, микроволновая печь польза, рецепт индейки в мультиварке, распродажа пылесосов, пельмени в мультиварке на пару, куриные грудки в мультиварке, блендер philips hr1659, блендер braun mx 2050, ролсен аэрогриль, сколько стоит моющий пылесос, блендер vita mix,  плов в мультиварке супра">
		<meta name="description" content="соковыжималка садовая 302 Классика в металле – именно так можно охарактеризовать стильный электрический ча...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/c75538a0a02b722bb4d5b9c47eb925e7.jpeg" title="соковыжималка садовая 302 Чайник электрический Tefal Vitesse Inox BI7625 1,7 л"><img src="photos/c75538a0a02b722bb4d5b9c47eb925e7.jpeg" alt="соковыжималка садовая 302 Чайник электрический Tefal Vitesse Inox BI7625 1,7 л" title="соковыжималка садовая 302 Чайник электрический Tefal Vitesse Inox BI7625 1,7 л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blenderkuhonnyy-kombayn-braun-mr-patis-fp-k-hc-5750r.php"><img src="photos/71cf139444313d5f31f36765a5ef5edf.jpeg" alt="микроволновые печи gorenje Блендер-кухонный комбайн Braun MR-570 Patis FP K HC" title="микроволновые печи gorenje Блендер-кухонный комбайн Braun MR-570 Patis FP K HC"></a><h2>Блендер-кухонный комбайн Braun MR-570 Patis FP K HC</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mx-3910r.php"><img src="photos/5a6cc5c274d661a65ab52201c3f36a5e.jpeg" alt="пылесос sc 4760h33 Блендер Braun MX-2050" title="пылесос sc 4760h33 Блендер Braun MX-2050"></a><h2>Блендер Braun MX-2050</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhbm-chernyy-3790r.php"><img src="photos/3c3fb3bc3e413c2b55272e4aa6c67fdc.jpeg" alt="пылесос samsung vc 5853 Блендер Redmond RHB-M2904 (черный)" title="пылесос samsung vc 5853 Блендер Redmond RHB-M2904 (черный)"></a><h2>Блендер Redmond RHB-M2904 (черный)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>соковыжималка садовая 302 Чайник электрический Tefal Vitesse Inox BI7625 1,7 л</h1>
						<div class="tb"><p>Цена: от <span class="price">2570</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_10470.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Классика в металле – именно так можно охарактеризовать стильный <b>электрический чайник </b><b>Vitesse Inox BI7625</b> от известной французской торговой марки Tefal. Однако прибор не только украсит вашу кухню, но и будет ежедневно обеспечивать максимальный комфорт своим обладателям. Модель выполнена в металлическом корпусе, оснащена удобной эргономичной ручкой, кнопками автооткрывания и блокировки крышки, возможностью установки на подставку в любом положении. Вместимость чайника стандартная – 1,7 л, мощность – 2400 Вт, нагревательный элемент скрытый, из нержавеющей стали. Также прибор обладает съемным фильтром против накипи, двумя индикаторами уровня воды и отсеком для хранения шнура. Компания Tefal выпускает высококачественную функциональную продукцию по разумной цене.</p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 2400 Вт; <li>Объем: 1,7 л; <li>Скрытый нагревательный элемент из нержавеющей стали; <li>Съемный фильтр против накипи; <li>2 индикатора уровня воды; <li>Кнопка автоматического открывания крышки; <li>Кнопка блокировки крышки; <li>Блокировка включения без воды; <li>Корпус из металла; <li>Автоотключение; <li>Вращение на подставке на 360°; <li>Отсек для шнура; <li>Удобная эргономичная ручка; <li>Цвет: матовая нержавеющая сталь.</li></ul><p><b>Производитель:</b> Tefal.</p><p><b>Страна: </b>Франция.</p><p><b>Гарантия: </b>2 года.</p> соковыжималка садовая 302</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/39e04c91cf56d7c949379d4f2e2d6076.jpeg" alt="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная" title="микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная"><div class="box" page="avtomaticheskaya-kofemashina-melitta-caffeo-lattea-krasnaya-29530r"><span class="title">микроволновая печь польза Автоматическая кофемашина Melitta CAFFEO Lattea, красная</span><p>от <span class="price">29530</span> руб.</p></div></li>
						<li><img src="photos/1c87b1da99c709915f1f2bf9d89b2035.jpeg" alt="рецепт индейки в мультиварке Zauber Кофемолка  X-470" title="рецепт индейки в мультиварке Zauber Кофемолка  X-470"><div class="box" page="zauber-kofemolka-x-850r"><span class="title">рецепт индейки в мультиварке Zauber Кофемолка  X-470</span><p>от <span class="price">850</span> руб.</p></div></li>
						<li><img src="photos/7b88076a90f90c4718597a4ab977cb0a.jpeg" alt="распродажа пылесосов Микроволновая печь Vitek VT-1682" title="распродажа пылесосов Микроволновая печь Vitek VT-1682"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3550r"><span class="title">распродажа пылесосов Микроволновая печь Vitek VT-1682</span><p>от <span class="price">3550</span> руб.</p></div></li>
						<li><img src="photos/7b810f6db4d02163ddaea09283048313.jpeg" alt="пельмени в мультиварке на пару Электрический миксер Bodum BISTRO 11151-913EURO белый" title="пельмени в мультиварке на пару Электрический миксер Bodum BISTRO 11151-913EURO белый"><div class="box" page="elektricheskiy-mikser-bodum-bistro-euro-belyy-2740r"><span class="title">пельмени в мультиварке на пару Электрический миксер Bodum BISTRO 11151-913EURO белый</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li class="large"><img src="photos/b8600793aec4a8059c2de0136a79b6b1.jpeg" alt="куриные грудки в мультиварке Пароварка Redmond RST-1103" title="куриные грудки в мультиварке Пароварка Redmond RST-1103"><div class="box" page="parovarka-redmond-rst-2390r"><span class="title">куриные грудки в мультиварке Пароварка Redmond RST-1103</span><p>от <span class="price">2390</span> руб.</p></div></li>
						<li class="large"><img src="photos/eb489286225dbbc8037e4654ee2b1544.jpeg" alt="блендер philips hr1659 Чайник электрический Redmond  RK-M114" title="блендер philips hr1659 Чайник электрический Redmond  RK-M114"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2990r"><span class="title">блендер philips hr1659 Чайник электрический Redmond  RK-M114</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li class="large"><img src="photos/508d5d97fb58fc95875b08492316946f.jpeg" alt="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29" title="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29"><div class="box" page="pylesos-dyson-allergy-db-dc-19990r"><span class="title">блендер braun mx 2050 Пылесос Dyson allergy dB DC 29</span><p>от <span class="price">19990</span> руб.</p></div></li>
						<li><img src="photos/103d1dd79396034a787226c582b363d1.jpeg" alt="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter" title="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter"><div class="box" page="pylesos-thomas-power-edition-aquafilter-6220r"><span class="title">ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter</span><p>от <span class="price">6220</span> руб.</p></div></li>
						<li><img src="photos/03817b6f2ca60ce9b5c33914a6a1ea52.jpeg" alt="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter" title="сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter"><div class="box" page="pylesos-thomas-genius-aquafilter-9480r"><span class="title">сколько стоит моющий пылесос Пылесос Thomas Genius Aquafilter</span><p>от <span class="price">9480</span> руб.</p></div></li>
						<li><img src="photos/2784b5cdf9478bbd2439685d61179e80.jpeg" alt="блендер vita mix Сушилка для рук AEG Haustehnik HE 181" title="блендер vita mix Сушилка для рук AEG Haustehnik HE 181"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-5900r"><span class="title">блендер vita mix Сушилка для рук AEG Haustehnik HE 181</span><p>от <span class="price">5900</span> руб.</p></div></li>
						<li><img src="photos/e1389eb03e943fe040843f1f9d6c693c.jpeg" alt="центральный пылесос Утюг Vitek VT-1251 синий" title="центральный пылесос Утюг Vitek VT-1251 синий"><div class="box" page="utyug-vitek-vt-siniy-1500r"><span class="title">центральный пылесос Утюг Vitek VT-1251 синий</span><p>от <span class="price">1500</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r.php")) require_once "comments/chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>