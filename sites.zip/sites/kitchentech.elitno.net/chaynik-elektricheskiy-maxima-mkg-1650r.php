<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-maxima-mkg-1650r.php","мясорубка для гаек");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-maxima-mkg-1650r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мясорубка для гаек Чайник электрический Maxima MK-G311  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мясорубка для гаек, сломалась мясорубка, шарлотка в мультиварке панасоник, курица во фритюрнице, кухня микроволновой печи, кофеварка нескафе дольче густо, чайник электрический bork, хлебопечка борк отзывы, дозиметр рентгеновского излучения, греется пылесос, измельчитель kenwood, принцип работы кофемашины, измельчитель сучьев, стимер для аэрогриля,  слоеное тесто в аэрогриле">
		<meta name="description" content="мясорубка для гаек Вскипятить воду и заварить чай одновременно? Легко! Электрический чайник черного...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" title="мясорубка для гаек Чайник электрический Maxima MK-G311"><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="мясорубка для гаек Чайник электрический Maxima MK-G311" title="мясорубка для гаек Чайник электрический Maxima MK-G311 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rbp-1490r.php"><img src="photos/54c015da9ba000a4c33278978300bae5.jpeg" alt="сломалась мясорубка Блендер Redmond RB-P1301" title="сломалась мясорубка Блендер Redmond RB-P1301"></a><h2>Блендер Redmond RB-P1301</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-33650r.php"><img src="photos/3298e4cbe4a01ff3e30b40e0178e9164.jpeg" alt="шарлотка в мультиварке панасоник Кофемашина Nivona NICR730 CafeRomatica" title="шарлотка в мультиварке панасоник Кофемашина Nivona NICR730 CafeRomatica"></a><h2>Кофемашина Nivona NICR730 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-vitek-vt-2750r.php"><img src="photos/d3bcfc3d08cc302406de89eb814d0d80.jpeg" alt="курица во фритюрнице Кухонный комбайн Vitek VT-1622" title="курица во фритюрнице Кухонный комбайн Vitek VT-1622"></a><h2>Кухонный комбайн Vitek VT-1622</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мясорубка для гаек Чайник электрический Maxima MK-G311</h1>
						<div class="tb"><p>Цена: от <span class="price">1650</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18627.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Вскипятить воду и заварить чай одновременно? Легко! Электрический чайник черного цвета MK-G311 в стильном стеклянном корпусе объединяет в себе обычный и заварочный чайник. В результате – сэкономленное время, а ко всем прочим заслугам прибор может поддерживать заданную Вами температуру.<br>Также прибор автоматически выключится при закипании или при недостаточном уровне воды, а специальный фильтр защиты от накипи<br>Все эти неоспоримые плюсы и классический белый цвет, особенный дизайн стеклянного корпуса, нагревательный диск и чайная корзина из нержавеющей стали несомненно делают этот чайник прекрасным решением для любой кухни, особенно для любителей чаепитий.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Мощность 800-1000 Вт; <li>Емкость: 0,8 л; <li>Дисковый нагревательный элемент из нержавеющей стали; <li>Чайная корзина из нержавеющей стали; <li>Стеклянный корпус; <li>3 уровня установки температуры нагрева воды: <br>40С - для детского питания<br>80С - для многих сортов чая<br>100С - для кофе и черного чая <li>Угол вращения на подставке 360; <li>Автоматическое выключение при закипании; <li>Автоматическое отключение при недостаточном количестве воды; <li>Фильтр от накипи; <li>Светодиодная индикация работы. </li></ul><p><strong>Производитель: MAXIMA</strong><br><strong>Гарантия: 1 год</strong></p> мясорубка для гаек</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d13e770b0f20ea7295762dcccfd88ddd.jpeg" alt="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда" title="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда"><div class="box" page="elektroplitka-indukcionnaya-maxima-mic-posuda-1790r"><span class="title">кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li><img src="photos/5ddb7c0074c19c7852a8997f3b296d03.jpeg" alt="кофеварка нескафе дольче густо Порционные весы NP-5001S" title="кофеварка нескафе дольче густо Порционные весы NP-5001S"><div class="box" page="porcionnye-vesy-nps-5260r"><span class="title">кофеварка нескафе дольче густо Порционные весы NP-5001S</span><p>от <span class="price">5260</span> руб.</p></div></li>
						<li><img src="photos/cba9fd30236faeadb264f6621c9544f6.jpeg" alt="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер" title="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер"><div class="box" page="sokovyzhimalka-maxima-mj-blender-2190r"><span class="title">чайник электрический bork Соковыжималка Maxima MJ-049 + блендер</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/5cd90ccf1383ae054567f8f62fe579ca.jpeg" alt="хлебопечка борк отзывы Тостер Atlanta ATH-237" title="хлебопечка борк отзывы Тостер Atlanta ATH-237"><div class="box" page="toster-atlanta-ath-740r"><span class="title">хлебопечка борк отзывы Тостер Atlanta ATH-237</span><p>от <span class="price">740</span> руб.</p></div></li>
						<li class="large"><img src="photos/316a6aef2ce50d76bdf9280d8e11dad1.jpeg" alt="дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230" title="дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230"><div class="box" page="hlebopechka-moulinex-ow-4790r"><span class="title">дозиметр рентгеновского излучения Хлебопечка Moulinex OW302230</span><p>от <span class="price">4790</span> руб.</p></div></li>
						<li class="large"><img src="photos/f529cddb8b0b7bbdfe7eea8e3d43b5b1.jpeg" alt="греется пылесос Чайник электрический Atlanta ATH-752" title="греется пылесос Чайник электрический Atlanta ATH-752"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1600r-2"><span class="title">греется пылесос Чайник электрический Atlanta ATH-752</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li class="large"><img src="photos/d221c08cbc7532258ec107ff315e3516.jpeg" alt="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)" title="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)"><div class="box" page="personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r"><span class="title">измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)</span><p>от <span class="price">20500</span> руб.</p></div></li>
						<li><img src="photos/e961b6308ccdf7d3b60d75fd50d3cfe9.jpeg" alt="принцип работы кофемашины Порошок для сухой чистки ковровых покрытий Dyson Zorb Pouch UK EU" title="принцип работы кофемашины Порошок для сухой чистки ковровых покрытий Dyson Zorb Pouch UK EU"><div class="box" page="poroshok-dlya-suhoy-chistki-kovrovyh-pokrytiy-dyson-zorb-pouch-uk-eu-890r"><span class="title">принцип работы кофемашины Порошок для сухой чистки ковровых покрытий Dyson Zorb Pouch UK EU</span><p>от <span class="price">890</span> руб.</p></div></li>
						<li><img src="photos/59a8dfc6750ee21e49e7e4126ec09217.jpeg" alt="измельчитель сучьев Пылесос Dyson all floors DC 25" title="измельчитель сучьев Пылесос Dyson all floors DC 25"><div class="box" page="pylesos-dyson-all-floors-dc-28990r"><span class="title">измельчитель сучьев Пылесос Dyson all floors DC 25</span><p>от <span class="price">28990</span> руб.</p></div></li>
						<li><img src="photos/127daa75b6d910b9f123f08316795848.png" alt="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37" title="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37"><div class="box" page="pylesos-dyson-allergy-musclehead-dc-24590r"><span class="title">стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37</span><p>от <span class="price">24590</span> руб.</p></div></li>
						<li><img src="photos/2e3efb1596b4e1a5bf1803f0fd03710f.jpeg" alt="мультиварка телефункен Пылесос Thomas Inox 30 Professional" title="мультиварка телефункен Пылесос Thomas Inox 30 Professional"><div class="box" page="pylesos-thomas-inox-professional-7740r"><span class="title">мультиварка телефункен Пылесос Thomas Inox 30 Professional</span><p>от <span class="price">7740</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-maxima-mkg-1650r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-maxima-mkg-1650r.php")) require_once "comments/chaynik-elektricheskiy-maxima-mkg-1650r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-maxima-mkg-1650r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>