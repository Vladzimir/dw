<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitek-vt-1770r.php","vs 400331 пароварка");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitek-vt-1770r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>vs 400331 пароварка Чайник электрический Vitek VT-1158  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="vs 400331 пароварка, кофемашина saeco инструкция, видео приготовление в аэрогриле, мультиварки киев, тольятти мультиварка, выбор кофемашины, утюг какой фирмы лучше, рецепты для хлебопечки с сыром, как приготовить в аэрогриле овощи, маленькие соковыжималки, книга рецептов для хлебопечки, испечь черный хлеб в хлебопечке, сервисный центр кофемашин, держатель для пылесоса,  микроволновая печь дешево">
		<meta name="description" content="vs 400331 пароварка Оригинальный корпус электрического чайника Vitek VT-1158 – это превосходное соче...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/d816a9ba34d3c4cbee3c0f60a1fb92cf.jpeg" title="vs 400331 пароварка Чайник электрический Vitek VT-1158"><img src="photos/d816a9ba34d3c4cbee3c0f60a1fb92cf.jpeg" alt="vs 400331 пароварка Чайник электрический Vitek VT-1158" title="vs 400331 пароварка Чайник электрический Vitek VT-1158 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-blender-v-russell-hobbs-allure-art-3490r.php"><img src="photos/8eb90b2c93f90da38a9a78776cb9380e.jpeg" alt="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56" title="кофемашина saeco инструкция Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56"></a><h2>Ручной блендер 3в1 Russell Hobbs Allure, арт. 18274-56</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-nivona-nicr-caferomatica-36590r.php"><img src="photos/c26c66e7052b7c7adfb4026bf7ee1ec7.jpeg" alt="видео приготовление в аэрогриле Кофемашина Nivona NICR750 CafeRomatica" title="видео приготовление в аэрогриле Кофемашина Nivona NICR750 CafeRomatica"></a><h2>Кофемашина Nivona NICR750 CafeRomatica</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-ci-black-76390r.php"><img src="photos/4c9f6fc7185095b9ee0e389df903b9c9.jpeg" alt="мультиварки киев Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)" title="мультиварки киев Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)"></a><h2>Эспрессо-кофемашина Melitta Caffeo CI Black (4.0009.97)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>vs 400331 пароварка Чайник электрический Vitek VT-1158</h1>
						<div class="tb"><p>Цена: от <span class="price">1770</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_8410.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Оригинальный корпус электрического чайника <b>V</b><b>itek</b><b> VT-1158 – </b>это превосходное сочетание нержавеющей стали внизу и полупрозрачного пластика наверху, который также выступает в качестве индикатора уровня воды. Отличительными особенностями модели можно отметить: многоуровневую подсветку резервуара, соответствующую выбранному режиму; ЖК-дисплей, осуществляющий температурный контроль; возможность выбора оптимальных условий для заваривания кофе, а также зеленого и черного чая.</p><p><b>Технические характеристики:</b></p><p><b></b></p><ul><li>Мощность: 2000 - 2400Вт <li>Нагревательный элемент: скрытый <li>Поворачивающийся корпус: 360° <li>Объем: 1.5л <li>Материал корпуса: комбинация нержавеющий стали и пластика <li>Фильтр: есть <li>Индикатор уровня воды: большой полупрозрачный резервуар для воды <li>Автоотключение при закипании воды: есть <li>Защита от перегрева: есть <li>Световой индикатор работы: есть <li>Многоуровневая внутренняя подсветка резервуара, соответствующая выбранному уровню температуры и режиму работы <li>ЖК дисплей - электронный контроль температуры воды и функция поддержания температуры <li>Функция подержания температуры: есть <li>Место для хранения шнура: есть <li>Возможность выбора оптимальной температуры для заваривания кофе, зеленого или черного чая</li></ul><p><b></b></p><p><b>Производитель:</b> Vitek.</p><p><b>Страна: </b>Россия.</p> vs 400331 пароварка</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/833ae77791168206a3b151985fda9a0b.jpeg" alt="тольятти мультиварка Кофемолка Maxima MCG-0316" title="тольятти мультиварка Кофемолка Maxima MCG-0316"><div class="box" page="kofemolka-maxima-mcg-650r"><span class="title">тольятти мультиварка Кофемолка Maxima MCG-0316</span><p>от <span class="price">650</span> руб.</p></div></li>
						<li><img src="photos/4f2572ea69a163b235386a6893a52b4a.jpeg" alt="выбор кофемашины Прибор для вакуумной упаковки Vacuum Sealer 024V" title="выбор кофемашины Прибор для вакуумной упаковки Vacuum Sealer 024V"><div class="box" page="pribor-dlya-vakuumnoy-upakovki-vacuum-sealer-v-1100r"><span class="title">выбор кофемашины Прибор для вакуумной упаковки Vacuum Sealer 024V</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/ff295724863185ff22e2c85236f25515.jpeg" alt="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый" title="утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый"><div class="box" page="bodum-bistro-euro-elektricheskiy-mikser-zelenyy-2740r"><span class="title">утюг какой фирмы лучше Bodum BISTRO 11151-565EURO Электрический миксер зеленый</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/f522dce957deccc1ec8ad4658577e80b.jpeg" alt="рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330" title="рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330"><div class="box" page="multivarka-moulinex-mk-4170r"><span class="title">рецепты для хлебопечки с сыром Мультиварка Moulinex MK700330</span><p>от <span class="price">4170</span> руб.</p></div></li>
						<li class="large"><img src="photos/86f0983e51433a2aeee203a14fbe12b2.jpeg" alt="как приготовить в аэрогриле овощи A&D SF-15KC Торговые весы до 15кг" title="как приготовить в аэрогриле овощи A&D SF-15KC Торговые весы до 15кг"><div class="box" page="ad-sfkc-torgovye-vesy-do-kg-10800r"><span class="title">как приготовить в аэрогриле овощи A&D SF-15KC Торговые весы до 15кг</span><p>от <span class="price">10800</span> руб.</p></div></li>
						<li class="large"><img src="photos/fe37fe3249ac15c2c7299f94675336f3.jpeg" alt="маленькие соковыжималки Тостер черный Bodum BISTRO 10709-01EURO" title="маленькие соковыжималки Тостер черный Bodum BISTRO 10709-01EURO"><div class="box" page="toster-chernyy-bodum-bistro-euro-3660r"><span class="title">маленькие соковыжималки Тостер черный Bodum BISTRO 10709-01EURO</span><p>от <span class="price">3660</span> руб.</p></div></li>
						<li class="large"><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li><img src="photos/388c2880498e546d8fcebc787f1cf894.jpeg" alt="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO" title="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO"><div class="box" page="elektricheskiy-chaynik-l-chernyy-bodum-bistro-euro-2270r"><span class="title">испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li><img src="photos/e19a6a84ed749d263503c61eb89d253b.jpeg" alt="сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4" title="сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-80r"><span class="title">сервисный центр кофемашин Батарейка GP Batteries Super alkaline LR6 15A-BC4</span><p>от <span class="price">80</span> руб.</p></div></li>
						<li><img src="photos/d9b92094264662e2a4b171c525a4ead7.jpeg" alt="держатель для пылесоса Пылесос Thomas Biovac 1620 C Aquafilter" title="держатель для пылесоса Пылесос Thomas Biovac 1620 C Aquafilter"><div class="box" page="pylesos-thomas-biovac-c-aquafilter-8430r"><span class="title">держатель для пылесоса Пылесос Thomas Biovac 1620 C Aquafilter</span><p>от <span class="price">8430</span> руб.</p></div></li>
						<li><img src="photos/45b64b122ef998f1bbed00c81620bedc.jpeg" alt="соковыжималка прессового отжима Vitesse VS-656 Утюг" title="соковыжималка прессового отжима Vitesse VS-656 Утюг"><div class="box" page="vitesse-vs-utyug-1800r"><span class="title">соковыжималка прессового отжима Vitesse VS-656 Утюг</span><p>от <span class="price">1800</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitek-vt-1770r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitek-vt-1770r.php")) require_once "comments/chaynik-elektricheskiy-vitek-vt-1770r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitek-vt-1770r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>