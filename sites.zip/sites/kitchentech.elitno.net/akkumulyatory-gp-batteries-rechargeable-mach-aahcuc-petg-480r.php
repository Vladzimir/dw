<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r.php","пылесос metabo");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос metabo Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос metabo, ручной блендер hr1659, купить хорошую кофеварку, соковыжималка ангел, рецепты для мультиварки viconte, quigg хлебопечка, хлебопечка борк отзывы, купить пылесос зелмер, кофемашины оптом, термопот toshiba, слоеное тесто в аэрогриле, средство от накипи для утюга, покрытие микроволновой печи, диски для кухонного комбайна,  профессиональные кофемолки">
		<meta name="description" content="пылесос metabo Аккумуляторы NiMh типа АА от GP Batteries разработаны в соответствии с современн...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/b29beb2174e6fe7aaeffea7945e79604.jpeg" title="пылесос metabo Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G"><img src="photos/b29beb2174e6fe7aaeffea7945e79604.jpeg" alt="пылесос metabo Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G" title="пылесос metabo Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/multivarka-maruchi-rwfz-4000r.php"><img src="photos/2118e94c9f54fd8ac8f1f2abebe50fe3.jpeg" alt="ручной блендер hr1659 Мультиварка Maruchi RW-FZ47" title="ручной блендер hr1659 Мультиварка Maruchi RW-FZ47"></a><h2>Мультиварка Maruchi RW-FZ47</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-vitek-vt-3500r.php"><img src="photos/b9289aece9f2ba28fb98a0e04eb84d01.jpeg" alt="купить хорошую кофеварку Мясорубка электрическая Vitek VT-1674" title="купить хорошую кофеварку Мясорубка электрическая Vitek VT-1674"></a><h2>Мясорубка электрическая Vitek VT-1674</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-maxima-mst-1290r.php"><img src="photos/21689be9dc7c8e66c7cb248c7b6f5f86.jpeg" alt="соковыжималка ангел Пароварка Maxima MST-1102" title="соковыжималка ангел Пароварка Maxima MST-1102"></a><h2>Пароварка Maxima MST-1102</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос metabo Аккумуляторы GP Batteries Rechargeable 2700 мАч 270AAHC-UC2 PET-G</h1>
						<div class="tb"><p>Цена: от <span class="price">480</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16536.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Аккумуляторы NiMh типа АА от GP Batteries разработаны в соответствии с современными особенностями портативных устройств. К примеру, зарядка цифрового фотоаппарата с такими элементами питания обеспечит непрерывную работу в 4 раза дольше, чем алкалиновые батарейки.</p><p>Среди особенностей можно отметить: отличную способность разряжаться большими токами, быструю зарядку, до 1000 циклов заряда-разряда, а также экологическую безопасность. В комплекте 2 штуки.</p><p><b>Характеристики:</b></p><ul type=disc><li>Технология производства: NiMh <li>Типоразмер: AA <li>Максимальная емкость: 2700мАч <li>Напряжение: 1,2V <li>Имеют длительный срок службы (до 1000 циклов заряд/разряд) <li>Характеризуются стабильной работой в широком диапазоне температур (от –20 до +50С) <li>Полностью отсутствует \эффект памяти\ <li>Оснащены предохранительными клапанами (для избегания последствий нарушения условий эксплуатации) <li>Не содержат ртути и кадмия – безопасны для окружающей среды </li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p> пылесос metabo</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/602afbefdc154f32c668e628ed57301c.jpeg" alt="рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903" title="рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903"><div class="box" page="sokovyzhimalka-maxima-mjm-1850r"><span class="title">рецепты для мультиварки viconte Соковыжималка Maxima MJ-M903</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li><img src="photos/ba4426ec9ff105596978c39d5f7ff4de.jpeg" alt="quigg хлебопечка Соковыжималка для цитрусовых 304-CP" title="quigg хлебопечка Соковыжималка для цитрусовых 304-CP"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-cp-1300r"><span class="title">quigg хлебопечка Соковыжималка для цитрусовых 304-CP</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li><img src="photos/5cd90ccf1383ae054567f8f62fe579ca.jpeg" alt="хлебопечка борк отзывы Тостер Atlanta ATH-237" title="хлебопечка борк отзывы Тостер Atlanta ATH-237"><div class="box" page="toster-atlanta-ath-740r"><span class="title">хлебопечка борк отзывы Тостер Atlanta ATH-237</span><p>от <span class="price">740</span> руб.</p></div></li>
						<li><img src="photos/67898b31f2a00b51820f96bc789fed43.jpeg" alt="купить пылесос зелмер Чайник электрический Maxima MК- M281" title="купить пылесос зелмер Чайник электрический Maxima MК- M281"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r"><span class="title">купить пылесос зелмер Чайник электрический Maxima MК- M281</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/78965fa03e391297ff5141e1ed5d2961.jpeg" alt="кофемашины оптом Электрический чайник Atlanta АТН-721" title="кофемашины оптом Электрический чайник Atlanta АТН-721"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r"><span class="title">кофемашины оптом Электрический чайник Atlanta АТН-721</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li class="large"><img src="photos/403a4b4ef798c09cf151962161efdcea.jpeg" alt="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый" title="термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый"><div class="box" page="elektricheskiy-chaynik-metallicheskiy-atlanta-ath-zelenyy-880r"><span class="title">термопот toshiba Электрический чайник металлический ATLANTA ATH-784, зеленый</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li class="large"><img src="photos/b28d3e929be020189d8c25424817be16.jpeg" alt="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO" title="слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO"><div class="box" page="elektricheskiy-chaynik-l-zelenyy-bodum-bistro-euro-2270r"><span class="title">слоеное тесто в аэрогриле Электрический чайник 1л зеленый Bodum BISTRO 11154-565EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li><img src="photos/05c48dbba69cff2727e6c1b6d1112395.jpeg" alt="средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2" title="средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2"><div class="box" page="batareyki-gp-batteries-super-alkaline-lr-abc-170r"><span class="title">средство от накипи для утюга Батарейки GP Batteries Super alkaline LR20 13A-BC2</span><p>от <span class="price">170</span> руб.</p></div></li>
						<li><img src="photos/e60d974a9eb12d238a3e8bae6f4ce905.jpeg" alt="покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)" title="покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)"><div class="box" page="soplo-dlya-pennoy-chistki-karcher-upakovka-l-670r"><span class="title">покрытие микроволновой печи Сопло для пенной чистки Karcher (упаковка 0,3 л)</span><p>от <span class="price">670</span> руб.</p></div></li>
						<li><img src="photos/6eaac51c54fbf44dce471193ec6d5c18.jpeg" alt="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail" title="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail"><div class="box" page="nabor-dlya-udaleniya-pyaten-s-kovrovyh-pokrytiy-i-myagkoy-mebeli-dyson-party-cleanup-kit-ir-cl-retail-2490r"><span class="title">диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/08939404bc185a897cf2a335ea28842f.jpeg" alt="пылесос вертикальный Пылесос Redmond RV-308" title="пылесос вертикальный Пылесос Redmond RV-308"><div class="box" page="pylesos-redmond-rv-7990r"><span class="title">пылесос вертикальный Пылесос Redmond RV-308</span><p>от <span class="price">7990</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r.php", 0, -4); if (file_exists("comments/akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r.php")) require_once "comments/akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="akkumulyatory-gp-batteries-rechargeable-mach-aahcuc-petg-480r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>