<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r.php","турбощетка для пылесоса самсунг");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>турбощетка для пылесоса самсунг Зарядное устройство GP Batteries PB350GS-UE1  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="турбощетка для пылесоса самсунг, кофеварка делонги отзывы, язык в аэрогриле, чалдовые кофеварки, мешки для пылесоса vax, пылесос samsung sc4520, хлебопечка в техносиле, купить кофемашину bosch, купить вертикальный утюг, пылесос thomas s1, бытовые микроволновые печи, хлебопечка советы, бытовой утюг, микроволновые печи в москве,  температура утюга">
		<meta name="description" content="турбощетка для пылесоса самсунг Компактное зарядное устройство размером 4,4х10,5х4,6см подходит для зарядки нике...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/61cc3edb3bfd24a6709976ba33646660.jpeg" title="турбощетка для пылесоса самсунг Зарядное устройство GP Batteries PB350GS-UE1"><img src="photos/61cc3edb3bfd24a6709976ba33646660.jpeg" alt="турбощетка для пылесоса самсунг Зарядное устройство GP Batteries PB350GS-UE1" title="турбощетка для пылесоса самсунг Зарядное устройство GP Batteries PB350GS-UE1 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/izmelchitel-ritter-mc-2700r.php"><img src="photos/b329bc8334f65653dc9ef4683c170e62.jpeg" alt="кофеварка делонги отзывы Измельчитель Ritter MC 800" title="кофеварка делонги отзывы Измельчитель Ritter MC 800"></a><h2>Измельчитель Ritter MC 800</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-solo-pure-white-28530r.php"><img src="photos/eb4618ce7491ec77cbaa3b4b7dd675cb.jpeg" alt="язык в аэрогриле Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)" title="язык в аэрогриле Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Solo Pure White (4.0009.91)</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-gourmet-chernaya-43999r.php"><img src="photos/a59c30a3b2d8957f43e9fce5f7b6e0f5.jpeg" alt="чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная" title="чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная"></a><h2>Автоматическая кофемашина Melitta CAFFEO GOURMET, черная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>турбощетка для пылесоса самсунг Зарядное устройство GP Batteries PB350GS-UE1</h1>
						<div class="tb"><p>Цена: от <span class="price">340</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16540.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Компактное зарядное устройство размером 4,4х10,5х4,6см подходит для зарядки никель-металлогидридных аккумуляторов типа АА и ААА. Время зарядки составляет 13 часов. На устройстве расположено два слота для элементов питания, а также световые индикаторы.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: Зарядное устройство <li>Тип заряжаемых аккумуляторов: NiMH <li>Заряжает AA: Да <li>Заряжает AAA: Да <li>Время заряда: 13 ч <li>Количество слотов: 2 <li>Количество каналов: 2 <li>Размеры (ШхГхВ): 4,4х10,5х4,6 см</li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p><p><b>Гарантия: </b>6 месяцев.</p> турбощетка для пылесоса самсунг</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/4a49eabd132fa073a575c3edfbe7b80b.jpeg" alt="мешки для пылесоса vax Микроволновая печь Vitek VT-1681" title="мешки для пылесоса vax Микроволновая печь Vitek VT-1681"><div class="box" page="mikrovolnovaya-pech-vitek-vt-2770r"><span class="title">мешки для пылесоса vax Микроволновая печь Vitek VT-1681</span><p>от <span class="price">2770</span> руб.</p></div></li>
						<li><img src="photos/7c640af98399cc1caf99796cb169cc20.jpeg" alt="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная" title="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная"><div class="box" page="myasorubka-elektricheskaya-vitek-vt-serebryanaya-3650r"><span class="title">пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная</span><p>от <span class="price">3650</span> руб.</p></div></li>
						<li><img src="photos/bbb4b27b3d39658b85227dbb77539d16.jpeg" alt="хлебопечка в техносиле Весы электронные для багажа Beurer LS 10" title="хлебопечка в техносиле Весы электронные для багажа Beurer LS 10"><div class="box" page="vesy-elektronnye-dlya-bagazha-beurer-ls-1100r"><span class="title">хлебопечка в техносиле Весы электронные для багажа Beurer LS 10</span><p>от <span class="price">1100</span> руб.</p></div></li>
						<li><img src="photos/60dff82992355ef436c4e763a78c1f99.jpeg" alt="купить кофемашину bosch Соковыжималка для цитрусовых" title="купить кофемашину bosch Соковыжималка для цитрусовых"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-760r"><span class="title">купить кофемашину bosch Соковыжималка для цитрусовых</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li class="large"><img src="photos/d50e72b2ec5f0dd45f81986f6b14d95a.jpeg" alt="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56" title="купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56"><div class="box" page="toster-russell-hobbs-jungle-green-art-1890r"><span class="title">купить вертикальный утюг Тостер Russell Hobbs Jungle Green, арт. 18338-56</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li class="large"><img src="photos/c73e008984140d52a15fd324bddeb59f.jpeg" alt="пылесос thomas s1 Чайник электрический Vitek VT-1141" title="пылесос thomas s1 Чайник электрический Vitek VT-1141"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1350r-2"><span class="title">пылесос thomas s1 Чайник электрический Vitek VT-1141</span><p>от <span class="price">1350</span> руб.</p></div></li>
						<li class="large"><img src="photos/4fcdbef1e4068bc4641fdad47e086ca6.jpeg" alt="бытовые микроволновые печи Парогенератор Maxima MSC-2001" title="бытовые микроволновые печи Парогенератор Maxima MSC-2001"><div class="box" page="parogenerator-maxima-msc-1650r"><span class="title">бытовые микроволновые печи Парогенератор Maxima MSC-2001</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/cc9208f636d59db8c6c0a8ac95064dc7.jpeg" alt="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0" title="хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0"><div class="box" page="shlang-podachi-vody-c-filtrom-karcher-1750r"><span class="title">хлебопечка советы Шланг подачи воды c фильтром Karcher 4.440-238.0</span><p>от <span class="price">1750</span> руб.</p></div></li>
						<li><img src="photos/100a2bcb8188ff9463a9e3368c849858.jpeg" alt="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit" title="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit"><div class="box" page="nabor-dlya-uborki-v-avtomobile-dyson-car-cleaning-kit-2790r"><span class="title">бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit</span><p>от <span class="price">2790</span> руб.</p></div></li>
						<li><img src="photos/11c7c6ddf93edcdf0c5e620d5363815f.jpeg" alt="микроволновые печи в москве Пылесос Vitek VT-1844" title="микроволновые печи в москве Пылесос Vitek VT-1844"><div class="box" page="pylesos-vitek-vt-3250r"><span class="title">микроволновые печи в москве Пылесос Vitek VT-1844</span><p>от <span class="price">3250</span> руб.</p></div></li>
						<li><img src="photos/2bc01cf0e5d557324370d108b991f168.jpeg" alt="бытовая техника пылесосы Пылесос Thomas Inox 45 S Professional" title="бытовая техника пылесосы Пылесос Thomas Inox 45 S Professional"><div class="box" page="pylesos-thomas-inox-s-professional-11290r"><span class="title">бытовая техника пылесосы Пылесос Thomas Inox 45 S Professional</span><p>от <span class="price">11290</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r.php", 0, -4); if (file_exists("comments/zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r.php")) require_once "comments/zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>