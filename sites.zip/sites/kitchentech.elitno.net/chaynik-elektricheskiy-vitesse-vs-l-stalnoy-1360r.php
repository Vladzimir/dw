<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r.php","пылесосы в тольятти");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесосы в тольятти Чайник электрический  Vitesse VS-115 1,7л стальной  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесосы в тольятти, кофеварка delonghi eco 310, выбор микроволновой печи, электрическая мультиварка, пылесос samsung sc4520, где купить ручную мясорубку, кофеварка эспрессо krups, сколько стоит пылесос, форум микроволновая печь, clatronic хлебопечка, panasonic мясорубка отзывы, магазин запчастей для мясорубок, mini пылесос, качество пылесосов,  температура утюга">
		<meta name="description" content="пылесосы в тольятти В стильном стальном корпусе электрического чайника Vitesse  VS-115 за считанные ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3e5de65e23113a4dedb018c90159e3df.jpeg" title="пылесосы в тольятти Чайник электрический  Vitesse VS-115 1,7л стальной"><img src="photos/3e5de65e23113a4dedb018c90159e3df.jpeg" alt="пылесосы в тольятти Чайник электрический  Vitesse VS-115 1,7л стальной" title="пылесосы в тольятти Чайник электрический  Vitesse VS-115 1,7л стальной -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mx-2400r.php"><img src="photos/c875beb952f9d6580895bee02e6ce554.jpeg" alt="кофеварка delonghi eco 310 Блендер Braun MX-2000" title="кофеварка delonghi eco 310 Блендер Braun MX-2000"></a><h2>Блендер Braun MX-2000</h2></li>
							<li><a href="http://kitchentech.elitno.net/vspenivatel-melitta-cremio-krasnyy-4155r.php"><img src="photos/0b57a5fa2564b3001e847ebdd45ce976.jpeg" alt="выбор микроволновой печи Вспениватель Melitta Cremio красный" title="выбор микроволновой печи Вспениватель Melitta Cremio красный"></a><h2>Вспениватель Melitta Cremio красный</h2></li>
							<li><a href="http://kitchentech.elitno.net/yogurtnica-maxima-mym-990r.php"><img src="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" alt="электрическая мультиварка Йогуртница Maxima MYM-0154" title="электрическая мультиварка Йогуртница Maxima MYM-0154"></a><h2>Йогуртница Maxima MYM-0154</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесосы в тольятти Чайник электрический  Vitesse VS-115 1,7л стальной</h1>
						<div class="tb"><p>Цена: от <span class="price">1360</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19622.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>В стильном стальном корпусе электрического чайника Vitesse  VS-115 за считанные минуты вскипятит 1,7 литра воды, специальный съемный фильтр  защитит от накипи, автоматика выключит чайник при закипании и заблокирует  включение при отсутствии воды, а шнур удобно хранить в специальном отсеке.</p><p><strong>Характеристики:</strong></p><ul type=\disc\><li>Объем: 1.7 л;</li><li>Мощность:  2200 Вт;</li><li>Тип  нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал корпуса: металл;</li><li>Блокировка  включения без воды;</li><li>Фильтр;</li><li>Индикация  включения;</li><li>Отсек для шнура.</li></ul><p><strong>Производитель: КНР</strong></p><strong>Гарантия:  1 год</strong> пылесосы в тольятти</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7c640af98399cc1caf99796cb169cc20.jpeg" alt="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная" title="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная"><div class="box" page="myasorubka-elektricheskaya-vitek-vt-serebryanaya-3650r"><span class="title">пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная</span><p>от <span class="price">3650</span> руб.</p></div></li>
						<li><img src="photos/16c51a83d3b90dc92106b51b933b769e.jpeg" alt="где купить ручную мясорубку Чайник электрический Binatone MEJ-1780 Mat Metal" title="где купить ручную мясорубку Чайник электрический Binatone MEJ-1780 Mat Metal"><div class="box" page="chaynik-elektricheskiy-binatone-mej-mat-metal-1500r"><span class="title">где купить ручную мясорубку Чайник электрический Binatone MEJ-1780 Mat Metal</span><p>от <span class="price">1500</span> руб.</p></div></li>
						<li><img src="photos/0fb0d4eda0d01d4692f2fbd689f6f46f.jpeg" alt="кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л" title="кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitek-vt-l-1890r"><span class="title">кофеварка эспрессо krups Чайник электрический Vitek VT-1112 1,7 л</span><p>от <span class="price">1890</span> руб.</p></div></li>
						<li><img src="photos/463a93164abee7f214102b8fe77a244c.jpeg" alt="сколько стоит пылесос Чайник электрический Atlanta ATH-690" title="сколько стоит пылесос Чайник электрический Atlanta ATH-690"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1280r"><span class="title">сколько стоит пылесос Чайник электрический Atlanta ATH-690</span><p>от <span class="price">1280</span> руб.</p></div></li>
						<li class="large"><img src="photos/b4a95c8a4ccd80ea8dd5b10c9fcfd32c.jpeg" alt="форум микроволновая печь Чайник электрический Maxima MК-112" title="форум микроволновая печь Чайник электрический Maxima MК-112"><div class="box" page="chaynik-elektricheskiy-maxima-mk-790r"><span class="title">форум микроволновая печь Чайник электрический Maxima MК-112</span><p>от <span class="price">790</span> руб.</p></div></li>
						<li class="large"><img src="photos/1bbdc32e5167c3f95a77515679aaf9df.jpeg" alt="clatronic хлебопечка Электрический чайник Atlanta АТН-700" title="clatronic хлебопечка Электрический чайник Atlanta АТН-700"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1280r"><span class="title">clatronic хлебопечка Электрический чайник Atlanta АТН-700</span><p>от <span class="price">1280</span> руб.</p></div></li>
						<li class="large"><img src="photos/0f99b07bf5e19dab36f8028f75c48889.jpeg" alt="panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735" title="panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-450r"><span class="title">panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735</span><p>от <span class="price">450</span> руб.</p></div></li>
						<li><img src="photos/ed6cccd8ae597a978fe91c415f9d06d3.jpeg" alt="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)" title="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-135r"><span class="title">магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)</span><p>от <span class="price">135</span> руб.</p></div></li>
						<li><img src="photos/28da988d46134dfe1236e7598e0579cc.jpeg" alt="mini пылесос Турбощетка Redmond  RV-308" title="mini пылесос Турбощетка Redmond  RV-308"><div class="box" page="turboschetka-redmond-rv-390r"><span class="title">mini пылесос Турбощетка Redmond  RV-308</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/dcfd8cc55439cd877d074c0e060c75d4.jpeg" alt="качество пылесосов Пылесос Vitek VT-1809 красный" title="качество пылесосов Пылесос Vitek VT-1809 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-2600r"><span class="title">качество пылесосов Пылесос Vitek VT-1809 красный</span><p>от <span class="price">2600</span> руб.</p></div></li>
						<li><img src="photos/9ae1fe09fe7308adffccf86c925a5fca.jpeg" alt="мясорубка 6061 Пылесос Thomas Inox 20 Professional" title="мясорубка 6061 Пылесос Thomas Inox 20 Professional"><div class="box" page="pylesos-thomas-inox-professional-6220r"><span class="title">мясорубка 6061 Пылесос Thomas Inox 20 Professional</span><p>от <span class="price">6220</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1360r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>