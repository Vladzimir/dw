<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1850r.php","аэрогриль время приготовления");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1850r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>аэрогриль время приготовления Чайник электрический  Vitesse VS-107 1,7л, стальной  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="аэрогриль время приготовления, утюг для сварки полипропиленовых труб, цилиндрические пылесосы, пылесос старый, bierhof кухонный комбайн, ножки в аэрогриле, хлебопечки панасоник инструкция, пылесос биматек, кофемашина bosch 5201, запчасти для блендера braun, kenwood пароварка, диски для кухонного комбайна, куриные грудки в аэрогриле, видео хлебопечка панасоник,  рецепты для мультиварки dex">
		<meta name="description" content="аэрогриль время приготовления Стальной электрический чайник строгого дизайна Vitesse VS-107 легко вскипятит 1,...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/296e5671e5f65168bbfd694532a2c751.jpeg" title="аэрогриль время приготовления Чайник электрический  Vitesse VS-107 1,7л, стальной"><img src="photos/296e5671e5f65168bbfd694532a2c751.jpeg" alt="аэрогриль время приготовления Чайник электрический  Vitesse VS-107 1,7л, стальной" title="аэрогриль время приготовления Чайник электрический  Vitesse VS-107 1,7л, стальной -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kofeynoe-zerno-v-belom-shokolade-melitta-60r-2.php"><img src="photos/c7135ebb16439ee300797217e2768779.png" alt="утюг для сварки полипропиленовых труб Кофейное зерно в белом шоколаде Melitta" title="утюг для сварки полипропиленовых труб Кофейное зерно в белом шоколаде Melitta"></a><h2>Кофейное зерно в белом шоколаде Melitta</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2190r.php"><img src="photos/1546b6eb4b08215189976c86afe6dd84.jpeg" alt="цилиндрические пылесосы Блендер Redmond RHB-2905" title="цилиндрические пылесосы Блендер Redmond RHB-2905"></a><h2>Блендер Redmond RHB-2905</h2></li>
							<li><a href="http://kitchentech.elitno.net/blendermaxima-mhb-760r.php"><img src="photos/29743842b370217cef729ce30e8386c4.jpeg" alt="пылесос старый БлендерMaxima MHB-0629" title="пылесос старый БлендерMaxima MHB-0629"></a><h2>БлендерMaxima MHB-0629</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>аэрогриль время приготовления Чайник электрический  Vitesse VS-107 1,7л, стальной</h1>
						<div class="tb"><p>Цена: от <span class="price">1850</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19597.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Стальной электрический чайник строгого дизайна Vitesse VS-107 легко вскипятит 1,7 литра воды за несколько минут, специальный фильтр защитит от  накипи, а автоматическая блокировка не даст поставить чайник без воды, также  удобно хранить шнур в специальном отсеке.</p><p><br><strong>Характеристики:</strong></p><ul type=\disc\><li>Объем:  1.7 л;</li><li>Мощность:  2200 Вт;</li><li>Тип нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал корпуса: металл;</li><li>Безопасность блокировка включения без воды;</li><li>Фильтр;</li><li>Индикация включения;</li><li>Отсек для шнура.</li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong><strong></strong></p> аэрогриль время приготовления</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/502f3c027327d4b33adc28c2b2f5d085.jpeg" alt="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica" title="bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica"><div class="box" page="kofemashina-nivona-nicr-caferomatica-73690r"><span class="title">bierhof кухонный комбайн Кофемашина Nivona NICR850 CafeRomatica</span><p>от <span class="price">73690</span> руб.</p></div></li>
						<li><img src="photos/3efeed2a40b596512ea138d7f6d2f182.jpeg" alt="ножки в аэрогриле Термопот Binatone TP-4055 White" title="ножки в аэрогриле Термопот Binatone TP-4055 White"><div class="box" page="termopot-binatone-tp-white-1990r"><span class="title">ножки в аэрогриле Термопот Binatone TP-4055 White</span><p>от <span class="price">1990</span> руб.</p></div></li>
						<li><img src="photos/0a3cf9abc3fc820de574913fb2ebcdd1.jpeg" alt="хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка" title="хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка"><div class="box" page="vitesse-vs-hlebopechka-5200r"><span class="title">хлебопечки панасоник инструкция Vitesse VS-422 Хлебопечка</span><p>от <span class="price">5200</span> руб.</p></div></li>
						<li><img src="photos/d23d3c42279f2a4fe0ce1702af341b90.jpeg" alt="пылесос биматек Чайник электрический Atlanta ATH-755" title="пылесос биматек Чайник электрический Atlanta ATH-755"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-950r"><span class="title">пылесос биматек Чайник электрический Atlanta ATH-755</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/ad9a939cae5c8a1c68f17220dbb422a8.jpeg" alt="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый" title="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belyy-1080r"><span class="title">кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li class="large"><img src="photos/e766dc7a6c0cf1b164fee2cb011a81f8.jpeg" alt="запчасти для блендера braun Чайник Vitek VT-1163" title="запчасти для блендера braun Чайник Vitek VT-1163"><div class="box" page="chaynik-vitek-vt-990r"><span class="title">запчасти для блендера braun Чайник Vitek VT-1163</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/97ad6f71f59b7db73d8fda12c75e94a2.jpeg" alt="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2" title="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-680r"><span class="title">kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2</span><p>от <span class="price">680</span> руб.</p></div></li>
						<li><img src="photos/6eaac51c54fbf44dce471193ec6d5c18.jpeg" alt="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail" title="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail"><div class="box" page="nabor-dlya-udaleniya-pyaten-s-kovrovyh-pokrytiy-i-myagkoy-mebeli-dyson-party-cleanup-kit-ir-cl-retail-2490r"><span class="title">диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/2bd3efe5f6abbadb315d0281a9a3d70f.jpeg" alt="куриные грудки в аэрогриле Пылесос Vitek VT-1810" title="куриные грудки в аэрогриле Пылесос Vitek VT-1810"><div class="box" page="pylesos-vitek-vt-2150r"><span class="title">куриные грудки в аэрогриле Пылесос Vitek VT-1810</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/64dc96f26f782ba3e39f0fd329fa03d0.jpeg" alt="видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C" title="видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C"><div class="box" page="pylesos-thomas-power-pack-c-4740r"><span class="title">видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C</span><p>от <span class="price">4740</span> руб.</p></div></li>
						<li><img src="photos/52337874dcd8ef0b9c93b02b2fe2cfac.jpeg" alt="соковыжималка juice Пылесос Thomas Power Pack 1630" title="соковыжималка juice Пылесос Thomas Power Pack 1630"><div class="box" page="pylesos-thomas-power-pack-5240r"><span class="title">соковыжималка juice Пылесос Thomas Power Pack 1630</span><p>от <span class="price">5240</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1850r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1850r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1850r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-l-stalnoy-1850r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>