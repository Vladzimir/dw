<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r.php","кухонный комбайн заказать");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>кухонный комбайн заказать Чайник электрический  Vitesse VS-112, дорожный 0,8л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="кухонный комбайн заказать, приготовление куры в аэрогриле, кофеварка philips отзывы, чалдовые кофеварки, спагетти в мультиварке, форум микроволновая печь, bamix блендер отзывы, запчасти пылесос томас, аренда промышленного пылесоса, кофеварка vitek 1513, бытовые микроволновые печи, купить мультиварку панасоник, мешки пылесборники для пылесосов, мини пылесос для дома,  микроволновая печь vitek">
		<meta name="description" content="кухонный комбайн заказать Миниатюрный электрический чайник Vitesse  VS-112  на 0,8 литра станет прекрасным...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/6b196c567e46a72cdbf1317947c6e278.jpeg" title="кухонный комбайн заказать Чайник электрический  Vitesse VS-112, дорожный 0,8л"><img src="photos/6b196c567e46a72cdbf1317947c6e278.jpeg" alt="кухонный комбайн заказать Чайник электрический  Vitesse VS-112, дорожный 0,8л" title="кухонный комбайн заказать Чайник электрический  Vitesse VS-112, дорожный 0,8л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/ochistitel-ot-nakipi-dlya-filtrkofevarok-i-chaynikov-melitta-zhidkiy-ml-295r.php"><img src="photos/cea4fd748306c2dcd557b55b05ac1d91.jpeg" alt="приготовление куры в аэрогриле Очиститель от накипи для фильтр-кофеварок и чайников Melitta, жидкий 250 мл" title="приготовление куры в аэрогриле Очиститель от накипи для фильтр-кофеварок и чайников Melitta, жидкий 250 мл"></a><h2>Очиститель от накипи для фильтр-кофеварок и чайников Melitta, жидкий 250 мл</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-pogruzhnoy-moulinex-ddd-3050r.php"><img src="photos/88431db04944e702f33c054454f31139.jpeg" alt="кофеварка philips отзывы Блендер погружной Moulinex DD407D72" title="кофеварка philips отзывы Блендер погружной Moulinex DD407D72"></a><h2>Блендер погружной Moulinex DD407D72</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-gourmet-chernaya-43999r.php"><img src="photos/a59c30a3b2d8957f43e9fce5f7b6e0f5.jpeg" alt="чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная" title="чалдовые кофеварки Автоматическая кофемашина Melitta CAFFEO GOURMET, черная"></a><h2>Автоматическая кофемашина Melitta CAFFEO GOURMET, черная</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>кухонный комбайн заказать Чайник электрический  Vitesse VS-112, дорожный 0,8л</h1>
						<div class="tb"><p>Цена: от <span class="price">970</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19613.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Миниатюрный электрический чайник Vitesse  VS-112  на 0,8 литра станет прекрасным  решением для дороги, выезда на дачу или офиса.<br>Классический белый цвет, корпус из  пластика, спираль из нержавеющей стали, автоматическое отключение при закипании  или недостатке воды, шкала воды  – весь  необходимый минимум для отличного чайника. Также в комплекте Вы получаете  две чашки и чехол для хранения.</p><p><strong>Характеристики:</strong></p><ul type=\disc\><li>Объем:  0.8 л;</li><li>Тип   нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал корпуса: пластик;</li><li>Блокировка  включения без воды;</li><li>Индикатор  уровня воды;</li><li>Индикация  включения;</li><li>Дополнительная  информация в комплекте: 2 чашки, дорожный чехол.</li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong></p> кухонный комбайн заказать</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/b4972945a0247403022f6df03f16440c.jpeg" alt="спагетти в мультиварке Пароварка-блендер Philips Avent 85300" title="спагетти в мультиварке Пароварка-блендер Philips Avent 85300"><div class="box"><a href="http://kitchentech.elitno.net/parovarkablender-philips-avent-5600r.php"><h3 class="title">спагетти в мультиварке Пароварка-блендер Philips Avent 85300</h3><p>от <span class="price">5600</span> руб.</p></a></div></li>
						<li><img src="photos/b4a95c8a4ccd80ea8dd5b10c9fcfd32c.jpeg" alt="форум микроволновая печь Чайник электрический Maxima MК-112" title="форум микроволновая печь Чайник электрический Maxima MК-112"><div class="box" page="chaynik-elektricheskiy-maxima-mk-790r"><span class="title">форум микроволновая печь Чайник электрический Maxima MК-112</span><p>от <span class="price">790</span> руб.</p></div></li>
						<li><img src="photos/795752aa9995ffddbd65e841f9d26c51.jpeg" alt="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л" title="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1820r"><span class="title">bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л</span><p>от <span class="price">1820</span> руб.</p></div></li>
						<li><img src="photos/140994d3679b87017beef134272baa56.jpeg" alt="запчасти пылесос томас Чайник дисковый керамический 1,7л, цветы Zauber ECO-340" title="запчасти пылесос томас Чайник дисковый керамический 1,7л, цветы Zauber ECO-340"><div class="box" page="chaynik-diskovyy-keramicheskiy-l-cvety-zauber-eco-1790r"><span class="title">запчасти пылесос томас Чайник дисковый керамический 1,7л, цветы Zauber ECO-340</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li class="large"><img src="photos/61cc3edb3bfd24a6709976ba33646660.jpeg" alt="аренда промышленного пылесоса Зарядное устройство GP Batteries PB350GS-UE1" title="аренда промышленного пылесоса Зарядное устройство GP Batteries PB350GS-UE1"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-340r"><span class="title">аренда промышленного пылесоса Зарядное устройство GP Batteries PB350GS-UE1</span><p>от <span class="price">340</span> руб.</p></div></li>
						<li class="large"><img src="photos/565e52ebc108aee0062c9aab0f314cab.jpeg" alt="кофеварка vitek 1513 Парогенератор Lelit PG024N" title="кофеварка vitek 1513 Парогенератор Lelit PG024N"><div class="box" page="parogenerator-lelit-pgn-16700r"><span class="title">кофеварка vitek 1513 Парогенератор Lelit PG024N</span><p>от <span class="price">16700</span> руб.</p></div></li>
						<li class="large"><img src="photos/4fcdbef1e4068bc4641fdad47e086ca6.jpeg" alt="бытовые микроволновые печи Парогенератор Maxima MSC-2001" title="бытовые микроволновые печи Парогенератор Maxima MSC-2001"><div class="box" page="parogenerator-maxima-msc-1650r"><span class="title">бытовые микроволновые печи Парогенератор Maxima MSC-2001</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/0c7359cf223fcc5ee81c11e13e2fdc99.jpeg" alt="купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый" title="купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый"><div class="box" page="parogenerator-maxima-msc-zheltyy-1650r"><span class="title">купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/df4499dd6fe2786e58841593ed771f8f.jpeg" alt="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009" title="мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009"><div class="box" page="moyuschiy-koncentrat-thomas-profloor-l-500r"><span class="title">мешки пылесборники для пылесосов Моющий концентрат Thomas Profloor 1 л 790-009</span><p>от <span class="price">500</span> руб.</p></div></li>
						<li><img src="photos/5b6e97489c13c0ebf62894fa7e5889c2.jpeg" alt="мини пылесос для дома Пылесос Dyson animal turbine DC 37" title="мини пылесос для дома Пылесос Dyson animal turbine DC 37"><div class="box" page="pylesos-dyson-animal-turbine-dc-27990r"><span class="title">мини пылесос для дома Пылесос Dyson animal turbine DC 37</span><p>от <span class="price">27990</span> руб.</p></div></li>
						<li><img src="photos/103d1dd79396034a787226c582b363d1.jpeg" alt="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter" title="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter"><div class="box" page="pylesos-thomas-power-edition-aquafilter-6220r"><span class="title">ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter</span><p>от <span class="price">6220</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-dorozhnyy-l-970r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>