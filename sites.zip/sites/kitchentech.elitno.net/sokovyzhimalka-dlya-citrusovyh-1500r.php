<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-dlya-citrusovyh-1500r.php","термопот panasonic nc pf30");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-dlya-citrusovyh-1500r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>термопот panasonic nc pf30 Соковыжималка для цитрусовых  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="термопот panasonic nc pf30, рецепты для хлебопечки с фото, картофель микроволновая печь, тканевый мешок для пылесоса, утюг с парогенератором philips, продам вафельницу, пароварка тефаль цена, продам хлебопечку, марки микроволновых печей, книга рецептов для хлебопечки, чем отличаются пылесосы, желтый пылесос, бездрожжевой хлеб в хлебопечке, видео хлебопечка панасоник,  хлебопечка клатроник">
		<meta name="description" content="термопот panasonic nc pf30 Хотите наслаждаться вкусным натуральным соком, не прилагая  для этого особых уси...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/8d898eca4e96ee4a2fd539403a61a2e7.jpeg" title="термопот panasonic nc pf30 Соковыжималка для цитрусовых"><img src="photos/8d898eca4e96ee4a2fd539403a61a2e7.jpeg" alt="термопот panasonic nc pf30 Соковыжималка для цитрусовых" title="термопот panasonic nc pf30 Соковыжималка для цитрусовых -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lounge-black-45500r.php"><img src="photos/f5887b3a092904b4c854c36d9035df19.jpeg" alt="рецепты для хлебопечки с фото Эспрессо-кофемашина Melitta Caffeo Lounge Black (4.0009.87)" title="рецепты для хлебопечки с фото Эспрессо-кофемашина Melitta Caffeo Lounge Black (4.0009.87)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lounge Black (4.0009.87)</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemolka-vitesse-vs-1980r.php"><img src="photos/127a383548663b9c155664559c9c2000.jpeg" alt="картофель микроволновая печь Кофемолка Vitesse VS-272" title="картофель микроволновая печь Кофемолка Vitesse VS-272"></a><h2>Кофемолка Vitesse VS-272</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-atlanta-atn-1050r-2.php"><img src="photos/56cb596182a024c5be877e612e6462d8.jpeg" alt="тканевый мешок для пылесоса Пароварка Atlanta АТН-605" title="тканевый мешок для пылесоса Пароварка Atlanta АТН-605"></a><h2>Пароварка Atlanta АТН-605</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>термопот panasonic nc pf30 Соковыжималка для цитрусовых</h1>
						<div class="tb"><p>Цена: от <span class="price">1500</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_26310.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Хотите наслаждаться вкусным натуральным соком, не прилагая  для этого особых усилий? Отличное решение для этого – соковыжималка. Соковыжималка  TURBO для цитрусовых изготовлена из качественной нержавеющей стали, имеет  удобную и простую конструкцию. Внешне соковыжималка TURBO представлена в  приятном серебристом цвете. </p> <p><strong>Характеристики:</strong></p> <ul type=disc>   <li>Для       цитрусовых;</li>   <li>Материал:       нержавеющая сталь;</li>   <li>Механический       пресс;</li>   <li>Цвет:       серебристый.</li> </ul> <p><strong>Производитель: Россия</strong></p> термопот panasonic nc pf30</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/a5a669656630312240d0cb17c653dfea.jpeg" alt="утюг с парогенератором philips Соковыжималка Maxima MJ-059" title="утюг с парогенератором philips Соковыжималка Maxima MJ-059"><div class="box" page="sokovyzhimalka-maxima-mj-1090r"><span class="title">утюг с парогенератором philips Соковыжималка Maxima MJ-059</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li><img src="photos/47745aa09108a6bfabc67b839ea476bd.jpeg" alt="продам вафельницу Чайник электрический Vitek VT-1114" title="продам вафельницу Чайник электрический Vitek VT-1114"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1030r"><span class="title">продам вафельницу Чайник электрический Vitek VT-1114</span><p>от <span class="price">1030</span> руб.</p></div></li>
						<li><img src="photos/fd3d354d6633b81b504bbc499f3c5989.jpeg" alt="пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый" title="пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-zheltyy-1120r"><span class="title">пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый</span><p>от <span class="price">1120</span> руб.</p></div></li>
						<li><img src="photos/357a4e7af6a4eca2e30275a2d5d14351.jpeg" alt="продам хлебопечку Чайник электрический Binatone CEJ-1744 White" title="продам хлебопечку Чайник электрический Binatone CEJ-1744 White"><div class="box" page="chaynik-elektricheskiy-binatone-cej-white-880r"><span class="title">продам хлебопечку Чайник электрический Binatone CEJ-1744 White</span><p>от <span class="price">880</span> руб.</p></div></li>
						<li class="large"><img src="photos/d6db045bcfab03ae142ac160811c2a0a.jpeg" alt="марки микроволновых печей Чайник электричесукий Atlanta ATH-756" title="марки микроволновых печей Чайник электричесукий Atlanta ATH-756"><div class="box" page="chaynik-elektrichesukiy-atlanta-ath-950r"><span class="title">марки микроволновых печей Чайник электричесукий Atlanta ATH-756</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li class="large"><img src="photos/24f877fd5e1c25786c4be92fe1684b56.jpeg" alt="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118" title="книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1999r"><span class="title">книга рецептов для хлебопечки Чайник электрический Redmond   RK-М118</span><p>от <span class="price">1999</span> руб.</p></div></li>
						<li class="large"><img src="photos/da3b8026757740acd31c2844cf598d4a.jpeg" alt="чем отличаются пылесосы Батарейка GP Batteries Super alkaline LR03 24A-BC4" title="чем отличаются пылесосы Батарейка GP Batteries Super alkaline LR03 24A-BC4"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-80r-2"><span class="title">чем отличаются пылесосы Батарейка GP Batteries Super alkaline LR03 24A-BC4</span><p>от <span class="price">80</span> руб.</p></div></li>
						<li><img src="photos/d53c2ed7dc8f0cab982dc0b1633d551f.jpeg" alt="желтый пылесос Пылесос Atlanta АТН-3400" title="желтый пылесос Пылесос Atlanta АТН-3400"><div class="box" page="pylesos-atlanta-atn-3400r"><span class="title">желтый пылесос Пылесос Atlanta АТН-3400</span><p>от <span class="price">3400</span> руб.</p></div></li>
						<li><img src="photos/7660e64f2f5c029aab5d6fad25c29084.jpeg" alt="бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843" title="бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843"><div class="box" page="pylesos-vitek-3990r"><span class="title">бездрожжевой хлеб в хлебопечке Пылесос Vitek 1843</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li><img src="photos/64dc96f26f782ba3e39f0fd329fa03d0.jpeg" alt="видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C" title="видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C"><div class="box" page="pylesos-thomas-power-pack-c-4740r"><span class="title">видео хлебопечка панасоник Пылесос Thomas Power Pack 1620 C</span><p>от <span class="price">4740</span> руб.</p></div></li>
						<li><img src="photos/103d1dd79396034a787226c582b363d1.jpeg" alt="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter" title="ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter"><div class="box" page="pylesos-thomas-power-edition-aquafilter-6220r"><span class="title">ролсен аэрогриль Пылесос Thomas Power Edition 1530 Aquafilter</span><p>от <span class="price">6220</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-dlya-citrusovyh-1500r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-dlya-citrusovyh-1500r.php")) require_once "comments/sokovyzhimalka-dlya-citrusovyh-1500r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-dlya-citrusovyh-1500r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>