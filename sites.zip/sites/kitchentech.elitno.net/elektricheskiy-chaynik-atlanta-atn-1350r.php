<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("elektricheskiy-chaynik-atlanta-atn-1350r.php","пароварка филипс 9110");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("elektricheskiy-chaynik-atlanta-atn-1350r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пароварка филипс 9110 Электрический чайник Atlanta АТН-788  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пароварка филипс 9110, где отремонтировать утюг, приготовление пищи в пароварке, профессиональный дозиметр, электрическая мультиварка, аэрогриль форум, чайник электрический bork, quigg хлебопечка, запчасти для пылесоса lg, микроволновая печь saturn, bamix блендер отзывы, mini пылесос, мини соковыжималка, микроволновая печь электросхема,  как приготовить хлеб в хлебопечке">
		<meta name="description" content="пароварка филипс 9110 Электрический чайник Atlanta АТН-788 – стильный кухонный прибор из нержавеющей с...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" title="пароварка филипс 9110 Электрический чайник Atlanta АТН-788"><img src="photos/162f6d9ea92d5d3a2efc137f3c8bea41.jpeg" alt="пароварка филипс 9110 Электрический чайник Atlanta АТН-788" title="пароварка филипс 9110 Электрический чайник Atlanta АТН-788 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-processor-redmond-rfp-2990r.php"><img src="photos/470cf0a1bfd5b3c4e3890030dcd4cf8d.jpeg" alt="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901" title="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901"></a><h2>Кухонный процессор Redmond  RFP-3901</h2></li>
							<li><a href="http://kitchentech.elitno.net/kofemashina-philips-saeco-hd-67000r.php"><img src="photos/7d364e47f91214e45b2e2f0dc4bfa3a6.jpeg" alt="приготовление пищи в пароварке Кофемашина Philips Saeco HD 8944 09" title="приготовление пищи в пароварке Кофемашина Philips Saeco HD 8944 09"></a><h2>Кофемашина Philips Saeco HD 8944 09</h2></li>
							<li><a href="http://kitchentech.elitno.net/schetka-silikonovaya-giza-vitesse-vs-500r.php"><img src="photos/0b78d91a105ad11353549e33ee928e3e.jpeg" alt="профессиональный дозиметр Щетка силиконовая Giza Vitesse VS-1819" title="профессиональный дозиметр Щетка силиконовая Giza Vitesse VS-1819"></a><h2>Щетка силиконовая Giza Vitesse VS-1819</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пароварка филипс 9110 Электрический чайник Atlanta АТН-788</h1>
						<div class="tb"><p>Цена: от <span class="price">1350</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_20009.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Atlanta АТН-788 – стильный кухонный прибор из нержавеющей стали с удобной вращающейся крышкой и иллюминацией. Его мощность составляет 2000 Вт при объеме 1,7 л. Используется защищенный закрытый нагревательный элемент, который гораздо проще мыть, чем открытую спираль. Безопасен, т. к. имеет защиту от перегрева, а также блокировку включения без воды. Предусмотрено место для электрошнура в цокольной подставке. Обладает низким уровнем электропотребления. Соответствует европейским и американским нормам безопасности. Изделие сертифицировано Госстандартом РФ.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Иллюминация <li>Удобная вращающаяся крышка <li>Объем 1,7 литра <li>Поворот на подставке на 360 <li>Быстрое закипание <li>Фильтр от накипи <li>Закрытый нагревательный элемент <li>Автоматическое отключение <li>Защита от перегрева без воды <li>Электрошнур в цокольной подставке <li>Изделие сертифицировано Госстандартом РФ <li>Соответствует американским и европейским нормам безопасности <li>Мощность 2000W <li>230V, 50Hz <li>20 x 20 x 26 см </li></ul><p><strong>Производитель: США</strong></p> пароварка филипс 9110</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/35ebdf1eb3139cf89fe5f6240c399711.jpeg" alt="электрическая мультиварка Йогуртница Maxima MYM-0154" title="электрическая мультиварка Йогуртница Maxima MYM-0154"><div class="box" page="yogurtnica-maxima-mym-990r"><span class="title">электрическая мультиварка Йогуртница Maxima MYM-0154</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/8c0aa6f2022172974ae917a715c05f94.jpeg" alt="аэрогриль форум Пароварка Vitek VT-1550N SR" title="аэрогриль форум Пароварка Vitek VT-1550N SR"><div class="box" page="parovarka-vitek-vtn-sr-2200r"><span class="title">аэрогриль форум Пароварка Vitek VT-1550N SR</span><p>от <span class="price">2200</span> руб.</p></div></li>
						<li><img src="photos/cba9fd30236faeadb264f6621c9544f6.jpeg" alt="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер" title="чайник электрический bork Соковыжималка Maxima MJ-049 + блендер"><div class="box" page="sokovyzhimalka-maxima-mj-blender-2190r"><span class="title">чайник электрический bork Соковыжималка Maxima MJ-049 + блендер</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/ba4426ec9ff105596978c39d5f7ff4de.jpeg" alt="quigg хлебопечка Соковыжималка для цитрусовых 304-CP" title="quigg хлебопечка Соковыжималка для цитрусовых 304-CP"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-cp-1300r"><span class="title">quigg хлебопечка Соковыжималка для цитрусовых 304-CP</span><p>от <span class="price">1300</span> руб.</p></div></li>
						<li class="large"><img src="photos/57a9dd1cf47f278e2b8c998d7aabc0c5.jpeg" alt="запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный" title="запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный"><div class="box" page="bodum-bistro-euro-toster-krasnyy-3660r"><span class="title">запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный</span><p>от <span class="price">3660</span> руб.</p></div></li>
						<li class="large"><img src="photos/2e45225f75584b99ef16cc23171266ef.jpeg" alt="микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л" title="микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1740r"><span class="title">микроволновая печь saturn Чайник электрический  Vitesse VS-132 1,7 л</span><p>от <span class="price">1740</span> руб.</p></div></li>
						<li class="large"><img src="photos/795752aa9995ffddbd65e841f9d26c51.jpeg" alt="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л" title="bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1820r"><span class="title">bamix блендер отзывы Чайник электрический  Vitesse VS-139 1,7л</span><p>от <span class="price">1820</span> руб.</p></div></li>
						<li><img src="photos/28da988d46134dfe1236e7598e0579cc.jpeg" alt="mini пылесос Турбощетка Redmond  RV-308" title="mini пылесос Турбощетка Redmond  RV-308"><div class="box" page="turboschetka-redmond-rv-390r"><span class="title">mini пылесос Турбощетка Redmond  RV-308</span><p>от <span class="price">390</span> руб.</p></div></li>
						<li><img src="photos/8201fb734cec793db96d43f2e27a6cc4.jpeg" alt="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail" title="мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail"><div class="box" page="nabor-dlya-doma-dyson-home-cleaning-kit-retail-2490r"><span class="title">мини соковыжималка Набор для дома Dyson Home Cleaning Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/00492fb3046ec485746c0b2d1a1385eb.jpeg" alt="микроволновая печь электросхема Пылесос Thomas Inox 1545 S" title="микроволновая печь электросхема Пылесос Thomas Inox 1545 S"><div class="box" page="pylesos-thomas-inox-s-10410r"><span class="title">микроволновая печь электросхема Пылесос Thomas Inox 1545 S</span><p>от <span class="price">10410</span> руб.</p></div></li>
						<li><img src="photos/d7f319eafa0a03def3b072699daeccdd.jpeg" alt="утюг в туле Утюг Vitek VT-1235" title="утюг в туле Утюг Vitek VT-1235"><div class="box" page="utyug-vitek-vt-970r"><span class="title">утюг в туле Утюг Vitek VT-1235</span><p>от <span class="price">970</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("elektricheskiy-chaynik-atlanta-atn-1350r.php", 0, -4); if (file_exists("comments/elektricheskiy-chaynik-atlanta-atn-1350r.php")) require_once "comments/elektricheskiy-chaynik-atlanta-atn-1350r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="elektricheskiy-chaynik-atlanta-atn-1350r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>