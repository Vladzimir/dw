<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-atlanta-ath-1280r.php","мультиварка sinbo sco");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-atlanta-ath-1280r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мультиварка sinbo sco Чайник электрический Atlanta ATH-690  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мультиварка sinbo sco, хлебопечка ру рецепты, какая фирма утюгов лучше, мешки для пылесоса vax, распродажа пылесосов, крылышки в пароварке, щетка для пылесоса electrolux, хлебопечка мулинекс 3101, запеканка в хлебопечке, пылесос thomas genius s2, магазин запчастей для мясорубок, борк мешки для пылесоса, сколько стоит соковыжималка, мультиварка телефункен,  как приготовить хлеб в хлебопечке">
		<meta name="description" content="мультиварка sinbo sco Электрический чайник Atlanta ATH-690 голубого цвета из термостойкого стекла объе...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/463a93164abee7f214102b8fe77a244c.jpeg" title="мультиварка sinbo sco Чайник электрический Atlanta ATH-690"><img src="photos/463a93164abee7f214102b8fe77a244c.jpeg" alt="мультиварка sinbo sco Чайник электрический Atlanta ATH-690" title="мультиварка sinbo sco Чайник электрический Atlanta ATH-690 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/oksiochistitel-ot-nakipi-swirl-hg-90r.php"><img src="photos/b1940086e49964580ca58fbacc9f1c79.jpeg" alt="хлебопечка ру рецепты Окси-очиститель от накипи Swirl, 2х15г" title="хлебопечка ру рецепты Окси-очиститель от накипи Swirl, 2х15г"></a><h2>Окси-очиститель от накипи Swirl, 2х15г</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-sause-ca-3230r.php"><img src="photos/9ef0650c09ea5519a1da65d43afff16d.jpeg" alt="какая фирма утюгов лучше Блендер Braun MR-530 Sause CA" title="какая фирма утюгов лучше Блендер Braun MR-530 Sause CA"></a><h2>Блендер Braun MR-530 Sause CA</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-2770r.php"><img src="photos/4a49eabd132fa073a575c3edfbe7b80b.jpeg" alt="мешки для пылесоса vax Микроволновая печь Vitek VT-1681" title="мешки для пылесоса vax Микроволновая печь Vitek VT-1681"></a><h2>Микроволновая печь Vitek VT-1681</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мультиварка sinbo sco Чайник электрический Atlanta ATH-690</h1>
						<div class="tb"><p>Цена: от <span class="price">1280</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_18116.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Atlanta ATH-690 голубого цвета из термостойкого стекла объемом 1,7 литра, мощностью 2000 Вт со скрытым дисковым нагревателем и фильтром от накипи. Абсолютно безопасен: выключается при закипании и не включается при отсутствии воды. </p><p><b>Характеристики:</b></p><ul type=disc><li>Объем: 1,7 л <li>Мощность: 2000 Вт <li>Скрытый дисковый нагреватель <li>Блокировка включения без воды <li>Автоматическое выключение </li></ul><p><b>Производитель: Китай</b></p> мультиварка sinbo sco</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/7b88076a90f90c4718597a4ab977cb0a.jpeg" alt="распродажа пылесосов Микроволновая печь Vitek VT-1682" title="распродажа пылесосов Микроволновая печь Vitek VT-1682"><div class="box" page="mikrovolnovaya-pech-vitek-vt-3550r"><span class="title">распродажа пылесосов Микроволновая печь Vitek VT-1682</span><p>от <span class="price">3550</span> руб.</p></div></li>
						<li><img src="photos/1c1d1049958bdd0b6b9f6e6cb13db14b.jpeg" alt="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый" title="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый"><div class="box" page="mikrovolnovaya-pech-s-grilem-moulinex-mw-l-belyy-3890r"><span class="title">крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый</span><p>от <span class="price">3890</span> руб.</p></div></li>
						<li><img src="photos/74bbce31ddb28c5063f247363080794a.jpeg" alt="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502" title="щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502"><div class="box" page="chasha-dlya-multivarki-redmond-iprmcm-990r"><span class="title">щетка для пылесоса electrolux Чаша для мультиварки Redmond IPRMC-M4502</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/7903c21b4883d9e9c99d0a478392fee7.jpeg" alt="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906" title="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906"><div class="box" page="sokovyzhimalka-redmond-rjm-4990r"><span class="title">хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li class="large"><img src="photos/5ccb08af67b9142dd99b94ec6317943c.jpeg" alt="запеканка в хлебопечке Чайник электрический Maxima MK-G311" title="запеканка в хлебопечке Чайник электрический Maxima MK-G311"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1650r"><span class="title">запеканка в хлебопечке Чайник электрический Maxima MK-G311</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li class="large"><img src="photos/94de14730b416ab6939a25c5af76e14e.jpeg" alt="пылесос thomas genius s2 Парогенератор Lelit PS11N" title="пылесос thomas genius s2 Парогенератор Lelit PS11N"><div class="box" page="parogenerator-lelit-psn-12000r"><span class="title">пылесос thomas genius s2 Парогенератор Lelit PS11N</span><p>от <span class="price">12000</span> руб.</p></div></li>
						<li class="large"><img src="photos/ed6cccd8ae597a978fe91c415f9d06d3.jpeg" alt="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)" title="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-135r"><span class="title">магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)</span><p>от <span class="price">135</span> руб.</p></div></li>
						<li><img src="photos/6d6e50224259e87ee797b3ec79edf80e.jpeg" alt="борк мешки для пылесоса Плоская универсальная насадка в упаковке Dyson Flat Out Head Retail NP" title="борк мешки для пылесоса Плоская универсальная насадка в упаковке Dyson Flat Out Head Retail NP"><div class="box" page="ploskaya-universalnaya-nasadka-v-upakovke-dyson-flat-out-head-retail-np-2190r"><span class="title">борк мешки для пылесоса Плоская универсальная насадка в упаковке Dyson Flat Out Head Retail NP</span><p>от <span class="price">2190</span> руб.</p></div></li>
						<li><img src="photos/b82293cd9bb86384904268699e41b0f9.jpeg" alt="сколько стоит соковыжималка Пылесос Thomas Power Pack 1630 Se" title="сколько стоит соковыжималка Пылесос Thomas Power Pack 1630 Se"><div class="box" page="pylesos-thomas-power-pack-se-7010r"><span class="title">сколько стоит соковыжималка Пылесос Thomas Power Pack 1630 Se</span><p>от <span class="price">7010</span> руб.</p></div></li>
						<li><img src="photos/2e3efb1596b4e1a5bf1803f0fd03710f.jpeg" alt="мультиварка телефункен Пылесос Thomas Inox 30 Professional" title="мультиварка телефункен Пылесос Thomas Inox 30 Professional"><div class="box" page="pylesos-thomas-inox-professional-7740r"><span class="title">мультиварка телефункен Пылесос Thomas Inox 30 Professional</span><p>от <span class="price">7740</span> руб.</p></div></li>
						<li><img src="photos/7fe394e6e0402a674ba207691524344d.jpeg" alt="мясорубка moulinex hv8 me625 Утюг Atlanta ATH-434" title="мясорубка moulinex hv8 me625 Утюг Atlanta ATH-434"><div class="box" page="utyug-atlanta-ath-680r"><span class="title">мясорубка moulinex hv8 me625 Утюг Atlanta ATH-434</span><p>от <span class="price">680</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-atlanta-ath-1280r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-atlanta-ath-1280r.php")) require_once "comments/chaynik-elektricheskiy-atlanta-ath-1280r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-atlanta-ath-1280r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>