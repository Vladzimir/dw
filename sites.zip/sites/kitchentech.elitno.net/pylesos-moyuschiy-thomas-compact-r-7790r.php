<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-moyuschiy-thomas-compact-r-7790r.php","микроволновая печь saturn");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-moyuschiy-thomas-compact-r-7790r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>микроволновая печь saturn Пылесос моющий Thomas Compact 20 R  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="микроволновая печь saturn, пылесос для ковролина, готовим в аэрогриле видео, подобрать пылесос, мини пылесос божья коровка, куриные грудки в мультиварке, измельчитель сучьев, мультиварка описание, форум микроволновая печь, покупка пылесоса, соковыжималка садовая, кофеварка в киеве, мясорубка kenwood mg510, кубань 8 вафельница,  пылесосы филлипс">
		<meta name="description" content="микроволновая печь saturn Моющий пылесос Thomas не боится никаких трудностей. Ему под силу справиться с за...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/07ba23dd2664a1f6554e1b4f71151996.jpeg" title="микроволновая печь saturn Пылесос моющий Thomas Compact 20 R"><img src="photos/07ba23dd2664a1f6554e1b4f71151996.jpeg" alt="микроволновая печь saturn Пылесос моющий Thomas Compact 20 R" title="микроволновая печь saturn Пылесос моющий Thomas Compact 20 R -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-atlanta-atn-990r.php"><img src="photos/096e72471ef2ac122b04cd03d0d34b33.jpeg" alt="пылесос для ковролина Блендер Atlanta АТН-343" title="пылесос для ковролина Блендер Atlanta АТН-343"></a><h2>Блендер Atlanta АТН-343</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskaya-nozhevaya-kofemolka-krasnaya-bodum-bistro-euro-1830r.php"><img src="photos/9902f4713a14989fcafcf26ed7445abc.jpeg" alt="готовим в аэрогриле видео Электрическая ножевая кофемолка красная Bodum BISTRO 11160-294EURO" title="готовим в аэрогриле видео Электрическая ножевая кофемолка красная Bodum BISTRO 11160-294EURO"></a><h2>Электрическая ножевая кофемолка красная Bodum BISTRO 11160-294EURO</h2></li>
							<li><a href="http://kitchentech.elitno.net/ruchnoy-mikser-i-izmelchitel-vitesse-vs-2550r.php"><img src="photos/a1d1eae985fdaf6c44e33d639f78a926.jpeg" alt="подобрать пылесос Ручной миксер и измельчитель Vitesse VS-248" title="подобрать пылесос Ручной миксер и измельчитель Vitesse VS-248"></a><h2>Ручной миксер и измельчитель Vitesse VS-248</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>микроволновая печь saturn Пылесос моющий Thomas Compact 20 R</h1>
						<div class="tb"><p>Цена: от <span class="price">7790</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14656.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий пылесос Thomas не боится никаких трудностей. Ему под силу справиться с загрязнениями любой сложности посредством сухой или влажной уборки. Прибор удобен в использовании и компактен в хранении. Он обладает мощностью 1400 Вт, оборудован пылесборником на 20 л, емкостью для чистой воды на 6 л. Пылесос выполнен в стильном эргономичном корпусе насыщенно красного цвета, комплектуется насадкой для твердых поверхностей и щелевой насадкой.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: обычный; </li><li>Уборка: влажная, сухая; </li><li>Потребляемая мощность: 1400 Вт; </li><li>Объем пылесборника: 20 л; </li><li>Типы пылесборника: сменные бумажные пылесборники; </li><li>Фильтрация воздуха: ступеней фильтраций – 4; </li><li>Регулятор мощности всасывания: на корпусе; </li><li>Емкость для воды: чистая вода - 6 л; </li><li>Трубка: составная; </li><li>Шнур питания: 6 м; </li><li>Размеры (ШxВxГ): 38,5x52x38,5 см; </li><li>Вес: 9 кг; </li><li>Материал трубки: пластик; </li><li>Цвет корпуса: красный; </li><li>Насадки в комплекте: для твердых полов, щелевая; </li><li>Тип питания: сеть.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> микроволновая печь saturn</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/a719c7f9b9161eaae5e6d50552aa1d04.jpeg" alt="мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011" title="мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011"><div class="box" page="myasorubka-elektricheskaya-tefal-le-hachoir-me-5880r"><span class="title">мини пылесос божья коровка Мясорубка электрическая Tefal Le Hachoir ME7011</span><p>от <span class="price">5880</span> руб.</p></div></li>
						<li><img src="photos/b8600793aec4a8059c2de0136a79b6b1.jpeg" alt="куриные грудки в мультиварке Пароварка Redmond RST-1103" title="куриные грудки в мультиварке Пароварка Redmond RST-1103"><div class="box" page="parovarka-redmond-rst-2390r"><span class="title">куриные грудки в мультиварке Пароварка Redmond RST-1103</span><p>от <span class="price">2390</span> руб.</p></div></li>
						<li><img src="photos/7b0ef0b12e5f66ec7582c9396725bc92.jpeg" alt="измельчитель сучьев Чайник электрический Vitek VT-1120" title="измельчитель сучьев Чайник электрический Vitek VT-1120"><div class="box" page="chaynik-elektricheskiy-vitek-vt-1150r"><span class="title">измельчитель сучьев Чайник электрический Vitek VT-1120</span><p>от <span class="price">1150</span> руб.</p></div></li>
						<li><img src="photos/01e798cd02e35629810cab1b511976bc.jpeg" alt="мультиварка описание Чайник электрический Tefal Reminisce KI201540 1,7 л" title="мультиварка описание Чайник электрический Tefal Reminisce KI201540 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r"><span class="title">мультиварка описание Чайник электрический Tefal Reminisce KI201540 1,7 л</span><p>от <span class="price">2370</span> руб.</p></div></li>
						<li class="large"><img src="photos/b4a95c8a4ccd80ea8dd5b10c9fcfd32c.jpeg" alt="форум микроволновая печь Чайник электрический Maxima MК-112" title="форум микроволновая печь Чайник электрический Maxima MК-112"><div class="box" page="chaynik-elektricheskiy-maxima-mk-790r"><span class="title">форум микроволновая печь Чайник электрический Maxima MК-112</span><p>от <span class="price">790</span> руб.</p></div></li>
						<li class="large"><img src="photos/a6fb3c6ce325a3d2e51b29fc0035a27d.jpeg" alt="покупка пылесоса Чайник электрический Redmond RK-M107" title="покупка пылесоса Чайник электрический Redmond RK-M107"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-1790r"><span class="title">покупка пылесоса Чайник электрический Redmond RK-M107</span><p>от <span class="price">1790</span> руб.</p></div></li>
						<li class="large"><img src="photos/a73fe1f79d4e2459d6da89e07445f626.jpeg" alt="соковыжималка садовая Электрический чайник Atlanta АТН-738" title="соковыжималка садовая Электрический чайник Atlanta АТН-738"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-520r"><span class="title">соковыжималка садовая Электрический чайник Atlanta АТН-738</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/ef5f34c264e9ba8f2acfacd6c8c1863a.jpeg" alt="кофеварка в киеве Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-330" title="кофеварка в киеве Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-330"><div class="box" page="chaynik-diskovyy-keramicheskiy-l-golubye-cvety-zauber-eco-1760r"><span class="title">кофеварка в киеве Чайник дисковый керамический 1,7л, голубые цветы Zauber ECO-330</span><p>от <span class="price">1760</span> руб.</p></div></li>
						<li><img src="photos/ebd6fc853a788b316468033f41ae3864.jpeg" alt="мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22" title="мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22"><div class="box" page="pylesos-dyson-motorhead-dc-34990r"><span class="title">мясорубка kenwood mg510 Пылесос Dyson motorhead DC 22</span><p>от <span class="price">34990</span> руб.</p></div></li>
						<li><img src="photos/4fbb8e89e08e4c6965da2c5a458072d3.jpeg" alt="кубань 8 вафельница Пылесос Vitek VT-1836 красный" title="кубань 8 вафельница Пылесос Vitek VT-1836 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3600r"><span class="title">кубань 8 вафельница Пылесос Vitek VT-1836 красный</span><p>от <span class="price">3600</span> руб.</p></div></li>
						<li><img src="photos/d7f319eafa0a03def3b072699daeccdd.jpeg" alt="утюг в туле Утюг Vitek VT-1235" title="утюг в туле Утюг Vitek VT-1235"><div class="box" page="utyug-vitek-vt-970r"><span class="title">утюг в туле Утюг Vitek VT-1235</span><p>от <span class="price">970</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-moyuschiy-thomas-compact-r-7790r.php", 0, -4); if (file_exists("comments/pylesos-moyuschiy-thomas-compact-r-7790r.php")) require_once "comments/pylesos-moyuschiy-thomas-compact-r-7790r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-moyuschiy-thomas-compact-r-7790r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>