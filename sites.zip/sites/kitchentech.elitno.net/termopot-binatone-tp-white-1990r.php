<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("termopot-binatone-tp-white-1990r.php","соковыжималка scarlett");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("termopot-binatone-tp-white-1990r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>соковыжималка scarlett Термопот Binatone TP-4055 White  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="соковыжималка scarlett, вафельница со сменными, соковыжималка profi cook, кухонный комбайн фото, фритюрница philips отзывы, блендер бош купить, пароварка тефаль цена, как разобрать утюг, какую купить мясорубку, пылесос витек с аквафильтром, купить мультиварку панасоник, пылесосы филипс отзывы, микроволновая печь bork, запчасти для пароварки,  трубка для пылесоса">
		<meta name="description" content="соковыжималка scarlett Термопот Binatone TP-4055 White сочетает в себе удобство пользования, большую вм...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3efeed2a40b596512ea138d7f6d2f182.jpeg" title="соковыжималка scarlett Термопот Binatone TP-4055 White"><img src="photos/3efeed2a40b596512ea138d7f6d2f182.jpeg" alt="соковыжималка scarlett Термопот Binatone TP-4055 White" title="соковыжималка scarlett Термопот Binatone TP-4055 White -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-bistro-bordeaux-47860r.php"><img src="photos/6b889eff1ae3a6014c4090d445e03c04.jpeg" alt="вафельница со сменными Эспрессо-кофемашина Melitta Bistro Bordeaux (4.000933)" title="вафельница со сменными Эспрессо-кофемашина Melitta Bistro Bordeaux (4.000933)"></a><h2>Эспрессо-кофемашина Melitta Bistro Bordeaux (4.000933)</h2></li>
							<li><a href="http://kitchentech.elitno.net/mylopoglotitel-nepriyatnyh-zapahov-vitesse-vs-530r.php"><img src="photos/b3484386aa5de93840c27e2c8187adfa.jpeg" alt="соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293" title="соковыжималка profi cook Мыло-поглотитель неприятных запахов Vitesse VS-1293"></a><h2>Мыло-поглотитель неприятных запахов Vitesse VS-1293</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-2750r.php"><img src="photos/a778f38f56b1abc67bee8e49c9772547.jpeg" alt="кухонный комбайн фото Микроволновая печь Vitek VT-1691" title="кухонный комбайн фото Микроволновая печь Vitek VT-1691"></a><h2>Микроволновая печь Vitek VT-1691</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>соковыжималка scarlett Термопот Binatone TP-4055 White</h1>
						<div class="tb"><p>Цена: от <span class="price">1990</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_6823.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Термопот </b><b>Binatone </b><b>TP-4055 </b><b>White</b> сочетает в себе удобство пользования, большую вместимость: 4 литра, а также элегантный дизайн: декорированный серебристым орнаментом корпус с индикатором уровня воды в виде капли. Корпус выполнен из термостойкого пластика, колба - из нержавеющей стали. Модель оснащена 3-мя режимами подачи воды: посредством электрического насоса, ручной помпы и нажатием чашки на клапан (функция «Cup switch»). Выбрать нужный режим работы поможет сенсорная панель управления. Преимуществом является ручка для переноски и возможность поворота устройства на подставке на 360є, что очень удобно. Функция поддержания температуры экономит электроэнергию. </p><p><b>Характеристики:</b></p><ul type=\disc\><li>Вместимость: 4 л; </li><li>Максимальная мощность: 750 Вт; </li><li>Максимальная мощность в режиме поддержания температуры: 35 Вт; </li><li>Колба из нержавеющей стали; </li><li>Корпус из термостойкого пластика; </li><li>3 режима подачи воды: электрическим насосом, ручной помпой, «Cup switch» (нажатием чашки на клапан); </li><li>Сенсорная панель управления; </li><li>Защитная блокировка электрического насоса и ручной помпы; </li><li>Функция повторного кипячения; </li><li>Скрытый нагревательный элемент; </li><li>Шкала уровня воды; </li><li>Индикаторы работы; </li><li>Съемная крышка; </li><li>Цвет: белый; </li><li>Вес: 3,6 кг.</li></ul><p><b>Производитель: </b>Binatone.</p> соковыжималка scarlett</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/cd757289d24d4d7e98d5fef52b1c314b.jpeg" alt="фритюрница philips отзывы Микроволновая печь Vitek 1652 (SR)" title="фритюрница philips отзывы Микроволновая печь Vitek 1652 (SR)"><div class="box" page="mikrovolnovaya-pech-vitek-sr-3990r"><span class="title">фритюрница philips отзывы Микроволновая печь Vitek 1652 (SR)</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li><img src="photos/76b45e609e76d0f51a02bc816db807a1.jpeg" alt="блендер бош купить Тостер Maxima MT-014" title="блендер бош купить Тостер Maxima MT-014"><div class="box" page="toster-maxima-mt-540r"><span class="title">блендер бош купить Тостер Maxima MT-014</span><p>от <span class="price">540</span> руб.</p></div></li>
						<li><img src="photos/fd3d354d6633b81b504bbc499f3c5989.jpeg" alt="пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый" title="пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый"><div class="box" page="chaynik-elektricheskiy-vitek-vt-zheltyy-1120r"><span class="title">пароварка тефаль цена Чайник электрический Vitek VT-1139 желтый</span><p>от <span class="price">1120</span> руб.</p></div></li>
						<li><img src="photos/c094c1a0c632dcd5f1edee8671f05107.jpeg" alt="как разобрать утюг Чайник электрический Maxima MК- M211" title="как разобрать утюг Чайник электрический Maxima MК- M211"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-1090r"><span class="title">как разобрать утюг Чайник электрический Maxima MК- M211</span><p>от <span class="price">1090</span> руб.</p></div></li>
						<li class="large"><img src="photos/b36e4518839f5476ba18891a0416843e.jpeg" alt="какую купить мясорубку Чайник электрический  Vitesse VS-110 1,7л" title="какую купить мясорубку Чайник электрический  Vitesse VS-110 1,7л"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-1950r"><span class="title">какую купить мясорубку Чайник электрический  Vitesse VS-110 1,7л</span><p>от <span class="price">1950</span> руб.</p></div></li>
						<li class="large"><img src="photos/5693cfb54e3dd38a9bb80b0d7d894cdb.jpeg" alt="пылесос витек с аквафильтром Открывалка Hand Free Opener (Can Opener)" title="пылесос витек с аквафильтром Открывалка Hand Free Opener (Can Opener)"><div class="box" page="otkryvalka-hand-free-opener-can-opener-470r"><span class="title">пылесос витек с аквафильтром Открывалка Hand Free Opener (Can Opener)</span><p>от <span class="price">470</span> руб.</p></div></li>
						<li class="large"><img src="photos/0c7359cf223fcc5ee81c11e13e2fdc99.jpeg" alt="купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый" title="купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый"><div class="box" page="parogenerator-maxima-msc-zheltyy-1650r"><span class="title">купить мультиварку панасоник Парогенератор Maxima MSC-2001 желтый</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/20c033d3c85583b2e6a71a21254a84f6.jpeg" alt="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail" title="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail"><div class="box" page="schetka-dlya-tverdyh-poverhnostey-v-upakovke-dyson-hard-floor-tool-assy-retail-1590r"><span class="title">пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail</span><p>от <span class="price">1590</span> руб.</p></div></li>
						<li><img src="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" alt="микроволновая печь bork Пылесос моющий Thomas Hygiene T2" title="микроволновая печь bork Пылесос моющий Thomas Hygiene T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-t-15900r"><span class="title">микроволновая печь bork Пылесос моющий Thomas Hygiene T2</span><p>от <span class="price">15900</span> руб.</p></div></li>
						<li><img src="photos/eb12162abf9f68b1f020c54d55eeb406.jpeg" alt="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM" title="запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM"><div class="box" page="sushilka-dlya-ruk-aeg-haustehnik-he-tm-7800r"><span class="title">запчасти для пароварки Сушилка для рук AEG Haustehnik HE 260 TM</span><p>от <span class="price">7800</span> руб.</p></div></li>
						<li><img src="photos/dad55c3e820faa7adb3396e1681091d7.jpeg" alt="рецепты для миксера Утюг Vitek VT-1255" title="рецепты для миксера Утюг Vitek VT-1255"><div class="box" page="utyug-vitek-vt-1350r"><span class="title">рецепты для миксера Утюг Vitek VT-1255</span><p>от <span class="price">1350</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("termopot-binatone-tp-white-1990r.php", 0, -4); if (file_exists("comments/termopot-binatone-tp-white-1990r.php")) require_once "comments/termopot-binatone-tp-white-1990r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="termopot-binatone-tp-white-1990r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>