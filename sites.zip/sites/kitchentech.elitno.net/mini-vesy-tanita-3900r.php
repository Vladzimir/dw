<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("mini-vesy-tanita-3900r.php","пылесос кирби цена");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("mini-vesy-tanita-3900r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесос кирби цена Мини весы Tanita 1579  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесос кирби цена, tupperware миксер, готовим в аэрогриле видео, крылышки в пароварке, видео мясорубки мулинекс, тканевый мешок для пылесоса, рисование утюгом, кувшин для кофеварки, измерение электромагнитного излучения, мультиварка киев купить, пылесосы в гродно, блендер philips hr 2860, kenwood пароварка, измельчитель kenwood,  мясорубка kenwood mg510">
		<meta name="description" content="пылесос кирби цена Карманные весы Tanita 1579 обязательно пригодятся вам в домашнем хозяйстве. Комп...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/ae6aa53dcc9eb32133541922b9ec3b16.jpeg" title="пылесос кирби цена Мини весы Tanita 1579"><img src="photos/ae6aa53dcc9eb32133541922b9ec3b16.jpeg" alt="пылесос кирби цена Мини весы Tanita 1579" title="пылесос кирби цена Мини весы Tanita 1579 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/vspenivatel-melitta-cremio-belyy-4155r.php"><img src="photos/701c1fd8791de13ef3fc3b11f131d4a2.jpeg" alt="tupperware миксер Вспениватель Melitta Cremio белый" title="tupperware миксер Вспениватель Melitta Cremio белый"></a><h2>Вспениватель Melitta Cremio белый</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskaya-nozhevaya-kofemolka-krasnaya-bodum-bistro-euro-1830r.php"><img src="photos/9902f4713a14989fcafcf26ed7445abc.jpeg" alt="готовим в аэрогриле видео Электрическая ножевая кофемолка красная Bodum BISTRO 11160-294EURO" title="готовим в аэрогриле видео Электрическая ножевая кофемолка красная Bodum BISTRO 11160-294EURO"></a><h2>Электрическая ножевая кофемолка красная Bodum BISTRO 11160-294EURO</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-s-grilem-moulinex-mw-l-belyy-3890r.php"><img src="photos/1c1d1049958bdd0b6b9f6e6cb13db14b.jpeg" alt="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый" title="крылышки в пароварке Микроволновая печь с грилем Moulinex MW220131 20 л, белый"></a><h2>Микроволновая печь с грилем Moulinex MW220131 20 л, белый</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесос кирби цена Мини весы Tanita 1579</h1>
						<div class="tb"><p>Цена: от <span class="price">3900</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_1040.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Карманные весы </b><b>Tanita 1579</b> обязательно пригодятся вам в домашнем хозяйстве. Компактные, они не будут занимать много места и пригодятся для измерения массы мелких грузов. Наделенные сразу несколькими функциями весы отвечают требованиям современного человека. Например, при взвешивании груза в емкости, весы могут не учитывать тару. После того как процедура взвешивания завершается, аппарат выключается автоматически. Несмотря на небольшой размер и отсутствие регистрации как предмета метрологии точность взвешивания прибором груза достигает сотых долей. Именно поэтому <b>Карманные весы </b><b>Tanita 1579</b> используются не только на кухнях частных квартир, но и в медицине, в аптеках, ломбардах, ювелирных магазинах.</p><p>Преимуществом данной модели весов то, что грузы взвешиваются не в статистическом, а в рабочем состоянии.</p><p><b>Особенности:</b> </p><ul type=disc><li>Весы имеют удобный контрастный жидкокристаллический дисплей <li>Функция тарокомпенсации (компенсация массы тары во всём диапазоне взвешивания) <li>Функция автовыключения (после того, как взвешивание завершено, аппарат автоматически выключается) <li>Индикация перегрузки <li>В комплект входит кожаный чехол <li>Элегантная модель весов в классическом черном корпусе <li>Режим автокалибровки <li>Функция вычета тары <li>Экран с яркой подсветкой </li></ul><p><b>Технические характеристики:</b></p><ul><li>Цена деления: 0,01 г <li>Предел взвешивания: 200 г <li>Возможность выбора 6 единиц измерения <li>Размеры платформы: 100 х 76 мм <li>Вес: 130 г <li>Питание: 2 литиевые батарейки CR-2032 <li>Габаритные размеры: 155 x 75 x 15 мм <li>Вес: 130 г </li></ul><p><b>Производитель:</b> Tanita (Япония)</p><p><b>Гарантия:</b> 3 года в авторизованном сервис-центре </p> пылесос кирби цена</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/4e7490247492c7ab40236e7400fed0df.jpeg" alt="видео мясорубки мулинекс Мультиварка Redmond RMC-M4503" title="видео мясорубки мулинекс Мультиварка Redmond RMC-M4503"><div class="box" page="multivarka-redmond-rmcm-2990r"><span class="title">видео мясорубки мулинекс Мультиварка Redmond RMC-M4503</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/56cb596182a024c5be877e612e6462d8.jpeg" alt="тканевый мешок для пылесоса Пароварка Atlanta АТН-605" title="тканевый мешок для пылесоса Пароварка Atlanta АТН-605"><div class="box" page="parovarka-atlanta-atn-1050r-2"><span class="title">тканевый мешок для пылесоса Пароварка Atlanta АТН-605</span><p>от <span class="price">1050</span> руб.</p></div></li>
						<li><img src="photos/1f7b9f216facd163cc074eb10bad1faf.jpeg" alt="рисование утюгом Соковыжималка Moulinex BKA1" title="рисование утюгом Соковыжималка Moulinex BKA1"><div class="box" page="sokovyzhimalka-moulinex-bka-2400r"><span class="title">рисование утюгом Соковыжималка Moulinex BKA1</span><p>от <span class="price">2400</span> руб.</p></div></li>
						<li><img src="photos/d4f76a5fd1a2c3a65c40e2234f6145bc.jpeg" alt="кувшин для кофеварки Соковыжималка Moulinex JU570D3 Juice Machine" title="кувшин для кофеварки Соковыжималка Moulinex JU570D3 Juice Machine"><div class="box" page="sokovyzhimalka-moulinex-jud-juice-machine-3320r"><span class="title">кувшин для кофеварки Соковыжималка Moulinex JU570D3 Juice Machine</span><p>от <span class="price">3320</span> руб.</p></div></li>
						<li class="large"><img src="photos/663e4c317fe5187d7f962aa4403e4d2c.jpeg" alt="измерение электромагнитного излучения Электрический чайник Zauber Z-370" title="измерение электромагнитного излучения Электрический чайник Zauber Z-370"><div class="box" page="elektricheskiy-chaynik-zauber-z-1900r"><span class="title">измерение электромагнитного излучения Электрический чайник Zauber Z-370</span><p>от <span class="price">1900</span> руб.</p></div></li>
						<li class="large"><img src="photos/1b3cfce3fc4c2602ab4206bda1961e7d.jpeg" alt="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный" title="мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belolazurnyy-920r"><span class="title">мультиварка киев купить Чайник электрический  Vitesse VS-136 2л бело-лазурный</span><p>от <span class="price">920</span> руб.</p></div></li>
						<li class="large"><img src="photos/759cc36b06e68665280825b9c45b38c7.jpeg" alt="пылесосы в гродно Электрический чайник 1л красный Bodum BISTRO 11154-294EURO" title="пылесосы в гродно Электрический чайник 1л красный Bodum BISTRO 11154-294EURO"><div class="box" page="elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2270r"><span class="title">пылесосы в гродно Электрический чайник 1л красный Bodum BISTRO 11154-294EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li><img src="photos/16e3783a13e306fc3fd90925cbbcc384.jpeg" alt="блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO" title="блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO"><div class="box" page="elektricheskiy-chaynik-l-krasnyy-bodum-bistro-euro-2740r"><span class="title">блендер philips hr 2860 Электрический чайник 1.5л красный Bodum Bistro 11138-294EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li><img src="photos/97ad6f71f59b7db73d8fda12c75e94a2.jpeg" alt="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2" title="kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2"><div class="box" page="zaryadnoe-ustroystvo-gp-batteries-pbgsue-680r"><span class="title">kenwood пароварка Зарядное устройство GP Batteries PB360GS210-UE2</span><p>от <span class="price">680</span> руб.</p></div></li>
						<li><img src="photos/d221c08cbc7532258ec107ff315e3516.jpeg" alt="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)" title="измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)"><div class="box" page="personalnyy-dozimetr-dkgd-«grach»-attestovan-v-mchs-rossii-20500r"><span class="title">измельчитель kenwood Персональный дозиметр ДКГ-03Д «Грач» (аттестован в МЧС России)</span><p>от <span class="price">20500</span> руб.</p></div></li>
						<li><img src="photos/26befd04ebef6df7b3db2c4e6ee2357f.jpeg" alt="brand аэрогриль Фильтры для пылесоса Vitek VT-1864 (VT-1844)" title="brand аэрогриль Фильтры для пылесоса Vitek VT-1864 (VT-1844)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-215r-2"><span class="title">brand аэрогриль Фильтры для пылесоса Vitek VT-1864 (VT-1844)</span><p>от <span class="price">215</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("mini-vesy-tanita-3900r.php", 0, -4); if (file_exists("comments/mini-vesy-tanita-3900r.php")) require_once "comments/mini-vesy-tanita-3900r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="mini-vesy-tanita-3900r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>