<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-moulinex-by-l-1950r.php","микроволновые печи купить киев");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-moulinex-by-l-1950r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>микроволновые печи купить киев Чайник электрический Moulinex BY5101 1,5 л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="микроволновые печи купить киев, запчасти для утюгов, пылесос samsung sc4520, тканевый мешок для пылесоса, мультиварка multihotter отзывы, блендер philips hr 1617, куриное филе в пароварке, блендер металлический, мясорубка белвар отзывы, шампунь для пылесоса, десерты в блендере, утюг для волос профессиональный, бетоносмеситель миксер, блендер braun mx 2050,  кофемашины verobar">
		<meta name="description" content="микроволновые печи купить киев Электрический чайник Moulinex объемом 1,5 л и мощностью 2000 Вт быстро вскипятит...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/3db103a42b99a0a770887670f28f5ba2.jpeg" title="микроволновые печи купить киев Чайник электрический Moulinex BY5101 1,5 л"><img src="photos/3db103a42b99a0a770887670f28f5ba2.jpeg" alt="микроволновые печи купить киев Чайник электрический Moulinex BY5101 1,5 л" title="микроволновые печи купить киев Чайник электрический Moulinex BY5101 1,5 л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/multivarka-redmond-rmcm-4490r.php"><img src="photos/785647aa8682372d107781ac6f9a4974.jpeg" alt="запчасти для утюгов Мультиварка Redmond RMC-M4504" title="запчасти для утюгов Мультиварка Redmond RMC-M4504"></a><h2>Мультиварка Redmond RMC-M4504</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-elektricheskaya-vitek-vt-serebryanaya-3650r.php"><img src="photos/7c640af98399cc1caf99796cb169cc20.jpeg" alt="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная" title="пылесос samsung sc4520 Мясорубка электрическая Vitek VT-1672 серебряная"></a><h2>Мясорубка электрическая Vitek VT-1672 серебряная</h2></li>
							<li><a href="http://kitchentech.elitno.net/parovarka-atlanta-atn-1050r-2.php"><img src="photos/56cb596182a024c5be877e612e6462d8.jpeg" alt="тканевый мешок для пылесоса Пароварка Atlanta АТН-605" title="тканевый мешок для пылесоса Пароварка Atlanta АТН-605"></a><h2>Пароварка Atlanta АТН-605</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>микроволновые печи купить киев Чайник электрический Moulinex BY5101 1,5 л</h1>
						<div class="tb"><p>Цена: от <span class="price">1950</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_12023.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Электрический чайник Moulinex</b> объемом 1,5 л и мощностью 2000 Вт быстро вскипятит воду и автоматически выключится. Он оснащен скрытым нагревательным элементом, что сокращает образование накипи, продлевает срок службы устройства, а также упрощает очистку. Стильный современный дизайн корпуса чайника отлично впишется в интерьер любой кухни.</p><p>Центральный контакт с вращением на 360є позволяет легко устанавливать прибор на подставку из любого положения. Благодаря фильтру против накипи в чашку попадает только чистая вода. Безопасность в эксплуатации прибора обеспечена не только функцией автоотключения при закипании, но и отключением при снятии или в случае отсутствия воды. </p><p><b></b></p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 2000 Вт; <li>Объем: 1,5 л; <li>Плоский нагревательный элемент; <li>Фильтр от накипи; <li>Вращающийся корпус; <li>Индикатор уровня воды; <li>Световой индикатор; <li>Материал корпуса: металл; <li>Отключение при снятии, закипании или отсутствии воды; <li>Цвет: нержавеющая сталь.</li></ul><p><b>Производитель:</b> Moulinex.</p><p><b>Страна:</b> Франция.</p><p><b>Гарантия:</b> 2 года.</p> микроволновые печи купить киев</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/5463e59bde9d8697c1104a5ca7198687.jpeg" alt="мультиварка multihotter отзывы Пароварка Redmond RST-M1101" title="мультиварка multihotter отзывы Пароварка Redmond RST-M1101"><div class="box"><a href="http://kitchentech.elitno.net/parovarka-redmond-rstm-3990r.php"><h3 class="title">мультиварка multihotter отзывы Пароварка Redmond RST-M1101</h3><p>от <span class="price">3990</span> руб.</p></a></div></li>
						<li><img src="photos/c4c3375bd5e900bb92cb2c5b9021e247.jpeg" alt="блендер philips hr 1617 Термопот  Redmond RTP-M801" title="блендер philips hr 1617 Термопот  Redmond RTP-M801"><div class="box" page="termopot-redmond-rtpm-3290r"><span class="title">блендер philips hr 1617 Термопот  Redmond RTP-M801</span><p>от <span class="price">3290</span> руб.</p></div></li>
						<li><img src="photos/c75538a0a02b722bb4d5b9c47eb925e7.jpeg" alt="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л" title="куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesse-inox-bi-l-2570r"><span class="title">куриное филе в пароварке Чайник электрический Tefal Vitesse Inox BI7625 1,7 л</span><p>от <span class="price">2570</span> руб.</p></div></li>
						<li><img src="photos/f2d6d870289f867bca2e3ea0f8531c8e.jpeg" alt="блендер металлический Электрический чайник  Zauber Z-350" title="блендер металлический Электрический чайник  Zauber Z-350"><div class="box" page="elektricheskiy-chaynik-zauber-z-1600r"><span class="title">блендер металлический Электрический чайник  Zauber Z-350</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li class="large"><img src="photos/10b8ffb3398d2d300d11c2e37221e09e.jpeg" alt="мясорубка белвар отзывы Чайник электрический Maxima МК-G114" title="мясорубка белвар отзывы Чайник электрический Maxima МК-G114"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-990r"><span class="title">мясорубка белвар отзывы Чайник электрический Maxima МК-G114</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li class="large"><img src="photos/52100c33edc3ca0743ca02e24c7f8dba.jpeg" alt="шампунь для пылесоса Электрический чайник Atlanta АТН-720" title="шампунь для пылесоса Электрический чайник Atlanta АТН-720"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-550r"><span class="title">шампунь для пылесоса Электрический чайник Atlanta АТН-720</span><p>от <span class="price">550</span> руб.</p></div></li>
						<li class="large"><img src="photos/133af075f6993e048350b753f5c2c798.jpeg" alt="десерты в блендере Электрический чайник Atlanta АТН-727" title="десерты в блендере Электрический чайник Atlanta АТН-727"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-400r-2"><span class="title">десерты в блендере Электрический чайник Atlanta АТН-727</span><p>от <span class="price">400</span> руб.</p></div></li>
						<li><img src="photos/ae6aa53dcc9eb32133541922b9ec3b16.jpeg" alt="утюг для волос профессиональный Мини весы Tanita 1579" title="утюг для волос профессиональный Мини весы Tanita 1579"><div class="box" page="mini-vesy-tanita-3900r"><span class="title">утюг для волос профессиональный Мини весы Tanita 1579</span><p>от <span class="price">3900</span> руб.</p></div></li>
						<li><img src="photos/569a7a448800e6c331839b4f1803d826.jpeg" alt="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502" title="бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502"><div class="box" page="moyuschiy-koncentrat-thomas-protex-l-520r"><span class="title">бетоносмеситель миксер Моющий концентрат Thomas Protex 1 л 787-502</span><p>от <span class="price">520</span> руб.</p></div></li>
						<li><img src="photos/508d5d97fb58fc95875b08492316946f.jpeg" alt="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29" title="блендер braun mx 2050 Пылесос Dyson allergy dB DC 29"><div class="box" page="pylesos-dyson-allergy-db-dc-19990r"><span class="title">блендер braun mx 2050 Пылесос Dyson allergy dB DC 29</span><p>от <span class="price">19990</span> руб.</p></div></li>
						<li><img src="photos/39a5505798446240c306b0610cc8e434.jpeg" alt="сколько стоит моющий пылесос Пылесос Vitek VT-1834" title="сколько стоит моющий пылесос Пылесос Vitek VT-1834"><div class="box" page="pylesos-vitek-vt-5890r"><span class="title">сколько стоит моющий пылесос Пылесос Vitek VT-1834</span><p>от <span class="price">5890</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-moulinex-by-l-1950r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-moulinex-by-l-1950r.php")) require_once "comments/chaynik-elektricheskiy-moulinex-by-l-1950r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-moulinex-by-l-1950r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>