<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-vitesse-vs-l-950r.php","пылесосы филлипс");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-vitesse-vs-l-950r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>пылесосы филлипс Чайник электрический  Vitesse VS-138 1,7л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="пылесосы филлипс, кофеварка philips отзывы, купить пароварку в интернете, magic pot мультиварка, ручной блендер hr1659, хлебопечка panasonic 256, блендер philips hr1659, кофемашина bosch 5201, испечь черный хлеб в хлебопечке, курица с грибами в мультиварке, микроволновая печь bork, стимер для аэрогриля, держатель для пылесоса, мясорубка 6061,  самые популярные пылесосы">
		<meta name="description" content="пылесосы филлипс Электрический чайник Vitesse VS-138 необычного округлого  дизайна вскипятит 1,7 ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/b2f5222e6fab12eeb526363895bfe319.jpeg" title="пылесосы филлипс Чайник электрический  Vitesse VS-138 1,7л"><img src="photos/b2f5222e6fab12eeb526363895bfe319.jpeg" alt="пылесосы филлипс Чайник электрический  Vitesse VS-138 1,7л" title="пылесосы филлипс Чайник электрический  Vitesse VS-138 1,7л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-pogruzhnoy-moulinex-ddd-3050r.php"><img src="photos/88431db04944e702f33c054454f31139.jpeg" alt="кофеварка philips отзывы Блендер погружной Moulinex DD407D72" title="кофеварка philips отзывы Блендер погружной Moulinex DD407D72"></a><h2>Блендер погружной Moulinex DD407D72</h2></li>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovka-zigmund-shtain-bmo-s-5960r.php"><img src="photos/e00b2c7020a116b6823146ca3337e357.jpeg" alt="купить пароварку в интернете Микроволновка Zigmund & Shtain BMO 01.232 S" title="купить пароварку в интернете Микроволновка Zigmund & Shtain BMO 01.232 S"></a><h2>Микроволновка Zigmund & Shtain BMO 01.232 S</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektricheskiy-mikser-krasnyy-bodum-bistro-euro-2740r.php"><img src="photos/be6b78c2525e9286d015556c4db7013b.jpeg" alt="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO" title="magic pot мультиварка Электрический миксер красный Bodum BISTRO 11151-294EURO"></a><h2>Электрический миксер красный Bodum BISTRO 11151-294EURO</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>пылесосы филлипс Чайник электрический  Vitesse VS-138 1,7л</h1>
						<div class="tb"><p>Цена: от <span class="price">950</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19640.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Электрический чайник Vitesse VS-138 необычного округлого  дизайна вскипятит 1,7 литра воды в считанные минуты.<br>Дополнительными плюсами являются автоматическая блокировка  включения без воды, специальный фильтр защиты от накипи и отсек для хранения  шнура.</p><p><strong>Характеристики:</strong></p><ul type=\disc\><li>Объем:  1.7 л;</li><li>Мощность:  2200 Вт;</li><li>Тип  нагревательного элемента: закрытая спираль (центральный контакт);</li><li>Материал  корпуса: пластик;</li><li>Блокировка включения без воды;</li><li>Фильтр;</li><li>Индикатор уровня воды;</li><li>Индикация  включения;</li><li>Отсек для шнура.</li></ul><p><strong>Производитель: КНР</strong><br><strong>Гарантия: 1 год</strong></p> пылесосы филлипс</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/2118e94c9f54fd8ac8f1f2abebe50fe3.jpeg" alt="ручной блендер hr1659 Мультиварка Maruchi RW-FZ47" title="ручной блендер hr1659 Мультиварка Maruchi RW-FZ47"><div class="box" page="multivarka-maruchi-rwfz-4000r"><span class="title">ручной блендер hr1659 Мультиварка Maruchi RW-FZ47</span><p>от <span class="price">4000</span> руб.</p></div></li>
						<li><img src="photos/f5d552f595352df6a881129a694e04b1.jpeg" alt="хлебопечка panasonic 256 Чайник электрический Redmond RK-M112" title="хлебопечка panasonic 256 Чайник электрический Redmond RK-M112"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-990r"><span class="title">хлебопечка panasonic 256 Чайник электрический Redmond RK-M112</span><p>от <span class="price">990</span> руб.</p></div></li>
						<li><img src="photos/eb489286225dbbc8037e4654ee2b1544.jpeg" alt="блендер philips hr1659 Чайник электрический Redmond  RK-M114" title="блендер philips hr1659 Чайник электрический Redmond  RK-M114"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2990r"><span class="title">блендер philips hr1659 Чайник электрический Redmond  RK-M114</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/ad9a939cae5c8a1c68f17220dbb422a8.jpeg" alt="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый" title="кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый"><div class="box" page="chaynik-elektricheskiy-vitesse-vs-l-belyy-1080r"><span class="title">кофемашина bosch 5201 Чайник электрический  Vitesse VS-102 2,3л, белый</span><p>от <span class="price">1080</span> руб.</p></div></li>
						<li class="large"><img src="photos/388c2880498e546d8fcebc787f1cf894.jpeg" alt="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO" title="испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO"><div class="box" page="elektricheskiy-chaynik-l-chernyy-bodum-bistro-euro-2270r"><span class="title">испечь черный хлеб в хлебопечке Электрический чайник 1л черный Bodum BISTRO 11154-01EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li class="large"><img src="photos/d5bfaa3b5f694911004b112b3792a6d5.jpeg" alt="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130" title="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130"><div class="box" page="komplekt-filtrovmeshkov-karcher-480r"><span class="title">курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li class="large"><img src="photos/af4db2e11d74fd9a3df56b0b95fb949a.jpeg" alt="микроволновая печь bork Пылесос моющий Thomas Hygiene T2" title="микроволновая печь bork Пылесос моющий Thomas Hygiene T2"><div class="box" page="pylesos-moyuschiy-thomas-hygiene-t-15900r"><span class="title">микроволновая печь bork Пылесос моющий Thomas Hygiene T2</span><p>от <span class="price">15900</span> руб.</p></div></li>
						<li><img src="photos/127daa75b6d910b9f123f08316795848.png" alt="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37" title="стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37"><div class="box" page="pylesos-dyson-allergy-musclehead-dc-24590r"><span class="title">стимер для аэрогриля Пылесос Dyson allergy musclehead DC 37</span><p>от <span class="price">24590</span> руб.</p></div></li>
						<li><img src="photos/edc4236e3a4947da96211057e15ad9d5.jpeg" alt="держатель для пылесоса Пылесос Vitek VT-1847 красный" title="держатель для пылесоса Пылесос Vitek VT-1847 красный"><div class="box" page="pylesos-vitek-vt-krasnyy-3650r"><span class="title">держатель для пылесоса Пылесос Vitek VT-1847 красный</span><p>от <span class="price">3650</span> руб.</p></div></li>
						<li><img src="photos/9ae1fe09fe7308adffccf86c925a5fca.jpeg" alt="мясорубка 6061 Пылесос Thomas Inox 20 Professional" title="мясорубка 6061 Пылесос Thomas Inox 20 Professional"><div class="box" page="pylesos-thomas-inox-professional-6220r"><span class="title">мясорубка 6061 Пылесос Thomas Inox 20 Professional</span><p>от <span class="price">6220</span> руб.</p></div></li>
						<li><img src="photos/5de427df249cca428db0963f8867058e.jpeg" alt="плов в мультиварке супра Утюг паровой Tefal Ultimate Autoclean FV9430E2" title="плов в мультиварке супра Утюг паровой Tefal Ultimate Autoclean FV9430E2"><div class="box" page="utyug-parovoy-tefal-ultimate-autoclean-fve-3300r"><span class="title">плов в мультиварке супра Утюг паровой Tefal Ultimate Autoclean FV9430E2</span><p>от <span class="price">3300</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-vitesse-vs-l-950r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-vitesse-vs-l-950r.php")) require_once "comments/chaynik-elektricheskiy-vitesse-vs-l-950r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-vitesse-vs-l-950r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>