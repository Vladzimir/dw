<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r.php","рынок пылесосов");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>рынок пылесосов Пылесос моющий Thomas Prestige 20 S Aquafilter  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="рынок пылесосов, мешки для пылесоса vax, мультиварка redmond 4504, кухня микроволновой печи, вафельница орешек 4, марки микроволновых печей, блендер philips hr1659, panasonic мясорубка отзывы, очистка кофеварки, карандаш для чистки утюга, курица с грибами в мультиварке, магазин запчастей для мясорубок, пылесосы филипс отзывы, диски для кухонного комбайна,  работа парогенератора">
		<meta name="description" content="рынок пылесосов Моющий пылесос от Thomas - компактный многофункциональный прибор, который служит...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/f508d547808db2bce707d6b2135eb926.jpeg" title="рынок пылесосов Пылесос моющий Thomas Prestige 20 S Aquafilter"><img src="photos/f508d547808db2bce707d6b2135eb926.jpeg" alt="рынок пылесосов Пылесос моющий Thomas Prestige 20 S Aquafilter" title="рынок пылесосов Пылесос моющий Thomas Prestige 20 S Aquafilter -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/mikrovolnovaya-pech-vitek-vt-2770r.php"><img src="photos/4a49eabd132fa073a575c3edfbe7b80b.jpeg" alt="мешки для пылесоса vax Микроволновая печь Vitek VT-1681" title="мешки для пылесоса vax Микроволновая печь Vitek VT-1681"></a><h2>Микроволновая печь Vitek VT-1681</h2></li>
							<li><a href="http://kitchentech.elitno.net/myasorubka-redmond-rmg-3290r.php"><img src="photos/696c3eff6d4752e21e651f3d4b34c0a7.jpeg" alt="мультиварка redmond 4504 Мясорубка Redmond RMG-1204" title="мультиварка redmond 4504 Мясорубка Redmond RMG-1204"></a><h2>Мясорубка Redmond RMG-1204</h2></li>
							<li><a href="http://kitchentech.elitno.net/elektroplitka-indukcionnaya-maxima-mic-posuda-1790r.php"><img src="photos/d13e770b0f20ea7295762dcccfd88ddd.jpeg" alt="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда" title="кухня микроволновой печи Электроплитка индукционная Maxima MIC-0146 + Посуда"></a><h2>Электроплитка индукционная Maxima MIC-0146 + Посуда</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>рынок пылесосов Пылесос моющий Thomas Prestige 20 S Aquafilter</h1>
						<div class="tb"><p>Цена: от <span class="price">10800</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_14629.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Моющий пылесос от Thomas - компактный многофункциональный прибор, который служит для влажной или сухой уборки помещений. Он способен на многое: может собирать разлитую жидкость, мыть не только горизонтальные, но и вертикальные поверхности, очищать твердые или мягкие предметы, а также прочищать засоры в ванной. Модель подходит для всех возможных покрытий пола. Для влажной уборки в пылесосе предусмотрены резервуары: один – для чистой воды и один - для сбора грязной.</p><p>Благодаря двухступенчатой турбине прибор быстро и эффективно очищает любые поверхности, не оставляя их влажными, подобно другим моделям пылесосов. Он прост в подготовке к уборке - понадобится лишь установить аквафильтр и надеть на мотор патронный фильтр. Циклонный аквафильтр устройства, емкостью в два литра, отлично удерживает пыль, остаток же оседает на долговечном патронном фильтре, который время от времени необходимо ополаскивать.</p><p><b>Характеристики:</b></p><ul type=disc><li>Тип: обычный; </li><li>Уборка: сухая / влажная; </li><li>Потребляемая мощность: 1600 Вт; </li><li>Пылесборник: аквафильтр, емкостью 2 л; </li><li>Регулятор мощности: на корпусе; </li><li>Источник питания: сеть; </li><li>Вертикальная парковка трубы всасывания на корпусе пылесоса; </li><li>Размеры (ШxГxВ): 39x39x73 cм; </li><li>Нагнетательный насос для распыления моющего средства 4 бар; </li><li>Объем 20 л; </li><li>Резервуар 3,6 литра моющего раствора; </li><li>Резервуар 6 л для грязной воды; </li><li>Возможность подключения электрощетки: есть.</li></ul><p><b>Дополнительные насадки в комплекте:</b></p><ul type=disc><li>Оросительная экстракционная насадка для чистки ковров; </li><li>Ковровая; </li><li>Щелевая; </li><li>Оросительная для мягкой мебели; </li><li>Сифонная; </li><li>Адаптер для твердых ковровых покрытий.</li></ul><p><b>Производитель:</b> Thomas.</p><p><b>Страна:</b> Германия.</p><p><b>Гарантия:</b> 2 года.</p> рынок пылесосов</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/d7869500a03daf3749520ba97157adc1.jpeg" alt="вафельница орешек 4 Хлебопечка Moulinex OW310130 Uno" title="вафельница орешек 4 Хлебопечка Moulinex OW310130 Uno"><div class="box" page="hlebopechka-moulinex-ow-uno-4990r"><span class="title">вафельница орешек 4 Хлебопечка Moulinex OW310130 Uno</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/d6db045bcfab03ae142ac160811c2a0a.jpeg" alt="марки микроволновых печей Чайник электричесукий Atlanta ATH-756" title="марки микроволновых печей Чайник электричесукий Atlanta ATH-756"><div class="box" page="chaynik-elektrichesukiy-atlanta-ath-950r"><span class="title">марки микроволновых печей Чайник электричесукий Atlanta ATH-756</span><p>от <span class="price">950</span> руб.</p></div></li>
						<li><img src="photos/eb489286225dbbc8037e4654ee2b1544.jpeg" alt="блендер philips hr1659 Чайник электрический Redmond  RK-M114" title="блендер philips hr1659 Чайник электрический Redmond  RK-M114"><div class="box" page="chaynik-elektricheskiy-redmond-rkm-2990r"><span class="title">блендер philips hr1659 Чайник электрический Redmond  RK-M114</span><p>от <span class="price">2990</span> руб.</p></div></li>
						<li><img src="photos/0f99b07bf5e19dab36f8028f75c48889.jpeg" alt="panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735" title="panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-450r"><span class="title">panasonic мясорубка отзывы Электрический чайник Atlanta АТН-735</span><p>от <span class="price">450</span> руб.</p></div></li>
						<li class="large"><img src="photos/22d30b7337c9635a9decf8a39fad0a54.jpeg" alt="очистка кофеварки Электрический чайник Atlanta АТН-793" title="очистка кофеварки Электрический чайник Atlanta АТН-793"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1420r-2"><span class="title">очистка кофеварки Электрический чайник Atlanta АТН-793</span><p>от <span class="price">1420</span> руб.</p></div></li>
						<li class="large"><img src="photos/ab7fd4cacdc88b690decc0d20bd53770.jpeg" alt="карандаш для чистки утюга Чайник-термос Atlanta АТН-768" title="карандаш для чистки утюга Чайник-термос Atlanta АТН-768"><div class="box" page="chayniktermos-atlanta-atn-1700r"><span class="title">карандаш для чистки утюга Чайник-термос Atlanta АТН-768</span><p>от <span class="price">1700</span> руб.</p></div></li>
						<li class="large"><img src="photos/d5bfaa3b5f694911004b112b3792a6d5.jpeg" alt="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130" title="курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130"><div class="box" page="komplekt-filtrovmeshkov-karcher-480r"><span class="title">курица с грибами в мультиварке Комплект фильтров-мешков Karcher 6.959-130</span><p>от <span class="price">480</span> руб.</p></div></li>
						<li><img src="photos/ed6cccd8ae597a978fe91c415f9d06d3.jpeg" alt="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)" title="магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)"><div class="box" page="filtry-dlya-pylesosa-vitek-vt-vt-135r"><span class="title">магазин запчастей для мясорубок Фильтры для пылесоса Vitek VT-1855 (VT-1825)</span><p>от <span class="price">135</span> руб.</p></div></li>
						<li><img src="photos/20c033d3c85583b2e6a71a21254a84f6.jpeg" alt="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail" title="пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail"><div class="box" page="schetka-dlya-tverdyh-poverhnostey-v-upakovke-dyson-hard-floor-tool-assy-retail-1590r"><span class="title">пылесосы филипс отзывы Щетка для твердых поверхностей в упаковке Dyson Hard Floor Tool Assy Retail</span><p>от <span class="price">1590</span> руб.</p></div></li>
						<li><img src="photos/6eaac51c54fbf44dce471193ec6d5c18.jpeg" alt="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail" title="диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail"><div class="box" page="nabor-dlya-udaleniya-pyaten-s-kovrovyh-pokrytiy-i-myagkoy-mebeli-dyson-party-cleanup-kit-ir-cl-retail-2490r"><span class="title">диски для кухонного комбайна Набор для удаления пятен с ковровых покрытий и мягкой мебели Dyson Party Clean-Up Kit Ir Cl Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/07ba23dd2664a1f6554e1b4f71151996.jpeg" alt="мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R" title="мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R"><div class="box" page="pylesos-moyuschiy-thomas-compact-r-7790r"><span class="title">мясорубку panasonic купить Пылесос моющий Thomas Compact 20 R</span><p>от <span class="price">7790</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r.php", 0, -4); if (file_exists("comments/pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r.php")) require_once "comments/pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="pylesos-moyuschiy-thomas-prestige-s-aquafilter-10800r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>