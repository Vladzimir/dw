<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r.php","мультиварка rmc 4502");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мультиварка rmc 4502 Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мультиварка rmc 4502, блюда на пару в мультиварке, мультиварка паларис, кухонный комбайн tefal, покупка мультиварки, манник в мультиварке панасоник, блендер vita mix, взбить сливки блендером, лучший пылесос с аквафильтром, сладкая выпечка в хлебопечке, мультиварка sinbo отзывы, рейтинг пылесосов 2011, мультиварка мэджик пот, продажа мультиварок,  аэрогриль lentel d101b">
		<meta name="description" content="мультиварка rmc 4502 Никель-металлогидридные аккумуляторы от GP Batteries разработаны в соответствии ...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/610809077bd818e574e4a814e433a999.jpeg" title="мультиварка rmc 4502 Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2"><img src="photos/610809077bd818e574e4a814e433a999.jpeg" alt="мультиварка rmc 4502 Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2" title="мультиварка rmc 4502 Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-vitek-vt-krasnyy-2500r.php"><img src="photos/f0cf14852d6125070feba5c77deecf93.jpeg" alt="блюда на пару в мультиварке Блендер Vitek VT-1458 красный" title="блюда на пару в мультиварке Блендер Vitek VT-1458 красный"></a><h2>Блендер Vitek VT-1458 красный</h2></li>
							<li><a href="http://kitchentech.elitno.net/avtomaticheskaya-kofemashina-melitta-caffeo-bistro-erp-serebristaya-36999r.php"><img src="photos/9fea21248e7566db156b2a08dbe43d4c.jpeg" alt="мультиварка паларис Автоматическая кофемашина Melitta Caffeo Bistro ERP, серебристая" title="мультиварка паларис Автоматическая кофемашина Melitta Caffeo Bistro ERP, серебристая"></a><h2>Автоматическая кофемашина Melitta Caffeo Bistro ERP, серебристая</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r.php"><img src="photos/33b43228a18b1110c1c8a14516611c99.jpeg" alt="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE" title="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE"></a><h2>Кухонный комбайн Tefal Storeinn DO302 EAE</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мультиварка rmc 4502 Аккумуляторы GP Batteries Rechargeable 1300 мАч 130AAHC-BC2</h1>
						<div class="tb"><p>Цена: от <span class="price">220</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16535.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Никель-металлогидридные аккумуляторы от GP Batteries разработаны в соответствии с современными особенностями портативных устройств. К примеру, зарядка цифрового фотоаппарата с такими элементами питания обеспечит непрерывную работу в 4 раза дольше, чем алкалиновые батарейки.</p><p>Среди особенностей можно отметить: отличную способность разряжаться большими токами, быструю зарядку, до 1000 циклов заряда-разряда, а также экологическую безопасность. В комплекте 2 штуки типа АА.</p><p><b>Характеристики:</b></p><ul type=disc><li>Технология производства: NiMh <li>Типоразмер: AA <li>Максимальная емкость: 1000мАч <li>Напряжение: 1,2V <li>Имеют длительный срок службы (до 1000 циклов заряд/разряд) <li>Характеризуются стабильной работой в широком диапазоне температур (от –20 до +50С) <li>Полностью отсутствует \эффект памяти\ <li>Оснащены предохранительными клапанами (для избегания последствий нарушения условий эксплуатации) <li>Не содержат ртути и кадмия – безопасны для окружающей среды </li></ul><p><b>Производитель:</b> GP Batteries.</p><p><b>Страна:</b> Гонконг.</p> мультиварка rmc 4502</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/3f9ea91ea855b5f87eaf160e0a74622e.jpeg" alt="покупка мультиварки Микроволновая печь с грилем Moulinex MW533031 пароварка, 23 л, нержавеющая сталь" title="покупка мультиварки Микроволновая печь с грилем Moulinex MW533031 пароварка, 23 л, нержавеющая сталь"><div class="box" page="mikrovolnovaya-pech-s-grilem-moulinex-mw-parovarka-l-nerzhaveyuschaya-stal-7000r"><span class="title">покупка мультиварки Микроволновая печь с грилем Moulinex MW533031 пароварка, 23 л, нержавеющая сталь</span><p>от <span class="price">7000</span> руб.</p></div></li>
						<li><img src="photos/1f738d1ec8329b2501736d61b71f3914.jpeg" alt="манник в мультиварке панасоник Пароварка Tefal Invent VC1014" title="манник в мультиварке панасоник Пароварка Tefal Invent VC1014"><div class="box" page="parovarka-tefal-invent-vc-3930r"><span class="title">манник в мультиварке панасоник Пароварка Tefal Invent VC1014</span><p>от <span class="price">3930</span> руб.</p></div></li>
						<li><img src="photos/5698b5516003bb90b12e44c09c465d2a.jpeg" alt="блендер vita mix Чайник электрический Maxima MK-G301" title="блендер vita mix Чайник электрический Maxima MK-G301"><div class="box" page="chaynik-elektricheskiy-maxima-mkg-1390r"><span class="title">блендер vita mix Чайник электрический Maxima MK-G301</span><p>от <span class="price">1390</span> руб.</p></div></li>
						<li><img src="photos/3a6317b1e5aa0207019da754f6c2351b.jpeg" alt="взбить сливки блендером Электрический чайник Atlanta АТН-673" title="взбить сливки блендером Электрический чайник Atlanta АТН-673"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-560r"><span class="title">взбить сливки блендером Электрический чайник Atlanta АТН-673</span><p>от <span class="price">560</span> руб.</p></div></li>
						<li class="large"><img src="photos/d509d0771406a8c20b2506d316fad0aa.jpeg" alt="лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario" title="лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario"><div class="box" page="chaynik-melitta-look-aqua-vario-2838r"><span class="title">лучший пылесос с аквафильтром Чайник Melitta Look Aqua Vario</span><p>от <span class="price">2838</span> руб.</p></div></li>
						<li class="large"><img src="photos/70eaaca49bbd014982b9856679d5c7e6.jpeg" alt="сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO" title="сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO"><div class="box" page="elektricheskiy-chaynik-l-bodum-bistro-euro-2740r"><span class="title">сладкая выпечка в хлебопечке Электрический чайник 1,5л Bodum BISTRO 11138-01EURO</span><p>от <span class="price">2740</span> руб.</p></div></li>
						<li class="large"><img src="photos/8944f8fffe785f4fd9884d354ff925ed.jpeg" alt="мультиварка sinbo отзывы Электрический чайник 1л белый Bodum BISTRO 11154-913EURO" title="мультиварка sinbo отзывы Электрический чайник 1л белый Bodum BISTRO 11154-913EURO"><div class="box" page="elektricheskiy-chaynik-l-belyy-bodum-bistro-euro-2270r"><span class="title">мультиварка sinbo отзывы Электрический чайник 1л белый Bodum BISTRO 11154-913EURO</span><p>от <span class="price">2270</span> руб.</p></div></li>
						<li><img src="photos/ea47296a93804ab77bc9f5e5af614a8b.jpeg" alt="рейтинг пылесосов 2011 Батарейка GP Batteries Super alkaline LR14 14A-BC2" title="рейтинг пылесосов 2011 Батарейка GP Batteries Super alkaline LR14 14A-BC2"><div class="box" page="batareyka-gp-batteries-super-alkaline-lr-abc-130r"><span class="title">рейтинг пылесосов 2011 Батарейка GP Batteries Super alkaline LR14 14A-BC2</span><p>от <span class="price">130</span> руб.</p></div></li>
						<li><img src="photos/51ac41098d88811e7ab3241e4fa31a8c.jpeg" alt="мультиварка мэджик пот Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA" title="мультиварка мэджик пот Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA"><div class="box" page="akkumulyatory-gp-batteries-rechargeable-mach-aaahcuc-petgaaa-300r"><span class="title">мультиварка мэджик пот Аккумуляторы GP Batteries Rechargeable 1000 мАч 100AAAHC-UC2 PET-GAAA</span><p>от <span class="price">300</span> руб.</p></div></li>
						<li><img src="photos/08f854ed7155a317d7f9ee53182183f6.jpeg" alt="продажа мультиварок Парогенератор Lelit PS21" title="продажа мультиварок Парогенератор Lelit PS21"><div class="box" page="parogenerator-lelit-ps-12650r-2"><span class="title">продажа мультиварок Парогенератор Lelit PS21</span><p>от <span class="price">12650</span> руб.</p></div></li>
						<li><img src="photos/bf1db2ec9a55f45d9ef32e836546d600.jpeg" alt="уха в мультиварке Пылесос моющий Thomas Super 30 S" title="уха в мультиварке Пылесос моющий Thomas Super 30 S"><div class="box" page="pylesos-moyuschiy-thomas-super-s-9020r"><span class="title">уха в мультиварке Пылесос моющий Thomas Super 30 S</span><p>от <span class="price">9020</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r.php", 0, -4); if (file_exists("comments/akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r.php")) require_once "comments/akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="akkumulyatory-gp-batteries-rechargeable-mach-aahcbc-220r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>