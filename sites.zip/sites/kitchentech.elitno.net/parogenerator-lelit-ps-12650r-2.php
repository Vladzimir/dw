<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("parogenerator-lelit-ps-12650r-2.php","мощность соковыжималки");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("parogenerator-lelit-ps-12650r-2.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>мощность соковыжималки Парогенератор Lelit PS21  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="мощность соковыжималки, bullet express кухонный комбайн, конвейер мясорубки сканворд, мясорубка moulinex hv, tupperware миксер, кухонный комбайн tefal, рецепт пельменей в хлебопечке, профессиональные утюги, измельчитель сена, делонги кофемашина примадонна, пылесос mediclean, clatronic хлебопечка, бытовой утюг, овощи гриль в аэрогриле,  пылесос bosch 82425">
		<meta name="description" content="мощность соковыжималки Парогенератор от итальянского производителя Lelit с бойлером из нержавеющей стал...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/08f854ed7155a317d7f9ee53182183f6.jpeg" title="мощность соковыжималки Парогенератор Lelit PS21"><img src="photos/08f854ed7155a317d7f9ee53182183f6.jpeg" alt="мощность соковыжималки Парогенератор Lelit PS21" title="мощность соковыжималки Парогенератор Lelit PS21 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/aerogril-maxima-mag-1970r.php"><img src="photos/04a8e0ddae201f494a4dc0f24ca2a85c.jpeg" alt="bullet express кухонный комбайн Аэрогриль Maxima MAG-0147" title="bullet express кухонный комбайн Аэрогриль Maxima MAG-0147"></a><h2>Аэрогриль Maxima MAG-0147</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-braun-mr-multiquick-3360r.php"><img src="photos/94a68ac1086ff8fbedebcd6e22667c94.jpeg" alt="конвейер мясорубки сканворд Блендер Braun MR-7 730 Multiquick" title="конвейер мясорубки сканворд Блендер Braun MR-7 730 Multiquick"></a><h2>Блендер Braun MR-7 730 Multiquick</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-solo-pure-silverblack-27000r.php"><img src="photos/e049963f26559d8e89e28ab3a3213f10.jpeg" alt="мясорубка moulinex hv Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)" title="мясорубка moulinex hv Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Solo Pure Silver-Black (4.0009.95)</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>мощность соковыжималки Парогенератор Lelit PS21</h1>
						<div class="tb"><p>Цена: от <span class="price">12650</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_16429.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Парогенератор от итальянского производителя Lelit с бойлером из нержавеющей стали может использоваться как дома, так и в профессиональной сфере. Модель <b>PS21</b> работает на обычной водопроводной воде, внутри алюминиевой подошвы утюга плотно запаяны 32 паровые камеры.</p><p>Среди достоинств парогенератора можно отметить: уникальный нагревательный элемент утюга, а также пробковое антискользящее покрытие рукоятки. При необходимости кнопку подачи пара можно настроить под левшей. Вес изделия 6,8 кг.</p><p><b>Технические характеристики:</b></p><ul type=disc><li>Напряжение: 220/230 В <li>Номинальный/Фактический объем бойлера: 1,4/1 л <li>Время непрерывной работы: 1 час <li>Потребляемая мощность: Утюг – 800 кВт/ Бойлер – 1000 кВт <li>Рабочее/ Максимальное давление пара: 2,5/5,5 бар <li>Стандартная комплектация: Воронка для залива воды. Утюг FS454 -вес 1,8 кг. Силиконовый коврик-подставка <li>Дополнительная комплектация: Тефлоновая подошва LELIT PA 205/1. Силиконовый коврик под утюг LELIT CD363. Подставка под парогенератор LELIT PA032. Коврик для очистки утюга Puliferro <li>Технические особенности: корпус и бойлер из нержавеющей стали INOX 18/10, нагревательный элемент выполнен из меди; Внутренний электроклапан. <li>Размер: 27х31х39 см <li>Вес: 6,8 кг</li></ul><p><b>Производитель:</b> Lelit.</p><p><b>Страна:</b> Италия.</p><p><b>Гарантия:</b> 1 год.</p> мощность соковыжималки</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/701c1fd8791de13ef3fc3b11f131d4a2.jpeg" alt="tupperware миксер Вспениватель Melitta Cremio белый" title="tupperware миксер Вспениватель Melitta Cremio белый"><div class="box" page="vspenivatel-melitta-cremio-belyy-4155r"><span class="title">tupperware миксер Вспениватель Melitta Cremio белый</span><p>от <span class="price">4155</span> руб.</p></div></li>
						<li><img src="photos/33b43228a18b1110c1c8a14516611c99.jpeg" alt="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE" title="кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE"><div class="box" page="kuhonnyy-kombayn-tefal-storeinn-do-eae-3570r"><span class="title">кухонный комбайн tefal Кухонный комбайн Tefal Storeinn DO302 EAE</span><p>от <span class="price">3570</span> руб.</p></div></li>
						<li><img src="photos/d325e4ff8de4614af80db126de07173a.jpeg" alt="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8" title="рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8"><div class="box" page="myasorubka-redmond-rmg-6690r"><span class="title">рецепт пельменей в хлебопечке Мясорубка Redmond RMG-1203-8</span><p>от <span class="price">6690</span> руб.</p></div></li>
						<li><img src="photos/8d898eca4e96ee4a2fd539403a61a2e7.jpeg" alt="профессиональные утюги Соковыжималка для цитрусовых" title="профессиональные утюги Соковыжималка для цитрусовых"><div class="box" page="sokovyzhimalka-dlya-citrusovyh-1500r"><span class="title">профессиональные утюги Соковыжималка для цитрусовых</span><p>от <span class="price">1500</span> руб.</p></div></li>
						<li class="large"><img src="photos/b563c2d22903c88ab1496d97329bc5bf.jpeg" alt="измельчитель сена Тостер Atlanta ATH-234" title="измельчитель сена Тостер Atlanta ATH-234"><div class="box" page="toster-atlanta-ath-690r"><span class="title">измельчитель сена Тостер Atlanta ATH-234</span><p>от <span class="price">690</span> руб.</p></div></li>
						<li class="large"><img src="photos/46a5120709bf99f581bc7ea7569bd649.png" alt="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902" title="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902"><div class="box" page="hlebopech-redmond-rbmm-3990r"><span class="title">делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li class="large"><img src="photos/4f7eae7926bb1b2816625b5940a25b78.jpeg" alt="пылесос mediclean Чайник электрический Vitek VT-1157" title="пылесос mediclean Чайник электрический Vitek VT-1157"><div class="box" page="chaynik-elektricheskiy-vitek-vt-2150r"><span class="title">пылесос mediclean Чайник электрический Vitek VT-1157</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li><img src="photos/1bbdc32e5167c3f95a77515679aaf9df.jpeg" alt="clatronic хлебопечка Электрический чайник Atlanta АТН-700" title="clatronic хлебопечка Электрический чайник Atlanta АТН-700"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-1280r"><span class="title">clatronic хлебопечка Электрический чайник Atlanta АТН-700</span><p>от <span class="price">1280</span> руб.</p></div></li>
						<li><img src="photos/100a2bcb8188ff9463a9e3368c849858.jpeg" alt="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit" title="бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit"><div class="box" page="nabor-dlya-uborki-v-avtomobile-dyson-car-cleaning-kit-2790r"><span class="title">бытовой утюг Набор для уборки в автомобиле Dyson Car Cleaning Kit</span><p>от <span class="price">2790</span> руб.</p></div></li>
						<li><img src="photos/d8b76d5d925f2e48955ce7204e57a699.jpeg" alt="овощи гриль в аэрогриле Набор для профилактики аллергии Dyson Allergy Kit Retail" title="овощи гриль в аэрогриле Набор для профилактики аллергии Dyson Allergy Kit Retail"><div class="box" page="nabor-dlya-profilaktiki-allergii-dyson-allergy-kit-retail-2490r"><span class="title">овощи гриль в аэрогриле Набор для профилактики аллергии Dyson Allergy Kit Retail</span><p>от <span class="price">2490</span> руб.</p></div></li>
						<li><img src="photos/a9173acd4bbfab2975fc7d7fd7dd2bd2.jpeg" alt="утюг braun texstyle control Пылесос моющий Thomas Twin T1 Aquafilter" title="утюг braun texstyle control Пылесос моющий Thomas Twin T1 Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-t-aquafilter-13080r"><span class="title">утюг braun texstyle control Пылесос моющий Thomas Twin T1 Aquafilter</span><p>от <span class="price">13080</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("parogenerator-lelit-ps-12650r-2.php", 0, -4); if (file_exists("comments/parogenerator-lelit-ps-12650r-2.php")) require_once "comments/parogenerator-lelit-ps-12650r-2.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="parogenerator-lelit-ps-12650r-2.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>