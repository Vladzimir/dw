<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r.php","хлебопечка с функцией йогурт");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>хлебопечка с функцией йогурт Чайник электрический Tefal VitesseS BF66224 1,7 л  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="хлебопечка с функцией йогурт, электрочайник braun, мультиварка скороварка moulinex, выбор кофемашины, каталог мясорубок, хлебопечка мулинекс 3101, утюг philips 9220, смазочный утюг, запчасти для пылесоса lg, пылесос для сухой чистки, греется пылесос, что можно сделать из пылесоса, утюг с тефлоновым покрытием, kress пылесос,  мультиварка кенвуд">
		<meta name="description" content="хлебопечка с функцией йогурт Электрический чайник Tefal VitesseS BF66224, выполненный в приятном салатовом цв...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/5a4405159d0c690183630df2cbdbbd36.jpeg" title="хлебопечка с функцией йогурт Чайник электрический Tefal VitesseS BF66224 1,7 л"><img src="photos/5a4405159d0c690183630df2cbdbbd36.jpeg" alt="хлебопечка с функцией йогурт Чайник электрический Tefal VitesseS BF66224 1,7 л" title="хлебопечка с функцией йогурт Чайник электрический Tefal VitesseS BF66224 1,7 л -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/chopper-vitek-vt-1790r.php"><img src="photos/ab6d4d55ecf241ffc9d0ef81c9ea44bc.jpeg" alt="электрочайник braun Чоппер Vitek VT-1641" title="электрочайник braun Чоппер Vitek VT-1641"></a><h2>Чоппер Vitek VT-1641</h2></li>
							<li><a href="http://kitchentech.elitno.net/espressokofemashina-melitta-caffeo-lattea-silverwhite-34975r.php"><img src="photos/6fa7808f592c05532d5148c220952ba1.jpeg" alt="мультиварка скороварка moulinex Эспрессо-кофемашина Melitta Caffeo Lattea Silver-White (4.0009.94)" title="мультиварка скороварка moulinex Эспрессо-кофемашина Melitta Caffeo Lattea Silver-White (4.0009.94)"></a><h2>Эспрессо-кофемашина Melitta Caffeo Lattea Silver-White (4.0009.94)</h2></li>
							<li><a href="http://kitchentech.elitno.net/pribor-dlya-vakuumnoy-upakovki-vacuum-sealer-v-1100r.php"><img src="photos/4f2572ea69a163b235386a6893a52b4a.jpeg" alt="выбор кофемашины Прибор для вакуумной упаковки Vacuum Sealer 024V" title="выбор кофемашины Прибор для вакуумной упаковки Vacuum Sealer 024V"></a><h2>Прибор для вакуумной упаковки Vacuum Sealer 024V</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>хлебопечка с функцией йогурт Чайник электрический Tefal VitesseS BF66224 1,7 л</h1>
						<div class="tb"><p>Цена: от <span class="price">1620</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_10472.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p><b>Электрический чайник </b><b>Tefal VitesseS </b><b>BF66224</b>, выполненный в приятном салатовом цвете, будет ежедневно дарить своим обладателям только положительные эмоции, и обеспечивать максимальный комфорт. Однако помимо стильного дизайна, он еще и функционален: прибор имеет регулируемый термостат, благодаря которому вы сможете не только кипятить воду, но и нагревать ее до температуры 80°С, которая идеальна для заваривания зеленого, красного, белого, желтого чаев, а также растворимого кофе или горячего шоколада. Модель выполнена в пластиковом корпусе, с закрытым нагревательным элементом из нержавеющей стали, оснащена нейлоновым фильтром против накипи, индикаторами включения и уровня воды, кнопкой блокировки крышки. Мощность чайника – 2200 Вт, объем – 1,7 л. </p><p><b>Характеристики:</b></p><ul type=disc><li>Мощность: 2200 Вт; <li>Объем: 1,7 л; <li>Тип нагревательного элемента: закрытая спираль (центральный контакт); <li>Покрытие нагревательного элемента: нержавеющая сталь; <li>Съемный фильтр против накипи (материал – нейлон); <li>Терморегулятор со световым индикатором; <li>Положение «нагрев до 80°С»; <li>Индикатор уровня воды; <li>Индикация включения; <li>Кнопка блокировки крышки; <li>Блокировка включения без воды; <li>Корпус из пластика; <li>Автоотключение; <li>Отсек для шнура; <li>Цвет: зеленый.</li></ul><p><b>Производитель:</b> Tefal.</p><p><b>Страна: </b>Франция.</p><p><b>Гарантия: </b>2 года.</p> хлебопечка с функцией йогурт</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/e07564a5fe71e20051b3b21f0806536a.jpeg" alt="каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam" title="каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam"><div class="box" page="sokovyzhimalka-moulinex-jue-tom-yam-1850r"><span class="title">каталог мясорубок Соковыжималка Moulinex JU32013E Tom Yam</span><p>от <span class="price">1850</span> руб.</p></div></li>
						<li><img src="photos/7903c21b4883d9e9c99d0a478392fee7.jpeg" alt="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906" title="хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906"><div class="box" page="sokovyzhimalka-redmond-rjm-4990r"><span class="title">хлебопечка мулинекс 3101 Соковыжималка  Redmond RJ-M906</span><p>от <span class="price">4990</span> руб.</p></div></li>
						<li><img src="photos/f99ea88369bed621a6594f78c2508e9a.jpeg" alt="утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO" title="утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO"><div class="box" page="elektricheskaya-sokovyzhimalka-limonnaya-bodum-bistro-euro-3340r"><span class="title">утюг philips 9220 Электрическая соковыжималка лимонная Bodum BISTRO 11149-565EURO</span><p>от <span class="price">3340</span> руб.</p></div></li>
						<li><img src="photos/53d96832eb34bb57a7f20e415ffd59f8.jpeg" alt="смазочный утюг Тостер Russell Hobbs Cottage, арт. 18260-57" title="смазочный утюг Тостер Russell Hobbs Cottage, арт. 18260-57"><div class="box" page="toster-russell-hobbs-cottage-art-2690r"><span class="title">смазочный утюг Тостер Russell Hobbs Cottage, арт. 18260-57</span><p>от <span class="price">2690</span> руб.</p></div></li>
						<li class="large"><img src="photos/57a9dd1cf47f278e2b8c998d7aabc0c5.jpeg" alt="запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный" title="запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный"><div class="box" page="bodum-bistro-euro-toster-krasnyy-3660r"><span class="title">запчасти для пылесоса lg Bodum BISTRO 10709-294EURO Тостер красный</span><p>от <span class="price">3660</span> руб.</p></div></li>
						<li class="large"><img src="photos/92677a851872ec83258943db2c5f8e10.jpeg" alt="пылесос для сухой чистки Чайник электрический Tefal Reminisce KI2016 1,7 л" title="пылесос для сухой чистки Чайник электрический Tefal Reminisce KI2016 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-reminisce-ki-l-2370r-2"><span class="title">пылесос для сухой чистки Чайник электрический Tefal Reminisce KI2016 1,7 л</span><p>от <span class="price">2370</span> руб.</p></div></li>
						<li class="large"><img src="photos/f529cddb8b0b7bbdfe7eea8e3d43b5b1.jpeg" alt="греется пылесос Чайник электрический Atlanta ATH-752" title="греется пылесос Чайник электрический Atlanta ATH-752"><div class="box" page="chaynik-elektricheskiy-atlanta-ath-1600r-2"><span class="title">греется пылесос Чайник электрический Atlanta ATH-752</span><p>от <span class="price">1600</span> руб.</p></div></li>
						<li><img src="photos/537c78beb6320fe2c86004c22681bdc6.jpeg" alt="что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)" title="что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-l-760r"><span class="title">что можно сделать из пылесоса Чайник электрический Maxima MК- M221 (1,5л)</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/9886fb8aa4d27a4c0947d702e96f79ee.jpeg" alt="утюг с тефлоновым покрытием Чайник электрический Maxima MК- M291" title="утюг с тефлоновым покрытием Чайник электрический Maxima MК- M291"><div class="box" page="chaynik-elektricheskiy-maxima-mk-m-760r-2"><span class="title">утюг с тефлоновым покрытием Чайник электрический Maxima MК- M291</span><p>от <span class="price">760</span> руб.</p></div></li>
						<li><img src="photos/cfc3673046a371ff9baffb342aa8e52b.jpeg" alt="kress пылесос Пылесос моющий Thomas Twin Aquafilter" title="kress пылесос Пылесос моющий Thomas Twin Aquafilter"><div class="box" page="pylesos-moyuschiy-thomas-twin-aquafilter-11550r"><span class="title">kress пылесос Пылесос моющий Thomas Twin Aquafilter</span><p>от <span class="price">11550</span> руб.</p></div></li>
						<li><img src="photos/63eadb71b95851c3e7f26e5885bd43ae.jpeg" alt="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832" title="moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832"><div class="box" page="pylesos-s-akvafiltrom-vitek-vt-6900r"><span class="title">moulinex mk7003 мультиварка Пылесос с аквафильтром Vitek VT-1832</span><p>от <span class="price">6900</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r.php", 0, -4); if (file_exists("comments/chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r.php")) require_once "comments/chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="chaynik-elektricheskiy-tefal-vitesses-bf-l-1620r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>