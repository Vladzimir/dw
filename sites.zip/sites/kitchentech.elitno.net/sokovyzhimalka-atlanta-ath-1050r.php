<?php
	session_start();
	
	error_reporting(0);
	
	require_once "comments.php";

	$go = new Comments(); 
	$go->AutoComment("sokovyzhimalka-atlanta-ath-1050r.php","очистка кофемашины");

	if (!empty($_POST["author"]) && !empty($_POST["comment"]) && !empty($_POST["captcha"]))
	{
		$nick = $_POST["author"];
		$comment = $_POST["comment"];
		
		if ($_SESSION["captcha"] == $_POST["captcha"])
		{
			$go->UserComment("sokovyzhimalka-atlanta-ath-1050r.php", $nick, $comment);
		}
		else
		{
			$error = "class=\"error\"";
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>очистка кофемашины Соковыжималка Atlanta ATH-310  </title>
		<meta charset="UTF-8">
		<meta name="keywords" content="очистка кофемашины, пылесос thomas genius s2, где отремонтировать утюг, пароварка scarlett is 550, парогенератор пээ, самый дорогой пылесос, соковыжималка ангел, какой моющий пылесос выбрать, делонги кофемашина примадонна, пылесос mediclean, мультиварка акции, взбить сливки блендером, hyla пылесос цена, купить мультиварку в красноярске,  панасоник соковыжималка">
		<meta name="description" content="очистка кофемашины Соковыжималка Atlanta ATH-310 белого цвета мощностью 270 Вт – простой и доступны...">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		<link type="text/css" rel="stylesheet" href="css/lightbox.css">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/lightbox.min.js"></script>
		<script type="text/javascript" src="js/validator.js"></script>
		<script type="text/javascript" src="lib/lib.js"></script>
		<script type="text/javascript">
			$(function(){$('a.photo').lightBox();});

			$(document).ready(function(){
				$(".see-also ul li").hover(
				function(){$(this).children(".box").toggle();},
				function(){$(this).children(".box").toggle();})
			});
		</script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<?php require_once "header.php"; ?>			<!-- [END OF HEADER] -->
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href="photos/82af66b2cc61bc47984a0dc33b3b0565.jpeg" title="очистка кофемашины Соковыжималка Atlanta ATH-310"><img src="photos/82af66b2cc61bc47984a0dc33b3b0565.jpeg" alt="очистка кофемашины Соковыжималка Atlanta ATH-310" title="очистка кофемашины Соковыжималка Atlanta ATH-310 -  "></a>
						<ul>
							<li><a href="http://kitchentech.elitno.net/blender-redmond-rhb-2180r.php"><img src="photos/a1f8cd769afd06226b32e6fb44474c86.jpeg" alt="пылесос thomas genius s2 Блендер Redmond RHB-2908" title="пылесос thomas genius s2 Блендер Redmond RHB-2908"></a><h2>Блендер Redmond RHB-2908</h2></li>
							<li><a href="http://kitchentech.elitno.net/kuhonnyy-processor-redmond-rfp-2990r.php"><img src="photos/470cf0a1bfd5b3c4e3890030dcd4cf8d.jpeg" alt="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901" title="где отремонтировать утюг Кухонный процессор Redmond  RFP-3901"></a><h2>Кухонный процессор Redmond  RFP-3901</h2></li>
							<li><a href="http://kitchentech.elitno.net/blender-maxima-mhb-870r.php"><img src="photos/08c15d1f7a465f949f829449dc3e88eb.jpeg" alt="пароварка scarlett is 550 Блендер Maxima MHB-0429" title="пароварка scarlett is 550 Блендер Maxima MHB-0429"></a><h2>Блендер Maxima MHB-0429</h2></li>
						</ul>
					</div>
					<div class="rs">
						<h1>очистка кофемашины Соковыжималка Atlanta ATH-310</h1>
						<div class="tb"><p>Цена: от <span class="price">1050</span> руб. <a href="go.php?url=http://profit-shop.ru/shop/UID_19670.html" target="_blank"><span class="button"></span></a></p></div>
						<div class="description"><p>Соковыжималка Atlanta ATH-310 белого цвета мощностью 270 Вт – простой и доступный прибор для приготовления сока в домашних условиях. Если вас не устраивают соки в магазине и вы хотите быть уверенными в качестве того что пьете, то используйте эту электрическую соковыжималку. Она предназначена, для приготовления сока не только из цитрусовых, но также из любых фруктов и ягод.</p><p><strong>Характеристики:</strong></p><ul type=disc><li>Для всех видов фруктов <li>Мощность 270 Вт <li>Подача сока сразу в стакан <li>Корпус из пластика <li>В x Ш x Г: 290 x 230 x 190 мм <li>Тип: универсальная <li>1 скорость <li>Комплектация: загрузочный лоток <li>Прорезиненные ножки <li>Цвет: белый <li>Резиновые ножки </li></ul><p><strong>Производитель: США</strong></p> очистка кофемашины</div>
					</div>
					<div class="end"></div>
				</div>

				<?php require_once "reclame.php"; ?>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><img src="photos/01c2ca770a8a823b21cf869aea4ab4ac.jpeg" alt="парогенератор пээ Кухонный комбайн Tefal Storeinn DO2081" title="парогенератор пээ Кухонный комбайн Tefal Storeinn DO2081"><div class="box"><a href="http://kitchentech.elitno.net/kuhonnyy-kombayn-tefal-storeinn-do-3370r.php"><h3 class="title">парогенератор пээ Кухонный комбайн Tefal Storeinn DO2081</h3><p>от <span class="price">3370</span> руб.</p></a></div></li>
						<li><img src="photos/8b7adfef9e224f5e6ff3fcdd084f6869.jpeg" alt="самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook" title="самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook"><div class="box" page="multivarka-moulinex-ce-minute-cook-5850r"><span class="title">самый дорогой пылесос Мультиварка Moulinex CE4000 Minute Cook</span><p>от <span class="price">5850</span> руб.</p></div></li>
						<li><img src="photos/21689be9dc7c8e66c7cb248c7b6f5f86.jpeg" alt="соковыжималка ангел Пароварка Maxima MST-1102" title="соковыжималка ангел Пароварка Maxima MST-1102"><div class="box" page="parovarka-maxima-mst-1290r"><span class="title">соковыжималка ангел Пароварка Maxima MST-1102</span><p>от <span class="price">1290</span> руб.</p></div></li>
						<li><img src="photos/d2b0cc36c62095fdc525b7665e50506c.jpeg" alt="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321" title="какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321"><div class="box" page="sokovyzhimalka-atlanta-ath-1010r"><span class="title">какой моющий пылесос выбрать Соковыжималка Atlanta ATH-321</span><p>от <span class="price">1010</span> руб.</p></div></li>
						<li class="large"><img src="photos/46a5120709bf99f581bc7ea7569bd649.png" alt="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902" title="делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902"><div class="box" page="hlebopech-redmond-rbmm-3990r"><span class="title">делонги кофемашина примадонна Хлебопечь Redmond RBM-M1902</span><p>от <span class="price">3990</span> руб.</p></div></li>
						<li class="large"><img src="photos/4f7eae7926bb1b2816625b5940a25b78.jpeg" alt="пылесос mediclean Чайник электрический Vitek VT-1157" title="пылесос mediclean Чайник электрический Vitek VT-1157"><div class="box" page="chaynik-elektricheskiy-vitek-vt-2150r"><span class="title">пылесос mediclean Чайник электрический Vitek VT-1157</span><p>от <span class="price">2150</span> руб.</p></div></li>
						<li class="large"><img src="photos/b11b426009f0167e5ff93f5aa64ca56d.jpeg" alt="мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л" title="мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л"><div class="box" page="chaynik-elektricheskiy-tefal-vitesses-bf-l-1650r"><span class="title">мультиварка акции Чайник электрический Tefal VitesseS BF66204 1,7 л</span><p>от <span class="price">1650</span> руб.</p></div></li>
						<li><img src="photos/3a6317b1e5aa0207019da754f6c2351b.jpeg" alt="взбить сливки блендером Электрический чайник Atlanta АТН-673" title="взбить сливки блендером Электрический чайник Atlanta АТН-673"><div class="box" page="elektricheskiy-chaynik-atlanta-atn-560r"><span class="title">взбить сливки блендером Электрический чайник Atlanta АТН-673</span><p>от <span class="price">560</span> руб.</p></div></li>
						<li><img src="photos/d50a3dd0a5055f1b90b2cf35609b3ff0.jpeg" alt="hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС" title="hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС"><div class="box" page="nitrattester-nitratomer-soeks-5290r"><span class="title">hyla пылесос цена Нитрат-тестер (нитратомер) СоЭкС</span><p>от <span class="price">5290</span> руб.</p></div></li>
						<li><img src="photos/510105f381aa497ebe08b03499acd217.jpeg" alt="купить мультиварку в красноярске Пылесос Redmond RV-307" title="купить мультиварку в красноярске Пылесос Redmond RV-307"><div class="box" page="pylesos-redmond-rv-4490r"><span class="title">купить мультиварку в красноярске Пылесос Redmond RV-307</span><p>от <span class="price">4490</span> руб.</p></div></li>
						<li><img src="photos/7850ec1f7f17c681ccafb6a0e80e0aff.jpeg" alt="микроволновая печь vitek Утюг паровой Tefal Aquaspeed Ultracord FV5250" title="микроволновая печь vitek Утюг паровой Tefal Aquaspeed Ultracord FV5250"><div class="box" page="utyug-parovoy-tefal-aquaspeed-ultracord-fv-2490r"><span class="title">микроволновая печь vitek Утюг паровой Tefal Aquaspeed Ultracord FV5250</span><p>от <span class="price">2490</span> руб.</p></div></li>
			
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<?php $page = substr("sokovyzhimalka-atlanta-ath-1050r.php", 0, -4); if (file_exists("comments/sokovyzhimalka-atlanta-ath-1050r.php")) require_once "comments/sokovyzhimalka-atlanta-ath-1050r.php"; if (file_exists("$page-comments.php")) require_once "$page-comments.php";?>					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="sokovyzhimalka-atlanta-ath-1050r.php" method="post" onsubmit="return checkForm(this)">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код" <?php if(isset($error)) echo "$error"; ?>><img class="captcha" src="captcha.php" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->

			<!-- [FOOTER] -->
			 <?php require_once "footer.php"; ?>			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>