<!DOCTYPE HTML>
<html>
	<head>
		<title>Название страницы</title>
		<meta charset="UTF-8">
		<link type="text/css" rel="stylesheet" href="css/styles.css">
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
	</head>
	<body>
		<!-- [CONTAINER] -->
		<div class="container">
			<!-- [HEADER] -->
			<div class="header-wrap">
				<div class="header">
					<a href="index.php"><img src="images/header-logo.png" alt="logo"></a>
					<ul class="nav">
						<li><a href="index.php">Главная</a></li>
						<li><a href="contact.php">Контакты</a></li>
						<li><a href="about.php">О нас</a></li>
					</ul>
				</div>
			</div>
			<!-- [END OF HEADER] -->
			
			<!-- [CONTENT] -->
			<div class="content">
				<div class="product">
					<div class="ls">
						<a class="photo" href=""><img src="images/photo.jpg" alt="" title=""></a>
						<ul>
							<li><a href=""><img src="images/preview.jpg" alt="" title=""></a></li>
							<li><a href=""><img src="images/preview.jpg" alt="" title=""></a></li>
							<li><a href=""><img src="images/preview.jpg" alt="" title=""></a></li>
						</ul>
					</div>
					<div class="rs">
						<h1>Автомобильный аппарат из будущего</h1>
						<div><p>Цена: от <span class="price">81450</span> руб. <a href="" target="_blank"><span class="button"></span></a></p></div>
						<p class="description">
							<b>Артикул:</b> LiskaSK11107T<br>
							<b>Дизайн:</b> designedinRussia<br>
							<b>Сезон:</b> Демисезон<br>
							<b>Цвет:</b> Серый<br>
							<b>Внешний материал:</b> Войлок<br>
							<b>Внутренний материал:</b> Натуральнаякожа<br>
							<b>Стелька:</b> Натуральнаякожа<br>
							<b>Подошва:</b> Искусcтвенныйматериал<br>
							<b>Высотакаблука:</b> 130<br>
							<br>
							Оригинальные демисезонные ботильоны от Liska. Верх, выполненный из серого войлока, оформлен черными вставками с глухой фигурной перфорацией на мысе и заднике. Край украшен отворотом. Удобная молния расположена в области задника. Высокий каблук компенсируется платформой, декорированной войлоком и кожаными кантами с прострочкой. Внутренняя отделка исполнена из кожи.
						</p>
					</div>
					<div class="end"></div>
				</div>
				<div class="see-also">
					<h2>Похожие товары</h2>
					<ul>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a><h3 class="title">Название товара</h3><p>от<span class="price">99999</span> руб.</p></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a><span class="title">Название товара</span></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li class="large"><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li class="large"><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li class="large"><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
						<li><a href=""><img src="images/picture.jpg" alt="" title=""></a></li>
					</ul>
				</div>
				<div class="comments">
					<h2>Отзывы покупателей</h2>
					<ul>
						<li><img src="images/preview.jpg" alt=""><span>Ник 12:32</span><p>Какое то сообщение, там такой длинненький текстик написал товарищ ник, прочитав где то... Ведётся обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара</p></li>
						<li><img src="images/preview.jpg" alt=""><span>Ник 12:32</span><p>Какое то сообщение, там такой длинненький текстик написал товарищ ник, прочитав где то... Ведётся обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара</p></li>
						<li><img src="images/preview.jpg" alt=""><span>Ник 12:32</span><p>Какое то сообщение, там такой длинненький текстик написал товарищ ник, прочитав где то... Ведётся обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара</p></li>
						<li><img src="images/preview.jpg" alt=""><span>Ник 12:32</span><p>Какое то сообщение, там такой длинненький текстик написал товарищ ник, прочитав где то... Ведётся обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара</p></li>
						<li><img src="images/preview.jpg" alt=""><span>Ник 12:32</span><p>Какое то сообщение, там такой длинненький текстик написал товарищ ник, прочитав где то... Ведётся обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара обсуждение данного товара</p></li>
					</ul>
					<script>$("div.comments li:odd").css("background-color", "#1A1A1A");</script>
					<h2>Оставить отзыв</h2>
					<form action="" method="post">
						<p><textarea name="comment" placeholder="Ваше сообщение здесь"></textarea></p>
						<p><input type="text" name="author" placeholder="*Имя"><input type="text" name="captcha" placeholder="*Код"><img class="captcha" src="images/picture.jpg" alt=""><input type="submit"></p>
					</form>
				</div>
			</div>
			<!-- [END OF CONTENT] -->
		
			<!-- [FOOTER] -->
			<div class="footer">
			
				<ul class="sn">
					<li><a href="http://www.twitter.com"><img src="images/twitter.png" alt="twitter"></a></li>
					<li><a href="http://www.facebook.com"><img src="images/facebook.png" alt="facebook"></a></li>
				</ul>
				<a href="index.php"><img class="logo" src="images/footer-logo.png" alt="logo"></a>
				<script type="text/javascript">document.write("<a href='http://www.liveinternet.ru/click' "+"target=_blank><img class='li' src='//counter.yadro.ru/hit?t40.6;r"+escape(document.referrer)+((typeof(screen)=="undefined")?"":";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+";"+Math.random()+"' alt='' title='LiveInternet' "+"border='0' width='31' height='31'><\/a>")</script>
				<ul class="nav">
					<li><a href="contact.php">Контакты</a></li>
					<li><a href="privacy.php">Политика конфидециальности</a></li>
					<li><a href="terms.php">Условия использования сайтом</a></li>
				</ul>
				
			</div>
			<!-- [END OF FOOTER] -->
		</div>
		<!-- [END OF CONTAINTER] -->
	</body>
</html>